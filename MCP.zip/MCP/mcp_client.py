from mcp.client.stdio import stdio_client
from mcp import ClientSession, StdioServerParameters, types
from mcp.shared.context import RequestContext
import asyncio
import logging
import contextlib
from schema.params import TransportType


logger = logging.getLogger(__name__)

logging.basicConfig(level=logging.DEBUG)


# Optional: create a sampling callback
async def handle_sampling_message(
    context: RequestContext[ClientSession, None], params: types.CreateMessageRequestParams
) -> types.CreateMessageResult:
    print(f"Sampling request: {params.messages}")
    return types.CreateMessageResult(
        role="assistant",
        content=types.TextContent(
            type="text",
            text="Hello, world! from model",
        ),
        model="gpt-3.5-turbo",
        stopReason="endTurn",
    )



class MCPClient:
    def __init__(self):
        self.session:ClientSession = None
        self.transport = None
        self.exit_stack = contextlib.AsyncExitStack()

    async def connect(self, params):
        

        if params.transport == TransportType.STDIO: 
        # read, write = await self.transport.__aenter__()
        # self.session = ClientSession(read, write, sampling_callback=handle_sampling_message)

         # This ensures stdio streams are properly managed
        self.transport = await self.exit_stack.enter_async_context(
            stdio_client(params)
        )
        read, write = self.transport
        
        # This ensures the session background tasks start
        self.session = await self.exit_stack.enter_async_context(
            ClientSession(read, write)
        )


        print("Connected to MCP server")
        await self.session.initialize()
        print("Initialized MCP server")
        return self.session
    
    def _setup_handlers(self):
        """
        Set up notification and request handlers
        
        THIS IS CRITICAL - without handlers, initialize() blocks!
        """
        
        # Handle notifications from server
        @self.session.notification_handler
        async def handle_notification(notification):
            """Handle any notifications the server sends"""
            method = notification.method
            params = notification.params
            
            logger.debug(f"📨 Notification: {method}")
            
            # Handle specific notification types
            if method == "notifications/progress":
                token = params.get("progressToken")
                progress = params.get("progress")
                total = params.get("total")
                message = params.get("message", "")
                logger.info(f"Progress [{token}]: {progress}/{total} - {message}")
            
            elif method == "notifications/resources/updated":
                uri = params.get("uri")
                logger.info(f"Resource updated: {uri}")
            
            elif method == "notifications/resources/list_changed":
                logger.info("Resource list changed")
            
            elif method == "notifications/tools/list_changed":
                logger.info("Tools list changed")
            
            else:
                logger.debug(f"Unhandled notification: {method}")
        
        # Handle requests from server (for sampling, elicitation)
        @self.session.request_handler
        async def handle_request(request):
            """Handle requests that server sends to client"""
            method = request.method
            params = request.params
            
            logger.debug(f"📬 Request: {method}")
            
            if method == "sampling/createMessage":
                # Server wants LLM completion
                logger.warning("⚠️ Sampling request received but no handler configured")
                # You would call your LLM here
                return {
                    "model": "none",
                    "stopReason": "error",
                    "role": "assistant",
                    "content": [{"type": "text", "text": "Sampling not configured"}]
                }
            
            elif method == "elicitation/create":
                # Server wants user input
                logger.warning("⚠️ Elicitation request received but no handler configured")
                return {
                    "action": "cancel"
                }
            
            else:
                logger.warning(f"Unhandled request: {method}")
                raise Exception(f"Unhandled request type: {method}")
    
    async def list_prompts(self):
        return await self.session.list_prompts()

    async def list_tools(self):
        return await self.session.list_tools()
    
    async def disconnect(self):
        if self.exit_stack:
            await self.exit_stack.aclose()

async def main():
    client = MCPClient()
    await client.connect(
        StdioServerParameters(
            command="/Users/sujith/Tech/MCP/MCP/_venv/bin/python", 
            args=["/Users/sujith/Tech/MCP/MCP/app.py"]
        )
    )
    prompts = await client.list_prompts()
    print(prompts)
    tools = await client.list_tools()
    print(tools)
    await client.disconnect()

if __name__ == "__main__":
    asyncio.run(main())