from mcp_client import MCPClient
from typing import Any, Callable, List
from schema.params import MCPServerParams
import asyncio
from schema.params import TransportType, StreamableHttpParams
from typing import Awaitable

class MCPManager:
    def __init__(
        self,
        params: List[MCPServerParams],
        elicitation_handler: Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]] = None,
        sampling_handler: Callable[List[dict], Awaitable[str]] = None
    ):
        self.mcp_clients = []
        self.params = params
        self.elicitation_handler = elicitation_handler
        self.sampling_handler = sampling_handler
        self.tools_clients_map = {}
        self.prompts_clients_map = {}


    async def connect(self):
        for param in self.params:
            client = MCPClient()
            await client.connect(param)
            await client.setSamplingHandler(self.sampling_handler)
            await client.setElicitationHandler(self.elicitation_handler)
            self.mcp_clients.append(client)
        await self.list_prompts()
        await self.list_tools()
    

    async def list_prompts(self):
        for client in self.mcp_clients:
            prompts = await client.list_prompts()
            for prompt in prompts:
                self.prompts_clients_map[prompt.name] = client

    async def list_tools(self):
        for client in self.mcp_clients:
            tools = await client.list_tools()
            for tool in tools:
                self.tools_clients_map[tool.name] = client


    async def call_tool(self, name: str, arguments: dict[str, Any]):
        client = self.tools_clients_map[name]
        return await client.call_tool(name, arguments)


    async def disconnect(self):
        for client in self.mcp_clients:
            await client.disconnect()


async def main():
    from google import genai
    async def handle_sampling(messages: List[dict]) -> str:
        client = genai.Client(vertexai=True, location="us-central1")
        # print(f"Sampling request: {messages}")
        # Convert MCP messages to Gemini format
        gemini_contents = []
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content")

            gemini_contents.append({
                "role": "user" if role == "user" else "model",
                "parts": [{"text": content}]
            })
        
        # Call Gemini API
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=gemini_contents,
        )
        return response.text


    async def handle_elicitation(message: str, requested_schema: dict[str, Any]):
        print(f"Elicitation request: {message}")
        # Collect user input based on schema
        if requested_schema:
            properties = requested_schema['properties']
            data = {}
            for field, info in properties.items():
                value = input(f"{info.get('description', field)}: ")
                data[field] = value
            return data
        
        raise ValueError("No schema provided")



    manager = MCPManager(
        params=[
            MCPServerParams(
                transport=TransportType.STREAMABLE_HTTP,
                params=StreamableHttpParams(url="http://localhost:8000/mcp")
            )
        ],
        elicitation_handler=handle_elicitation,
        sampling_handler=handle_sampling
    )
    await manager.connect() 


    response = await manager.call_tool("get_weather", {"city": "New York"})
    print(response)
    print("\n\n -------------------------------- \n\n")
    # result = await manager.call_tool("create_user_account", {})
    # print(result)
    # print("\n\n -------------------------------- \n\n")
    result = await manager.call_tool("multi_step_research", {"topic": "The history of the universe"})
    print(result)
    print("\n\n -------------------------------- \n\n")
    await manager.disconnect()

if __name__ == "__main__":
    asyncio.run(main())