from mcp.client.stdio import stdio_client
from mcp.client.streamable_http import streamablehttp_client
from mcp import ClientSession, StdioServerParameters, types
from typing import Any, Callable, List
from mcp.shared.context import RequestContext
import asyncio
import logging
import contextlib
from schema.prompt import PromptModel, PromptArgument
from schema.tool import ToolModel, ToolInputSchema, ToolOutputSchema
from mcp.types import ElicitRequestParams, ElicitResult, CreateMessageRequestParams, CreateMessageResult, TextContent
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.WARNING)
from schema.params import TransportType
from typing import Awaitable

class MCPClient:
    def __init__(
        self,   
    ):
        self.session:ClientSession = None
        self.transport = None
        self.exit_stack = contextlib.AsyncExitStack()
        self.elicitation_handler = None
        self.sampling_handler = None

    async def setElicitationHandler(self, elicitation_handler: Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]]):
        self.elicitation_handler = elicitation_handler
    
    async def setSamplingHandler(self, sampling_handler: Callable[List[dict], Awaitable[str]]):
        self.sampling_handler = sampling_handler


    async def connect(self, params):

        if params.transport == TransportType.STDIO:
            read, write = await self.exit_stack.enter_async_context(
                stdio_client(StdioServerParameters(
                    command=params.params.command,
                    args=params.params.args,
                ))
            )

        elif params.transport == TransportType.STREAMABLE_HTTP:
            read, write, _  = await self.exit_stack.enter_async_context(
                streamablehttp_client(params.params.url)
            )


        self.session = await self.exit_stack.enter_async_context(
            ClientSession(read, write, elicitation_callback=self.handle_elicitation, sampling_callback=self.handle_sampling)
        )
        

        await self.session.initialize()
        return self.session
    

    async def handle_sampling(self,    
        requestContext: RequestContext,
        params: CreateMessageRequestParams,
    ) -> CreateMessageResult:
        """Handle sampling requests"""
        messages = params.messages

        msgs = []
        for message in messages:
            msgs.append({"role": message.role, "content": message.content.text})
        
        response = ""
        if self.sampling_handler:
            response = await self.sampling_handler(msgs)        
        
        return CreateMessageResult(role='assistant', content=TextContent(type='text', text=response), model='any')

    async def handle_elicitation(self, requestContext: RequestContext, params: ElicitRequestParams) -> ElicitResult:
        """Handle elicitation requests"""
        message = params.message
        requested_schema = params.requestedSchema
                
        if self.elicitation_handler:
            try:
                response = await self.elicitation_handler(message, requested_schema)
                return ElicitResult(action='accept', content=response)
            except Exception as e:
                logger.exception(f"Error handling elicitation {e}")
                return ElicitResult(action='decline')



        
    

    async def list_prompts(self):
        try:
            prompts = (await self.session.list_prompts()).prompts

            prompt_models = []
            for prompt in prompts:
                prompt_models.append(PromptModel(
                    name=prompt.name,
                    title=prompt.title,
                    description=prompt.description,
                    arguments=[PromptArgument(
                        name=arg.name,
                        description=arg.description,
                        required=arg.required
                    ) for arg in prompt.arguments]
                ))

            return prompt_models
        except Exception as e:
            logger.exception(f"Error listing prompts {e}")
            raise ValueError(str(e))


    async def print_prompt_list(self):
        prompts = await self.list_prompts()
        for prompt in prompts:
            print(prompt.name)
            print(prompt.description)
            print(prompt.arguments)
            print("--------------------------------")

    async def list_tools(self):
        try:
            tools = (await self.session.list_tools()).tools

            tool_models = []
            for tool in tools:
                tool_models.append(ToolModel(
                    name=tool.name,
                    title=tool.title,
                    description=tool.description,
                    inputSchema=ToolInputSchema(
                        properties=tool.inputSchema.get("properties"),
                        type=tool.inputSchema.get("type"),
                        required=tool.inputSchema.get("required")
                    ),
                    outputSchema=ToolOutputSchema(
                        properties=tool.outputSchema.get("properties"),
                        type=tool.outputSchema.get("type"),
                        required=tool.outputSchema.get("required")
                    )
                ))
            return tool_models
        except Exception as e:
            logger.exception(f"Error listing tools {e}")
            raise ValueError(str(e))
    
    async def print_tool_list(self):
        tools = await self.list_tools()
        for tool in tools:
            print(tool.name)
            print(tool.description)
            print(tool.inputSchema)
            print(tool.outputSchema)
            print("--------------------------------")

    async def call_tool(self, name: str, arguments: dict[str, Any]):
        result = await self.session.call_tool(name, arguments)
        return result.content[0].text
    
    async def disconnect(self):
        if self.exit_stack:
            await self.exit_stack.aclose()

async def main():
    from schema.params import MCPServerParams, StreamableHttpParams, StdIOParams
    client = MCPClient()
    # await client.connect(
    #     MCPServerParams(
    #         transport=TransportType.STDIO,
    #         params=StdIOParams(
    #             command="/Users/sujith/Tech/MCP/MCP/_venv/bin/python", 
    #             args=["/Users/sujith/Tech/MCP/MCP/app_stdio.py"]
    #         )
    #     )
    # )
    await client.connect(   
        MCPServerParams(
            transport=TransportType.STREAMABLE_HTTP,
            params=StreamableHttpParams(
                url="http://localhost:8000/mcp"
            )
        )
    )
    await client.print_prompt_list()
    await client.print_tool_list()
    result = await client.call_tool("get_weather", {"city": "New York"})
    print(result)
    # result = await client.call_tool("create_user_account", {})
    # print(result)
    result = await client.call_tool("multi_step_research", {"topic": "The history of the universe"})
    print(result)
    await client.disconnect()

if __name__ == "__main__":
    asyncio.run(main())