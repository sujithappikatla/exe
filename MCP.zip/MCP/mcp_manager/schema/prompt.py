from pydantic import BaseModel


class PromptArgument(BaseModel):
    name: str
    description: str | None
    required: bool | None


class PromptModel(BaseModel):
    name: str
    title: str
    description: str | None
    arguments: list[PromptArgument]