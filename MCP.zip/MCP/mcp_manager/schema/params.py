from pydantic import BaseModel
from typing import Union
from enum import Enum


class StdIOParams(BaseModel):
    command: str
    args: list[str]

class StreamableHttpParams(BaseModel):
    url: str


class TransportType(Enum):
    STDIO = "stdio"
    STREAMABLE_HTTP = "streamable-http"

class MCPServerParams(BaseModel):
    transport: TransportType
    params: Union[StdIOParams, StreamableHttpParams]