from pydantic import BaseModel
from typing import Any


class ToolInputSchema(BaseModel):
    properties: dict[str, Any]
    type: str
    required: list[str] | None = None

class ToolOutputSchema(BaseModel):
    properties: dict[str, Any]
    type: str
    required: list[str] | None = None

class ToolModel(BaseModel):
    name: str
    title: str | None
    description: str | None
    inputSchema: ToolInputSchema | None
    outputSchema: ToolOutputSchema | None