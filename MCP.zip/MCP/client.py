# client.py
from fastmcp import Client
from fastmcp.client.transports import PythonStdioTransport
from google import genai
from mcp.types import CreateMessageResult, TextContent
import asyncio
import os




async def main():
    # Create transport using FastMCP's PythonStdioTransport
    transport = PythonStdioTransport(
        script_path="/Users/sujith/Tech/MCP/MCP/app.py",
        python_cmd="/Users/sujith/Tech/MCP/MCP/_venv/bin/python"
    )
    
    # Create client with sampling support
    async with Client(
        transport,
        # Sampling handler - provide LLM access
        sampling_handler=call_llm
    ) as client:
        
        # List available tools
        tools = await client.list_tools()
        print(f"Available tools: {[t.name for t in tools]}")
        
        # Call tool that uses elicitation and sampling
        result = await client.call_tool(
            "multi_step_research",
            {"topic": "The history of the universe"}
        )
        
        print(f"\nResult: {result}")


async def call_llm(messages, params, context):
    """Handle sampling requests - call actual LLM
    
    Args:
        messages: List of SamplingMessage objects
        params: CreateMessageRequestParams with max_tokens, system_prompt, etc.
        context: RequestContext for the client session
    """
    
    client = genai.Client(vertexai=True, location="us-central1")
    
    max_tokens = params.maxTokens or 1000
    system = params.systemPrompt or ""
    
    # Convert MCP messages to Gemini format
    gemini_contents = []
    for msg in messages:
        role = msg.role
        content = msg.content
        
        # Extract text from content (TextContent, ImageContent, etc.)
        if hasattr(content, 'text'):
            text = content.text
        elif isinstance(content, str):
            text = content
        else:
            text = str(content)
        
        gemini_contents.append({
            "role": "user" if role == "user" else "model",
            "parts": [{"text": text}]
        })
    
    # Call Gemini API
    response = client.models.generate_content(
        model="gemini-2.0-flash-exp",
        contents=gemini_contents,
    )
    
    # Return result in MCP format
    return CreateMessageResult(
        model="gemini-2.0-flash-exp",
        stopReason="end_turn",
        role="assistant",
        content=TextContent(type="text", text=response.text)
    )


if __name__ == "__main__":
    asyncio.run(main())