# server_with_elicitation.py
from fastmcp import FastMCP, Context
from mcp.types import SamplingMessage, TextContent
import asyncio

mcp = FastMCP("MCP Server")

@mcp.prompt(title="Code Review")
def review_code(code: str) -> str:
    return f"Please review this code:\n\n{code}"

@mcp.tool()
async def get_weather(city: str = None, ctx: Context = None) -> str:
    """Get the weather for a given city"""
    return f"The weather in {city} is sunny"


@mcp.tool()
async def book_restaurant(
    restaurant_name: str = None,
    ctx: Context = None
) -> str:
    """Book a restaurant table - will ask for missing details"""
    
    # If restaurant name not provided, elicit it
    if not restaurant_name:
        response = await ctx.request_user_input(
            message="Which restaurant would you like to book?",
            schema={
                "type": "object",
                "properties": {
                    "restaurant_name": {
                        "type": "string",
                        "description": "Name of the restaurant"
                    }
                },
                "required": ["restaurant_name"]
            }
        )
        
        # Check user action
        if response["action"] == "accept":
            restaurant_name = response["content"]["restaurant_name"]
        elif response["action"] == "decline":
            return "Booking declined by user"
        else:  # cancel
            return "Booking cancelled"
    
    # Ask for booking details
    booking_details = await ctx.request_user_input(
        message=f"Please provide booking details for {restaurant_name}",
        schema={
            "type": "object",
            "properties": {
                "date": {
                    "type": "string",
                    "description": "Booking date (YYYY-MM-DD)"
                },
                "time": {
                    "type": "string",
                    "description": "Booking time (HH:MM)"
                },
                "guests": {
                    "type": "integer",
                    "description": "Number of guests"
                },
                "phone": {
                    "type": "string",
                    "description": "Contact phone number"
                }
            },
            "required": ["date", "time", "guests"]
        }
    )
    
    if booking_details["action"] == "accept":
        details = booking_details["content"]
        return f"""✅ Booking confirmed at {restaurant_name}
        Date: {details['date']}
        Time: {details['time']}
        Guests: {details['guests']}
        Phone: {details.get('phone', 'Not provided')}"""
    elif booking_details["action"] == "decline":
        return "Booking details declined"
    else:
        return "Booking cancelled"


from pydantic import BaseModel, Field
from typing import Optional


class BasicInfoSchema(BaseModel):
    username: str  = Field(description="Your username")
    email: str  = Field(description="Your email address")

class PreferencesSchema(BaseModel):
    newsletter: bool = Field(description="Subscribe to newsletter?")
    theme: str = Field(description="Preferred theme (light/dark)", default="light")



@mcp.tool()
async def create_user_account(ctx: Context) -> str:
    """Create a user account by collecting information step by step"""
    
    # Step 1: Basic info
    basic_info = await ctx.elicit(
        message="Let's create your account. First, basic information:",
        response_type=BasicInfoSchema
    )

    await ctx.error(f"Basic info: {basic_info}")
    
    print(f"Basic info: {basic_info}")

    if basic_info.action != "accept":
        return "----Account creation cancelled"
    
    # Step 2: Preferences
    preferences = await ctx.elicit(
        message="Now, set your preferences:",
        response_type=PreferencesSchema
    )
    
    if preferences.action != "accept":
        return "Account creation cancelled"
    
    # Create account
    user = basic_info.data
    prefs = preferences.data

    
    return f"""✅ Account created successfully!
    Username: {user.username}
    Email: {user.email}
    Newsletter: {prefs.newsletter}
    Theme: {prefs.theme}"""


@mcp.tool()
async def multi_step_research(topic: str, ctx: Context) -> str:
    """Do multi-step research using LLM sampling"""
    
    # Step 1: Get overview
    overview = await ctx.sample(
        messages=[
            SamplingMessage(
                role="user",
                content=TextContent(type="text", text=f"Provide a brief overview of: {topic}")
            )
        ],
        max_tokens=300
    )
    
    # Step 2: Get key points based on overview  
    key_points = await ctx.sample(
        messages=[
            SamplingMessage(
                role="user",
                content=TextContent(type="text", text=f"Provide a brief overview of: {topic}")
            ),
            SamplingMessage(
                role="assistant",
                content=TextContent(type="text", text=overview.text)
            ),
            SamplingMessage(
                role="user",
                content=TextContent(type="text", text="Now list the 5 most important aspects to explore further")
            )
        ],
        max_tokens=400
    )
    
    # Step 3: Deep dive
    deep_analysis = await ctx.sample(
        messages=[
            SamplingMessage(
                role="user",
                content=TextContent(type="text", text=f"Topic: {topic}\n\nOverview: {overview.text}\n\nKey points: {key_points.text}\n\nNow provide a detailed analysis covering these key points.")
            )
        ],
        max_tokens=1000,
    )
    
    return f"""# Research Report: {topic}

## Overview
{overview.text}

## Key Points
{key_points.text}

## Detailed Analysis
{deep_analysis.text}
"""



if __name__ == "__main__":
    # Run with stdio transport (for Claude Desktop, etc.)
    mcp.run(transport="streamable-http")
    
    # For HTTP/SSE transport (remote servers):
    # mcp.run(transport="sse", port=8000)