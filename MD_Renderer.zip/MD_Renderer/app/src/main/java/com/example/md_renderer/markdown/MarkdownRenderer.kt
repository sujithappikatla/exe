package com.example.md_renderer.markdown

import android.content.Context
import android.graphics.Typeface
import android.text.style.ForegroundColorSpan
import android.text.style.LineHeightSpan
import android.text.style.RelativeSizeSpan
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.AbstractMarkwonPlugin
import io.noties.markwon.Markwon
import io.noties.markwon.MarkwonVisitor
import io.noties.markwon.core.MarkwonTheme
import io.noties.markwon.ext.strikethrough.StrikethroughPlugin
import io.noties.markwon.ext.tables.TablePlugin
import io.noties.markwon.ext.tasklist.TaskListPlugin
import io.noties.markwon.html.HtmlPlugin
import org.commonmark.node.Heading
import io.noties.markwon.core.spans.LastLineSpacingSpan
import android.text.Spanned
import android.graphics.Canvas
import android.graphics.Paint
import android.text.Layout
import android.text.style.LeadingMarginSpan
import android.text.style.LineBackgroundSpan
import android.text.style.TypefaceSpan
import androidx.compose.ui.unit.dp
import androidx.core.content.res.ResourcesCompat
import org.commonmark.ext.gfm.tables.TableCell
import org.commonmark.node.BlockQuote
import org.commonmark.node.Paragraph
import org.commonmark.node.ListItem
import org.commonmark.node.FencedCodeBlock
import org.commonmark.node.BulletList
import org.commonmark.node.OrderedList
import androidx.compose.foundation.text.selection.SelectionContainer
import android.text.util.Linkify

/**
 * MarkdownRenderer.kt
 * 
 * This file contains the core functionality for rendering Markdown text in Android using the Markwon library.
 * It provides a customizable Markdown rendering solution with support for:
 * - Headings (H1-H6) with custom styling
 * - Lists (bullet and numbered) with nesting
 * - Code blocks with syntax highlighting
 * - Block quotes
 * - Custom fonts and colors
 * - Configurable spacing and margins
 */

/**
 * A Composable function that renders Markdown text with customizable styling.
 * This is the main entry point for using the Markdown renderer.
 * 
 * @param markdown The markdown text to render
 * @param style Custom styling configuration for the markdown elements (optional)
 * @param modifier Compose modifier for the rendered text (optional)
 * 
 * Example usage:
 * ```
 * MarkdownText(
 *     markdown = "# Hello\nThis is **markdown** text",
 *     style = MarkdownStyle(
 *         h1Style = HeadingStyle(fontSize = 24.sp)
 *     )
 * )
 * ```
 */
@Composable
fun MarkdownText(
    markdown: String,
    style: MarkdownStyle = MarkdownStyle(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    // Load and cache all custom fonts for better performance
    val fonts = remember {
        MarkdownFontWeight.values().associateWith { weight ->
            ResourcesCompat.getFont(context, style.fontFamily.getFontForWeight(weight))
        }
    }
    
    // Create and remember Markwon instance with custom styling
    val markwon = remember(style) {
        createMarkwon(context, style, fonts)
    }
    
    // Enable text selection for copy/paste functionality
    SelectionContainer {
        AndroidView(
            modifier = modifier,
            factory = { context ->
                android.widget.TextView(context).apply {
                    setTextColor(style.paragraphStyle.color.toArgb())
                    setLineSpacing(0f, style.lineSpacing)
                    setTextIsSelectable(true)  // Enable text selection
                    linksClickable = true      // Make links clickable
                    autoLinkMask = Linkify.WEB_URLS  // Auto-detect URLs
                }
            },
            update = { textView ->
                markwon.setMarkdown(textView, markdown)
            }
        )
    }
}

/**
 * Creates a configured Markwon instance with custom styling and plugins.
 * 
 * @param context Android context
 * @param style Custom styling configuration
 * @param fonts Map of font weights to their corresponding Typeface
 * @return Configured Markwon instance
 */
private fun createMarkwon(
    context: Context, 
    style: MarkdownStyle,
    fonts: Map<MarkdownFontWeight, Typeface?>
): Markwon {
    return Markwon.builder(context)
        .usePlugin(createStylePlugin(style, fonts))  // Custom styling plugin
        .usePlugin(TablePlugin.create(context))      // Table support
        .usePlugin(TaskListPlugin.create(context))   // Task list support
        .usePlugin(StrikethroughPlugin.create())    // Strikethrough text support
        .usePlugin(HtmlPlugin.create())             // Basic HTML support
        .build()
}

/**
 * Custom span for rendering heading underlines.
 * Draws a horizontal line under the heading text when enabled in HeadingStyle.
 * 
 * @param color Color of the underline
 * @param thickness Thickness of the underline (default: 2f)
 * @param padding Space between text and underline (default: 8f)
 */
private class HeadingDividerSpan(
    private val color: Int,
    private val thickness: Float = 2f,
    private val padding: Float = 8f
) : LineBackgroundSpan {
    override fun drawBackground(
        canvas: Canvas,
        paint: Paint,
        left: Int,
        right: Int,
        top: Int,
        baseline: Int,
        bottom: Int,
        text: CharSequence,
        start: Int,
        end: Int,
        lineNumber: Int
    ) {
        // Only draw the underline after the last line of the heading
        val isLastLine = text.getOrNull(end) == '\n' || end == text.length
        if (!isLastLine) return
        
        val originalColor = paint.color
        paint.color = color
        paint.strokeWidth = thickness
        
        // Draw the underline below the text
        val y = bottom + padding
        canvas.drawLine(left.toFloat(), y, right.toFloat(), y, paint)
        
        paint.color = originalColor
    }
}

/**
 * Creates the main styling plugin that handles the rendering of all Markdown elements.
 * This plugin configures how different Markdown elements (headings, paragraphs, lists, etc.)
 * are rendered and styled.
 * 
 * @param style Custom styling configuration
 * @param fonts Map of font weights to their corresponding Typeface
 * @return AbstractMarkwonPlugin configured with custom styling
 */
private fun createStylePlugin(
    style: MarkdownStyle,
    fonts: Map<MarkdownFontWeight, Typeface?>
) = object : AbstractMarkwonPlugin() {
    override fun configureTheme(builder: MarkwonTheme.Builder) {
        builder
            .linkColor(style.linkColor.toArgb())
            .codeBackgroundColor(style.codeBackgroundColor.toArgb())
            .blockQuoteColor(style.blockQuoteColor.toArgb())
            .blockMargin(style.blockQuoteIndent.value.toInt())
            .blockQuoteWidth(style.blockQuoteStripeWidth.value.toInt())
    }

    /**
     * Visitor configuration for different markdown elements.
     * This section configures how each type of markdown element is rendered.
     */
    override fun configureVisitor(builder: MarkwonVisitor.Builder) {
        /**
         * Heading Visitor (H1-H6)
         * Handles the rendering of all heading levels with:
         * - Custom font sizes and weights for each level
         * - Optional underline with custom color and thickness
         * - Configurable top and bottom spacing
         * - Custom line height for multi-line headings
         */
        builder.on(Heading::class.java) { visitor, heading ->
            val headingStyle = when (heading.level) {
                1 -> style.h1Style
                2 -> style.h2Style
                3 -> style.h3Style
                4 -> style.h4Style
                5 -> style.h5Style
                else -> style.h6Style
            }
            
            // Add top spacing before the heading
            visitor.builder().append("\n")
            val topSpacingStart = visitor.builder().length - 1
            val topSpacingEnd = visitor.builder().length
            visitor.builder().setSpan(
                LastLineSpacingSpan(headingStyle.topSpacing.value.toInt()),
                topSpacingStart,
                topSpacingEnd,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            
            // Get the start position for the heading content
            val start = visitor.builder().length
            
            // Visit the children first to get the content
            visitor.visitChildren(heading)
            
            // Add a newline after the heading
            visitor.builder().append("\n")
            
            // Get the end position (before newline)
            val end = visitor.builder().length - 1
            
            // Apply spans with proper range
            visitor.builder().apply {
                setSpan(RelativeSizeSpan(headingStyle.fontSize.value / style.paragraphStyle.fontSize.value), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(ForegroundColorSpan(headingStyle.color.toArgb()), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(LastLineSpacingSpan(headingStyle.bottomSpacing.value.toInt()), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                
                // Apply custom font based on weight
                fonts[headingStyle.fontWeight]?.let { font ->
                    setSpan(CustomTypefaceSpan(font), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                
                // Add divider line if enabled
                if (headingStyle.showUnderline) {
                    setSpan(
                        HeadingDividerSpan(
                            color = headingStyle.color.toArgb(),
                            thickness = 2f,
                            padding = 4f
                        ),
                        start,
                        end,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                
                // Add line height control
                setSpan(
                    LineHeightSpan.Standard(
                        (headingStyle.fontSize.value * headingStyle.lineHeight).toInt()
                    ),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }

        /**
         * Paragraph Visitor
         * Handles regular text paragraphs with:
         * - Different styling for standalone vs nested paragraphs
         * - Custom font and color
         * - Configurable spacing before and after
         * - Special handling when inside lists or blockquotes
         */
        builder.on(Paragraph::class.java) { visitor, paragraph ->
            // Check if this is a standalone paragraph
            val isStandalone = isStandaloneParagraph(paragraph)
            
            if (isStandalone) {
                // Add top spacing before the paragraph
                visitor.builder().append("\n")
                val topSpacingStart = visitor.builder().length - 1
                val topSpacingEnd = visitor.builder().length
                visitor.builder().setSpan(
                    LastLineSpacingSpan(style.paragraphStyle.topSpacing.value.toInt()),
                    topSpacingStart,
                    topSpacingEnd,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            
            // Get the start position
            val start = visitor.builder().length
            
            // Visit children first
            visitor.visitChildren(paragraph)
            
            if (isStandalone) {
                // Add a newline after the paragraph
                visitor.builder().append("\n")
            }
            
            // Get end position (before newline)
            val end = visitor.builder().length - (if (isStandalone) 1 else 0)
            
            // Apply paragraph styling
            visitor.builder().apply {
                // Apply font
                fonts[style.paragraphStyle.fontWeight]?.let { font ->
                    setSpan(CustomTypefaceSpan(font), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                
                // Apply text color
                setSpan(
                    ForegroundColorSpan(style.paragraphStyle.color.toArgb()),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                
                // Apply bottom spacing only for standalone paragraphs
                if (isStandalone) {
                    setSpan(
                        LastLineSpacingSpan(style.paragraphStyle.bottomSpacing.value.toInt()),
                        start,
                        end,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
            }
        }

        /**
         * BlockQuote Visitor
         * Renders quoted text blocks with:
         * - Vertical stripe on the left
         * - Custom background and text colors
         * - Support for nested quotes with increasing indentation
         * - Configurable spacing and margins
         */
        builder.on(BlockQuote::class.java) { visitor, blockQuote ->
            // Add top spacing
            visitor.builder().append("\n")
            val topSpacingStart = visitor.builder().length - 1
            val topSpacingEnd = visitor.builder().length
            visitor.builder().setSpan(
                LastLineSpacingSpan(style.elementSpacing.blockQuoteTopSpacing.value.toInt()),
                topSpacingStart,
                topSpacingEnd,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            // Get the start position
            val start = visitor.builder().length

            // Calculate nesting level
            var level = 0
            var parent = blockQuote.parent
            while (parent != null) {
                if (parent is BlockQuote) level++
                parent = parent.parent
            }

            // Calculate indent based on nesting level
            val indent = style.blockQuoteIndent.value * 
                Math.pow(style.blockQuoteNestedIndentMultiplier.toDouble(), level.toDouble()).toFloat()

            // Visit children first
            visitor.visitChildren(blockQuote)

            // Add bottom spacing
            visitor.builder().append("\n")
            val end = visitor.builder().length - 1

            visitor.builder().apply {
                // Apply the block quote span
                setSpan(
                    BlockQuoteSpan(
                        style.blockQuoteStripeColor.toArgb(),
                        style.blockQuoteStripeWidth.value,
                        indent,
                        style.blockQuoteColor.toArgb()
                    ),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                // Apply bottom spacing
                setSpan(
                    LastLineSpacingSpan(style.elementSpacing.blockQuoteBottomSpacing.value.toInt()),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }

        /**
         * Code Block Visitor
         * Renders code blocks with:
         * - Rounded corner background
         * - Custom background color
         * - Configurable padding and margins
         * - Custom line height for code readability
         * - Monospace font (if specified)
         */
        builder.on(FencedCodeBlock::class.java) { visitor, codeBlock ->
            // Add empty line for top spacing
            visitor.builder().append("\n".repeat(style.elementSpacing.codeBlockTopSpacing.value.toInt() / 8))
            
            // Get start position
            val start = visitor.builder().length
            
            // Add the code content
            visitor.builder().append(codeBlock.literal)
            
            // Add empty lines for bottom spacing
            visitor.builder().append("\n".repeat(style.elementSpacing.codeBlockBottomSpacing.value.toInt() / 8))
            
            val end = visitor.builder().length
            
            visitor.builder().apply {
                // Apply code block styling with padding
                setSpan(
                    CodeBlockSpan(
                        backgroundColor = style.codeBackgroundColor.toArgb(),
                        padding = style.elementSpacing.codeBlockPadding.value,
                        horizontalMargin = style.elementSpacing.codeBlockHorizontalMargin.value,
                        cornerRadius = style.elementSpacing.codeBlockCornerRadius.value,
                        topTextMargin = 16f,
                        extraTextPadding = 16f,
                        lineHeight = style.elementSpacing.codeBlockLineHeight
                    ),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }

        /**
         * List Visitor Helper
         * Common functionality for both ordered and unordered lists:
         * - Handles nested lists with increasing indentation
         * - Configures spacing between list items
         * - Manages list markers (bullets or numbers)
         * 
         * @param visitor The markdown visitor
         * @param list The list node
         * @param ordered Whether this is a numbered list
         */
        val listVisitor = { visitor: MarkwonVisitor, list: org.commonmark.node.Node, ordered: Boolean ->
            // Calculate nesting level
            var level = 0
            var parent = list.parent
            while (parent != null) {
                if (parent is BulletList || parent is OrderedList) level++
                parent = parent.parent
            }

            // Calculate indent based on nesting level
            val indent = style.elementSpacing.listIndent.value * 
                Math.pow(style.elementSpacing.listNestedIndentMultiplier.toDouble(), level.toDouble()).toFloat()

            // Add top spacing
            visitor.builder().append("\n")
            val topSpacingStart = visitor.builder().length - 1
            val topSpacingEnd = visitor.builder().length
            visitor.builder().setSpan(
                LastLineSpacingSpan(style.elementSpacing.listTopSpacing.value.toInt()),
                topSpacingStart,
                topSpacingEnd,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            // Get start position
            val start = visitor.builder().length

            // Visit children
            visitor.visitChildren(list)

            // Add bottom spacing
            visitor.builder().append("\n")
            val end = visitor.builder().length - 1

            visitor.builder().apply {
                // Apply list indentation
                setSpan(
                    ListSpan(indent, ordered),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                
                // Apply bottom spacing
                setSpan(
                    LastLineSpacingSpan(style.elementSpacing.listBottomSpacing.value.toInt()),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }

        /**
         * Bullet List Visitor
         * Handles unordered lists with bullet points
         */
        builder.on(BulletList::class.java) { visitor, list ->
            listVisitor(visitor, list, false)
        }

        /**
         * Ordered List Visitor
         * Handles numbered lists with automatic numbering
         */
        builder.on(OrderedList::class.java) { visitor, list ->
            listVisitor(visitor, list, true)
        }

        /**
         * List Item Visitor
         * Handles individual list items with:
         * - Bullet points or numbers
         * - Custom spacing between items
         * - Proper indentation
         * - Support for nested content
         */
        builder.on(ListItem::class.java) { visitor, item ->
            // Add minimal newline before list item
            visitor.builder().append("\n")
            
            // Add top spacing if specified
            if (style.elementSpacing.listItemTopSpacing > 0.dp) {
                val topSpacingStart = visitor.builder().length - 1
                val topSpacingEnd = visitor.builder().length
                visitor.builder().setSpan(
                    LastLineSpacingSpan(style.elementSpacing.listItemTopSpacing.value.toInt()),
                    topSpacingStart,
                    topSpacingEnd,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            
            val start = visitor.builder().length
            
            // Add bullet or number
            if (item.parent is BulletList) {
                visitor.builder().append("• ")
            } else if (item.parent is OrderedList) {
                var count = 1
                var prev = item.previous
                while (prev != null) {
                    count++
                    prev = prev.previous
                }
                visitor.builder().append("$count. ")
            }
            
            visitor.visitChildren(item)
            
            // Add minimal newline after list item
            visitor.builder().append("\n")
            
            // Add bottom spacing if specified
            if (style.elementSpacing.listItemBottomSpacing > 0.dp) {
                val bottomSpacingStart = visitor.builder().length - 1
                val bottomSpacingEnd = visitor.builder().length
                visitor.builder().setSpan(
                    LastLineSpacingSpan(style.elementSpacing.listItemBottomSpacing.value.toInt()),
                    bottomSpacingStart,
                    bottomSpacingEnd,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            
            val end = visitor.builder().length - 1

            // Apply list item spacing only if it's not the last item
            if (item.next != null) {
                visitor.builder().setSpan(
                    LastLineSpacingSpan(style.elementSpacing.listItemSpacing.value.toInt()),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
    }

    /**
     * Helper function to determine if a paragraph should be treated as standalone.
     * Standalone paragraphs receive different spacing treatment than nested ones.
     * 
     * @param paragraph The paragraph node to check
     * @return true if the paragraph is standalone, false if nested in another element
     */
    private fun isStandaloneParagraph(paragraph: Paragraph): Boolean {
        val parent = paragraph.parent
        return when {
            parent is ListItem -> false     // Inside a list item
            parent is TableCell -> false    // Inside a table cell
            parent is BlockQuote -> false   // Inside a block quote
            else -> true                    // Standalone paragraph
        }
    }
}

/**
 * Custom span for handling code blocks with advanced styling features.
 * Provides rounded corners, background color, margins, and line height control.
 * 
 * @param backgroundColor Color of the code block background
 * @param padding Internal padding of the code block
 * @param horizontalMargin Space from screen edges
 * @param cornerRadius Radius for rounded corners
 * @param topTextMargin Space above the first line of text
 * @param extraTextPadding Additional text padding from left
 * @param lineHeight Line spacing multiplier for code text
 */
private class CodeBlockSpan(
    private val backgroundColor: Int,
    private val padding: Float = 16f,
    private val horizontalMargin: Float = 16f,
    private val cornerRadius: Float = 8f,
    private val topTextMargin: Float = 16f,
    private val extraTextPadding: Float = 16f,
    private val lineHeight: Float = 1.2f
) : LineBackgroundSpan, LineHeightSpan, LeadingMarginSpan {
    
    override fun getLeadingMargin(first: Boolean): Int {
        return (horizontalMargin + extraTextPadding).toInt()
    }

    override fun drawLeadingMargin(
        canvas: Canvas,
        paint: Paint,
        x: Int,
        dir: Int,
        top: Int,
        baseline: Int,
        bottom: Int,
        text: CharSequence,
        start: Int,
        end: Int,
        first: Boolean,
        layout: Layout
    ) {
        // No need to draw anything here as we're just using it for margin
    }

    override fun drawBackground(
        canvas: Canvas, 
        paint: Paint, 
        left: Int, 
        right: Int, 
        top: Int, 
        baseline: Int, 
        bottom: Int,
        text: CharSequence, 
        start: Int, 
        end: Int, 
        lineNumber: Int
    ) {
        val originalColor = paint.color
        val originalStyle = paint.style
        
        paint.color = backgroundColor
        paint.style = Paint.Style.FILL
        
        // Draw background with rounded corners and horizontal margins
        canvas.drawRoundRect(
            left.toFloat() - padding + horizontalMargin,  // Add margin from left
            top.toFloat(),
            right.toFloat() + padding - horizontalMargin, // Add margin from right
            bottom.toFloat(),
            cornerRadius,
            cornerRadius,
            paint
        )
        
        paint.color = originalColor
        paint.style = originalStyle
    }

    override fun chooseHeight(
        text: CharSequence,
        start: Int,
        end: Int,
        spanstartv: Int,
        lineHeight: Int,
        fm: Paint.FontMetricsInt
    ) {
        // Calculate the new line height based on the base height
        val baseHeight = fm.descent - fm.ascent
        val newHeight = (baseHeight * this.lineHeight).toInt()
        
        // Adjust line metrics
        val adjustment = (newHeight - baseHeight) / 2
        fm.descent += adjustment
        fm.ascent -= adjustment
        
        // Add top margin only for first line
        if (isFirstLine(text, start)) {
            fm.ascent -= topTextMargin.toInt()
            fm.top = fm.ascent
        }
    }

    private fun isFirstLine(text: CharSequence, start: Int): Boolean {
        return start == 0 || text.getOrNull(start - 1) == '\n'
    }

    private fun isLastLine(text: CharSequence, end: Int): Boolean {
        return end == text.length || text.getOrNull(end) == '\n'
    }
}

/**
 * Custom span for block quotes that handles both the vertical stripe and text color.
 * Supports nested block quotes with configurable indentation.
 * 
 * @param stripeColor Color of the vertical stripe
 * @param stripeWidth Width of the vertical stripe
 * @param indent Space from the left margin
 * @param textColor Color of the quoted text
 */
private class BlockQuoteSpan(
    private val stripeColor: Int,
    private val stripeWidth: Float,
    private val indent: Float,
    private val textColor: Int
) : LeadingMarginSpan, android.text.style.ForegroundColorSpan(textColor) {
    
    override fun getLeadingMargin(first: Boolean): Int = indent.toInt()

    override fun drawLeadingMargin(
        canvas: Canvas,
        paint: Paint,
        x: Int,
        dir: Int,
        top: Int,
        baseline: Int,
        bottom: Int,
        text: CharSequence,
        start: Int,
        end: Int,
        first: Boolean,
        layout: Layout
    ) {
        val originalColor = paint.color
        val originalStyle = paint.style
        
        // Draw the vertical stripe
        paint.style = Paint.Style.FILL
        paint.color = stripeColor
        
        val stripeX = x.toFloat() + (indent - stripeWidth)
        canvas.drawRect(
            stripeX,
            top.toFloat(),
            stripeX + stripeWidth,
            bottom.toFloat(),
            paint
        )
        
        // Restore original paint properties
        paint.color = originalColor
        paint.style = originalStyle
    }
}

/**
 * Custom span for applying custom fonts to text.
 * Extends TypefaceSpan to support custom Typeface objects.
 * 
 * @param typeface The custom font to apply
 */
private class CustomTypefaceSpan(private val typeface: Typeface) : TypefaceSpan("") {
    override fun updateDrawState(ds: android.text.TextPaint) {
        ds.typeface = typeface
    }

    override fun updateMeasureState(paint: android.text.TextPaint) {
        paint.typeface = typeface
    }
}

/**
 * Custom span for handling list indentation and markers.
 * Supports both ordered (numbered) and unordered (bullet) lists.
 * 
 * @param indent Space from the left margin
 * @param ordered Whether this is a numbered list
 */
private class ListSpan(
    private val indent: Float,
    private val ordered: Boolean
) : LeadingMarginSpan {
    override fun getLeadingMargin(first: Boolean): Int = indent.toInt()
    
    override fun drawLeadingMargin(canvas: Canvas, paint: Paint, x: Int, dir: Int,
                                 top: Int, baseline: Int, bottom: Int,
                                 text: CharSequence, start: Int, end: Int,
                                 first: Boolean, layout: Layout) {
        if (first && ordered) {
            // Draw bullet point or number
            // Implementation depends on your needs
        }
    }
} 