package com.example.md_renderer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.md_renderer.ui.theme.MD_RendererTheme
import com.example.md_renderer.markdown.MarkdownStyle
import com.example.md_renderer.markdown.MarkdownText
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.md_renderer.markdown.HeadingStyle
import com.example.md_renderer.markdown.ParagraphStyle
import com.example.md_renderer.markdown.MarkdownFontFamily
import android.content.res.Resources
import com.example.md_renderer.markdown.MarkdownFontWeight
import com.example.md_renderer.markdown.ElementSpacing

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MD_RendererTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val customStyle = MarkdownStyle(
                        fontFamily = MarkdownFontFamily(),
                        h1Style = HeadingStyle(
                            fontSize = 28.sp,
                            fontWeight = MarkdownFontWeight.BOLD,
                            bottomSpacing = 0.dp,
                            topSpacing = 4.dp,
                            showUnderline = true,
                            color = Color.DarkGray,
                            lineHeight = 1.5f
                        ),
                        h2Style = HeadingStyle(
                            fontSize = 24.sp,
                            fontWeight = MarkdownFontWeight.SEMIBOLD,
                            bottomSpacing = -10.dp,
                            topSpacing = 0.dp,
                            lineHeight = 1.3f
                        ),
                        paragraphStyle = ParagraphStyle(
                            fontSize = 16.sp,
                            fontWeight = MarkdownFontWeight.REGULAR,
                            bottomSpacing = 20.dp,
                            color = Color.DarkGray
                        ),
                        elementSpacing = ElementSpacing(
                            listItemSpacing = 2.dp,
                            listItemTopSpacing = 0.dp,
                            listItemBottomSpacing = 0.dp,
                            blockQuoteTopSpacing = 16.dp,
                            blockQuoteBottomSpacing = 16.dp,
                            codeBlockLineHeight = 1.0f
                        )
                    )
                    
                    val markdownText = """# The Stokes' Theorem: A Deep Dive into Vector Calculus

Stokes' Theorem is a powerful generalization of the Fundamental Theorem of Calculus to higher dimensions.  It connects a line integral around a closed curve to a surface integral over a surface bounded by that curve.  This connection reveals profound relationships between vector fields and their behavior on surfaces.

## I.  The Theorem: A Precise Statement

Let's begin with a precise mathematical statement of Stokes' Theorem:

Let *S* be an oriented, piecewise-smooth surface that is bounded by a simple, closed, piecewise-smooth boundary curve *C* with positive orientation.  Let **F** be a vector field whose components have continuous partial derivatives on an open region in  ℝ³ containing *S*.  Then:

∮<sub>C</sub> **F** ⋅ d**r** = ∬<sub>S</sub> (∇ × **F**) ⋅ d**S**

Where:

* **∮<sub>C</sub> F ⋅ dr** is the line integral of **F** around the curve *C*.  This represents the work done by the vector field **F** along the curve *C*.
* **∬<sub>S</sub> (∇ × F) ⋅ dS** is the surface integral of the curl of **F** over the surface *S*.  This represents the flux of the curl of **F** through the surface *S*.
* **∇ × F** denotes the curl of the vector field **F**.  The curl measures the rotation of the vector field at each point.
* d**r** and d**S** represent the infinitesimal line element and surface element, respectively, with appropriate orientations.  The orientations of *C* and *S* must be consistent (right-hand rule).


## II.  Understanding the Components

Let's break down the key elements of the theorem:

* **Vector Field (F):**  A vector field assigns a vector to each point in space.  Think of wind velocity, where at each location, you have a vector representing the wind's speed and direction.
* **Curl (∇ × F):** The curl of a vector field is a vector quantity that measures the rotation or circulation of the field at a point.  A high curl indicates significant rotation.
* **Line Integral (∮<sub>C</sub> F ⋅ dr):** This integral measures the work done by the vector field along a curve.  It's the sum of the dot products of the vector field and the infinitesimal displacement along the curve.
* **Surface Integral (∬<sub>S</sub> (∇ × F) ⋅ dS):**  This integral measures the flux of the curl of the vector field through the surface.  Flux represents the amount of the vector field passing through the surface.
* **Orientation:** The orientation of the surface and curve is crucial.  The right-hand rule determines the correct orientation: if you curl the fingers of your right hand in the direction of the boundary curve *C*, your thumb should point in the direction of the normal vector to the surface *S*.


## III.  Significance and Applications

Stokes' Theorem has profound implications:

* **Equivalence of Line and Surface Integrals:**  It provides a powerful relationship between line integrals (1D) and surface integrals (2D), allowing for computations to be simplified depending on the context.
* **Physical Interpretations:**  It has direct applications in physics, especially in fluid dynamics and electromagnetism, relating circulation and vorticity.  For example, it can be used to relate the circulation of a fluid around a closed curve to the vorticity (rotation) within the enclosed surface.
* **Simplification of Calculations:**  Often, calculating a surface integral is easier than a line integral, or vice-versa.  Stokes' Theorem allows us to choose the more convenient calculation based on the specific problem.
* **Generalized to Higher Dimensions:**  Stokes' Theorem is a special case of a more general theorem in differential geometry known as the generalized Stokes' theorem.


## IV.  Example

Consider a vector field **F** = (y, -x, 0) and a surface *S* that is the portion of the paraboloid z = x² + y² below the plane z = 1.  Calculating the line integral directly can be challenging, but using Stokes' Theorem and computing the surface integral of the curl (∇ × **F**) can significantly simplify the calculation.  (The curl would be (0, 0, -2) in this case).


## V.  Conclusion

Stokes' Theorem is a powerful and elegant result in vector calculus, revealing deep connections between line and surface integrals.  Its applications extend across numerous fields, offering both theoretical insight and practical computational advantages.  Understanding its components, significance, and applications is vital for anyone working in vector calculus and its applications.

                     """.trimIndent()

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White)
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    )
                    {
                        MarkdownText(
                            markdown = markdownText,
                            style = MarkdownStyle(),
                            modifier = Modifier.padding(innerPadding)
                        )
                    }


                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MD_RendererTheme {
        Greeting("Android")
    }
}