package com.example.md_renderer.markdown

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.text.style.UnderlineSpan
import com.example.md_renderer.R

/**
 * MarkdownStyle.kt
 * 
 * This file contains all styling configurations for the Markdown renderer.
 * It provides a comprehensive styling system that allows customization of:
 * - Font families and weights
 * - Text colors and sizes
 * - Spacing and margins
 * - Element-specific styling (headings, lists, code blocks, etc.)
 */

/**
 * Enum class that defines all available font weights with their corresponding font resource.
 * Each weight maps to a specific font file in the resources.
 * 
 * Usage:
 * - THIN: For very light text
 * - REGULAR: For normal text
 * - SEMIBOLD: For medium emphasis
 * - BOLD: For strong emphasis
 * Each weight also has an italic variant
 */
enum class MarkdownFontWeight {
    THIN,
    THIN_ITALIC,
    REGULAR,
    REGULAR_ITALIC,
    SEMIBOLD,
    SEMIBOLD_ITALIC,
    BOLD,
    BOLD_ITALIC
}

/**
 * Configuration class for font resources used in markdown rendering.
 * Maps each font weight to its corresponding resource ID.
 * 
 * @property thin Resource ID for thin font
 * @property thinItalic Resource ID for thin italic font
 * @property regular Resource ID for regular font
 * @property regularItalic Resource ID for regular italic font
 * @property semiBold Resource ID for semi-bold font
 * @property semiBoldItalic Resource ID for semi-bold italic font
 * @property bold Resource ID for bold font
 * @property boldItalic Resource ID for bold italic font
 */
data class MarkdownFontFamily(
    val thin: Int = R.font.roboto_thin,
    val thinItalic: Int = R.font.roboto_thin_italic,
    val regular: Int = R.font.roboto_regular,
    val regularItalic: Int = R.font.roboto_regular_italic,
    val semiBold: Int = R.font.roboto_medium,
    val semiBoldItalic: Int = R.font.roboto_medium_italic,
    val bold: Int = R.font.roboto_bold,
    val boldItalic: Int = R.font.roboto_bold_italic
) {
    /**
     * Gets the font resource ID for a specific weight.
     * @param weight The desired font weight
     * @return Resource ID for the corresponding font
     */
    fun getFontForWeight(weight: MarkdownFontWeight): Int {
        return when (weight) {
            MarkdownFontWeight.THIN -> thin
            MarkdownFontWeight.THIN_ITALIC -> thinItalic
            MarkdownFontWeight.REGULAR -> regular
            MarkdownFontWeight.REGULAR_ITALIC -> regularItalic
            MarkdownFontWeight.SEMIBOLD -> semiBold
            MarkdownFontWeight.SEMIBOLD_ITALIC -> semiBoldItalic
            MarkdownFontWeight.BOLD -> bold
            MarkdownFontWeight.BOLD_ITALIC -> boldItalic
        }
    }
}

/**
 * Main styling configuration for markdown rendering.
 * Provides comprehensive control over all aspects of markdown appearance.
 * 
 * @property fontFamily Font configuration for all text elements
 * @property lineSpacing Global line spacing multiplier
 * @property linkColor Color for hyperlinks
 * @property elementSpacing Spacing configuration for different elements
 * @property codeBackgroundColor Background color for code blocks
 * @property blockQuoteColor Text color for block quotes
 * @property blockQuoteStripeColor Color of the vertical stripe in block quotes
 * @property blockQuoteStripeWidth Width of the block quote stripe
 * @property blockQuoteIndent Indentation for block quotes
 * @property blockQuoteNestedIndentMultiplier Multiplier for nested quote indentation
 * @property h1Style through h6Style Styling for different heading levels
 * @property paragraphStyle Styling for regular paragraphs
 */
data class MarkdownStyle(
    // Font configuration
    val fontFamily: MarkdownFontFamily = MarkdownFontFamily(),
    
    // Common text styles
    val lineSpacing: Float = 1.3f,
    val linkColor: Color = Color.Blue,
    
    // Common spacing
    val elementSpacing: ElementSpacing = ElementSpacing(),
    
    // Code styles
    val codeBackgroundColor: Color = Color.LightGray.copy(alpha = 0.4f),
    
    // Block quote styles
    val blockQuoteColor: Color = Color.DarkGray.copy(alpha = 0.7f),
    val blockQuoteStripeColor: Color = Color.LightGray.copy(alpha = 0.7f),
    val blockQuoteStripeWidth: Dp = 5.dp,
    val blockQuoteIndent: Dp = 24.dp,
    val blockQuoteNestedIndentMultiplier: Float = 1.5f,
    
    // Heading Styles
    val h1Style: HeadingStyle = HeadingStyle(
        fontSize = 28.sp,
        fontWeight = MarkdownFontWeight.BOLD,
        bottomSpacing = 0.dp,
        topSpacing = 4.dp,
        showUnderline = true,
        color = Color.DarkGray
    ),
    val h2Style: HeadingStyle = HeadingStyle(
        fontSize = 22.sp,
        fontWeight = MarkdownFontWeight.SEMIBOLD,
        bottomSpacing = -10.dp,
        topSpacing = 0.dp
    ),
    val h3Style: HeadingStyle = HeadingStyle(
        fontSize = 20.sp,
        fontWeight = MarkdownFontWeight.SEMIBOLD,
        bottomSpacing = -10.dp,
        topSpacing = 0.dp
    ),
    val h4Style: HeadingStyle = HeadingStyle(
        fontSize = 18.sp,
        fontWeight = MarkdownFontWeight.SEMIBOLD,
        bottomSpacing = 0.dp,
        topSpacing = 0.dp
    ),
    val h5Style: HeadingStyle = HeadingStyle(
        fontSize = 16.sp,
        fontWeight = MarkdownFontWeight.REGULAR,
        bottomSpacing = 0.dp,
        topSpacing = 0.dp
    ),
    val h6Style: HeadingStyle = HeadingStyle(
        fontSize = 14.sp,
        fontWeight = MarkdownFontWeight.REGULAR,
        bottomSpacing = 0.dp,
        topSpacing = 0.dp
    ),
    
    // Paragraph Style
    val paragraphStyle: ParagraphStyle = ParagraphStyle(
        fontSize = 16.sp,
        fontWeight = MarkdownFontWeight.REGULAR,
        bottomSpacing = 0.dp,
        topSpacing = 0.dp,
        color = Color.Black
    )
)

/**
 * Styling configuration for headings.
 * Controls the appearance of H1-H6 elements.
 * 
 * @property fontSize Size of the heading text
 * @property fontWeight Font weight (normal, bold, etc.)
 * @property bottomSpacing Space after the heading
 * @property topSpacing Space before the heading
 * @property color Text color
 * @property showUnderline Whether to show an underline
 * @property lineHeight Line height multiplier for multi-line headings
 */
data class HeadingStyle(
    val fontSize: TextUnit,
    val fontWeight: MarkdownFontWeight = MarkdownFontWeight.REGULAR,
    val bottomSpacing: Dp,
    val topSpacing: Dp = 0.dp,
    val color: Color = Color.Black,
    val showUnderline: Boolean = false,
    val lineHeight: Float = 1.3f  // Add line height multiplier
)

/**
 * Styling configuration for paragraphs.
 * Controls the appearance of regular text blocks.
 * 
 * @property fontSize Size of paragraph text
 * @property fontWeight Font weight for paragraph text
 * @property bottomSpacing Space after the paragraph
 * @property topSpacing Space before the paragraph
 * @property color Text color
 */
data class ParagraphStyle(
    val fontSize: TextUnit,
    val fontWeight: MarkdownFontWeight = MarkdownFontWeight.REGULAR,
    val bottomSpacing: Dp,
    val topSpacing: Dp = 0.dp,
    val color: Color
)

/**
 * Spacing configuration for different markdown elements.
 * Provides fine-grained control over spacing and margins.
 * 
 * Code Block Properties:
 * @property codeBlockTopSpacing Space before code blocks
 * @property codeBlockBottomSpacing Space after code blocks
 * @property codeBlockPadding Internal padding in code blocks
 * @property codeBlockHorizontalMargin Horizontal margins for code blocks
 * @property codeBlockCornerRadius Corner radius for code blocks
 * @property codeBlockLineHeight Line height multiplier for code text
 * 
 * List Properties:
 * @property listTopSpacing Space before lists
 * @property listBottomSpacing Space after lists
 * @property listItemSpacing Space between list items
 * @property listItemTopSpacing Additional space before each item
 * @property listItemBottomSpacing Additional space after each item
 * @property listIndent Base indentation for lists
 * @property listNestedIndentMultiplier Multiplier for nested list indentation
 * 
 * Block Quote Properties:
 * @property blockQuoteTopSpacing Space before block quotes
 * @property blockQuoteBottomSpacing Space after block quotes
 */
data class ElementSpacing(
    // Code block spacing
    val codeBlockTopSpacing: Dp = 8.dp,
    val codeBlockBottomSpacing: Dp = 2.dp,
    val codeBlockPadding: Dp = 0.dp,
    val codeBlockHorizontalMargin: Dp = 16.dp,
    val codeBlockCornerRadius: Dp = 8.dp,
    val codeBlockLineHeight: Float = 0.75f,  // Add line height control for code blocks
    
    // List spacing
    val listTopSpacing: Dp = -30.dp,
    val listBottomSpacing: Dp = -20.dp,
    val listItemSpacing: Dp = -25.dp,
    val listItemTopSpacing: Dp = 0.dp,
    val listItemBottomSpacing: Dp = 0.dp,
    
    // Blockquote spacing
    val blockQuoteTopSpacing: Dp = 4.dp,    // Space before blockquote
    val blockQuoteBottomSpacing: Dp = 4.dp, // Space after blockquote
    
    // Nested list indentation
    val listIndent: Dp = 30.dp,
    val listNestedIndentMultiplier: Float = 1.2f
) 