package com.ska.nav3

import android.util.Log
import android.widget.Space
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.ui.NavDisplay
import kotlinx.serialization.Serializable

@Serializable
data class Screen1Key(
    val name: String
) : NavKey

@Serializable
data object Screen2Key: NavKey

@Serializable
data object Screen3Key : NavKey

@Serializable
data object Screen4Key : NavKey


@Composable
fun ComplexNavigation() {
    val navBackStack = rememberNavBackStack(Screen1Key("Test"))

    val currentScreen by remember {
        derivedStateOf { navBackStack.lastOrNull() }
    }

    val showBFullScreen = when (currentScreen) {
        Screen4Key  -> true
        else -> false
    }

    val leftBoxWeight by animateFloatAsState(
        targetValue = if (!showBFullScreen) 0.4f else 0.001f,
        label = "weightAnim"
    )

    LaunchedEffect(showBFullScreen) {
        Log.d("Navigation", showBFullScreen.toString())
    }


    Box(
        modifier = Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {

        Row {
//            AnimatedVisibility(
//                visible = !showBFullScreen,
//                // Enter: Starts at -100% width (completely to the left) and moves to 0
//                enter = slideInHorizontally(
//                    initialOffsetX = { fullWidth -> -fullWidth }
//                ),
//                // Exit: Starts at 0 and moves to +100% width (completely to the right)
//                exit = slideOutHorizontally(
//                    targetOffsetX = { fullWidth -> fullWidth }
//                )
//            ) {
            if (leftBoxWeight > 0.01f) {
                Box(
                    modifier = Modifier.fillMaxHeight()
                        .fillMaxWidth(leftBoxWeight)
                        .background( MaterialTheme.colorScheme.background)
                        .padding(8.dp)
                ) {

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "Screen1",
                            modifier = Modifier.fillMaxWidth()
                                .clickable{
                                    navBackStack.add(Screen1Key("New Test"))
                                }
                                .padding(16.dp),
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            "Screen2",
                            modifier = Modifier.fillMaxWidth()
                                .clickable{
                                    navBackStack.add(Screen2Key)
                                }
                                .padding(16.dp),
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            "Screen3",
                            modifier = Modifier.fillMaxWidth()
                                .clickable{
                                    navBackStack.add(Screen3Key)
                                }
                                .padding(16.dp),
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center
                        )

                    }
                }
            }



            Box(
                modifier = Modifier.fillMaxHeight()
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.secondary)
            ) {
                NavDisplay(
                    backStack = navBackStack,
                    onBack = {
                        navBackStack.removeLastOrNull()
                    },
                    entryProvider = entryProvider {
                        entry<Screen1Key> {
                            Screen1(it.name) {
                                navBackStack.add(Screen4Key)
                            }
                        }
                        entry<Screen2Key> {
                            Screen2()
                        }
                        entry<Screen3Key> {
                            Screen3()
                        }
                        entry<Screen4Key> {
                            Screen4()
                        }
                    }

                )
            }

        }
    }
}


@Composable
fun Screen1(name: String, onScreen4:()-> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Screen1 : $name",
            color = MaterialTheme.colorScheme.onSecondary,
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "Go to Screen 4",
            color = MaterialTheme.colorScheme.onSecondary,
            modifier = Modifier.clickable{
                onScreen4()
            }
        )
    }
}

@Composable
fun Screen2() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Screen2",
            color = MaterialTheme.colorScheme.onSecondary
        )
    }
}

@Composable
fun Screen3() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Screen3",
            color = MaterialTheme.colorScheme.onSecondary
        )
    }
}

@Composable
fun Screen4() {
    Box(
        modifier = Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.tertiary),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Screen3",
            color = MaterialTheme.colorScheme.onTertiary
        )
    }
}