package com.ska.nav3

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.ui.NavDisplay
import kotlinx.serialization.Serializable


@Serializable
data object Home : NavKey

@Serializable
data object About : NavKey

@Serializable
data class Products(
    val name: String
) : NavKey


@Composable
fun BasicNavigation() {
    val navBackStack = rememberNavBackStack(Home)

    Box(
        modifier = Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        NavDisplay(
            backStack = navBackStack,
            onBack = {navBackStack.removeLastOrNull()},
            entryProvider = entryProvider {
                entry<Home> {
                    HomeScreen(
                        onNavigateToAbout = { navBackStack.add(About) },
                        onNavigateToProducts = { navBackStack.add(Products("Umbrella")) }
                    )
                }
                entry<About> {
                    AboutScreen()
                }
                entry<Products> {
                    ProductsScreen(it.name)
                }
            }
        )
    }





}

@Composable
fun HomeScreen(onNavigateToAbout: () -> Boolean, onNavigateToProducts: () -> Boolean) {
    Box(
        modifier = Modifier.fillMaxSize()
            .padding(5.dp),
        contentAlignment = Alignment.Center
    ) {
        Column {
            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onNavigateToProducts() }
                    .background(MaterialTheme.colorScheme.primary)
                    .border(1.dp, MaterialTheme.colorScheme.secondary)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ){
                Text(
                    "Products",
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onNavigateToAbout() }
                    .background(MaterialTheme.colorScheme.primary)
                    .border(1.dp, MaterialTheme.colorScheme.secondary)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ){
                Text(
                    "About",
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

@Composable
fun ProductsScreen(name: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Products : $name",
            color = MaterialTheme.colorScheme.onBackground
        )

    }
}

@Composable
fun AboutScreen() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "About",
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}