package com.example.od_ai

data class STATS(
    val total_time:String,
    val ttft:String,
    val tokens_per_second:String,
    val number_of_tokens:Int
)
