package com.example.od_ai.ui.chat

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.od_ai.AppVM
import dev.jeziellago.compose.markdowntext.MarkdownText


val LOGTAG = "ChatComponent"

@Composable
fun ChatComponent(appVM: AppVM = viewModel())
{

    var inputMsg by remember { mutableStateOf("") }

    val onInputMsgChange = { msg:String ->
        inputMsg = msg
    }

    val cxt = LocalContext.current

    Box(
        modifier = Modifier.fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF232323), Color(0xFF000000)),
                    start = Offset(0f, 0f),       // top left
                    end = Offset(1600f, 1000f)   // bottom right (example)
                )
            )

    )
    {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.fillMaxWidth()
                    .weight(1f)
            )
            {
                ChatArea(
                    appVM
                )
            }
            Box(
                modifier = Modifier.fillMaxWidth()
                    .height(120.dp)
            )
            {
                ChatInput(
                    inputMsg,
                    onInputMsgChange
                ){
                    Log.i(LOGTAG, "Send Clicked, InputMsg : $inputMsg")
                    appVM.runInference(cxt, inputMsg)
                    inputMsg = ""
                }
            }

        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatInput(inputMsg: String,
              onInputMsgChange: (String) -> Unit,
              onSendClick: () -> Unit)
{

    val brush = remember {
        Brush.linearGradient(
            colors = listOf(Color(0xFFFFCCCC), Color(0xFFAACCAA), Color(0xFF9999BB)
            )
        )
    }

    Row(
      modifier = Modifier
          .fillMaxWidth()
          .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    )
    {
        TextField(
            value = inputMsg,
            onValueChange = onInputMsgChange,
            placeholder = { Text("Type a message...") },
            singleLine = false,
            keyboardActions = KeyboardActions(onSend = { onSendClick() }),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            colors = TextFieldDefaults.textFieldColors(
                cursorColor = Color.White,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                containerColor = Color(0xFF333333),

            ),
            shape = RoundedCornerShape(8.dp),
            textStyle = TextStyle(
                brush = brush,
                fontSize = 18.sp
            ),
            modifier = Modifier.border(0.1.dp, brush, RoundedCornerShape(8.dp))
                .weight(1f)
        )

        Spacer(modifier = Modifier.width(2.dp))
        IconButton(onClick = onSendClick) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = "Send",
                tint = Color.Unspecified, // Don't use a solid tint!
                modifier = Modifier
                    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                    .drawWithContent {
                        drawContent()
                        drawRect(brush, blendMode = BlendMode.SrcIn)
                    }
                    .size(34.dp)
            )
        }
    }

}



@Composable
fun ChatArea(appVM: AppVM)
{
    val aiMessage = appVM.aiMessage.collectAsState().value
    val stats = appVM.stats.collectAsState().value
    val brush = remember {
        Brush.linearGradient(
            colors = listOf(Color(0xFFFFCCCC), Color(0xFFAACCAA), Color(0xFF9999BB)
            )
        )
    }


    Box(
        modifier = Modifier
            .padding(8.dp, 64.dp,8.dp, 8.dp)
    )
    {
        LazyColumn {
            item{
                MarkdownText(
                    markdown = aiMessage,
                    style = TextStyle(
                        fontSize = 16.sp,
                        color = Color(0xFFCCCCCC)
                    ),
                )
            }
            if(stats != null)
            {
                item{
                    Text(
                        "TTFT : ${stats.ttft} \n# of Tokens : ${stats.number_of_tokens} \nTotal Time : ${stats.total_time} \nTokens/sec : ${stats.tokens_per_second}",
                        style = TextStyle(
                            fontSize = 14.sp,
                            color = Color(0xFFAAAAAA),
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

        }

    }

}

