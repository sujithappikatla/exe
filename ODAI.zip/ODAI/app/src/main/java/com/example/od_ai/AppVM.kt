package com.example.od_ai

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.ProgressListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch





class AppVM :ViewModel() {

    val LOGTAG = "AppVM"
    var llmInference:LlmInference? = null


    private val _aiMessage = MutableStateFlow<String>("")
    val aiMessage:StateFlow<String> = _aiMessage

    private val _stats = MutableStateFlow<STATS?>(null)
    val stats:StateFlow<STATS?> = _stats

    private fun initInferenceAPI(cxt: Context)
    {

        Log.e(LOGTAG, "Loading LLM Inference Model")

        val taskOptions = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/llm/gemma3-1b-it-int4.task") // Specify your model's path
            .setMaxTopK(64) // Optional: Set the number of top-k tokens to consider
            .build()

        llmInference = LlmInference.createFromOptions(cxt, taskOptions)

    }

    fun runInference(cxt:Context, inputPrompt:String)
    {
        viewModelScope.launch(Dispatchers.IO) {
            _aiMessage.value = ""
            _stats.value = null
            if(llmInference == null)
            {
                initInferenceAPI(cxt)
            }

            val startTime = System.nanoTime()

            var fullMessage = ""
            var totalTokens = 0
            var ttft:Double? = null
            llmInference?.generateResponseAsync(inputPrompt, {chunk:String, done:Boolean ->
                totalTokens++
                if(ttft == null)
                {
                    val endTime = System.nanoTime()
                    val elapsedSeconds = (endTime - startTime) / 1_000_000_000.0
                    ttft = elapsedSeconds
                }
                if (done) {
                    _aiMessage.value = fullMessage
                    val endTime = System.nanoTime()
                    var elapsedSeconds = (endTime - startTime) / 1_000_000_000.0

                    _stats.value = STATS(
                        total_time = "${String.format("%.2f", elapsedSeconds)} sec",
                        number_of_tokens = totalTokens,
                        tokens_per_second = "${String.format("%.1f", totalTokens/elapsedSeconds)}",
                        ttft = "${String.format("%.2f", ttft)} sec"
                    )

                    Log.d(LOGTAG, "Inference took $elapsedSeconds seconds, total tokens : $totalTokens")
                }
                fullMessage = fullMessage + chunk
                _aiMessage.value = fullMessage
                Log.i(LOGTAG, "Chunk : $chunk")
            })

        }
    }


}