document.addEventListener('DOMContentLoaded', () => {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {type: "getScrollPosition"}, function(response) {
            document.getElementById('position').textContent = `X: ${response.x}, Y: ${response.y}`;
        });
    });

    // This would go in your background script or a persistent part of your extension
    

});


chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.type === "scrollEvent") {
        console.log("scrolled");
        console.log("Scroll Position:", message.position);
        // Update popup or handle the scroll event as needed
        // This could involve updating some shared state or storing the scroll data
    }
});
