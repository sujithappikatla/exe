package com.example.lessons.data.api

import com.example.lessons.data.models.DownloadUrlResponse
import com.example.lessons.data.models.LessonListResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface LessonApiService {
    
    @POST("lesson/list")
    suspend fun getLessons(@Body request: Map<String, String>): Response<LessonListResponse>
    
    @POST("lesson/audio/download")
    suspend fun getAudioDownloadUrl(@Body request: Map<String, String>): Response<DownloadUrlResponse>
    
    @POST("lesson/transcript/download")
    suspend fun getTranscriptDownloadUrl(@Body request: Map<String, String>): Response<DownloadUrlResponse>
    
    @POST("lesson/summary/download")
    suspend fun getSummaryDownloadUrl(@Body request: Map<String, String>): Response<DownloadUrlResponse>
} 