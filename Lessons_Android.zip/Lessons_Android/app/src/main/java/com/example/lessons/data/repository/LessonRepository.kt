package com.example.lessons.data.repository

import com.example.lessons.data.api.ApiClient
import com.example.lessons.data.models.DownloadUrlResponse
import com.example.lessons.data.models.Lesson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LessonRepository {
    private val apiService = ApiClient.lessonApiService
    private val userId = "USER1"
    
    suspend fun getLessons(): Result<List<Lesson>> = withContext(Dispatchers.IO) {
        try {
            val request = mapOf("user_id" to userId)
            val response = apiService.getLessons(request)
            
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!.lessons.lessons)
            } else {
                Result.failure(Exception("Failed to fetch lessons: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun getAudioDownloadUrl(lessonId: String): Result<String> = withContext(Dispatchers.IO) {
        getDownloadUrl(lessonId) { id ->
            apiService.getAudioDownloadUrl(mapOf("user_id" to userId, "lesson_id" to id))
        }
    }
    
    suspend fun getTranscriptDownloadUrl(lessonId: String): Result<String> = withContext(Dispatchers.IO) {
        getDownloadUrl(lessonId) { id ->
            apiService.getTranscriptDownloadUrl(mapOf("user_id" to userId, "lesson_id" to id))
        }
    }
    
    suspend fun getSummaryDownloadUrl(lessonId: String): Result<String> = withContext(Dispatchers.IO) {
        getDownloadUrl(lessonId) { id ->
            apiService.getSummaryDownloadUrl(mapOf("user_id" to userId, "lesson_id" to id))
        }
    }
    
    private suspend fun getDownloadUrl(
        lessonId: String,
        apiCall: suspend (String) -> retrofit2.Response<DownloadUrlResponse>
    ): Result<String> {
        return try {
            val response = apiCall(lessonId)
            
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!.download_url)
            } else {
                Result.failure(Exception("Failed to get download URL: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
} 