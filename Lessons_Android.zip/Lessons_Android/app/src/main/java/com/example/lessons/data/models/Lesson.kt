package com.example.lessons.data.models

data class Lesson(
    val id: String,
    val name: String
)

data class LessonListResponse(
    val lessons: LessonsWrapper
)

data class LessonsWrapper(
    val lessons: List<Lesson>
)

data class DownloadUrlResponse(
    val download_url: String
) 