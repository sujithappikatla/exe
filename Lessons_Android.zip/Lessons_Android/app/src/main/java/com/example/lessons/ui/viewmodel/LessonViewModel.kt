package com.example.lessons.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.lessons.data.models.Lesson
import com.example.lessons.data.repository.LessonRepository
import com.example.lessons.utils.FileDownloader
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class LessonViewModel(
    private val repository: LessonRepository,
    private val fileDownloader: FileDownloader
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(LessonUiState())
    val uiState: StateFlow<LessonUiState> = _uiState.asStateFlow()
    
    init {
        fetchLessons()
    }
    
    fun fetchLessons() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            repository.getLessons()
                .onSuccess { lessons ->
                    _uiState.update { 
                        it.copy(
                            isLoading = false,
                            lessons = lessons
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.message ?: "Failed to fetch lessons"
                        )
                    }
                }
        }
    }
    
    fun selectLesson(lesson: Lesson) {
        _uiState.update { it.copy(selectedLesson = lesson) }
    }
    
    fun downloadAudio() {
        val lessonId = _uiState.value.selectedLesson?.id ?: return
        downloadFile(lessonId, "audio", "mp4") { repository.getAudioDownloadUrl(lessonId) }
    }
    
    fun downloadTranscript() {
        val lessonId = _uiState.value.selectedLesson?.id ?: return
        downloadFile(lessonId, "transcript", "txt") { repository.getTranscriptDownloadUrl(lessonId) }
    }
    
    fun downloadSummary() {
        val lessonId = _uiState.value.selectedLesson?.id ?: return
        downloadFile(lessonId, "summary", "txt") { repository.getSummaryDownloadUrl(lessonId) }
    }
    
    fun resetDownloadState() {
        _uiState.update { it.copy(downloadProgress = null, downloadError = null) }
    }
    
    private fun downloadFile(
        lessonId: String,
        fileType: String,
        fileExtension: String,
        getUrlFun: suspend () -> Result<String>
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(
                downloadProgress = 0, 
                downloadError = null,
                downloadedBytes = 0L,
                totalBytes = 0L,
                isRetrying = false,
                retryInfo = null
            ) }
            
            getUrlFun()
                .onSuccess { url ->
                    fileDownloader.downloadFile(url, "${lessonId}_${fileType}", fileExtension)
                        .collect { status ->
                            when (status) {
                                is FileDownloader.DownloadStatus.Progress -> {
                                    _uiState.update { it.copy(
                                        downloadProgress = status.percentage,
                                        downloadedBytes = status.downloadedBytes,
                                        totalBytes = status.totalBytes
                                    ) }
                                }
                                is FileDownloader.DownloadStatus.Success -> {
                                    _uiState.update { it.copy(
                                        downloadProgress = 100,
                                        downloadedFile = status.file,
                                        isRetrying = false,
                                        retryInfo = null
                                    ) }
                                }
                                is FileDownloader.DownloadStatus.Error -> {
                                    _uiState.update { it.copy(
                                        downloadError = status.message,
                                        isRetrying = false,
                                        retryInfo = null
                                    ) }
                                }
                                is FileDownloader.DownloadStatus.Retrying -> {
                                    _uiState.update { it.copy(
                                        isRetrying = true,
                                        retryInfo = "Retry ${status.attempt} of ${status.maxAttempts}: ${status.reason}"
                                    ) }
                                }
                            }
                        }
                }
                .onFailure { error ->
                    _uiState.update { it.copy(
                        downloadError = error.message ?: "Failed to get download URL",
                        isRetrying = false,
                        retryInfo = null
                    ) }
                }
        }
    }
}

data class LessonUiState(
    val isLoading: Boolean = false,
    val lessons: List<Lesson> = emptyList(),
    val error: String? = null,
    val selectedLesson: Lesson? = null,
    val downloadProgress: Int? = null,
    val downloadedBytes: Long? = null,
    val totalBytes: Long? = null,
    val downloadError: String? = null,
    val downloadedFile: java.io.File? = null,
    val isRetrying: Boolean = false,
    val retryInfo: String? = null
)

class LessonViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LessonViewModel::class.java)) {
            return LessonViewModel(
                repository = LessonRepository(),
                fileDownloader = FileDownloader(context)
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
} 