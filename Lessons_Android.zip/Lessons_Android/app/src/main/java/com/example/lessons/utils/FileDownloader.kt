package com.example.lessons.utils

import android.content.Context
import android.os.Environment
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.ResponseBody
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import kotlin.contracts.ExperimentalContracts

class FileDownloader(private val context: Context) {
    
    private val TAG = "FileDownloader"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
    
    sealed class DownloadStatus {
        data class Progress(val percentage: Int, val downloadedBytes: Long, val totalBytes: Long) : DownloadStatus()
        data class Success(val file: File) : DownloadStatus()
        data class Error(val message: String) : DownloadStatus()
        data class Retrying(val attempt: Int, val maxAttempts: Int, val reason: String) : DownloadStatus()
    }
    
    fun downloadFile(
        url: String,
        fileName: String,
        fileExtension: String
    ): Flow<DownloadStatus> = flow {
        Log.d(TAG, "Starting download for $fileName.$fileExtension from $url")
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val file = File(downloadsDir, "$fileName.$fileExtension")
        
        // Check if file might already be fully downloaded
        if (file.exists()) {
            Log.d(TAG, "File already exists, checking if it's complete...")
            
            // Do an initial HEAD request to get file size without downloading content
            val headRequest = Request.Builder()
                .url(url)
                .head()  // Only get headers, not body
                .build()
                
            try {
                val headResponse = client.newCall(headRequest).execute()
                
                if (headResponse.isSuccessful) {
                    val contentLength = headResponse.header("Content-Length")?.toLongOrNull()
                    
                    if (contentLength != null && contentLength > 0) {
                        Log.d(TAG, "Server reports file size: $contentLength bytes, local file size: ${file.length()} bytes")
                        
                        // If file sizes match (or local is bigger due to possible incomplete previous download), 
                        // assume it's already downloaded
                        if (file.length() >= contentLength) {
                            Log.d(TAG, "File appears to be completely downloaded already")
                            emit(DownloadStatus.Success(file))
                            return@flow
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error checking file size via HEAD request: ${e.message}")
                // Continue with normal download if HEAD request fails
            }
        }
        
        var retryCount = 0
        val maxRetries = 3
        var lastException: Exception? = null
        var completed = false
        var forceFullDownload = false
        
        while (retryCount <= maxRetries && !completed) {
            if (retryCount > 0) {
                val retryMessage = lastException?.message ?: "Unknown error"
                Log.d(TAG, "Retry $retryCount/$maxRetries due to: $retryMessage")
                emit(DownloadStatus.Retrying(retryCount, maxRetries, retryMessage))
                delay(2000) // Wait before retrying
            }
            
            var inputStream: InputStream? = null
            var outputStream: OutputStream? = null
            
            try {
                // Check if file exists and get its size for resuming
                val fileExists = file.exists()
                var downloadedBytes = if (fileExists && !forceFullDownload) file.length() else 0L
                
                // If we're forcing a full download, delete existing file
                if (forceFullDownload && fileExists) {
                    Log.d(TAG, "Forcing full download, deleting existing file")
                    file.delete()
                    downloadedBytes = 0L
                }
                
                Log.d(TAG, "File exists: $fileExists, already downloaded: $downloadedBytes bytes, force full: $forceFullDownload")
                
                // Create request with range header if resuming
                val requestBuilder = Request.Builder().url(url)
                if (downloadedBytes > 0) {
                    Log.d(TAG, "Adding Range header: bytes=$downloadedBytes-")
                    requestBuilder.header("Range", "bytes=$downloadedBytes-")
                }
                
                val request = requestBuilder.build()
                Log.d(TAG, "Executing request: ${request.url}")
                
                val response = client.newCall(request).execute()
                Log.d(TAG, "Response code: ${response.code}")
                
                // Handle 416 Range Not Satisfiable error specifically
                if (response.code == 416) {
                    Log.w(TAG, "Server returned 416 Range Not Satisfiable, checking if file is already complete")
                    
                    // This typically happens when the file is already fully downloaded
                    // Let's check if our file seems complete by doing a HEAD request
                    val checkRequest = Request.Builder()
                        .url(url)
                        .head()
                        .build()
                    
                    try {
                        val checkResponse = client.newCall(checkRequest).execute()
                        
                        if (checkResponse.isSuccessful) {
                            val contentLength = checkResponse.header("Content-Length")?.toLongOrNull()
                            
                            if (contentLength != null && contentLength > 0) {
                                Log.d(TAG, "Server reports file size: $contentLength bytes, local file size: ${file.length()} bytes")
                                
                                // If our file is the same size or larger, it's likely complete
                                // (Might be larger if the server file was replaced with a smaller one)
                                if (file.length() >= contentLength) {
                                    Log.d(TAG, "File appears to be completely downloaded already")
                                    emit(DownloadStatus.Success(file))
                                    completed = true
                                    return@flow
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error checking file size after 416 error: ${e.message}")
                    }
                    
                    // If we get here, the file isn't complete - try a full download
                    if (downloadedBytes > 0) {
                        Log.d(TAG, "Trying full download instead of resuming")
                        forceFullDownload = true
                        continue
                    } else {
                        val errorMessage = "Cannot download file, range not satisfiable even from start"
                        Log.e(TAG, errorMessage)
                        emit(DownloadStatus.Error(errorMessage))
                        return@flow
                    }
                }
                
                // If we requested a range but got 200 instead of 206, server doesn't support ranges
                // Start over with a full download
                if (downloadedBytes > 0 && response.code == 200) {
                    Log.w(TAG, "Server doesn't support range requests (got 200 OK instead of 206 Partial), starting fresh")
                    forceFullDownload = true
                    continue  // Restart without incrementing retry count
                }
                
                if (!response.isSuccessful) {
                    val errorMessage = "Failed to download: ${response.code}"
                    Log.e(TAG, errorMessage)
                    lastException = IOException(errorMessage)
                    retryCount++
                    continue
                }
                
                val body = response.body
                if (body == null) {
                    val errorMessage = "Empty response body"
                    Log.e(TAG, errorMessage)
                    lastException = IOException(errorMessage)
                    retryCount++
                    continue
                }
                
                // Get content length from response
                val contentLength = body.contentLength()
                Log.d(TAG, "Content length: $contentLength")
                
                // For range requests (206 Partial Content), the content length is just the range
                // For full downloads (200 OK), it's the entire file
                val totalBytes = if (response.code == 206) {
                    // This is a partial response, total = current + new content
                    downloadedBytes + contentLength
                } else {
                    // This is a full file response, regardless of what we already have
                    contentLength
                }
                
                Log.d(TAG, "Total expected bytes: $totalBytes")
                
                try {
                    inputStream = body.byteStream()
                    
                    // If this is a full download response (200 OK), we need to overwrite
                    // If this is a partial response (206), we append
                    outputStream = if (response.code == 206) {
                        Log.d(TAG, "Opening file in append mode for partial content")
                        FileOutputStream(file, true)
                    } else {
                        Log.d(TAG, "Opening file in write mode for full content")
                        FileOutputStream(file)
                    }
                    
                    val buffer = ByteArray(8 * 1024)
                    var bytesRead: Int
                    var totalBytesRead = downloadedBytes
                    var lastEmittedProgress = 0
                    var lastLoggedProgress = 0
                    
                    Log.d(TAG, "Starting to read data stream")
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        outputStream.write(buffer, 0, bytesRead)
                        totalBytesRead += bytesRead
                        
                        val progress = if (totalBytes != Long.MAX_VALUE) {
                            ((totalBytesRead * 100) / totalBytes).toInt()
                        } else {
                            // Cannot determine exact progress for unknown size
                            ((totalBytesRead - downloadedBytes) * 100 / (5 * 1024 * 1024)).coerceAtMost(99).toInt()
                        }
                        
                        // Log every 10% progress
                        if (progress >= lastLoggedProgress + 10) {
                            Log.d(TAG, "Download progress: $progress%, $totalBytesRead bytes")
                            lastLoggedProgress = progress
                        }
                        
                        // Only emit progress updates when they change by at least 1%
                        if (progress > lastEmittedProgress) {
                            lastEmittedProgress = progress
                            emit(DownloadStatus.Progress(progress, totalBytesRead, totalBytes))
                        }
                    }
                    
                    Log.d(TAG, "Download completed successfully: ${file.absolutePath}")
                    emit(DownloadStatus.Success(file))
                    completed = true
                    
                } catch (e: Exception) {
                    Log.e(TAG, "Error during download: ${e.message}", e)
                    lastException = e
                    
                    // Delete potentially corrupted file if it's the first attempt and no previous data
                    if (retryCount == 0 && downloadedBytes == 0L) {
                        Log.d(TAG, "Deleting potentially corrupted file")
                        file.delete()
                    }
                    
                    retryCount++
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error setting up download: ${e.message}", e)
                lastException = e
                retryCount++
            } finally {
                try {
                    inputStream?.close()
                } catch (e: Exception) {
                    Log.e(TAG, "Error closing input stream", e)
                }
                
                try {
                    outputStream?.close()
                } catch (e: Exception) {
                    Log.e(TAG, "Error closing output stream", e)
                }
            }
        }
        
        // If we've exhausted all retries and haven't completed the download
        if (!completed) {
            val errorMessage = "Failed after $maxRetries retries: ${lastException?.message}"
            Log.e(TAG, errorMessage)
            emit(DownloadStatus.Error(errorMessage))
        }
    }.flowOn(Dispatchers.IO)
    
    /**
     * Checks if we need to resume a download
     * @return Pair of (file exists, downloaded bytes)
     */
    private fun getResumeInfo(file: File): Pair<Boolean, Long> {
        val exists = file.exists()
        val size = if (exists) file.length() else 0L
        return Pair(exists, size)
    }
} 