package com.example.flexibleui

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.flexibleui.R
import com.example.flexibleui.ui.theme.FlexibleUITheme
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FlexibleUITheme {
//                DraggableRectangleCanvas()
                Flexi()
            }
        }
    }
}
@Composable
fun CustomAlignedImageWithBitmap(
    width: Dp,
    height: Dp,
) {
    val imageBitmap = ImageBitmap.imageResource(id = R.drawable.car)
    val density = LocalDensity.current
    var boxPosition by remember { mutableStateOf(Offset(0f, 0f)) }
    var containerSize by remember { mutableStateOf(Size(700F,700F)) }
    val boxSizePx = with(density) { 200.dp.toPx() }
    var imageOffset by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier.size(width, height)
            .graphicsLayer {
                containerSize = size
            }
    ) {


        Canvas(modifier = Modifier.matchParentSize()) {

            val aspectRatio = 700F/800F

            val availableWidth = 700.dp.toPx().toInt()

            Log.i("TAG", "------" +(aspectRatio * imageBitmap.width).toString())


            imageOffset = imageOffset.coerceIn(0f, (imageBitmap.width-imageBitmap.height*aspectRatio).toFloat())

            // Draw the image with source and destination bounds
            drawImage(
                image = imageBitmap,
                srcOffset = IntOffset(imageOffset.roundToInt(),0),
                srcSize = IntSize(imageBitmap.height*aspectRatio.roundToInt(), imageBitmap.height),
                dstSize = IntSize(700.dp.toPx().toInt(), 800.dp.toPx().toInt())
            )
        }

        Box(
            modifier = Modifier
                .size(200.dp)
                .offset {
                    IntOffset(
                        boxPosition.x.roundToInt(),
                        boxPosition.y.roundToInt()
                    )
                }
                .clip(RectangleShape)
                .background(Color.Red.copy(alpha = 0.3f))
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()

                        // Calculate new position
                        val newX = (boxPosition.x + dragAmount.x)
                            .coerceIn(0f, containerSize.width - boxSizePx)
                        val newY = (boxPosition.y + dragAmount.y)
                            .coerceIn(0f, containerSize.height- boxSizePx)

                        boxPosition = Offset(newX, newY)

                        if(boxPosition.x < 100)
                            imageOffset = (imageOffset-20)

                        if(boxPosition.x > containerSize.width- boxSizePx - 100)
                            imageOffset = (imageOffset+20)

                        // Calculate image offset based on box position
//                        val boxProgress = newX / (containerSize.width - boxSizePx)
//                        val maxImageOffset = containerSize.width - imageBitmap.width
//                        imageOffset = maxImageOffset * boxProgress
                    }
                }
        )
    }
}

@Composable
fun DraggableRectangleCanvas() {
    var rectPosition by remember { mutableStateOf(Offset(100f, 100f)) }
    var rectSize by remember { mutableStateOf(Size(200f, 200f)) }
    val cornerTouchRadius = 40f
    var dragMode by remember { mutableStateOf(DragMode.NONE) }
    val imageBitmap = ImageBitmap.imageResource(id = R.drawable.car)
    var imageOffset by remember { mutableStateOf(0f) }
    var imageScale by remember { mutableStateOf(1f) }
    var minImageScale by remember { mutableStateOf(1f) }  // Track minimum scale reached
    var imageVerticalOffset by remember { mutableStateOf(0f) }
    var isAnimating by remember { mutableStateOf(false) }
    var animationProgress by remember { mutableStateOf(0f) }
    var startImageOffset by remember { mutableStateOf(0f) }
    var startRectX by remember { mutableStateOf(0f) }
    var startImageScale by remember { mutableStateOf(1f) }
    var startRectSize by remember { mutableStateOf(Size(0f, 0f)) }
    var endImageOffset by remember { mutableStateOf(0f) }
    var endRectX by remember { mutableStateOf(0f) }
    var endImageScale by remember { mutableStateOf(1f) }
    var endRectSize by remember { mutableStateOf(Size(0f, 0f)) }
    var canvasSize by remember { mutableStateOf(Size(0f, 0f)) }
    
    // Single animation value
    val progress by animateFloatAsState(
        targetValue = animationProgress,
        animationSpec = tween(700),
        finishedListener = { isAnimating = false }
    )
    
    // Update all animated values using the same progress
    if (isAnimating) {
        imageOffset = lerp(startImageOffset, endImageOffset, progress)
        imageScale = lerp(startImageScale, endImageScale, progress)
        if (imageScale < minImageScale) {
            minImageScale = imageScale  // Update minimum scale if we go lower
        }
        rectPosition = rectPosition.copy(
            x = lerp(startRectX, endRectX, progress)
        )
        rectSize = Size(
            width = lerp(startRectSize.width, endRectSize.width, progress),
            height = lerp(startRectSize.height, endRectSize.height, progress)
        )
        // Center the image vertically when scaling
        imageVerticalOffset = (1f - imageScale) * canvasSize.height / 2
    }
    
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        isAnimating = false
                        animationProgress = 0f
                        dragMode = when {
                            isNearTopLeft(offset, rectPosition, cornerTouchRadius) -> DragMode.TOP_LEFT
                            isNearTopRight(offset, rectPosition, rectSize, cornerTouchRadius) -> DragMode.TOP_RIGHT
                            isNearBottomLeft(offset, rectPosition, rectSize, cornerTouchRadius) -> DragMode.BOTTOM_LEFT
                            isNearBottomRight(offset, rectPosition, rectSize, cornerTouchRadius) -> DragMode.BOTTOM_RIGHT
                            isWithinRect(offset, rectPosition, rectSize) -> DragMode.MOVE
                            else -> DragMode.NONE
                        }
                    },
                    onDragEnd = {
                        val canvasWidth = size.width.toFloat()
                        val canvasHeight = size.height.toFloat()
                        canvasSize = Size(canvasWidth, canvasHeight)
                        val edgeThreshold = 300f
                        val baseScale = canvasHeight / imageBitmap.height.toFloat()
                        val scaledImageWidth = (imageBitmap.width.toFloat() * baseScale * imageScale)
                        
                        // If image already fits canvas width, no more scaling or panning
                        if (scaledImageWidth <= canvasWidth) {
                            return@detectDragGestures
                        }
                        
                        val maxImageOffset = (scaledImageWidth - canvasWidth).coerceAtLeast(0f)
                        
                        // Check if we're in a resize mode and near edges
                        val isResizeMode = dragMode == DragMode.TOP_LEFT || dragMode == DragMode.TOP_RIGHT ||
                                         dragMode == DragMode.BOTTOM_LEFT || dragMode == DragMode.BOTTOM_RIGHT
                        
                        // Check if rectangle spans both edges
                        val isNearLeftEdge = rectPosition.x < edgeThreshold
                        val isNearRightEdge = rectPosition.x + rectSize.width > canvasWidth - edgeThreshold
                        val spansEdges = isNearLeftEdge && isNearRightEdge
                        
                        // Calculate visible image bounds
                        val visibleLeft = imageOffset.coerceIn(0f, canvasWidth)
                        val visibleRight = (imageOffset + scaledImageWidth).coerceIn(0f, canvasWidth)
                        
                        // Calculate rectangle's relative position to image content
                        val rectLeftRatio = (rectPosition.x - imageOffset) / scaledImageWidth
                        val rectRightRatio = (rectPosition.x + rectSize.width - imageOffset) / scaledImageWidth
                        
                        when {

                            // Rectangle spans both edges during resize
                            spansEdges && isResizeMode -> {
                                isAnimating = true
                                startImageOffset = imageOffset
                                startRectX = rectPosition.x
                                startImageScale = imageScale
                                startRectSize = rectSize
                                
                                // Calculate how much we need to scale down
                                val totalOverlap = (rectPosition.x + rectSize.width - canvasWidth) + (-rectPosition.x)
                                val scaleReduction = (scaledImageWidth - totalOverlap) / scaledImageWidth
                                endImageScale = (imageScale * scaleReduction)
                                    .coerceAtMost(minImageScale)  // Never scale up beyond minimum
                                    .coerceAtLeast(canvasWidth / (imageBitmap.width.toFloat() * baseScale))  // Don't scale smaller than needed
                                
                                // Center the image horizontally
                                endImageOffset = 0f
                                
                                // Calculate new rectangle size and position
                                val newScaledWidth = scaledImageWidth * (endImageScale / imageScale)
                                endRectSize = Size(
                                    width = rectSize.width * (endImageScale / imageScale),
                                    height = rectSize.height * (endImageScale / imageScale)
                                )
                                
                                // Maintain relative position within bounds
                                endRectX = (rectLeftRatio * newScaledWidth)
                                    .coerceIn(0f, canvasWidth - endRectSize.width)
                                
                                animationProgress = 1f
                            }
                            // Near left edge during resize or move
                            isNearLeftEdge && (isResizeMode || dragMode == DragMode.MOVE) -> {
                                isAnimating = true
                                startImageOffset = imageOffset
                                startRectX = rectPosition.x
                                startImageScale = imageScale
                                startRectSize = rectSize
                                
                                // Try to pan first
                                val imageMove = canvasWidth * 0.3f
                                val proposedOffset = imageOffset + imageMove
                                
                                // Calculate how much of right edge would become visible
                                val rightOverlap = proposedOffset - maxImageOffset + edgeThreshold
                                Log.d("TAG", "rightOverlap : $rightOverlap")
                                if (rightOverlap > 0 && isResizeMode) {
                                    // Need to scale down proportionally
                                    val scaleReduction = (scaledImageWidth - rightOverlap) / scaledImageWidth
                                    endImageScale = (imageScale * scaleReduction)
                                        .coerceAtMost(minImageScale)  // Never scale up beyond minimum
                                        .coerceAtLeast(canvasWidth / (imageBitmap.width.toFloat() * baseScale))  // Don't scale smaller than needed
                                    
                                    // Adjust offset based on new scale
                                    val newScaledWidth = scaledImageWidth * (endImageScale / imageScale)
                                    endImageOffset = 0f
                                    
                                    // Scale rectangle proportionally
                                    endRectSize = Size(
                                        width = rectSize.width * (endImageScale / imageScale),
                                        height = rectSize.height * (endImageScale / imageScale)
                                    )
                                    
                                    // Maintain relative position within bounds
                                    endRectX = (rectLeftRatio * newScaledWidth)
                                        .coerceIn(0f, canvasWidth - endRectSize.width)
                                } else {
                                    // Just pan
                                    endImageScale = imageScale.coerceAtMost(minImageScale)  // Ensure we don't scale up
                                    endImageOffset = proposedOffset.coerceIn(-maxImageOffset, 0f)
                                    endRectSize = rectSize
                                    
                                    // Move rectangle proportionally and constrain to visible bounds
                                    val actualImageMove = endImageOffset - imageOffset
                                    endRectX = (rectPosition.x + actualImageMove)
                                        .coerceIn(0f, canvasWidth - rectSize.width)
                                }
                                
                                animationProgress = 1f
                            }
                            // Near right edge during resize or move
                            isNearRightEdge && (isResizeMode || dragMode == DragMode.MOVE) -> {
                                isAnimating = true
                                startImageOffset = imageOffset
                                startRectX = rectPosition.x
                                startImageScale = imageScale
                                startRectSize = rectSize
                                
                                // Try to pan first
                                val imageMove = canvasWidth * 0.3f
                                val proposedOffset = imageOffset - imageMove
                                
                                // Calculate how much of left edge would become visible
                                val leftOverlap = -proposedOffset + edgeThreshold
                                
                                if (leftOverlap > 0 && isResizeMode) {
                                    // Need to scale down proportionally
                                    val scaleReduction = (scaledImageWidth - leftOverlap) / scaledImageWidth
                                    endImageScale = (imageScale * scaleReduction)
                                        .coerceAtMost(minImageScale)  // Never scale up beyond minimum
                                        .coerceAtLeast(canvasWidth / (imageBitmap.width.toFloat() * baseScale))  // Don't scale smaller than needed
                                    
                                    // Adjust offset based on new scale
                                    val newScaledWidth = scaledImageWidth * (endImageScale / imageScale)
                                    endImageOffset = 0f
                                    
                                    // Scale rectangle proportionally
                                    endRectSize = Size(
                                        width = rectSize.width * (endImageScale / imageScale),
                                        height = rectSize.height * (endImageScale / imageScale)
                                    )
                                    
                                    // Maintain relative position within bounds
                                    endRectX = (rectRightRatio * newScaledWidth - endRectSize.width)
                                        .coerceIn(0f, canvasWidth - endRectSize.width)
                                } else {
                                    // Just pan
                                    endImageScale = imageScale.coerceAtMost(minImageScale)  // Ensure we don't scale up
                                    endImageOffset = proposedOffset.coerceIn(-maxImageOffset, 0f)
                                    endRectSize = rectSize
                                    
                                    // Move rectangle proportionally and constrain to visible bounds
                                    val actualImageMove = imageOffset - endImageOffset
                                    endRectX = (rectPosition.x - actualImageMove)
                                        .coerceIn(0f, canvasWidth - rectSize.width)
                                }
                                
                                animationProgress = 1f
                            }
                            // Rectangle near left or right edge after drag ends
                            (isNearLeftEdge || isNearRightEdge) && !isAnimating -> {
                                isAnimating = true
                                startImageOffset = imageOffset
                                startRectX = rectPosition.x
                                startImageScale = imageScale
                                startRectSize = rectSize

                                // Calculate vertical scale reduction
                                val scaleReduction = 0.8f  // Reduce to 80% of current scale
                                endImageScale = (imageScale * scaleReduction)
                                    .coerceAtMost(minImageScale)  // Never scale up beyond minimum
                                    .coerceAtLeast(canvasWidth / (imageBitmap.width.toFloat() * baseScale))  // Don't scale smaller than needed

                                // Center the image horizontally
                                endImageOffset = imageOffset

                                // Scale rectangle proportionally
                                endRectSize = Size(
                                    width = rectSize.width * (endImageScale / imageScale),
                                    height = rectSize.height * (endImageScale / imageScale)
                                )

                                // Maintain rectangle's horizontal position
                                endRectX = rectPosition.x * (endImageScale / imageScale)
                                    .coerceIn(0f, canvasWidth - endRectSize.width)

                                animationProgress = 1f
                            }
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        
                        val canvasWidth = size.width.toFloat()
                        val canvasHeight = size.height.toFloat()
                        val baseScale = canvasHeight / imageBitmap.height.toFloat()
                        val scaledImageWidth = (imageBitmap.width.toFloat() * baseScale * imageScale)
                        val scaledHeight = canvasHeight * imageScale
                        
                        // Calculate visible image bounds (constrained to canvas)
                        val visibleLeft = imageOffset.coerceIn(0f, canvasWidth)
                        val visibleRight = (imageOffset + scaledImageWidth).coerceIn(0f, canvasWidth)
                        val visibleTop = imageVerticalOffset.coerceIn(0f, canvasHeight)
                        val visibleBottom = (imageVerticalOffset + scaledHeight).coerceIn(0f, canvasHeight)
                        
                        when (dragMode) {
                            DragMode.MOVE -> {
                                // Calculate new rectangle position constrained to visible image bounds
                                val newX = (rectPosition.x + dragAmount.x)
                                    .coerceIn(visibleLeft, visibleRight - rectSize.width)
                                val newY = (rectPosition.y + dragAmount.y)
                                    .coerceIn(visibleTop, visibleBottom - rectSize.height)
                                
                                rectPosition = Offset(newX, newY)
                            }
                            DragMode.TOP_LEFT -> {
                                val newX = (rectPosition.x + dragAmount.x)
                                    .coerceIn(visibleLeft, rectPosition.x + rectSize.width - 50f)
                                val newY = (rectPosition.y + dragAmount.y)
                                    .coerceIn(visibleTop, rectPosition.y + rectSize.height - 50f)
                                val newWidth = rectSize.width - (newX - rectPosition.x)
                                val newHeight = rectSize.height - (newY - rectPosition.y)
                                
                                if (newWidth > 50f && newHeight > 50f) {
                                    rectPosition = Offset(newX, newY)
                                    rectSize = Size(newWidth, newHeight)
                                }
                            }
                            DragMode.TOP_RIGHT -> {
                                val newY = (rectPosition.y + dragAmount.y)
                                    .coerceIn(visibleTop, rectPosition.y + rectSize.height - 50f)
                                val newWidth = (rectSize.width + dragAmount.x)
                                    .coerceIn(50f, visibleRight - rectPosition.x)
                                val newHeight = rectSize.height - (newY - rectPosition.y)
                                
                                if (newWidth > 50f && newHeight > 50f) {
                                    rectPosition = Offset(rectPosition.x, newY)
                                    rectSize = Size(newWidth, newHeight)
                                }
                            }
                            DragMode.BOTTOM_LEFT -> {
                                val newX = (rectPosition.x + dragAmount.x)
                                    .coerceIn(visibleLeft, rectPosition.x + rectSize.width - 50f)
                                val newWidth = rectSize.width - (newX - rectPosition.x)
                                val newHeight = (rectSize.height + dragAmount.y)
                                    .coerceIn(50f, visibleBottom - rectPosition.y)
                                
                                if (newWidth > 50f && newHeight > 50f) {
                                    rectPosition = Offset(newX, rectPosition.y)
                                    rectSize = Size(newWidth, newHeight)
                                }
                            }
                            DragMode.BOTTOM_RIGHT -> {
                                val newWidth = (rectSize.width + dragAmount.x)
                                    .coerceIn(50f, visibleRight - rectPosition.x)
                                val newHeight = (rectSize.height + dragAmount.y)
                                    .coerceIn(50f, visibleBottom - rectPosition.y)
                                
                                if (newWidth > 50f && newHeight > 50f) {
                                    rectSize = Size(newWidth, newHeight)
                                }
                            }
                            DragMode.NONE -> { /* No changes needed */ }
                        }
                    }
                )
            }
    ) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        canvasSize = Size(canvasWidth, canvasHeight)  // Update canvas size
        
        // Calculate scaled image size maintaining aspect ratio and full height
        val baseScale = (canvasHeight / imageBitmap.height.toFloat())
        val scale = baseScale * imageScale
        val scaledWidth = (imageBitmap.width.toFloat() * scale)
        val scaledHeight = (canvasHeight * imageScale)
        
        // Draw the image with proper scaling and offset
        drawImage(
            image = imageBitmap,
            dstSize = IntSize(scaledWidth.roundToInt(), scaledHeight.roundToInt()),
            dstOffset = IntOffset(imageOffset.roundToInt(), imageVerticalOffset.roundToInt())
        )

        // Draw rectangle and corner indicators
        drawRect(
            color = Color.Blue.copy(alpha = 0.5f),
            topLeft = rectPosition,
            size = rectSize
        )
        
        // Draw corner indicators
        val cornerRadius = 10f
        val cornerColor = Color.Green
        
        listOf(
            rectPosition,
            Offset(rectPosition.x + rectSize.width, rectPosition.y),
            Offset(rectPosition.x, rectPosition.y + rectSize.height),
            Offset(rectPosition.x + rectSize.width, rectPosition.y + rectSize.height)
        ).forEach { corner ->
            drawCircle(
                color = cornerColor,
                radius = cornerRadius,
                center = corner
            )
        }
    }
}

// Helper function to interpolate between two float values
private fun lerp(start: Float, end: Float, fraction: Float): Float {
    return start + (end - start) * fraction
}

private enum class DragMode {
    NONE, MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
}

private fun isNearTopLeft(point: Offset, rectPosition: Offset, threshold: Float): Boolean {
    return (point - rectPosition).getDistance() < threshold
}

private fun isNearTopRight(point: Offset, rectPosition: Offset, rectSize: Size, threshold: Float): Boolean {
    val corner = Offset(rectPosition.x + rectSize.width, rectPosition.y)
    return (point - corner).getDistance() < threshold
}

private fun isNearBottomLeft(point: Offset, rectPosition: Offset, rectSize: Size, threshold: Float): Boolean {
    val corner = Offset(rectPosition.x, rectPosition.y + rectSize.height)
    return (point - corner).getDistance() < threshold
}

private fun isNearBottomRight(point: Offset, rectPosition: Offset, rectSize: Size, threshold: Float): Boolean {
    val corner = Offset(rectPosition.x + rectSize.width, rectPosition.y + rectSize.height)
    return (point - corner).getDistance() < threshold
}

private fun isWithinRect(point: Offset, rectPosition: Offset, rectSize: Size): Boolean {
    return point.x >= rectPosition.x &&
           point.x <= rectPosition.x + rectSize.width &&
           point.y >= rectPosition.y &&
           point.y <= rectPosition.y + rectSize.height
}
