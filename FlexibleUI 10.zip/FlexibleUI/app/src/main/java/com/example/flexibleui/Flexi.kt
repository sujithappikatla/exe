package com.example.flexibleui

import android.util.Log
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.pow
import androidx.compose.animation.core.*
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.unit.dp
import kotlin.math.abs

private fun isNearCorner(x: Float, y: Float, cornerX: Float, cornerY: Float): Boolean {
    val threshold = 100f // Increased from 30f for larger corner touch area
    return (x - cornerX).pow(2) + (y - cornerY).pow(2) <= threshold.pow(2)
}

private fun checkAndAdjustZoom(
    rectLeft: Float, rectTop: Float, rectWidth: Float, rectHeight: Float,
    viewportWidth: Float, viewportHeight: Float,
    currentOffsetX: Float, currentOffsetY: Float,
    scale: Float
): Triple<Float, Float, Float>? {

    return null

    // Skip if scale is already at or near minimum
    if (scale <= 1f) {
        return null
    }

    // Define resting area as 50% of viewport and left-centered
    val restingAreaWidth = viewportWidth * 0.5f
    val restingAreaHeight = viewportHeight * 0.5f
    val restingAreaLeft = viewportWidth * 0.1f  // 10% from left edge
    val restingAreaTop = (viewportHeight - restingAreaHeight) / 2  // Vertically centered

    val edgeThreshold = 100f  // Distance from edge to trigger zoom out
    val rectRight = rectLeft + rectWidth
    val rectBottom = rectTop + rectHeight
    
    // Calculate visible bounds in resting area coordinates
    val visibleLeft = -currentOffsetX + restingAreaLeft
    val visibleTop = -currentOffsetY + restingAreaTop
    val visibleRight = visibleLeft + restingAreaWidth
    val visibleBottom = visibleTop + restingAreaHeight

    // Check if rectangle is near edges of resting area
    val nearEdge = (rectLeft - visibleLeft < edgeThreshold) ||
            (visibleRight - rectRight < edgeThreshold) ||
            (rectTop - visibleTop < edgeThreshold) ||
            (visibleBottom - rectBottom < edgeThreshold)

    if (nearEdge) {
        // Calculate new scale to fit rectangle within resting area with padding
        val padding = 50f
        val widthScale = restingAreaWidth / (rectWidth + padding * 2)
        val heightScale = restingAreaHeight / (rectHeight + padding * 2)
        val newScale = minOf(widthScale, heightScale, scale)  // Don't zoom out more than current scale
        
        // Calculate new offsets to center the rectangle in resting area
        val newOffsetX = -(rectLeft - (restingAreaWidth/newScale - rectWidth) / 2 - restingAreaLeft/newScale)
        val newOffsetY = -(rectTop - (restingAreaHeight/newScale - rectHeight) / 2 - restingAreaTop/newScale)
        
        return Triple(newScale, newOffsetX, newOffsetY)
    }
    
    return null
}

private fun ensureRectInView(
    rectLeft: Float, rectTop: Float, rectWidth: Float, rectHeight: Float,
    viewportWidth: Float, viewportHeight: Float,
    currentOffsetX: Float, currentOffsetY: Float,
    currentScale: Float,
    imageBitmap: ImageBitmap,
    minScale: Float
): Triple<Float, Float, Float>? {

    return null
    // Skip if current scale is already near minimum scale (with some tolerance)
    val scaleThreshold = minScale * 1.2f  // 20% above minScale
//    if (currentScale <= 1f) {
//        return null
//    }

    // Define resting area
    val restingAreaWidth = viewportWidth * 0.5f
    val restingAreaHeight = viewportHeight * 0.5f
    val restingAreaLeft = viewportWidth * 0.1f
    val restingAreaTop = (viewportHeight - restingAreaHeight) / 2

    // Check if image is already in resting position
    val imageLeft = -currentOffsetX / currentScale
    val imageTop = -currentOffsetY / currentScale
    val imageWidth = imageBitmap.width.toFloat()
    val imageHeight = imageBitmap.height.toFloat()

    // Calculate if image is roughly in resting area (with some tolerance)
    val tolerance = 20f
    val isInRestingArea = 
        abs(imageLeft - restingAreaLeft/currentScale) < tolerance &&
        abs(imageTop - restingAreaTop/currentScale) < tolerance &&
        abs(imageWidth * currentScale - restingAreaWidth) < tolerance &&
        abs(imageHeight * currentScale - restingAreaHeight) < tolerance

    // If image is already in resting area, don't adjust
    if (isInRestingArea) {
        return null
    }

    // Calculate what percentage of the image the rectangle takes up
    val imageArea = imageBitmap.width * imageBitmap.height
    val rectArea = rectWidth * rectHeight
    val areaRatio = rectArea / imageArea

    // If rectangle takes up more than 70% of the image, zoom out to show full image
    if (areaRatio > 0.7f) {
        val padding = viewportWidth * 0.1f
        val widthScale = viewportWidth / (imageBitmap.width + padding * 2)
        val heightScale = viewportHeight / (imageBitmap.height + padding * 2)
        val newScale = minOf(widthScale, heightScale)
        
        val newOffsetX = -(imageBitmap.width - viewportWidth/newScale) / 2
        val newOffsetY = -(imageBitmap.height - viewportHeight/newScale) / 2
        
        return Triple(newScale, newOffsetX, newOffsetY)
    }

    // Calculate visible bounds in resting area coordinates
    val visibleLeft = -currentOffsetX / currentScale + restingAreaLeft
    val visibleTop = -currentOffsetY / currentScale + restingAreaTop
    val visibleRight = visibleLeft + (restingAreaWidth / currentScale)
    val visibleBottom = visibleTop + (restingAreaHeight / currentScale)

    val isFullyVisible = rectLeft >= visibleLeft &&
            (rectLeft + rectWidth) <= visibleRight &&
            rectTop >= visibleTop &&
            (rectTop + rectHeight) <= visibleBottom

    if (!isFullyVisible) {
        val padding = 20f
        val widthScale = restingAreaWidth / (rectWidth + padding * 2)
        val heightScale = restingAreaHeight / (rectHeight + padding * 2)
        val newScale = minOf(widthScale, heightScale, currentScale)
        
        val newOffsetX = -(rectLeft - (restingAreaWidth/newScale - rectWidth) / 2 - restingAreaLeft/newScale)
        val newOffsetY = -(rectTop - (restingAreaHeight/newScale - rectHeight) / 2 - restingAreaTop/newScale)
        
        return Triple(newScale, newOffsetX, newOffsetY)
    }
    return null
}

@Composable
fun Flexi()
{
    Box(
        modifier = Modifier.fillMaxSize()
    )
    {
        Box(
            modifier = Modifier.fillMaxSize().background(Color.DarkGray)
        )
        {

        }
        ZoomableCanvas()
        Box(
            modifier = Modifier
                .padding(700.dp, 5.dp,5.dp, 5.dp)
                .width(600.dp)
                .fillMaxHeight()
                .border(1.dp, Color.Blue)
                .background(Color.DarkGray.copy(0.5f))

        )
        {

        }
    }
}


@Composable
fun ZoomableCanvas() {
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }
    
    var lastScale by remember { mutableStateOf(1f) }
    var lastOffsetX by remember { mutableStateOf(0f) }
    var lastOffsetY by remember { mutableStateOf(0f) }
    
    // Animation setup
    val coroutineScope = rememberCoroutineScope()
    val animationSpec = tween<Float>(
        durationMillis = 300,
        easing = FastOutSlowInEasing
    )
    
    // Create animations
    val scaleAnimation = remember { Animatable(1f) }
    val offsetXAnimation = remember { Animatable(0f) }
    val offsetYAnimation = remember { Animatable(0f) }

    // Update scale and offset from animations
    LaunchedEffect(scaleAnimation.value) {
        scale = scaleAnimation.value
    }
    LaunchedEffect(offsetXAnimation.value) {
        offsetX = offsetXAnimation.value
    }
    LaunchedEffect(offsetYAnimation.value) {
        offsetY = offsetYAnimation.value
    }

    // Resting position control (0f = start/top, 0.5f = center, 1f = end/bottom)
    val horizontalRestingAlignment = 0.01f // Change this to control horizontal resting position
    val verticalRestingAlignment = 0.5f   // Change this to control vertical resting position

    // Drawing state
    var isDrawing by remember { mutableStateOf(true) } // Start in drawing mode
    var currentPath by remember { mutableStateOf(listOf<Offset>()) }
    var showDrawing by remember { mutableStateOf(false) } // Control drawing visibility
    
    // Rectangle state
    var rectLeft by remember { mutableStateOf(100f) }
    var rectTop by remember { mutableStateOf(100f) }
    var rectWidth by remember { mutableStateOf(200f) }
    var rectHeight by remember { mutableStateOf(200f) }
    var showRectangle by remember { mutableStateOf(false) }
    
    // Track if we're interacting with the rectangle
    var isInteractingWithRect by remember { mutableStateOf(false) }
    var resizeMode by remember { mutableStateOf("") }

    val imageBitmap = ImageBitmap.imageResource(id = R.drawable.screen)

    // Constants for zoom limits
    val minScale = 0.5f
    val maxScale = 5f
    
    // Threshold for when to start transitioning to center
    val transitionThreshold = minScale * 1.5f

    // Add touch threshold and tracking variables
    val touchSlop = 8f  // Threshold for touch movement
    var initialTouchPosition by remember { mutableStateOf(Offset.Zero) }
    var hasMoved by remember { mutableStateOf(false) }

    // Add state to track two-finger gesture
    var isTwoFingerGesture by remember { mutableStateOf(false) }
    var lastTwoFingerEventTime by remember { mutableStateOf(0L) }
    val twoFingerCooldown = 200L  // Cooldown period in milliseconds

    // Add constraint width
    val constraintWidth = remember { mutableStateOf(0f) }
    
    // Add constraint check function
    fun checkRectangleConstraints(
        rectLeft: Float,
        rectWidth: Float,
        scale: Float,
        offsetX: Float
    ): Triple<Float, Float, Float>? {
        // Convert rectangle position to screen coordinates
        val screenRectLeft = rectLeft * scale + offsetX
        val screenRectRight = (rectLeft + rectWidth) * scale + offsetX

        // Check if rectangle is outside constraint width
        if (screenRectLeft < 0 || screenRectRight > constraintWidth.value) {
            // Calculate scale needed to fit rectangle within constraint width with padding
            val padding = 50f
            val newScale = (constraintWidth.value - padding * 2) / rectWidth
            
            // Calculate offset to position rectangle within constraint width
            val newOffsetX = padding - (rectLeft * newScale)
            
            // Keep vertical position
            val newOffsetY = offsetY
            
            return Triple(newScale, newOffsetX, newOffsetY)
        }
        return null
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val currentTime = System.currentTimeMillis()

                        when {
                            // Handle two-finger gestures
                            event.changes.size == 2 -> {
                                Log.d("TAGG", "double tap ---")
                                isTwoFingerGesture = true
                                lastTwoFingerEventTime = currentTime

                                val first = event.changes[0]
                                val second = event.changes[1]

                                val centroid = Offset(
                                    (first.position.x + second.position.x) / 2f,
                                    (first.position.y + second.position.y) / 2f
                                )

                                val firstPrevPos = first.previousPosition
                                val secondPrevPos = second.previousPosition

                                val prevCentroid = Offset(
                                    (firstPrevPos.x + secondPrevPos.x) / 2f,
                                    (firstPrevPos.y + secondPrevPos.y) / 2f
                                )

                                val prevDistance = (firstPrevPos - secondPrevPos).getDistance()
                                val distance = (first.position - second.position).getDistance()
                                val zoom = if (prevDistance > 0) distance / prevDistance else 1f

                                // Calculate new scale
                                val newScale = (lastScale * zoom).coerceIn(minScale, maxScale)

                                // Calculate scaled dimensions
                                val scaledWidth = imageBitmap.width * newScale
                                val scaledHeight = imageBitmap.height * newScale

                                // Calculate the focus point in image coordinates before zoom
                                val focusX = (centroid.x - offsetX) / lastScale
                                val focusY = (centroid.y - offsetY) / lastScale

                                // Calculate where that point would be after applying the new scale
                                val newFocusX = focusX * newScale
                                val newFocusY = focusY * newScale

                                // Calculate the offset needed to keep the focus point at the same screen position
                                var newOffsetX = centroid.x - newFocusX
                                var newOffsetY = centroid.y - newFocusY

                                // Apply pan
                                val pan = centroid - prevCentroid
                                newOffsetX += pan.x
                                newOffsetY += pan.y

                                // Calculate the minimum allowed X offset to keep image aligned with left side
                                var minOffsetX = if (scaledWidth <= size.width) {
                                    (size.width - scaledWidth) * horizontalRestingAlignment
                                } else {
                                    -(scaledWidth - size.width * horizontalRestingAlignment)
                                }

                                minOffsetX = -(scaledWidth - size.width * horizontalRestingAlignment)

                                if(newScale <= minScale * 1.2f)
                                    minOffsetX = (size.width - scaledWidth) * horizontalRestingAlignment

                                // Apply bounds while maintaining left alignment
                                newOffsetX = newOffsetX.coerceIn(minOffsetX, size.width * horizontalRestingAlignment)

                                // Apply vertical bounds
                                if (scaledHeight > size.height) {
                                    val maxOffsetY = (scaledHeight - size.height).coerceAtLeast(0f)
                                    newOffsetY = newOffsetY.coerceIn(-maxOffsetY, 0f)
                                } else {
                                    // Center vertically if smaller than canvas height
                                    newOffsetY = (size.height - scaledHeight) * verticalRestingAlignment
                                }

                                offsetX = newOffsetX
                                offsetY = newOffsetY
                                scale = newScale
                                lastScale = scale
                                lastOffsetX = offsetX
                                lastOffsetY = offsetY
                            }

                            // Handle single finger drag, but only if not in two-finger cooldown period
                            event.changes.size == 1 -> {
                                val timeSinceLastTwoFinger = currentTime - lastTwoFingerEventTime

                                if (!isTwoFingerGesture || timeSinceLastTwoFinger > twoFingerCooldown) {
                                    Log.d("TAG", "single tap----- $timeSinceLastTwoFinger")
                                    val change = event.changes[0]
                                    val position = change.position

                                    if (!change.pressed) {
                                        // Reset two-finger gesture state on touch up
                                        isTwoFingerGesture = false
                                    }

                                    if (change.pressed) {
                                        if (!hasMoved) {
                                            // Store initial touch position if this is a new touch
                                            if (initialTouchPosition == Offset.Zero) {
                                                initialTouchPosition = position

                                                // Check if touch is inside rectangle bounds
                                                val transformedX = (position.x - offsetX) / scale
                                                val transformedY = (position.y - offsetY) / scale

                                                val isInsideRect = transformedX in rectLeft..(rectLeft + rectWidth) &&
                                                        transformedY in rectTop..(rectTop + rectHeight)

                                                // Check if touch is on rectangle edges
                                                val edgeThreshold = 40f  // Increased from 20f for easier edge detection
                                                val onLeftEdge = transformedX in (rectLeft - edgeThreshold)..(rectLeft + edgeThreshold) &&
                                                        transformedY in rectTop..(rectTop + rectHeight)
                                                val onRightEdge = transformedX in (rectLeft + rectWidth - edgeThreshold)..(rectLeft + rectWidth + edgeThreshold) &&
                                                        transformedY in rectTop..(rectTop + rectHeight)
                                                val onTopEdge = transformedY in (rectTop - edgeThreshold)..(rectTop + edgeThreshold) &&
                                                        transformedX in rectLeft..(rectLeft + rectWidth)
                                                val onBottomEdge = transformedY in (rectTop + rectHeight - edgeThreshold)..(rectTop + rectHeight + edgeThreshold) &&
                                                        transformedX in rectLeft..(rectLeft + rectWidth)

                                                val isOnEdge = onLeftEdge || onRightEdge || onTopEdge || onBottomEdge

                                                if (isInsideRect || isOnEdge) {
                                                    // Set rectangle interaction mode
                                                    when {
                                                        // Improved corner detection
                                                        isNearCorner(transformedX, transformedY, rectLeft, rectTop) -> {
                                                            isInteractingWithRect = true
                                                            resizeMode = "topLeft"
                                                        }
                                                        isNearCorner(transformedX, transformedY, rectLeft + rectWidth, rectTop) -> {
                                                            isInteractingWithRect = true
                                                            resizeMode = "topRight"
                                                        }
                                                        isNearCorner(transformedX, transformedY, rectLeft, rectTop + rectHeight) -> {
                                                            isInteractingWithRect = true
                                                            resizeMode = "bottomLeft"
                                                        }
                                                        isNearCorner(transformedX, transformedY, rectLeft + rectWidth, rectTop + rectHeight) -> {
                                                            isInteractingWithRect = true
                                                            resizeMode = "bottomRight"
                                                        }
                                                        onLeftEdge -> { isInteractingWithRect = true; resizeMode = "left" }
                                                        onRightEdge -> { isInteractingWithRect = true; resizeMode = "right" }
                                                        onTopEdge -> { isInteractingWithRect = true; resizeMode = "top" }
                                                        onBottomEdge -> { isInteractingWithRect = true; resizeMode = "bottom" }
                                                        isInsideRect -> {
                                                            isInteractingWithRect = true
                                                            resizeMode = "move"
                                                        }
                                                    }
                                                }
                                            }

                                            // Check if touch has moved beyond threshold
                                            val movement = (position - initialTouchPosition)
                                            if (movement.getDistance() > touchSlop) {
                                                hasMoved = true

                                                if (!isInteractingWithRect) {
                                                    // Start drawing if not interacting with rectangle
                                                    isDrawing = true
                                                    currentPath = listOf(Offset(
                                                        (position.x - offsetX) / scale,
                                                        (position.y - offsetY) / scale
                                                    ))
//                                                    showRectangle = false
                                                    showDrawing = true
                                                }
                                            }
                                        } else {
                                            // Handle continued movement
                                            if (isDrawing) {
                                                // Add point to drawing path
                                                currentPath = currentPath + Offset(
                                                    (position.x - offsetX) / scale,
                                                    (position.y - offsetY) / scale
                                                )
                                            } else if (isInteractingWithRect) {
                                                // Handle rectangle drag/resize
                                                val dragX = (position.x - change.previousPosition.x) / scale
                                                val dragY = (position.y - change.previousPosition.y) / scale

                                                when (resizeMode) {
                                                    "move" -> {
                                                        rectLeft = (rectLeft + dragX)
                                                            .coerceIn(0f, imageBitmap.width - rectWidth)
                                                        rectTop = (rectTop + dragY)
                                                            .coerceIn(0f, imageBitmap.height - rectHeight)
                                                    }
                                                    "topLeft", "topRight", "bottomLeft", "bottomRight", "left", "right", "top", "bottom" -> {
                                                        // Original resize logic
                                                        when (resizeMode) {
                                                            "topLeft" -> {
                                                                val newLeft = (rectLeft + dragX).coerceIn(0f, rectLeft + rectWidth - 50f)
                                                                val newTop = (rectTop + dragY).coerceIn(0f, rectTop + rectHeight - 50f)
                                                                rectWidth += (rectLeft - newLeft)
                                                                rectHeight += (rectTop - newTop)
                                                                rectLeft = newLeft
                                                                rectTop = newTop
                                                            }
                                                            "topRight" -> {
                                                                val newTop = (rectTop + dragY).coerceIn(0f, rectTop + rectHeight - 50f)
                                                                rectWidth = (rectWidth + dragX).coerceIn(50f, imageBitmap.width - rectLeft)
                                                                rectHeight += (rectTop - newTop)
                                                                rectTop = newTop
                                                            }
                                                            "bottomLeft" -> {
                                                                val newLeft = (rectLeft + dragX).coerceIn(0f, rectLeft + rectWidth - 50f)
                                                                rectWidth += (rectLeft - newLeft)
                                                                rectLeft = newLeft
                                                                rectHeight = (rectHeight + dragY).coerceIn(50f, imageBitmap.height - rectTop)
                                                            }
                                                            "bottomRight" -> {
                                                                rectWidth = (rectWidth + dragX).coerceIn(50f, imageBitmap.width - rectLeft)
                                                                rectHeight = (rectHeight + dragY).coerceIn(50f, imageBitmap.height - rectTop)
                                                            }
                                                            "left" -> {
                                                                val newLeft = (rectLeft + dragX).coerceIn(0f, rectLeft + rectWidth - 50f)
                                                                rectWidth += (rectLeft - newLeft)
                                                                rectLeft = newLeft
                                                            }
                                                            "right" -> {
                                                                rectWidth = (rectWidth + dragX).coerceIn(50f, imageBitmap.width - rectLeft)
                                                            }
                                                            "top" -> {
                                                                val newTop = (rectTop + dragY).coerceIn(0f, rectTop + rectHeight - 50f)
                                                                rectHeight += (rectTop - newTop)
                                                                rectTop = newTop
                                                            }
                                                            "bottom" -> {
                                                                rectHeight = (rectHeight + dragY).coerceIn(50f, imageBitmap.height - rectTop)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        // Touch ended
                                        if (isDrawing && hasMoved) {
                                            // Finish drawing
                                            if (currentPath.isNotEmpty()) {
                                                // Calculate bounds of current drawing
                                                var minX = Float.POSITIVE_INFINITY
                                                var minY = Float.POSITIVE_INFINITY
                                                var maxX = Float.NEGATIVE_INFINITY
                                                var maxY = Float.NEGATIVE_INFINITY

                                                currentPath.forEach { point ->
                                                    minX = minOf(minX, point.x)
                                                    minY = minOf(minY, point.y)
                                                    maxX = maxOf(maxX, point.x)
                                                    maxY = maxOf(maxY, point.y)
                                                }

                                                // Check if drawing is completely outside the image
                                                val isCompletelyOutside = minX > imageBitmap.width || maxX < 0 ||
                                                        minY > imageBitmap.height || maxY < 0

                                                // Calculate area of the drawn region
                                                val drawnArea = (maxX - minX) * (maxY - minY)
                                                Log.d("TAGG", "$drawnArea ----")
                                                val minimumArea = 5000f

                                                if (!isCompletelyOutside && drawnArea >= minimumArea) {
                                                    // Clip bounds to image dimensions
                                                    val clippedLeft = minX.coerceIn(0f, imageBitmap.width.toFloat())
                                                    val clippedTop = minY.coerceIn(0f, imageBitmap.height.toFloat())
                                                    val clippedRight = maxX.coerceIn(0f, imageBitmap.width.toFloat())
                                                    val clippedBottom = maxY.coerceIn(0f, imageBitmap.height.toFloat())

                                                    // Set rectangle bounds to clipped drawing bounds
                                                    rectLeft = clippedLeft
                                                    rectTop = clippedTop
                                                    rectWidth = clippedRight - clippedLeft
                                                    rectHeight = clippedBottom - clippedTop

                                                    // Check if rectangle needs view adjustment
                                                    ensureRectInView(
                                                        rectLeft, rectTop, rectWidth, rectHeight,
                                                        size.width.toFloat(), size.height.toFloat(),
                                                        offsetX, offsetY,
                                                        scale,
                                                        imageBitmap,
                                                        minScale
                                                    )?.let { (newScale, newOffsetX, newOffsetY) ->
                                                        // Start animations with longer duration for smoother effect
                                                        coroutineScope.launch {
                                                            launch {
                                                                scaleAnimation.snapTo(scale)
                                                                scaleAnimation.animateTo(
                                                                    targetValue = newScale,
                                                                    animationSpec = tween(
                                                                        durationMillis = 500,
                                                                        easing = FastOutSlowInEasing
                                                                    )
                                                                )
                                                            }
                                                            launch {
                                                                offsetXAnimation.snapTo(offsetX)
                                                                offsetXAnimation.animateTo(
                                                                    targetValue = newOffsetX * newScale,
                                                                    animationSpec = tween(
                                                                        durationMillis = 500,
                                                                        easing = FastOutSlowInEasing
                                                                    )
                                                                )
                                                            }
                                                            launch {
                                                                offsetYAnimation.snapTo(offsetY)
                                                                offsetYAnimation.animateTo(
                                                                    targetValue = newOffsetY * newScale,
                                                                    animationSpec = tween(
                                                                        durationMillis = 500,
                                                                        easing = FastOutSlowInEasing
                                                                    )
                                                                )
                                                            }
                                                        }

                                                        lastScale = newScale
                                                        lastOffsetX = newOffsetX * newScale
                                                        lastOffsetY = newOffsetY * newScale
                                                    }
                                                }
                                                // else: drawing is completely outside or too small, keep previous rectangle position

                                                // Show rectangle
                                                showRectangle = true
                                                // Clear drawing and exit drawing mode
                                                currentPath = listOf()
                                                showDrawing = false
                                                isDrawing = false
                                            }
                                        }

                                        // Check for zoom adjustment when touch ends and we were resizing/moving
                                        if (isInteractingWithRect) {
                                            // First check if rectangle is within constraint width
                                            checkRectangleConstraints(
                                                rectLeft, rectWidth, scale, offsetX
                                            )?.let { (newScale, newOffsetX, newOffsetY) ->
                                                coroutineScope.launch {
                                                    launch {
                                                        scaleAnimation.snapTo(scale)
                                                        scaleAnimation.animateTo(
                                                            targetValue = newScale,
                                                            animationSpec = tween(
                                                                durationMillis = 400,
                                                                easing = FastOutSlowInEasing
                                                            )
                                                        )
                                                    }
                                                    launch {
                                                        offsetXAnimation.snapTo(offsetX)
                                                        offsetXAnimation.animateTo(
                                                            targetValue = newOffsetX,
                                                            animationSpec = tween(
                                                                durationMillis = 400,
                                                                easing = FastOutSlowInEasing
                                                            )
                                                        )
                                                    }
                                                    launch {
                                                        offsetYAnimation.snapTo(offsetY)
                                                        offsetYAnimation.animateTo(
                                                            targetValue = newOffsetY,
                                                            animationSpec = tween(
                                                                durationMillis = 400,
                                                                easing = FastOutSlowInEasing
                                                            )
                                                        )
                                                    }
                                                }
                                                
                                                lastScale = newScale
                                                lastOffsetX = newOffsetX
                                                lastOffsetY = newOffsetY
                                            } ?: run {
                                                // Only check edge adjustment if rectangle is within constraint width
                                                checkAndAdjustZoom(
                                                    rectLeft, rectTop, rectWidth, rectHeight,
                                                    size.width / scale, size.height / scale,
                                                    offsetX / scale, offsetY / scale,
                                                    scale
                                                )?.let { (newScale, newOffsetX, newOffsetY) ->
                                                    // ... existing animation code ...
                                                }
                                            }
                                        }

                                        // Reset touch tracking
                                        initialTouchPosition = Offset.Zero
                                        hasMoved = false
                                        isInteractingWithRect = false
                                        resizeMode = ""
                                    }
                                }
                            }

                            // Reset two-finger state when no touches are detected
                            event.changes.isEmpty() -> {
                                isTwoFingerGesture = false
                                // Show rectangle
                                showRectangle = true
                                // Clear drawing and exit drawing mode
                                currentPath = listOf()
                                showDrawing = false
                                isDrawing = false

                                // Reset touch tracking
                                initialTouchPosition = Offset.Zero
                                hasMoved = false
                                isInteractingWithRect = false
                                resizeMode = ""
                            }
                        }
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Set constraint width here where we have access to size
            if (constraintWidth.value == 0f) {
                constraintWidth.value = size.width * 0.5f
            }

            with(drawContext.canvas.nativeCanvas) {
                save()

                translate(offsetX, offsetY)
                scale(scale, scale)

                // Draw the image
                drawImage(
                    imageBitmap,
                    dstSize = IntSize(imageBitmap.width.toInt(), imageBitmap.height.toInt()),
                    dstOffset = IntOffset(0, 0)
                )

                // Draw current path only while drawing
                if (showDrawing && currentPath.size > 1) {
                    for (i in 0 until currentPath.size - 1) {
                        drawLine(
                            color = Color(0xFFFF0000), // Bright red color
                            start = currentPath[i],
                            end = currentPath[i + 1],
                            strokeWidth = 16f  // Thicker lines
                        )
                    }
                }

                // Draw selection rectangle when not drawing
                if (showRectangle) {
                    // Create a path for clipping
                    val insideClipPath = Path().apply {
                        addRoundRect(
                            androidx.compose.ui.geometry.RoundRect(
                                left = rectLeft,
                                top = rectTop,
                                right = rectLeft + rectWidth,
                                bottom = rectTop + rectHeight,
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f)
                            )
                        )
                    }

                    val outTreshold = 150f
                    val outsideClipPath = Path().apply {
                        addRoundRect(
                            androidx.compose.ui.geometry.RoundRect(
                                left = rectLeft-outTreshold,
                                top = rectTop-outTreshold,
                                right = rectLeft + rectWidth + outTreshold,
                                bottom = rectTop + rectHeight + outTreshold,
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(100f)
                            )
                        )
                    }

                    clipPath(
                        path = outsideClipPath,
                    ) {
                        // Draw outer glow/dispersion effect
                        clipPath(
                            path = insideClipPath,
                            clipOp = androidx.compose.ui.graphics.ClipOp.Difference
                        ) {
                            for (i in 15 downTo 1) {
                                val expansion = i * 8f
                                val alpha = 0.015f * (1f / i) * 8  // Increased intensity for better visibility

                                drawRoundRect(
                                    color = Color(0.85f, 0.9f, 1f, alpha),
                                    topLeft = Offset(rectLeft - expansion, rectTop - expansion),
                                    size = androidx.compose.ui.geometry.Size(rectWidth + expansion * 2, rectHeight + expansion * 2),
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f)
                                )
                            }
                        }
                    }

                    // Draw corner handles
                    val cornerLength = 35f  // Length of each corner segment
                    val cornerThickness = 8f // Thickness for more visibility
                    val cornerRadius = 4f   // Consistent corner radius
                    
                    val corners = listOf(
                        Triple(Offset(rectLeft, rectTop), 0f, 0f), // Top-left
                        Triple(Offset(rectLeft + rectWidth, rectTop), -cornerLength, 0f), // Top-right
                        Triple(Offset(rectLeft, rectTop + rectHeight), 0f, -cornerLength), // Bottom-left
                        Triple(Offset(rectLeft + rectWidth, rectTop + rectHeight), -cornerLength, -cornerLength) // Bottom-right
                    )

                    corners.forEach { (position, xOffset, yOffset) ->
                        // Create path for L-shaped corner with proper rounding
                        val cornerPath = Path().apply {
                            if (xOffset == 0f && yOffset == 0f) {  // Top-left
                                moveTo(position.x, position.y + cornerLength - cornerRadius)
                                lineTo(position.x, position.y + cornerRadius)
                                quadraticBezierTo(
                                    position.x, position.y,
                                    position.x + cornerRadius, position.y
                                )
                                lineTo(position.x + cornerLength - cornerRadius, position.y)
                                quadraticBezierTo(
                                    position.x + cornerLength, position.y,
                                    position.x + cornerLength, position.y + cornerRadius
                                )
                            } else if (xOffset < 0f && yOffset == 0f) {  // Top-right
                                moveTo(position.x, position.y + cornerLength - cornerRadius)
                                lineTo(position.x, position.y + cornerRadius)
                                quadraticBezierTo(
                                    position.x, position.y,
                                    position.x - cornerRadius, position.y
                                )
                                lineTo(position.x - cornerLength + cornerRadius, position.y)
                                quadraticBezierTo(
                                    position.x - cornerLength, position.y,
                                    position.x - cornerLength, position.y + cornerRadius
                                )
                            } else if (xOffset == 0f && yOffset < 0f) {  // Bottom-left
                                moveTo(position.x, position.y - cornerLength + cornerRadius)
                                lineTo(position.x, position.y - cornerRadius)
                                quadraticBezierTo(
                                    position.x, position.y,
                                    position.x + cornerRadius, position.y
                                )
                                lineTo(position.x + cornerLength - cornerRadius, position.y)
                                quadraticBezierTo(
                                    position.x + cornerLength, position.y,
                                    position.x + cornerLength, position.y - cornerRadius
                                )
                            } else {  // Bottom-right
                                moveTo(position.x, position.y - cornerLength + cornerRadius)
                                lineTo(position.x, position.y - cornerRadius)
                                quadraticBezierTo(
                                    position.x, position.y,
                                    position.x - cornerRadius, position.y
                                )
                                lineTo(position.x - cornerLength + cornerRadius, position.y)
                                quadraticBezierTo(
                                    position.x - cornerLength, position.y,
                                    position.x - cornerLength, position.y - cornerRadius
                                )
                            }
                        }
                        
                        // Draw the corner with proper stroke width
                        drawPath(
                            path = cornerPath,
                            color = Color.White,
                            style = Stroke(width = cornerThickness)
                        )
                    }
                }

                restore()
            }
        }
    }
}