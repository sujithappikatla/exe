package com.example.dashboardui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dashboardui.ui.theme.DashboardUITheme

// Custom colors matching the image
object CustomColors {
    val LightBlue = Color(0xFF4A90E2)
    val BackgroundGray = Color(0xFFF5F5F5)
    val TextGray = Color(0xFF666666)
    val SelectedBlue = Color(0xFFE3F2FD)
    val BorderGray = Color(0xFFE0E0E0)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DashboardUITheme {
                DashboardScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    var selectedClass by remember { mutableStateOf("Solar system") }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CustomColors.BackgroundGray)
    ) {
        // Top App Bar
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Dashboard",
                        tint = CustomColors.LightBlue
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Dashboard", color = CustomColors.LightBlue)
                }
            },
            actions = {
                Text("Country US", color = CustomColors.TextGray)
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = { /* Handle close */ }) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Close",
                        tint = CustomColors.TextGray
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.White
            )
        )

        // Main Content
        Row(modifier = Modifier.fillMaxSize()) {
            // Left Panel - Classes
            ClassesPanel(
                modifier = Modifier
                    .width(240.dp)
                    .fillMaxHeight()
                    .padding(16.dp),
                selectedClass = selectedClass,
                onClassSelected = { selectedClass = it }
            )

            // Right Panel - Transcript/Summary
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Tabs
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = Color.White,
                        contentColor = CustomColors.LightBlue
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("Transcript") }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("Summary") }
                        )
                    }

                    when (selectedTab) {
                        0 -> TranscriptContent()
                        1 -> SummaryContent()
                    }
                }
            }
        }
    }
}

@Composable
fun ClassesPanel(
    modifier: Modifier = Modifier,
    selectedClass: String,
    onClassSelected: (String) -> Unit
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Grade and Subject Dropdowns
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                DropdownSection("Grade", "6th")
                DropdownSection("Subject", "Geography")
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            Text("Classes", 
                fontWeight = FontWeight.Bold,
                color = CustomColors.TextGray
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Class List
            val classes = listOf(
                ClassItem("Earth", "12.03.24"),
                ClassItem("Sun", "11.20.24"),
                ClassItem("Moon", "10.22.24"),
                ClassItem("Solar system", "09.13.24")
            )
            
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(classes) { classItem ->
                    ClassListItem(
                        classItem = classItem,
                        isSelected = classItem.name == selectedClass,
                        onClick = { onClassSelected(classItem.name) }
                    )
                }
            }
        }
    }
}

@Composable
fun DropdownSection(label: String, value: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .border(1.dp, CustomColors.BorderGray, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Text(
            "$label: $value",
            color = CustomColors.TextGray,
            fontSize = 14.sp
        )
        Icon(
            Icons.Default.ArrowDropDown,
            contentDescription = null,
            tint = CustomColors.TextGray
        )
    }
}

@Composable
fun ClassListItem(
    classItem: ClassItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .clickable(onClick = onClick),
        color = if (isSelected) CustomColors.SelectedBlue else Color.White
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                classItem.name,
                color = if (isSelected) CustomColors.LightBlue else CustomColors.TextGray
            )
            Text(
                classItem.date,
                color = CustomColors.TextGray,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun TranscriptContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "Transcript will appear here",
            color = CustomColors.TextGray
        )
    }
}

@Composable
fun SummaryContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Audio Player
        AudioPlayer()
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Summary Content
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "Scale of the solar system: Exploring Distance, Sizes and Solar Prominences",
                fontWeight = FontWeight.Bold,
                color = CustomColors.TextGray,
                fontSize = 18.sp
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Timeline Items
            TimelineItem("00:00", "1. The Immensity of Space", 
                "The vast distances between celestial bodies emphasize the enormous scale of space, including solar phenomena like prominences that highlight the Sun's massive energy.")
            
            TimelineItem("04:22", "Circle To Search - Solar Prominence",
                "In solar physics, a prominence is a large structure of plasma and magnetic fields extending from the Sun's surface.")
            
            TimelineItem("08:22", "2. Comparing Planetary Sizes",
                "The planets vary significantly in size, from the massive scale of Jupiter to the much smaller Mercury.")
            
            TimelineItem("08:34", "3. Scale Models of the Solar System", "")
        }
        
        // Bottom Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { /* Handle delete */ },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = CustomColors.TextGray
                ),
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Delete Summary", fontSize = 14.sp)
            }
            
            Button(
                onClick = { /* Handle share */ },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = CustomColors.TextGray
                )
            ) {
                Icon(
                    Icons.Default.Share,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Share summary", fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun AudioPlayer() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CustomColors.BorderGray)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { /* Handle play/pause */ }) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = CustomColors.LightBlue
                )
            }
            
            Slider(
                value = 0.5f,
                onValueChange = { /* Handle progress change */ },
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = CustomColors.LightBlue,
                    activeTrackColor = CustomColors.LightBlue
                )
            )
            
            Text(
                "15:02 / 49:09",
                color = CustomColors.TextGray,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            
            IconButton(onClick = { /* Handle volume */ }) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Volume",
                    tint = CustomColors.LightBlue
                )
            }
        }
    }
}

@Composable
fun TimelineItem(time: String, title: String, description: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            time,
            modifier = Modifier.width(48.dp),
            color = CustomColors.LightBlue,
            fontSize = 14.sp
        )
        Column {
            Text(
                title,
                fontWeight = FontWeight.Bold,
                color = CustomColors.TextGray
            )
            if (description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    description,
                    color = CustomColors.TextGray,
                    fontSize = 14.sp
                )
            }
        }
    }
}

data class ClassItem(
    val name: String,
    val date: String
)