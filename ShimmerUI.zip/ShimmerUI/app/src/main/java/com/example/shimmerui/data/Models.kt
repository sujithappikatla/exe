package com.example.shimmerui.data

// Image Search Models
data class ImageSearchRequest(
    val query: String,
    val gl: String? = null,
    val lr: String? = null,
    val num: Int? = 10,
    val safe: Boolean? = true,
    val start: Int? = 1,
    val image_size: String? = null,
    val image_type: String? = null,
    val image_color: String? = null
)

data class ImageSearchResponse(
    val success: Boolean,
    val data: List<ImageItem>,
    val status_code: Int
)

data class ImageItem(
    val title: String,
    val image_url: String,
    val context_url: String,
    val height: Int,
    val width: Int
)

// Gemini Streaming Models
data class GeminiExplainRequest(
    val analysis: String
)

data class GeminiExplainResponse(
    val content: String,
    val rendered_content: String,
    val citations: List<Citation>
)

data class Citation(
    val title: String,
    val uri: String
)

// App UI States
sealed class ImageLoadState {
    object Loading : ImageLoadState()
    data class Success(val images: List<ImageItem>) : ImageLoadState()
    data class Error(val message: String) : ImageLoadState()
}

sealed class AiInsightState {
    object Idle : AiInsightState()
    object Loading : AiInsightState()
    data class Streaming(val content: String) : AiInsightState()
    data class Success(val content: String, val citations: List<Citation>) : AiInsightState()
    data class Error(val message: String) : AiInsightState()
} 