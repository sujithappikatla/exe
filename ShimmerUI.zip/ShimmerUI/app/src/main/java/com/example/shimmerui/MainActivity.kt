package com.example.shimmerui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.shimmerui.ui.MainViewModel
import com.example.shimmerui.ui.components.AiInsights
import com.example.shimmerui.ui.components.ImageGallery
import com.example.shimmerui.ui.components.SearchBox
import com.example.shimmerui.ui.theme.ShimmerUITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ShimmerUITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: MainViewModel = viewModel()) {
    val queryText by viewModel.queryText.collectAsState()
    val imageState by viewModel.imageLoadState.collectAsState()
    val aiInsightState by viewModel.aiInsightState.collectAsState()
    
    val scrollState = rememberScrollState()
    
    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // Search Box
            SearchBox(
                query = queryText,
                onQueryChange = viewModel::updateQuery,
                onSearch = viewModel::search
            )
            
            // Image Gallery
            ImageGallery(imageState = imageState)
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // AI Insights
            AiInsights(insightState = aiInsightState)
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    ShimmerUITheme {
        MainScreen()
    }
}