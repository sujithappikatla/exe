package com.example.shimmerui.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.shimmerui.data.AiInsightState
import com.example.shimmerui.data.ImageLoadState
import com.example.shimmerui.data.Repository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val repository = Repository()
    
    private val _queryText = MutableStateFlow("")
    val queryText: StateFlow<String> = _queryText
    
    private val _imageLoadState = MutableStateFlow<ImageLoadState>(ImageLoadState.Loading)
    val imageLoadState: StateFlow<ImageLoadState> = _imageLoadState
    
    private val _aiInsightState = MutableStateFlow<AiInsightState>(AiInsightState.Idle)
    val aiInsightState: StateFlow<AiInsightState> = _aiInsightState
    
    fun updateQuery(query: String) {
        _queryText.value = query
    }
    
    fun search() {
        val query = queryText.value
        if (query.isBlank()) return
        
        // Start searching for images
        viewModelScope.launch {
            repository.searchImages(query).collect { state ->
                _imageLoadState.value = state
            }
        }
        
        // Start getting AI insights
        viewModelScope.launch {
            repository.getAiInsights(query).collect { state ->
                _aiInsightState.value = state
            }
        }
    }
    
    fun resetSearch() {
        _imageLoadState.value = ImageLoadState.Loading
        _aiInsightState.value = AiInsightState.Idle
    }
} 