package com.example.shimmerui.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImagePainter
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import coil.request.ImageRequest
import com.example.shimmerui.data.ImageItem
import com.example.shimmerui.data.ImageLoadState

@Composable
fun ImageGallery(
    imageState: ImageLoadState,
    modifier: Modifier = Modifier
) {
    when (imageState) {
        is ImageLoadState.Loading -> {
            LoadingImageGallery(modifier)
        }
        is ImageLoadState.Success -> {
            if (imageState.images.isEmpty()) {
                EmptyImageResult(modifier)
            } else {
                SuccessImageGallery(images = imageState.images, modifier = modifier)
            }
        }
        is ImageLoadState.Error -> {
            ErrorImageGallery(message = imageState.message, modifier = modifier)
        }
    }
}

@Composable
fun LoadingImageGallery(modifier: Modifier = Modifier) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        item {
            ShimmerImageItem(
                modifier = Modifier
                    .width(200.dp)
                    .height(150.dp)
            )
        }
        
        item {
            Spacer(modifier = Modifier.width(8.dp))
            ShimmerImageItem(
                modifier = Modifier
                    .width(100.dp)
                    .height(100.dp)
            )
        }
        
        item {
            Spacer(modifier = Modifier.width(8.dp))
            ShimmerImageItem(
                modifier = Modifier
                    .width(100.dp)
                    .height(100.dp)
            )
        }
    }
}

@Composable
fun SuccessImageGallery(
    images: List<ImageItem>,
    modifier: Modifier = Modifier
) {
    var showMoreImages by remember { mutableStateOf(false) }
    
    Column(modifier = modifier.fillMaxWidth()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Show all images if showMoreImages is true, otherwise just the first 5
            val imagesToShow = if (showMoreImages) images else images.take(5)
            
            items(imagesToShow) { image ->
                val imageRatio = image.width.toFloat() / image.height.toFloat()
                
                Box(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .width(if (image == imagesToShow.first()) 200.dp else 100.dp)
                        .height(if (image == imagesToShow.first()) 150.dp else 100.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.LightGray.copy(alpha = 0.2f))
                ) {
                    GalleryImage(
                        imageUrl = image.image_url,
                        contentDescription = image.title
                    )
                }
            }
            
            // Show "Show More Images" button if there are more than 5 images and not already showing all
            if (images.size > 5 && !showMoreImages) {
                item {
                    Box(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .width(100.dp)
                            .height(100.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        TextButton(onClick = { showMoreImages = true }) {
                            Text(
                                text = "Show More Images",
                                style = MaterialTheme.typography.labelMedium,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GalleryImage(
    imageUrl: String,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    SubcomposeAsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(imageUrl)
            .crossfade(true)
            .build(),
        contentDescription = contentDescription,
        modifier = modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
    ) {
        val state = painter.state
        if (state is AsyncImagePainter.State.Loading || state is AsyncImagePainter.State.Error) {
            if (state is AsyncImagePainter.State.Loading) {
                ShimmerImageItem(modifier = Modifier.fillMaxSize())
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.BrokenImage,
                        contentDescription = "Image failed to load",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        } else {
            SubcomposeAsyncImageContent()
        }
    }
}

@Composable
fun EmptyImageResult(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(150.dp)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Image,
                contentDescription = "No images found",
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "No images found",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
fun ErrorImageGallery(
    message: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(150.dp)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.BrokenImage,
                contentDescription = "Error loading images",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Error loading images",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.error
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                textAlign = TextAlign.Center
            )
        }
    }
} 