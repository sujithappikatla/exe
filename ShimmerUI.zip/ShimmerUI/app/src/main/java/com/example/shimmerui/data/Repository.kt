package com.example.shimmerui.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import java.io.BufferedReader
import java.io.InputStreamReader

class Repository {
    private val apiService = NetworkClient.apiService
    private val gson = NetworkClient.gson
    
    suspend fun searchImages(query: String): Flow<ImageLoadState> = flow {
        emit(ImageLoadState.Loading)
        try {
            val response = apiService.searchImages(ImageSearchRequest(query = query))
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                if (body.success) {
                    emit(ImageLoadState.Success(body.data))
                } else {
                    emit(ImageLoadState.Error("Failed to load images: ${body.status_code}"))
                }
            } else {
                emit(ImageLoadState.Error("Error: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            emit(ImageLoadState.Error("Error: ${e.message}"))
        }
    }.flowOn(Dispatchers.IO)
    
    suspend fun getAiInsights(query: String): Flow<AiInsightState> = flow {
        emit(AiInsightState.Loading)
        try {
            val response = apiService.getAiInsightsStream(GeminiExplainRequest(analysis = query))
            if (response.isSuccessful && response.body() != null) {
                // Process the streaming response
                val reader = BufferedReader(InputStreamReader(response.body()!!.byteStream()))
                var line: String?
                var finalChunk: GeminiExplainResponse? = null
                
                while (reader.readLine().also { line = it } != null) {
                    line?.let {
                        if (it.isNotBlank()) {
                            try {
                                val chunk = gson.fromJson(it, GeminiExplainResponse::class.java)
                                if (chunk.rendered_content.isNotEmpty() || chunk.citations.isNotEmpty()) {
                                    // This is the final chunk with all metadata
                                    finalChunk = chunk
                                }
                                emit(AiInsightState.Streaming(chunk.content))
                            } catch (e: Exception) {
                                // Skip malformed JSON
                            }
                        }
                    }
                }
                
                // If we received a final chunk with complete data, emit it as a success state
                finalChunk?.let {
                    emit(AiInsightState.Success(it.content, it.citations))
                } ?: emit(AiInsightState.Success("", emptyList())) // Fallback if no final chunk
                
            } else {
                emit(AiInsightState.Error("Error: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            emit(AiInsightState.Error("Error: ${e.message}"))
        }
    }.flowOn(Dispatchers.IO)
} 