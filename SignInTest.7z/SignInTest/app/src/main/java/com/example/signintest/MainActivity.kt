package com.example.signintest

import LocalAuthServer
import UserAccount
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.signintest.ui.theme.SignInTestTheme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import android.net.Uri
import android.content.pm.PackageManager
import androidx.browser.customtabs.CustomTabsIntent
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import android.util.Log
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: AuthViewModel
    private var localServer: LocalAuthServer? = null

    private val clientId = "827241926711-qbb4o092cpenpd9ohrdip7ub5ak2sg9k.apps.googleusercontent.com"
    private val clientSecret = "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"
    private val redirectUri = "http://localhost:8080/oauth2callback"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // lifecycleScope.launch {

        //         Log.d("OAuth", "Starting sign-in process")

        //         withContext(Dispatchers.IO) {
        //             startLocalServer()
        //         }
        //     }

        setContent {
            SignInTestTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    viewModel = viewModel()
                    viewModel.startAuthServer(LocalContext.current)
                    AuthScreen(
                        onSignInClick = { signIn() },
                        onSignOutClick = { signOut() }
                    )
                }
            }
        }
    }

    private fun startLocalServer() {
        try {
            if (localServer != null) {
                Log.d("Server", "Stopping existing server")
                stopLocalServer()
            }

            Log.d("Server", "Creating new server instance")
            localServer = LocalAuthServer { authCode ->
                Log.d("OAuth", "Received auth code: $authCode")
                lifecycleScope.launch(Dispatchers.IO) {
                    exchangeCodeForToken(authCode)
                }
            }

            localServer?.start()
            Log.d("Server", "Server started successfully")
            
        } catch (e: Exception) {
            Log.e("Server", "Server initialization failed", e)
            throw e
        }
    }

    private fun signIn() {
        lifecycleScope.launch {
            try {
                Log.d("OAuth", "Starting sign-in process")
                


                val state = generateRandomState()
                val oauthUrl = "https://accounts.google.com/o/oauth2/v2/auth?" +
                        "client_id=$clientId" +
                        "&redirect_uri=${Uri.encode(redirectUri)}" +
                        "&response_type=code" +
                        "&scope=${Uri.encode("email profile openid")}" +
                        "&access_type=offline" +
                        "&prompt=select_account" +  // Force account picker
                        "&state=$state"

                Log.d("OAuth", "Authorization URL: $oauthUrl")

                // Launch in Chrome Custom Tab
                val builder = CustomTabsIntent.Builder().apply {
                    setShowTitle(true)
                    setUrlBarHidingEnabled(false)
                }
                
                val customTabsIntent = builder.build().apply {
                    // Add these flags to ensure proper launching
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                
                withContext(Dispatchers.Main) {
                    try {
                        customTabsIntent.launchUrl(this@MainActivity, Uri.parse(oauthUrl))
                        Log.d("OAuth", "Browser launched successfully")
                    } catch (e: Exception) {
                        Log.e("OAuth", "Failed to launch browser", e)
                        throw e
                    }
                }
                
            } catch (e: Exception) {
                Log.e("OAuth", "Sign in process failed", e)
                stopLocalServer()
                viewModel.onSignInError()
            }
        }
    }

    private suspend fun exchangeCodeForToken(code: String) {
        try {
            Log.d("OAuth", "Starting code exchange...")

            val url = URL("https://oauth2.googleapis.com/token")
            val connection = url.openConnection() as HttpURLConnection

            val postData = Uri.Builder()
                .appendQueryParameter("code", code)
                .appendQueryParameter("client_id", clientId)
                .appendQueryParameter("client_secret", clientSecret)
                .appendQueryParameter("redirect_uri", redirectUri)
                .appendQueryParameter("grant_type", "authorization_code")
                .build()
                .getQuery()

            connection.apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                setRequestProperty("Accept", "application/json")
            }

            connection.outputStream.use { os ->
                if (postData != null) {
                    os.write(postData.toByteArray())
                }
            }

            val responseCode = connection.responseCode
            Log.d("OAuth", "Token exchange response code: $responseCode")

            if (responseCode == HttpURLConnection.HTTP_OK) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                Log.d("OAuth", "Token exchange response: $response")

                val jsonObject = JSONObject(response)
                val accessToken = jsonObject.getString("access_token")
                fetchUserInfo(accessToken)
            } else {
                val error = connection.errorStream?.bufferedReader()?.use { it.readText() }
                Log.e("OAuth", "Token exchange error: $error")
                withContext(Dispatchers.Main) {
                    viewModel.onSignInError()
                }
            }
        } catch (e: Exception) {
            Log.e("OAuth", "Token exchange exception", e)
            withContext(Dispatchers.Main) {
                viewModel.onSignInError()
            }
        }
    }

    private suspend fun fetchUserInfo(accessToken: String) {
        try {
            Log.d("OAuth", "Fetching user info...")
            val url = URL("https://www.googleapis.com/oauth2/v3/userinfo")
            val connection = url.openConnection() as HttpURLConnection
            connection.apply {
                requestMethod = "GET"
                setRequestProperty("Authorization", "Bearer $accessToken")
            }

            val responseCode = connection.responseCode
            Log.d("OAuth", "User info response code: $responseCode")

            if (responseCode == HttpURLConnection.HTTP_OK) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                Log.d("OAuth", "User info response: $response")

                val jsonObject = JSONObject(response)
                val name = jsonObject.optString("name")
                val email = jsonObject.optString("email")

                withContext(Dispatchers.Main) {
                    val userAccount = UserAccount(
                        displayName = name,
                        email = email
                    )
                    viewModel.onSignInSuccess(userAccount)
                }
            } else {
                val error = connection.errorStream?.bufferedReader()?.use { it.readText() }
                Log.e("OAuth", "User info error: $error")
                withContext(Dispatchers.Main) {
                    viewModel.onSignInError()
                }
            }
        } catch (e: Exception) {
            Log.e("OAuth", "User info exception", e)
            withContext(Dispatchers.Main) {
                viewModel.onSignInError()
            }
        }
    }

    private fun stopLocalServer() {
        localServer?.stop()
        localServer = null
        Log.d("Server", "Local server stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLocalServer()
    }

    companion object {
        private const val SOCKET_READ_TIMEOUT = 180000 // 3 minutes
    }

    private fun generateRandomState(): String {
        return UUID.randomUUID().toString()
    }

    private fun signOut() {
        viewModel.onSignOut()
    }

    private fun launchBrowser(url: String) {
        val builder = CustomTabsIntent.Builder().apply {
            setShowTitle(true)
        }
        val customTabsIntent = builder.build()
        
        try {
            customTabsIntent.launchUrl(this@MainActivity, Uri.parse(url))
            Log.d("OAuth", "Browser launched successfully")
        } catch (e: Exception) {
            Log.e("OAuth", "Failed to launch browser", e)
            stopLocalServer()
            viewModel.onSignInError()
        }
    }
}
