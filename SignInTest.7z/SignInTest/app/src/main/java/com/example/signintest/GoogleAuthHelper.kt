package com.example.signintest

import UserAccount
import android.util.Log
import com.google.api.client.auth.oauth2.TokenResponse
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

class GoogleAuthHelper {
    companion object {
        private val CLIENT_ID = "827241926711-qbb4o092cpenpd9ohrdip7ub5ak2sg9k.apps.googleusercontent.com"
        private val CLIENT_SECRET = "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"

        private const val REDIRECT_URI = "http://localhost:8080/oauth2callback"
        
        suspend fun getUserInfo(authCode: String): UserAccount? = withContext(Dispatchers.IO) {
            try {
                // Exchange auth code for token
                val tokenResponse = exchangeAuthCode(authCode)
                
                // Use access token to get user info
                val userInfo = fetchUserInfo(tokenResponse.accessToken)
                
                return@withContext UserAccount(
                    displayName = userInfo.getString("name"),
                    email = userInfo.getString("email")
                )
            } catch (e: Exception) {
                Log.e("GoogleAuthHelper", "Error getting user info", e)
                return@withContext null
            }
        }

        private fun exchangeAuthCode(authCode: String): TokenResponse {
            return GoogleAuthorizationCodeTokenRequest(
                NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                "https://oauth2.googleapis.com/token",
                CLIENT_ID,
                CLIENT_SECRET,
                authCode,
                REDIRECT_URI
            ).execute()
        }

        private fun fetchUserInfo(accessToken: String): JSONObject {
            val url = URL("https://www.googleapis.com/oauth2/v3/userinfo")
            val connection = url.openConnection() as java.net.HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(response)
        }
    }
}
