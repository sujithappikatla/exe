package com.example.signintest

import UserAccount
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import android.os.Build
import android.app.Activity
import android.content.pm.PackageManager
import android.content.BroadcastReceiver
import android.content.IntentFilter
import com.example.signintest.GoogleAuthHelper

class AuthViewModel : ViewModel() {
    var uiState by mutableStateOf(AuthUiState())
        private set
    private var authReceiver: BroadcastReceiver? = null
    
    fun onSignInSuccess(account: UserAccount) {
        Log.d("AuthViewModel", "onSignInSuccess called with username: ${account.displayName}")
        uiState = uiState.copy(
            isSignedIn = true,
            userName = account.displayName,
            errorMessage = null
        )
        Log.d("AuthViewModel", "Updated uiState: $uiState")
    }

    fun onSignInError() {
        uiState = uiState.copy(
            isSignedIn = false,
            userName = null,
            errorMessage = "Sign in failed. Please try again."
        )
    }

    fun onSignOut() {
        uiState = uiState.copy(
            isSignedIn = false,
            userName = null,
            errorMessage = null
        )
    }

    fun testServerConnection(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Get the device's IP from the server logs and replace below
                val url = URL("http://10.0.2.2:8080/test")  // or your device IP
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.requestMethod = "GET"
                
                val responseCode = connection.responseCode
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                
                Log.d("ServerTest", "Response Code: $responseCode")
                Log.d("ServerTest", "Response: $response")
            } catch (e: Exception) {
                Log.e("ServerTest", "Connection test failed", e)
            }
        }
    }

    private fun processAuthCode(code: String) {
        viewModelScope.launch {
            try {
                val userAccount = GoogleAuthHelper.getUserInfo(code)
                if (userAccount != null) {
                    onSignInSuccess(userAccount)
                } else {
                    onSignInError()
                }
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Error processing auth code", e)
                onSignInError()
            }
        }
    }

    fun startAuthServer(context: Context) {
        try {
            // Register broadcast receiver
            authReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    Log.d("AuthViewModel", "Received broadcast: ${intent?.action}")
                    if (intent?.action == "AUTH_SUCCESS_ACTION") {
                        val code = intent.getStringExtra("auth_code")
                        if (code != null) {
                            processAuthCode(code)
                        }
                    }
                }
            }
            
            // Create intent filter with the specific action
            val filter = IntentFilter("AUTH_SUCCESS_ACTION").apply {
                addCategory(Intent.CATEGORY_DEFAULT)
            }
            
            // Register receiver with appropriate flags
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                context.registerReceiver(
                    authReceiver, 
                    filter,
                    Context.RECEIVER_NOT_EXPORTED
                )
            } else {
                context.registerReceiver(authReceiver, filter)
            }
            
            Log.d("AuthViewModel", "Broadcast receiver registered")
            
            // Start service
            val serviceIntent = Intent(context, LocalAuthServerService::class.java)
            context.startService(serviceIntent)
            Log.d("AuthViewModel", "Service start requested")
        } catch (e: Exception) {
            Log.e("AuthViewModel", "Failed to start service", e)
        }
    }

    fun stopAuthServer(context: Context) {
        try {
            // Unregister receiver
            authReceiver?.let {
                context.unregisterReceiver(it)
                authReceiver = null
            }
            
            context.stopService(Intent(context, LocalAuthServerService::class.java))
            Log.d("AuthViewModel", "Service stop requested")
        } catch (e: Exception) {
            Log.e("AuthViewModel", "Failed to stop service", e)
        }
    }
}

data class AuthUiState(
    val isSignedIn: Boolean = false,
    val userName: String? = null,
    val errorMessage: String? = null
)
