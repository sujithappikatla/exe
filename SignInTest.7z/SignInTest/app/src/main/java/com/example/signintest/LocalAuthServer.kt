import fi.iki.elonen.NanoHTTPD
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL

class LocalAuthServer(
    private val onAuthCode: (String) -> Unit
) : NanoHTTPD("0.0.0.0", 8080) {
    
    init {
        Log.d("LocalServer", "Initializing server on 0.0.0.0:8080")
    }

    override fun start() {
        try {
            super.start(SOCKET_READ_TIMEOUT, false)
            Log.d("LocalServer", "Server started successfully")
        } catch (e: Exception) {
            Log.e("LocalServer", "Failed to start server", e)
            throw e
        }
    }

    override fun stop() {
        super.stop()
        Log.e("LocalServer", "Server stopped successfully")
    }

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        val method = session.method
        val headers = session.headers
        
        Log.d("LocalServer", """
            Received request:
            - URI: $uri
            - Method: $method
            - Headers: $headers
            - Remote IP: ${session.remoteIpAddress}
        """.trimIndent())
        
        return try {
            if (uri == "/test") {
                Log.d("LocalServer", "Test endpoint hit")
                newFixedLengthResponse(Response.Status.OK, MIME_PLAINTEXT, "Server is working!")
            } else if (uri.startsWith("/oauth2callback")) {
                val parameters = session.parameters
                Log.d("LocalServer", "Callback parameters: $parameters")
                
                val code = parameters["code"]?.firstOrNull()
                if (code != null) {
                    Log.d("LocalServer", "Auth code received")
                    onAuthCode(code)  // Pass the auth code to service
                    createSuccessResponse()
                } else {
                    Log.e("LocalServer", "No auth code in callback")
                    createErrorResponse("No auth code received")
                }
            } else {
                Log.d("LocalServer", "Received request for: ${session.uri}")
                newFixedLengthResponse(Response.Status.OK, MIME_PLAINTEXT, "Server is running")
            }
        } catch (e: Exception) {
            Log.e("LocalServer", "Error serving request", e)
            createErrorResponse("Internal server error: ${e.message}")
        }
    }

    private fun createSuccessResponse(): Response {
        return newFixedLengthResponse(
            Response.Status.OK,
            MIME_HTML,
            """
            <html>
                <head>
                    <title>Success</title>
                </head>
                <body>
                    <h1>Authentication Successful!</h1>
                    <p>You can close this window now.</p>
                    <script>
                        window.close();
                    </script>
                </body>
            </html>
            """
        )
    }

    private fun createErrorResponse(error: String): Response {
        return newFixedLengthResponse(
            Response.Status.BAD_REQUEST,
            MIME_HTML,
            """
            <html>
                <body>
                    <h1>Error</h1>
                    <p>$error</p>
                </body>
            </html>
            """
        )
    }

    private fun getDeviceIpAddress(): String {
        try {
            java.net.NetworkInterface.getNetworkInterfaces().iterator().forEach { networkInterface ->
                networkInterface.inetAddresses.iterator().forEach { address ->
                    if (!address.isLoopbackAddress && address is java.net.Inet4Address) {
                        return address.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("LocalServer", "Error getting IP address", e)
        }
        return "unknown"
    }

    companion object {
        private const val SOCKET_READ_TIMEOUT = 180000 // 3 minutes
    }
}
