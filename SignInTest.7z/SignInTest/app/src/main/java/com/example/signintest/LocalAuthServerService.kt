package com.example.signintest

import LocalAuthServer
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class LocalAuthServerService : Service() {
    private var server: LocalAuthServer? = null

    override fun onCreate() {
        super.onCreate()
        Log.d("LocalAuthServerService", "Starting server...")
        try {
            server = LocalAuthServer { code ->
                Log.d("LocalAuthServerService", "Received auth code: $code")
                val intent = Intent("AUTH_SUCCESS_ACTION").apply {
                    setPackage(packageName)
                    putExtra("auth_code", code)
                    addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                }
                sendBroadcast(intent)
            }
            server?.start()
            Log.d("LocalAuthServerService", "Server started successfully")
        } catch (e: Exception) {
            Log.e("LocalAuthServerService", "Failed to start server", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
