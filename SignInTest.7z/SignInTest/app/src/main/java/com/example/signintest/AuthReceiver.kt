package com.example.signintest

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AuthReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d("AuthReceiver", "Received broadcast: ${intent?.action}")
        if (intent?.action == "AUTH_SUCCESS_ACTION") {
            Log.d("AuthReceiver", "Processing AUTH_SUCCESS_ACTION")
            // Send internal broadcast that ViewModel is listening for
            context?.sendBroadcast(Intent("AUTH_INTERNAL_ACTION"))
        }
    }
}
