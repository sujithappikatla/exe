function showResult(message, type) {
    const result = document.getElementById('result');
    result.textContent = message;
    result.className = `result ${type}`;
    result.style.display = 'block';
}

document.getElementById('uploadForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const fileInput = document.getElementById('fileInput');
    const uploadBtn = document.getElementById('uploadBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    
    if (!fileInput.files.length) {
        showResult('Please select a file first.', 'error');
        return;
    }
    
    const file = fileInput.files[0];
    
    // Validate file type
    const allowedTypes = ['.pdf', '.xlsx', '.csv', '.jpg', '.jpeg', '.png'];
    const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
    
    if (!allowedTypes.includes(fileExtension)) {
        showResult('Please upload a valid file type: PDF, Excel (.xlsx), CSV, or image files (JPG, PNG, GIF).', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    // Show loading state
    uploadBtn.disabled = true;
    loading.style.display = 'block';
    result.style.display = 'none';
    
    try {
        const response = await fetch('http://localhost:8000/upload', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult(`Food menu uploaded successfully! ${data.message || ''}`, 'success');
            // Reset the form
            fileInput.value = '';
        } else {
            showResult(`Upload failed: ${data.error || 'Unknown error'}`, 'error');
        }
    } catch (error) {
        showResult(`Upload failed: ${error.message}`, 'error');
    } finally {
        // Hide loading state
        uploadBtn.disabled = false;
        loading.style.display = 'none';
    }
});

// Optional: Add drag and drop functionality
const fileInput = document.getElementById('fileInput');
const uploadForm = document.getElementById('uploadForm');

// Prevent default drag behaviors
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    uploadForm.addEventListener(eventName, preventDefaults, false);
    document.body.addEventListener(eventName, preventDefaults, false);
});

// Highlight drop area when item is dragged over it
['dragenter', 'dragover'].forEach(eventName => {
    uploadForm.addEventListener(eventName, highlight, false);
});

['dragleave', 'drop'].forEach(eventName => {
    uploadForm.addEventListener(eventName, unhighlight, false);
});

// Handle dropped files
uploadForm.addEventListener('drop', handleDrop, false);

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

function highlight(e) {
    uploadForm.classList.add('highlight');
}

function unhighlight(e) {
    uploadForm.classList.remove('highlight');
}

function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    
    if (files.length > 0) {
        const file = files[0];
        const allowedTypes = ['.pdf', '.xlsx', '.csv', '.jpg', '.jpeg', '.png'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
        
        if (!allowedTypes.includes(fileExtension)) {
            showResult('Please upload a valid file type: PDF, Excel (.xlsx), CSV, or image files (JPG, PNG).', 'error');
            return;
        }
        
        fileInput.files = files;
        showResult(`File "${file.name}" ready for upload.`, 'success');
    }
}

// Add some styling for drag and drop
const style = document.createElement('style');
style.textContent = `
    .upload-form.highlight {
        border: 2px dashed #3b82f6;
        background-color: rgba(59, 130, 246, 0.1);
    }
    
    .upload-form {
        transition: all 0.3s ease;
    }
`;
document.head.appendChild(style); 