function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

function toggleShrink() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    sidebar.classList.toggle('shrunk');
    mainContent.classList.toggle('shrunk');
}

function toggleSection(event, sectionId) {
    event.preventDefault();
    const section = document.getElementById(sectionId);
    section.classList.toggle('show');
    const header = event.target;
    header.textContent = header.textContent.replace(section.classList.contains('show') ? '▼' : '▶', section.classList.contains('show') ? '▶' : '▼');
}

function toggleDropdown(event) {
    event.preventDefault();
    const dropdownContent = event.target.nextElementSibling;
    dropdownContent.classList.toggle('show');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const dropdowns = document.getElementsByClassName('dropdown-content');
    for (let i = 0; i < dropdowns.length; i++) {
        const openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show') && !openDropdown.parentElement.contains(event.target)) {
            openDropdown.classList.remove('show');
        }
    }
});