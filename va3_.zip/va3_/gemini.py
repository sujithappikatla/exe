from google import genai
import os
from dotenv import load_dotenv

load_dotenv()


USE_VERTEX_AI = os.getenv("USE_VERTEX_AI") == "True"
LLM_MODEL = os.getenv("LLM_MODEL")


if USE_VERTEX_AI:
    client = genai.Client( 
        vertexai=True,
        project=os.getenv("PROJECT_ID"),
        location=os.getenv("LOCATION")
    )
else:
    API_KEY = os.getenv("GOOGLE_AI_STUDIO_KEY")
    client = genai.Client(api_key=API_KEY)  


def generate_response(prompt):
    response = client.models.generate_content(
        model=LLM_MODEL,
        contents=prompt
    )
    return response.text

def generate_embeddings(text):
    if USE_VERTEX_AI:
        model = os.getenv("VERTEX_AI_EMBEDDING_MODEL")
    else:
        model = os.getenv("AI_STUDIO_EMBEDDING_MODEL")
    
    result = client.models.embed_content(
        model=model,
        contents=text
    )
    return result.embeddings[0].values


if __name__ == "__main__":
    # print(generate_response("Explain bubble sort to me."))
    print(generate_embeddings("Explain bubble sort to me."))