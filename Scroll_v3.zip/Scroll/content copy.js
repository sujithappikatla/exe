// Listen for scroll events on the current page.
document.addEventListener('scroll', function() {
    var scrollPosition = {
        x: window.scrollX,
        y: window.scrollY
    };

    // Send the scroll position to the extension.
    chrome.runtime.sendMessage({type: "scrollEvent", position: scrollPosition});
});

// Continue to listen for messages from the popup.
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.type === "getScrollPosition") {
            sendResponse({x: window.scrollX, y: window.scrollY});
        }
    }
);



// Set up the event listener for resize events.
window.addEventListener('resize', function(){
    const size = {
        width: window.innerWidth,
        height: window.innerHeight
    };

    // Send the new size to the extension's background script or popup.
    chrome.runtime.sendMessage({type: "windowResize", size: size});
});


window.addEventListener('GetDocSize', (event) => {
    // Access the passed data from the event detail
    console.log('Received data in content script:', event.detail);
    const dimensions = 
    {
        ...event.detail,
        "Docwidth": document.documentElement.scrollWidth,
        "Docheight": document.documentElement.scrollHeight,
        
      };
      
      chrome.runtime.sendMessage(dimensions);
  });
  