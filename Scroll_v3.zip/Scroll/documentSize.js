// // contentScript.js

// const dimensions = {
//     width: document.documentElement.scrollWidth,
//     height: document.documentElement.scrollHeight
//   };
  
//   chrome.runtime.sendMessage(dimensions);
  