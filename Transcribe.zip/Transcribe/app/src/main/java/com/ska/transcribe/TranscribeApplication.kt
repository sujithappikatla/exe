package com.ska.transcribe

import android.app.Application
import com.ska.transcribe.audio.AudioRecorder

/**
 * Application class for the Transcribe app.
 *
 * Initializes global components like AudioRecorder.
 */
class TranscribeApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Initialize AudioRecorder singleton
        AudioRecorder.initialize(this)
    }

    override fun onTerminate() {
        super.onTerminate()

        // Cleanup AudioRecorder resources
        AudioRecorder.cleanup()
    }
}

