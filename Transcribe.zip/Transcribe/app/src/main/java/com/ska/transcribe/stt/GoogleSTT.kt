package com.ska.transcribe.stt

import android.util.Log
import com.google.api.gax.core.FixedCredentialsProvider
import com.google.api.gax.rpc.ClientStream
import com.google.api.gax.rpc.ResponseObserver
import com.google.api.gax.rpc.StreamController
import com.google.auth.oauth2.AccessToken
import com.google.auth.oauth2.GoogleCredentials
import com.google.cloud.speech.v2.ExplicitDecodingConfig
import com.google.cloud.speech.v2.RecognitionConfig
import com.google.cloud.speech.v2.RecognitionFeatures
import com.google.cloud.speech.v2.SpeechClient
import com.google.cloud.speech.v2.SpeechSettings
import com.google.cloud.speech.v2.StreamingRecognitionConfig
import com.google.cloud.speech.v2.StreamingRecognitionFeatures
import com.google.cloud.speech.v2.StreamingRecognizeRequest
import com.google.cloud.speech.v2.StreamingRecognizeResponse
import com.google.protobuf.ByteString
import com.ska.transcribe.audio.AudioRecorder
import com.ska.transcribe.audio.AudioResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

// ============================================================================
// Configuration
// ============================================================================

/**
 * Configuration for Google Cloud Speech-to-Text service.
 *
 * @param projectId Your Google Cloud project ID (required)
 * @param locationId Google Cloud region (default: us-central1)
 * @param recognizerId Recognizer ID (use "_" for default)
 * @param model Speech recognition model (e.g., "chirp_2", "long", "short")
 * @param languageCode Language code for recognition (e.g., "en-US")
 * @param sampleRate Audio sample rate in Hz (must match AudioRecorder config)
 * @param enableAutomaticPunctuation Whether to add punctuation automatically
 * @param maxReconnectAttempts Maximum number of reconnection attempts
 * @param baseReconnectDelayMs Initial delay for exponential backoff
 * @param maxReconnectDelayMs Maximum delay between reconnection attempts
 * @param streamDurationBeforeReconnectMs Time before proactive reconnection (default 4.5 min)
 */
data class GoogleSTTConfig(
    val projectId: String = "cloud-learning-443407",
    val locationId: String = "us-central1",
    val recognizerId: String = "_",
    val model: String = "telephony",
    val languageCode: String = "en-US",
    val sampleRate: Int = 16000,
    val enableAutomaticPunctuation: Boolean = true,
    val maxReconnectAttempts: Int = 5,
    val baseReconnectDelayMs: Long = 100L,
    val maxReconnectDelayMs: Long = 5000L,
    val streamDurationBeforeReconnectMs: Long = 270_000L  // 4.5 minutes (before 5 min limit)
) {
    /**
     * Full recognizer resource name for the API.
     */
    val recognizerName: String
        get() = "projects/$projectId/locations/$locationId/recognizers/$recognizerId"

    /**
     * gRPC endpoint for the specified location.
     */
    val endpoint: String
        get() = "$locationId-speech.googleapis.com:443"
}

// ============================================================================
// Google STT Implementation
// ============================================================================

/**
 * Google Cloud Speech-to-Text implementation using the official gRPC library.
 *
 * This class connects to Google's Speech-to-Text v2 API and provides
 * real-time transcription of audio from [AudioRecorder].
 *
 * Features:
 * - Uses Google Cloud Speech v2 API with Chirp 2 model
 * - Automatic reconnection before 5-minute streaming limit
 * - Token refresh on reconnection
 * - Comprehensive error handling with retry logic
 * - Interim and final transcript support
 *
 * @param tokenProvider Provider for Google OAuth2 access tokens
 * @param config Configuration options
 *
 * Example:
 * ```
 * val tokenProvider = TokenProvider { api.getGoogleAccessToken() }
 * val stt = GoogleSTT(
 *     tokenProvider = tokenProvider,
 *     config = GoogleSTTConfig(projectId = "my-project-id")
 * )
 *
 * stt.start()
 *
 * stt.transcripts.collect { result ->
 *     println("${if (result.isFinal) "Final" else "Interim"}: ${result.text}")
 * }
 * ```
 */
class GoogleSTT(
    private val tokenProvider: TokenProvider,
    private val config: GoogleSTTConfig
) : SpeechToText {

    companion object {
        private const val TAG = "GoogleSTT"
        private const val MAX_DURATION_ERROR = "Max duration"
        private const val STREAM_REMOVED_ERROR = "Stream removed"
    }

    // ========================================================================
    // State
    // ========================================================================

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _transcripts = MutableSharedFlow<TranscriptResult>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    override val transcripts: SharedFlow<TranscriptResult> = _transcripts.asSharedFlow()

    private val _status = MutableStateFlow<SttStatus>(SttStatus.Idle)
    override val status: StateFlow<SttStatus> = _status.asStateFlow()

    // gRPC state
    private var speechClient: SpeechClient? = null
    private var requestStream: ClientStream<StreamingRecognizeRequest>? = null
    private val clientMutex = Mutex()

    // Job management
    private var audioCollectorJob: Job? = null
    private var reconnectTimerJob: Job? = null

    // Connection state
    private val reconnectAttempts = AtomicInteger(0)
    private val isStarted = AtomicBoolean(false)
    private val isManuallyStopped = AtomicBoolean(false)
    private val isStreamActive = AtomicBoolean(false)

    // Track stream start time for proactive reconnection
    private var streamStartTime: Long = 0L

    // ========================================================================
    // Public Interface
    // ========================================================================

    override fun start() {
        if (isStarted.getAndSet(true)) {
            Log.d(TAG, "Already started, ignoring")
            return
        }

        Log.i(TAG, "Starting Google STT")
        isManuallyStopped.set(false)
        reconnectAttempts.set(0)

        scope.launch {
            connect()
        }
    }

    override fun stop() {
        Log.i(TAG, "Stopping Google STT")
        isManuallyStopped.set(true)
        isStarted.set(false)

        scope.launch {
            disconnect()
            _status.value = SttStatus.Stopped
        }
    }

    /**
     * Release all resources.
     * After calling this, the instance should not be reused.
     */
    fun cleanup() {
        Log.i(TAG, "Cleanup requested")
        stop()
    }

    // ========================================================================
    // Connection Management
    // ========================================================================

    private suspend fun connect() {
        if (isManuallyStopped.get()) {
            Log.d(TAG, "Manually stopped, not connecting")
            return
        }

        _status.value = SttStatus.Connecting
        Log.d(TAG, "Connecting to Google Speech-to-Text...")

        try {
            // Get access token
            val accessToken = withContext(Dispatchers.IO) {
                tokenProvider.getToken()
            }
            Log.d(TAG, "Access token obtained")

            // Initialize speech client
            initializeSpeechClient(accessToken)

            // Start streaming
            startStreaming()

            // Start audio collection
            startAudioCollection()

            // Schedule proactive reconnection
            scheduleReconnection()

            _status.value = SttStatus.Connected
            reconnectAttempts.set(0)
            Log.i(TAG, "Connected to Google Speech-to-Text")

        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to connect", e)
            handleConnectionFailure(e)
        }
    }

    private suspend fun initializeSpeechClient(accessToken: String) = withContext(Dispatchers.IO) {
        clientMutex.withLock {
            // Close existing client if any
            speechClient?.let { client ->
                try {
                    client.close()
                } catch (e: Exception) {
                    Log.w(TAG, "Error closing existing client", e)
                }
            }

            // Create credentials from access token
            val credentials = GoogleCredentials.create(AccessToken(accessToken, null))

            // Build speech settings
            val speechSettings = SpeechSettings.newBuilder()
                .setCredentialsProvider(FixedCredentialsProvider.create(credentials))
                .setEndpoint(config.endpoint)
                .build()

            // Create speech client
            speechClient = SpeechClient.create(speechSettings)
            Log.d(TAG, "Speech client created with endpoint: ${config.endpoint}")
        }
    }

    private suspend fun startStreaming() {
        val client = speechClient ?: throw IllegalStateException("Speech client not initialized")

        // Create recognition config
        val recognitionConfig = RecognitionConfig.newBuilder()
            .setExplicitDecodingConfig(
                ExplicitDecodingConfig.newBuilder()
                    .setAudioChannelCount(1)
                    .setEncoding(ExplicitDecodingConfig.AudioEncoding.LINEAR16)
                    .setSampleRateHertz(config.sampleRate)
                    .build()
            )
            .addLanguageCodes(config.languageCode)
            .setModel(config.model)
            .setFeatures(
                RecognitionFeatures.newBuilder()
                    .setEnableAutomaticPunctuation(config.enableAutomaticPunctuation)
                    .setEnableWordTimeOffsets(false)
                    .build()
            )
            .build()

        // Create streaming config
        val streamingConfig = StreamingRecognitionConfig.newBuilder()
            .setConfig(recognitionConfig)
            .setStreamingFeatures(
                StreamingRecognitionFeatures.newBuilder()
                    .setInterimResults(true)
                    .build()
            )
            .build()

        // Create response observer
        val responseObserver = createResponseObserver()

        // Start streaming call
        clientMutex.withLock {
            requestStream = client.streamingRecognizeCallable().splitCall(responseObserver)

            // Send initial config request
            val initialRequest = StreamingRecognizeRequest.newBuilder()
                .setRecognizer(config.recognizerName)
                .setStreamingConfig(streamingConfig)
                .build()

            requestStream?.send(initialRequest)
            isStreamActive.set(true)
            streamStartTime = System.currentTimeMillis()
            Log.d(TAG, "Streaming started with recognizer: ${config.recognizerName}")
        }
    }

    private fun createResponseObserver(): ResponseObserver<StreamingRecognizeResponse> {
        return object : ResponseObserver<StreamingRecognizeResponse> {
            override fun onStart(controller: StreamController) {
                Log.d(TAG, "gRPC stream started")
            }

            override fun onResponse(response: StreamingRecognizeResponse) {
                if (response.resultsCount > 0) {
                    val result = response.getResults(0)
                    if (result.alternativesCount > 0) {
                        val transcript = result.getAlternatives(0).transcript
                        val isFinal = result.isFinal

                        if (transcript.isNotBlank()) {
                            scope.launch {
                                _transcripts.emit(
                                    TranscriptResult(
                                        text = transcript,
                                        isFinal = isFinal
                                    )
                                )
                            }
                            Log.d(TAG, "${if (isFinal) "Final" else "Interim"}: $transcript")
                        }
                    }
                }
            }

            override fun onError(t: Throwable) {
                Log.e(TAG, "gRPC stream error: ${t.message}", t)
                isStreamActive.set(false)

                scope.launch {
                    // Check if it's a max duration error or stream removed error
                    val errorMessage = t.message ?: ""
                    val isRecoverableError = errorMessage.contains(MAX_DURATION_ERROR, ignoreCase = true) ||
                            errorMessage.contains(STREAM_REMOVED_ERROR, ignoreCase = true)

                    if (isRecoverableError && !isManuallyStopped.get() && isStarted.get()) {
                        Log.w(TAG, "Recoverable error detected, reconnecting...")
                        reconnect()
                    } else if (!isManuallyStopped.get()) {
                        handleConnectionFailure(Exception(t.message, t))
                    }
                }
            }

            override fun onComplete() {
                Log.d(TAG, "gRPC stream completed")
                isStreamActive.set(false)

                // If we're still supposed to be running, reconnect
                if (!isManuallyStopped.get() && isStarted.get()) {
                    scope.launch {
                        Log.d(TAG, "Stream completed unexpectedly, reconnecting...")
                        reconnect()
                    }
                }
            }
        }
    }

    private suspend fun reconnect() {
        if (isManuallyStopped.get()) return

        Log.i(TAG, "Reconnecting...")
        _status.value = SttStatus.Reconnecting

        // Stop current audio collection and stream
        audioCollectorJob?.cancel()
        audioCollectorJob = null

        reconnectTimerJob?.cancel()
        reconnectTimerJob = null

        clientMutex.withLock {
            try {
                requestStream?.closeSend()
            } catch (e: Exception) {
                Log.w(TAG, "Error closing request stream", e)
            }
            requestStream = null
        }

        // Small delay before reconnecting
        delay(100)

        // Reconnect with fresh token
        connect()
    }

    private suspend fun disconnect() {
        Log.d(TAG, "Disconnecting...")

        // Cancel jobs
        audioCollectorJob?.cancel()
        audioCollectorJob = null

        reconnectTimerJob?.cancel()
        reconnectTimerJob = null

        isStreamActive.set(false)

        // Close gRPC stream and client
        clientMutex.withLock {
            requestStream?.let { stream ->
                try {
                    stream.closeSend()
                } catch (e: Exception) {
                    Log.w(TAG, "Error closing request stream", e)
                }
            }
            requestStream = null

            speechClient?.let { client ->
                try {
                    client.awaitTermination(500, TimeUnit.MILLISECONDS)
                } catch (e: Exception) {
                    Log.w(TAG, "Error awaiting client termination", e)
                } finally {
                    try {
                        client.close()
                    } catch (e: Exception) {
                        Log.w(TAG, "Error closing speech client", e)
                    }
                }
            }
            speechClient = null
        }

        Log.d(TAG, "Disconnected")
    }

    private suspend fun handleConnectionFailure(error: Exception) {
        val attempt = reconnectAttempts.incrementAndGet()

        if (isManuallyStopped.get()) {
            _status.value = SttStatus.Stopped
            return
        }

        if (attempt > config.maxReconnectAttempts) {
            Log.e(TAG, "Max reconnection attempts ($attempt) reached")
            _status.value = SttStatus.Error(
                message = "Failed to connect after ${config.maxReconnectAttempts} attempts: ${error.message}",
                recoverable = false
            )
            isStarted.set(false)
            return
        }

        // Calculate delay with exponential backoff
        val delay = minOf(
            config.baseReconnectDelayMs * (1 shl (attempt - 1)),
            config.maxReconnectDelayMs
        )

        Log.w(TAG, "Connection failed (attempt $attempt/${config.maxReconnectAttempts}), retrying in ${delay}ms")
        _status.value = SttStatus.Reconnecting

        delay(delay)

        if (!isManuallyStopped.get()) {
            connect()
        }
    }

    // ========================================================================
    // Audio Collection
    // ========================================================================

    private fun startAudioCollection() {
        audioCollectorJob?.cancel()
        audioCollectorJob = scope.launch(Dispatchers.IO) {
            Log.d(TAG, "Starting audio collection")

            try {
                AudioRecorder.audioChunks.collect { result ->
                    when (result) {
                        is AudioResult.Success -> {
                            sendAudioChunk(result.data)
                        }
                        is AudioResult.Error -> {
                            Log.w(TAG, "Audio error: ${result.error}")
                        }
                    }
                }
            } catch (e: CancellationException) {
                Log.d(TAG, "Audio collection cancelled")
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Audio collection error", e)
            }
        }
    }

    private suspend fun sendAudioChunk(audioData: ByteArray) {
        if (!isStreamActive.get()) return

        clientMutex.withLock {
            requestStream?.let { stream ->
                try {
                    val audioRequest = StreamingRecognizeRequest.newBuilder()
                        .setAudio(ByteString.copyFrom(audioData))
                        .build()
                    stream.send(audioRequest)
                } catch (e: Exception) {
                    Log.w(TAG, "Error sending audio chunk: ${e.message}")
                    // If stream is half-closed, it will be handled by onError
                }
            }
        }
    }

    // ========================================================================
    // Proactive Reconnection (for 5-minute limit)
    // ========================================================================

    private fun scheduleReconnection() {
        reconnectTimerJob?.cancel()
        reconnectTimerJob = scope.launch {
            val reconnectDelay = config.streamDurationBeforeReconnectMs
            Log.d(TAG, "Scheduling proactive reconnection in ${reconnectDelay / 1000}s")

            delay(reconnectDelay)

            if (isManuallyStopped.get() || !isStarted.get()) return@launch

            Log.i(TAG, "Proactive reconnection to avoid 5-minute limit")
            reconnect()
        }
    }
}

