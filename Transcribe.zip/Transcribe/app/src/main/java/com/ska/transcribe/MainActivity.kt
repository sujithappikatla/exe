package com.ska.transcribe

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ska.transcribe.stt.AssemblyAiTokenRepository
import com.ska.transcribe.stt.GoogleTokenRepository
import com.ska.transcribe.stt.TokenProvider
import com.ska.transcribe.stt.asTokenProvider
import com.ska.transcribe.ui.SttProviderConfig
import com.ska.transcribe.ui.TranscribeScreen
import com.ska.transcribe.ui.TranscribeViewModel
import com.ska.transcribe.ui.TranscribeViewModelFactory
import com.ska.transcribe.ui.theme.TranscribeTheme

class MainActivity : ComponentActivity() {

    // ========================================
    // ASSEMBLYAI TOKEN REPOSITORY
    // ========================================
    // Implement this to return AssemblyAI temporary tokens
    private val assemblyAiTokenRepository = object : AssemblyAiTokenRepository {
        override suspend fun getTemporaryToken(): String {
            // Call your backend API to get a temporary AssemblyAI token.
            // For testing, you can use your API key directly (NOT recommended for production)
            return "" // Replace with your token
        }
    }

    // ========================================
    // GOOGLE TOKEN REPOSITORY
    // ========================================
    // Implement this to return Google OAuth2 access tokens
    private val googleTokenRepository = object : GoogleTokenRepository {
        override suspend fun getAccessToken(): String {
            // Call your backend API to get a Google OAuth2 access token.
            // The backend should use a service account to generate these tokens.
            //
            // Example:
            // return myApi.getGoogleAccessToken().accessToken

//            throw NotImplementedError(
//                "You must implement GoogleTokenRepository.getAccessToken() " +
//                "to return a valid Google OAuth2 access token from your backend."
//            )
            return ""
        }
    }

    // ========================================
    // GOOGLE PROJECT ID
    // ========================================
    // Your Google Cloud project ID
    private val googleProjectId = "cloud-learning-443407" // Replace with your project ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create provider configuration
        val providerConfig = SttProviderConfig(
            assemblyAiTokenProvider = assemblyAiTokenRepository.asTokenProvider(),
            googleTokenProvider = googleTokenRepository.asTokenProvider(),
            googleProjectId = googleProjectId
        )

        setContent {
            TranscribeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewModel: TranscribeViewModel = viewModel(
                        factory = TranscribeViewModelFactory(
                            application = application,
                            providerConfig = providerConfig
                        )
                    )

                    TranscribeScreen(viewModel = viewModel)
                }
            }
        }
    }
}
