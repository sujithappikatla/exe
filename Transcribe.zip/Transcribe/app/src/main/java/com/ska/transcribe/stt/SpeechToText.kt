package com.ska.transcribe.stt

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

// ============================================================================
// Common Data Classes
// ============================================================================

/**
 * Represents a transcript result from speech-to-text processing.
 *
 * @param text The transcribed text
 * @param isFinal Whether this is a final (confirmed) transcript or an interim result
 * @param timestamp When this transcript was received
 */
data class TranscriptResult(
    val text: String,
    val isFinal: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Represents the current status of an STT service.
 */
sealed class SttStatus {
    /** STT service is idle, not connected */
    data object Idle : SttStatus()

    /** STT service is connecting to the server */
    data object Connecting : SttStatus()

    /** STT service is connected and ready to process audio */
    data object Connected : SttStatus()

    /** STT service is attempting to reconnect after a disconnection */
    data object Reconnecting : SttStatus()

    /**
     * An error occurred in the STT service.
     *
     * @param message Human-readable error message
     * @param recoverable Whether the service can attempt to recover from this error
     */
    data class Error(
        val message: String,
        val recoverable: Boolean
    ) : SttStatus()

    /** STT service has been stopped */
    data object Stopped : SttStatus()
}

// ============================================================================
// Token Provider
// ============================================================================

/**
 * Interface for providing authentication tokens for STT services.
 *
 * Implementations should handle token generation/refresh logic.
 * This is typically called:
 * - On initial connection
 * - When a token expires and reconnection is needed
 *
 * Example implementation:
 * ```
 * val tokenProvider = TokenProvider {
 *     // Call your backend to get a temporary token
 *     api.getAssemblyAiToken()
 * }
 * ```
 */
fun interface TokenProvider {
    /**
     * Get a valid authentication token.
     * This may involve making a network request to generate a new token.
     *
     * @return A valid authentication token
     * @throws Exception if token generation fails
     */
    suspend fun getToken(): String
}

// ============================================================================
// Common STT Interface
// ============================================================================

/**
 * Common interface for Speech-to-Text services.
 *
 * This interface provides a minimal contract that all STT implementations
 * must follow, allowing consumers to switch between different STT providers
 * with minimal code changes.
 *
 * Example usage:
 * ```
 * val stt: SpeechToText = AssemblyAiSTT(tokenProvider)
 *
 * // Start transcription
 * stt.start()
 *
 * // Collect transcripts
 * stt.transcripts.collect { result ->
 *     if (result.isFinal) {
 *         println("Final: ${result.text}")
 *     } else {
 *         println("Interim: ${result.text}")
 *     }
 * }
 *
 * // Stop when done
 * stt.stop()
 * ```
 */
interface SpeechToText {
    /**
     * Flow of transcript results.
     *
     * Emits [TranscriptResult] objects as speech is recognized.
     * - Interim results have [TranscriptResult.isFinal] = false
     * - Final results have [TranscriptResult.isFinal] = true
     */
    val transcripts: SharedFlow<TranscriptResult>

    /**
     * Current status of the STT service.
     *
     * Observe this to track connection state, errors, and reconnection attempts.
     */
    val status: StateFlow<SttStatus>

    /**
     * Start the STT service.
     *
     * This will:
     * 1. Obtain a token from the TokenProvider
     * 2. Connect to the STT service
     * 3. Begin collecting audio from AudioRecorder
     * 4. Start emitting transcripts
     *
     * If already started, this is a no-op.
     */
    fun start()

    /**
     * Stop the STT service.
     *
     * This will:
     * 1. Stop collecting audio
     * 2. Close the connection to the STT service
     * 3. Set status to [SttStatus.Stopped]
     *
     * The service can be restarted by calling [start] again.
     */
    fun stop()
}

