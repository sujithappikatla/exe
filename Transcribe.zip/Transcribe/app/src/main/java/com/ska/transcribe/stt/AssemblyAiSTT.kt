package com.ska.transcribe.stt

import android.util.Log
import com.ska.transcribe.audio.AudioRecorder
import com.ska.transcribe.audio.AudioResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

// ============================================================================
// Configuration
// ============================================================================

/**
 * Configuration for AssemblyAI STT service.
 *
 * @param sampleRate Audio sample rate in Hz (must match AudioRecorder config)
 * @param formatTurns Whether to request formatted final transcripts
 * @param endOfTurnConfidenceThreshold Confidence threshold for end-of-turn detection (0.0-1.0)
 * @param maxReconnectAttempts Maximum number of reconnection attempts before giving up
 * @param baseReconnectDelayMs Initial delay for exponential backoff (doubles each retry)
 * @param maxReconnectDelayMs Maximum delay between reconnection attempts
 * @param tokenRefreshBufferMs Time before token expiry to proactively refresh (default 30s)
 * @param region AssemblyAI region (US or EU)
 */
data class AssemblyAiConfig(
    val sampleRate: Int = 16000,
    val formatTurns: Boolean = true,
    val endOfTurnConfidenceThreshold: Float = 0.4f,
    val maxReconnectAttempts: Int = 5,
    val baseReconnectDelayMs: Long = 100L,
    val maxReconnectDelayMs: Long = 5000L,
    val tokenRefreshBufferMs: Long = 30_000L,
    val region: Region = Region.US
) {
    enum class Region(val host: String) {
        US("streaming.assemblyai.com"),
        EU("streaming.eu.assemblyai.com")
    }
}

// ============================================================================
// WebSocket Message Types (AssemblyAI API)
// ============================================================================

@Serializable
private sealed class AssemblyAiMessage {
    abstract val type: String
}

@Serializable
@SerialName("Begin")
private data class BeginMessage(
    override val type: String = "Begin",
    val id: String,
    @SerialName("expires_at") val expiresAt: Long
) : AssemblyAiMessage()

@Serializable
@SerialName("Turn")
private data class TurnMessage(
    override val type: String = "Turn",
    val transcript: String,
    @SerialName("end_of_turn") val endOfTurn: Boolean,
    @SerialName("turn_order") val turnOrder: Int? = null,
    @SerialName("turn_is_formatted") val turnIsFormatted: Boolean? = null,
    @SerialName("end_of_turn_confidence") val endOfTurnConfidence: Float? = null,
    val words: List<WordMessage>? = null
) : AssemblyAiMessage()

@Serializable
private data class WordMessage(
    val text: String,
    val start: Int,
    val end: Int,
    val confidence: Float,
    @SerialName("word_is_final") val wordIsFinal: Boolean
)

@Serializable
@SerialName("Termination")
private data class TerminationMessage(
    override val type: String = "Termination",
    @SerialName("audio_duration_seconds") val audioDurationSeconds: Float? = null,
    @SerialName("session_duration_seconds") val sessionDurationSeconds: Float? = null
) : AssemblyAiMessage()

// Outgoing messages
@Serializable
private data class TerminateCommand(val type: String = "Terminate")

@Serializable
private data class ForceEndpointCommand(val type: String = "ForceEndpoint")

// ============================================================================
// AssemblyAI STT Implementation
// ============================================================================

/**
 * AssemblyAI Streaming Speech-to-Text implementation.
 *
 * This class connects to AssemblyAI's Universal Streaming API and provides
 * real-time transcription of audio from [AudioRecorder].
 *
 * Features:
 * - Automatic token refresh before expiry
 * - Auto-reconnection with exponential backoff
 * - Proper handling of interim and final transcripts
 * - Support for US and EU regions
 *
 * @param tokenProvider Provider for AssemblyAI temporary authentication tokens
 * @param config Configuration options
 *
 * Example:
 * ```
 * val tokenProvider = TokenProvider { api.getAssemblyAiToken() }
 * val stt = AssemblyAiSTT(tokenProvider)
 *
 * stt.start()
 *
 * stt.transcripts.collect { result ->
 *     println("${if (result.isFinal) "Final" else "Interim"}: ${result.text}")
 * }
 * ```
 */
class AssemblyAiSTT(
    private val tokenProvider: TokenProvider,
    private val config: AssemblyAiConfig = AssemblyAiConfig()
) : SpeechToText {

    companion object {
        private const val TAG = "AssemblyAiSTT"
        private const val ENCODING = "pcm_s16le"
    }

    // ========================================================================
    // State
    // ========================================================================

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _transcripts = MutableSharedFlow<TranscriptResult>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    override val transcripts: SharedFlow<TranscriptResult> = _transcripts.asSharedFlow()

    private val _status = MutableStateFlow<SttStatus>(SttStatus.Idle)
    override val status: StateFlow<SttStatus> = _status.asStateFlow()

    // WebSocket state
    private var webSocket: WebSocket? = null
    private val webSocketMutex = Mutex()

    // Session state
    private var currentToken: String? = null
    private var sessionId: String? = null
    private var sessionExpiresAt: Long? = null

    // Job management
    private var audioCollectorJob: Job? = null
    private var tokenRefreshJob: Job? = null

    // Reconnection state
    private val reconnectAttempts = AtomicInteger(0)
    private val isReconnecting = AtomicBoolean(false)
    private val isStarted = AtomicBoolean(false)
    private val isManuallyStopped = AtomicBoolean(false)

    // JSON parser
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    // OkHttp client with appropriate timeouts
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS) // No read timeout for WebSocket
        .writeTimeout(30, TimeUnit.SECONDS)
        .pingInterval(30, TimeUnit.SECONDS) // Keep connection alive
        .build()

    // ========================================================================
    // Public Interface
    // ========================================================================

    override fun start() {
        if (isStarted.getAndSet(true)) {
            Log.d(TAG, "Already started, ignoring")
            return
        }

        Log.i(TAG, "Starting AssemblyAI STT")
        isManuallyStopped.set(false)
        reconnectAttempts.set(0)

        scope.launch {
            connect()
        }
    }

    override fun stop() {
        Log.i(TAG, "Stopping AssemblyAI STT")
        isManuallyStopped.set(true)
        isStarted.set(false)

        scope.launch {
            disconnect(sendTerminate = true)
            _status.value = SttStatus.Stopped
        }
    }

    /**
     * Force an end-of-turn detection.
     *
     * This can be useful when you want to get a final transcript
     * without waiting for natural speech pauses.
     */
    fun forceEndpoint() {
        scope.launch {
            webSocketMutex.withLock {
                webSocket?.let { ws ->
                    val command = json.encodeToString(ForceEndpointCommand.serializer(), ForceEndpointCommand())
                    ws.send(command)
                    Log.d(TAG, "Sent ForceEndpoint command")
                }
            }
        }
    }

    /**
     * Release all resources.
     * After calling this, the instance should not be reused.
     */
    fun cleanup() {
        Log.i(TAG, "Cleanup requested")
        stop()
        okHttpClient.dispatcher.executorService.shutdown()
    }

    // ========================================================================
    // Connection Management
    // ========================================================================

    private suspend fun connect() {
        if (isManuallyStopped.get()) {
            Log.d(TAG, "Manually stopped, not connecting")
            return
        }

        _status.value = SttStatus.Connecting
        Log.d(TAG, "Connecting to AssemblyAI...")

        try {
            // Get token
            currentToken = withContext(Dispatchers.IO) {
                tokenProvider.getToken()
            }
            Log.d(TAG, "Token obtained")

            // Build WebSocket URL
            val url = buildWebSocketUrl(currentToken!!)
            Log.d(TAG, "WebSocket URL: ${url.replace(currentToken!!, "***")}")

            // Create WebSocket request
            val request = Request.Builder()
                .url(url)
                .build()

            // Connect
            webSocketMutex.withLock {
                webSocket = okHttpClient.newWebSocket(request, createWebSocketListener())
            }

        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to connect", e)
            handleConnectionFailure(e)
        }
    }

    private fun buildWebSocketUrl(token: String): String {
        return buildString {
            append("wss://")
            append(config.region.host)
            append("/v3/ws")
            append("?token=").append(token)
            append("&sample_rate=").append(config.sampleRate)
            append("&encoding=").append(ENCODING)
            append("&format_turns=").append(config.formatTurns)
        }
    }

    private suspend fun disconnect(sendTerminate: Boolean = false) {
        Log.d(TAG, "Disconnecting...")

        // Cancel jobs
        audioCollectorJob?.cancel()
        audioCollectorJob = null

        tokenRefreshJob?.cancel()
        tokenRefreshJob = null

        // Close WebSocket
        webSocketMutex.withLock {
            webSocket?.let { ws ->
                if (sendTerminate) {
                    try {
                        val command = json.encodeToString(TerminateCommand.serializer(), TerminateCommand())
                        ws.send(command)
                        Log.d(TAG, "Sent Terminate command")
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to send terminate command", e)
                    }
                }
                ws.close(1000, "Normal closure")
            }
            webSocket = null
        }

        // Clear session state
        sessionId = null
        sessionExpiresAt = null

        Log.d(TAG, "Disconnected")
    }

    private suspend fun handleConnectionFailure(error: Exception) {
        val attempt = reconnectAttempts.incrementAndGet()

        if (isManuallyStopped.get()) {
            _status.value = SttStatus.Stopped
            return
        }

        if (attempt > config.maxReconnectAttempts) {
            Log.e(TAG, "Max reconnection attempts ($attempt) reached")
            _status.value = SttStatus.Error(
                message = "Failed to connect after ${config.maxReconnectAttempts} attempts: ${error.message}",
                recoverable = false
            )
            isStarted.set(false)
            return
        }

        // Calculate delay with exponential backoff
        val delay = minOf(
            config.baseReconnectDelayMs * (1 shl (attempt - 1)),
            config.maxReconnectDelayMs
        )

        Log.w(TAG, "Connection failed (attempt $attempt/${config.maxReconnectAttempts}), retrying in ${delay}ms")
        _status.value = SttStatus.Reconnecting

        delay(delay)

        if (!isManuallyStopped.get()) {
            connect()
        }
    }

    // ========================================================================
    // WebSocket Listener
    // ========================================================================

    private fun createWebSocketListener(): WebSocketListener {
        return object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket connected")
                reconnectAttempts.set(0)
                isReconnecting.set(false)
                // Status will be updated to Connected when we receive Begin message
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                scope.launch {
                    handleMessage(text)
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                // AssemblyAI doesn't send binary messages, but handle just in case
                Log.w(TAG, "Received unexpected binary message: ${bytes.size} bytes")
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closing: code=$code, reason=$reason")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.i(TAG, "WebSocket closed: code=$code, reason=$reason")
                scope.launch {
                    handleWebSocketClosed(code, reason)
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket failure: ${t.message}", t)
                scope.launch {
                    handleWebSocketFailure(t, response)
                }
            }
        }
    }

    // ========================================================================
    // Message Handling
    // ========================================================================

    private suspend fun handleMessage(text: String) {
        try {
            // Parse the message type first
            val typeMatch = Regex(""""type"\s*:\s*"(\w+)"""").find(text)
            val messageType = typeMatch?.groupValues?.get(1)

            when (messageType) {
                "Begin" -> handleBeginMessage(text)
                "Turn" -> handleTurnMessage(text)
                "Termination" -> handleTerminationMessage(text)
                else -> Log.w(TAG, "Unknown message type: $messageType")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse message: $text", e)
        }
    }

    private suspend fun handleBeginMessage(text: String) {
        val message = json.decodeFromString<BeginMessage>(text)
        sessionId = message.id
        sessionExpiresAt = message.expiresAt * 1000 // Convert to milliseconds

        Log.i(TAG, "Session started: id=${message.id}, expiresAt=${message.expiresAt}")
        _status.value = SttStatus.Connected

        // Start audio collection
        startAudioCollection()

        // Schedule token refresh
        scheduleTokenRefresh()
    }

    private suspend fun handleTurnMessage(text: String) {
        val message = json.decodeFromString<TurnMessage>(text)

        // Determine if this is a final transcript based on the rules:
        // 1. end_of_turn = true → final
        // 2. end_of_turn = false BUT last word has word_is_final = true → final
        // 3. Otherwise → interim
        val isFinal = when {
            message.endOfTurn -> true
            message.words?.isNotEmpty() == true && message.words.last().wordIsFinal -> true
            else -> false
        }

        // Only emit if there's actual text
        if (message.transcript.isNotBlank()) {
            val result = TranscriptResult(
                text = message.transcript,
                isFinal = isFinal
            )
            _transcripts.emit(result)

            Log.d(TAG, "${if (isFinal) "Final" else "Interim"}: ${message.transcript}")
        }
    }

    private fun handleTerminationMessage(text: String) {
        try {
            val message = json.decodeFromString<TerminationMessage>(text)
            Log.i(TAG, "Session terminated: audioDuration=${message.audioDurationSeconds}s, sessionDuration=${message.sessionDurationSeconds}s")
        } catch (e: Exception) {
            Log.d(TAG, "Session terminated")
        }
    }

    // ========================================================================
    // WebSocket Error Handling
    // ========================================================================

    private suspend fun handleWebSocketClosed(code: Int, reason: String) {
        // Clear WebSocket reference
        webSocketMutex.withLock {
            webSocket = null
        }

        // Stop audio collection
        audioCollectorJob?.cancel()
        audioCollectorJob = null

        tokenRefreshJob?.cancel()
        tokenRefreshJob = null

        if (isManuallyStopped.get()) {
            _status.value = SttStatus.Stopped
            return
        }

        // Handle based on close code
        when (code) {
            1000 -> {
                // Normal closure
                Log.d(TAG, "Normal WebSocket closure")
                if (isStarted.get() && !isManuallyStopped.get()) {
                    // Reconnect if we should still be running
                    handleConnectionFailure(Exception("WebSocket closed normally, reconnecting"))
                }
            }
            4000, 4001, 4002, 4003, 4008 -> {
                // AssemblyAI specific error codes
                Log.e(TAG, "AssemblyAI error: code=$code, reason=$reason")
                _status.value = SttStatus.Error(
                    message = "AssemblyAI error ($code): $reason",
                    recoverable = code != 4001 // 4001 is typically auth error
                )
                if (code == 4001) {
                    // Token expired or invalid, try to refresh and reconnect
                    handleConnectionFailure(Exception("Token error: $reason"))
                }
            }
            else -> {
                // Unexpected closure, try to reconnect
                handleConnectionFailure(Exception("WebSocket closed: code=$code, reason=$reason"))
            }
        }
    }

    private suspend fun handleWebSocketFailure(error: Throwable, response: Response?) {
        // Clear WebSocket reference
        webSocketMutex.withLock {
            webSocket = null
        }

        // Stop audio collection
        audioCollectorJob?.cancel()
        audioCollectorJob = null

        tokenRefreshJob?.cancel()
        tokenRefreshJob = null

        if (isManuallyStopped.get()) {
            _status.value = SttStatus.Stopped
            return
        }

        handleConnectionFailure(Exception(error.message ?: "WebSocket failure", error))
    }

    // ========================================================================
    // Audio Collection
    // ========================================================================

    private fun startAudioCollection() {
        audioCollectorJob?.cancel()
        audioCollectorJob = scope.launch(Dispatchers.IO) {
            Log.d(TAG, "Starting audio collection")

            try {
                AudioRecorder.audioChunks.collect { result ->
                    when (result) {
                        is AudioResult.Success -> {
                            sendAudioChunk(result.data)
                        }
                        is AudioResult.Error -> {
                            Log.w(TAG, "Audio error: ${result.error}")
                            // Don't stop STT for audio errors, let AudioRecorder handle recovery
                        }
                    }
                }
            } catch (e: CancellationException) {
                Log.d(TAG, "Audio collection cancelled")
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Audio collection error", e)
            }
        }
    }

    private suspend fun sendAudioChunk(audioData: ByteArray) {
        webSocketMutex.withLock {
            webSocket?.let { ws ->
                val sent = ws.send(audioData.toByteString())
                if (!sent) {
                    Log.w(TAG, "Failed to send audio chunk (${audioData.size} bytes)")
                }
            }
        }
    }

    // ========================================================================
    // Token Refresh
    // ========================================================================

    private fun scheduleTokenRefresh() {
        tokenRefreshJob?.cancel()

        val expiresAt = sessionExpiresAt ?: return
        val refreshAt = expiresAt - config.tokenRefreshBufferMs
        val now = System.currentTimeMillis()
        val delayMs = maxOf(0, refreshAt - now)

        Log.d(TAG, "Scheduling token refresh in ${delayMs}ms (expires in ${expiresAt - now}ms)")

        tokenRefreshJob = scope.launch {
            delay(delayMs)

            if (isManuallyStopped.get()) return@launch

            Log.i(TAG, "Proactively refreshing token before expiry")

            // Disconnect and reconnect with new token
            try {
                disconnect(sendTerminate = false)
                reconnectAttempts.set(0) // Reset for fresh connection
                connect()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to refresh token", e)
                handleConnectionFailure(e)
            }
        }
    }
}

