package com.ska.transcribe.stt

/**
 * Repository interface for obtaining AssemblyAI temporary authentication tokens.
 *
 * You must implement this interface to provide tokens for the AssemblyAI STT service.
 * Typically, you would call your backend server which generates temporary tokens
 * using your AssemblyAI API key.
 *
 * Example implementation:
 * ```
 * class MyAssemblyAiTokenRepository(
 *     private val api: MyBackendApi
 * ) : AssemblyAiTokenRepository {
 *
 *     override suspend fun getTemporaryToken(): String {
 *         // Call your backend to get a temporary token
 *         val response = api.getAssemblyAiToken()
 *         return response.token
 *     }
 * }
 * ```
 *
 * Backend example (Node.js):
 * ```javascript
 * app.get('/api/assemblyai/token', async (req, res) => {
 *   const response = await fetch('https://api.assemblyai.com/v2/realtime/token', {
 *     method: 'POST',
 *     headers: {
 *       'Authorization': process.env.ASSEMBLYAI_API_KEY,
 *       'Content-Type': 'application/json'
 *     },
 *     body: JSON.stringify({ expires_in: 3600 }) // 1 hour
 *   });
 *   const data = await response.json();
 *   res.json({ token: data.token });
 * });
 * ```
 */
interface AssemblyAiTokenRepository {
    /**
     * Get a temporary authentication token for AssemblyAI streaming.
     *
     * This token is used to authenticate WebSocket connections to AssemblyAI's
     * streaming API. Tokens typically expire after a set period (e.g., 1 hour).
     *
     * @return A valid temporary token string
     * @throws Exception if token generation fails (network error, auth error, etc.)
     */
    suspend fun getTemporaryToken(): String
}

/**
 * Creates a [TokenProvider] from an [AssemblyAiTokenRepository].
 *
 * This is a convenience extension to bridge the repository pattern with the
 * TokenProvider interface used by AssemblyAiSTT.
 *
 * Example:
 * ```
 * val tokenRepository: AssemblyAiTokenRepository = MyAssemblyAiTokenRepository(api)
 * val stt = AssemblyAiSTT(tokenRepository.asTokenProvider())
 * ```
 */
fun AssemblyAiTokenRepository.asTokenProvider(): TokenProvider {
    return TokenProvider { getTemporaryToken() }
}

