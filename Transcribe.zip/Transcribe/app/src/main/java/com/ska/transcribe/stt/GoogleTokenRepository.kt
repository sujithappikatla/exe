package com.ska.transcribe.stt

/**
 * Repository interface for obtaining Google Cloud OAuth2 access tokens.
 *
 * You must implement this interface to provide access tokens for the Google STT service.
 * Typically, you would call your backend server which generates access tokens
 * using your Google Cloud service account credentials.
 *
 * Example implementation:
 * ```
 * class MyGoogleTokenRepository(
 *     private val api: MyBackendApi
 * ) : GoogleTokenRepository {
 *
 *     override suspend fun getAccessToken(): String {
 *         // Call your backend to get an access token
 *         val response = api.getGoogleAccessToken()
 *         return response.accessToken
 *     }
 * }
 * ```
 *
 * Backend example (Node.js with Google Auth Library):
 * ```javascript
 * const { GoogleAuth } = require('google-auth-library');
 *
 * const auth = new GoogleAuth({
 *   scopes: ['https://www.googleapis.com/auth/cloud-platform']
 * });
 *
 * app.get('/api/google/token', async (req, res) => {
 *   const client = await auth.getClient();
 *   const accessToken = await client.getAccessToken();
 *   res.json({ accessToken: accessToken.token });
 * });
 * ```
 *
 * Alternatively, you can use a service account JSON file to generate tokens:
 * ```javascript
 * const { JWT } = require('google-auth-library');
 *
 * const client = new JWT({
 *   keyFile: 'path/to/service-account.json',
 *   scopes: ['https://www.googleapis.com/auth/cloud-platform'],
 * });
 *
 * app.get('/api/google/token', async (req, res) => {
 *   const tokens = await client.authorize();
 *   res.json({ accessToken: tokens.access_token });
 * });
 * ```
 */
interface GoogleTokenRepository {
    /**
     * Get an OAuth2 access token for Google Cloud Speech-to-Text.
     *
     * This token is used to authenticate gRPC connections to Google's
     * Speech-to-Text API. Access tokens typically expire after 1 hour.
     *
     * @return A valid OAuth2 access token string
     * @throws Exception if token generation fails (network error, auth error, etc.)
     */
    suspend fun getAccessToken(): String
}

/**
 * Creates a [TokenProvider] from a [GoogleTokenRepository].
 *
 * This is a convenience extension to bridge the repository pattern with the
 * TokenProvider interface used by GoogleSTT.
 *
 * Example:
 * ```
 * val tokenRepository: GoogleTokenRepository = MyGoogleTokenRepository(api)
 * val stt = GoogleSTT(
 *     tokenProvider = tokenRepository.asTokenProvider(),
 *     config = GoogleSTTConfig(projectId = "my-project")
 * )
 * ```
 */
fun GoogleTokenRepository.asTokenProvider(): TokenProvider {
    return TokenProvider { getAccessToken() }
}

