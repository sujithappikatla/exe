package com.ska.transcribe.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ska.transcribe.audio.AudioRecorder
import com.ska.transcribe.audio.RecorderStatus
import com.ska.transcribe.stt.AssemblyAiConfig
import com.ska.transcribe.stt.AssemblyAiSTT
import com.ska.transcribe.stt.GoogleSTT
import com.ska.transcribe.stt.GoogleSTTConfig
import com.ska.transcribe.stt.SpeechToText
import com.ska.transcribe.stt.SttStatus
import com.ska.transcribe.stt.TokenProvider
import com.ska.transcribe.stt.TranscriptResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Available STT providers.
 */
enum class SttProvider(val displayName: String) {
    ASSEMBLY_AI("AssemblyAI"),
    GOOGLE("Google Cloud")
}

/**
 * UI state for the transcription screen.
 */
data class TranscribeUiState(
    /** Whether transcription is currently active */
    val isTranscribing: Boolean = false,

    /** Currently selected STT provider */
    val selectedProvider: SttProvider = SttProvider.ASSEMBLY_AI,

    /** Current interim transcript (not yet finalized) */
    val interimTranscript: String = "",

    /** List of finalized transcripts */
    val finalTranscripts: List<String> = emptyList(),

    /** Current audio recorder status */
    val audioStatus: RecorderStatus = RecorderStatus.Idle,

    /** Current STT service status */
    val sttStatus: SttStatus = SttStatus.Idle,

    /** Error message to display, if any */
    val errorMessage: String? = null,

    /** Whether microphone permission has been granted */
    val hasPermission: Boolean = false
)

/**
 * Configuration for STT providers.
 */
data class SttProviderConfig(
    val assemblyAiTokenProvider: TokenProvider,
    val googleTokenProvider: TokenProvider,
    val googleProjectId: String
)

/**
 * ViewModel for managing transcription state and operations.
 *
 * @param application Application context for AudioRecorder initialization
 * @param providerConfig Configuration for STT providers
 */
class TranscribeViewModel(
    application: Application,
    private val providerConfig: SttProviderConfig
) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "TranscribeViewModel"
    }

    private val _uiState = MutableStateFlow(TranscribeUiState())
    val uiState: StateFlow<TranscribeUiState> = _uiState.asStateFlow()

    // STT instances
    private var currentStt: SpeechToText? = null
    private var sttStatusJob: Job? = null
    private var sttTranscriptJob: Job? = null

    init {
        // Ensure AudioRecorder is initialized
        if (!AudioRecorder.isInitialized()) {
            AudioRecorder.initialize(application)
        }

        // Observe audio recorder status
        viewModelScope.launch {
            AudioRecorder.status.collect { status ->
                _uiState.update { it.copy(audioStatus = status) }

                // Handle audio errors
                if (status is RecorderStatus.Error) {
                    _uiState.update {
                        it.copy(errorMessage = status.error.toDisplayMessage())
                    }
                }
            }
        }
    }

    /**
     * Select an STT provider.
     * Can only be changed when not transcribing.
     */
    fun selectProvider(provider: SttProvider) {
        if (_uiState.value.isTranscribing) {
            Log.w(TAG, "Cannot change provider while transcribing")
            return
        }

        if (_uiState.value.selectedProvider == provider) {
            return
        }

        Log.i(TAG, "Switching STT provider to: ${provider.displayName}")

        // Cleanup current STT instance
        cleanupCurrentStt()

        _uiState.update { it.copy(selectedProvider = provider, sttStatus = SttStatus.Idle) }
    }

    /**
     * Called when microphone permission is granted.
     */
    fun onPermissionGranted() {
        _uiState.update { it.copy(hasPermission = true, errorMessage = null) }
    }

    /**
     * Called when microphone permission is denied.
     */
    fun onPermissionDenied() {
        _uiState.update {
            it.copy(
                hasPermission = false,
                errorMessage = "Microphone permission is required for transcription"
            )
        }
    }

    /**
     * Start transcription with the selected provider.
     */
    fun startTranscription() {
        if (_uiState.value.isTranscribing) {
            Log.d(TAG, "Already transcribing")
            return
        }

        val provider = _uiState.value.selectedProvider
        Log.i(TAG, "Starting transcription with ${provider.displayName}")

        // Clear previous state
        _uiState.update {
            it.copy(
                isTranscribing = true,
                interimTranscript = "",
                errorMessage = null
            )
        }

        // Create STT instance for selected provider
        currentStt = createSttInstance(provider)

        // Observe STT status
        sttStatusJob = viewModelScope.launch {
            currentStt?.status?.collect { status ->
                _uiState.update { it.copy(sttStatus = status) }

                if (status is SttStatus.Error) {
                    _uiState.update {
                        it.copy(errorMessage = status.message)
                    }
                    if (!status.recoverable) {
                        stopTranscription()
                    }
                }
            }
        }

        // Observe transcripts
        sttTranscriptJob = viewModelScope.launch {
            currentStt?.transcripts?.collect { result ->
                handleTranscript(result)
            }
        }

        // Start STT
        currentStt?.start()
    }

    /**
     * Stop transcription.
     */
    fun stopTranscription() {
        if (!_uiState.value.isTranscribing) {
            Log.d(TAG, "Not transcribing")
            return
        }

        Log.i(TAG, "Stopping transcription")

        currentStt?.stop()

        // Cancel observation jobs
        sttStatusJob?.cancel()
        sttStatusJob = null
        sttTranscriptJob?.cancel()
        sttTranscriptJob = null

        // Finalize any remaining interim transcript
        val interim = _uiState.value.interimTranscript
        if (interim.isNotBlank()) {
            _uiState.update {
                it.copy(
                    finalTranscripts = it.finalTranscripts + interim,
                    interimTranscript = ""
                )
            }
        }

        _uiState.update { it.copy(isTranscribing = false) }
    }

    /**
     * Toggle transcription on/off.
     */
    fun toggleTranscription() {
        if (_uiState.value.isTranscribing) {
            stopTranscription()
        } else {
            startTranscription()
        }
    }

    /**
     * Clear all transcripts.
     */
    fun clearTranscripts() {
        _uiState.update {
            it.copy(
                interimTranscript = "",
                finalTranscripts = emptyList()
            )
        }
    }

    /**
     * Dismiss error message.
     */
    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    /**
     * Force end-of-turn detection (AssemblyAI specific).
     */
    fun forceEndpoint() {
        (currentStt as? AssemblyAiSTT)?.forceEndpoint()
    }

    private fun createSttInstance(provider: SttProvider): SpeechToText {
        return when (provider) {
            SttProvider.ASSEMBLY_AI -> AssemblyAiSTT(
                tokenProvider = providerConfig.assemblyAiTokenProvider,
                config = AssemblyAiConfig(
                    sampleRate = 16000,
                    formatTurns = true
                )
            )
            SttProvider.GOOGLE -> GoogleSTT(
                tokenProvider = providerConfig.googleTokenProvider,
                config = GoogleSTTConfig(
                    projectId = providerConfig.googleProjectId,
                    sampleRate = 16000,
                    model = "chirp"
                )
            )
        }
    }

    private fun cleanupCurrentStt() {
        sttStatusJob?.cancel()
        sttStatusJob = null
        sttTranscriptJob?.cancel()
        sttTranscriptJob = null

        when (val stt = currentStt) {
            is AssemblyAiSTT -> stt.cleanup()
            is GoogleSTT -> stt.cleanup()
            else -> {}
        }
        currentStt = null
    }

    private fun handleTranscript(result: TranscriptResult) {
        if (result.isFinal) {
            // Add to final transcripts and clear interim
            if (result.text.isNotBlank()) {
                _uiState.update {
                    it.copy(
                        finalTranscripts = it.finalTranscripts + result.text,
                        interimTranscript = ""
                    )
                }
            }
        } else {
            // Update interim transcript
            _uiState.update {
                it.copy(interimTranscript = result.text)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(TAG, "ViewModel cleared")
        cleanupCurrentStt()
    }
}

/**
 * Factory for creating TranscribeViewModel with dependencies.
 */
class TranscribeViewModelFactory(
    private val application: Application,
    private val providerConfig: SttProviderConfig
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TranscribeViewModel::class.java)) {
            return TranscribeViewModel(application, providerConfig) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
