package com.ska.transcribe.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger

// ============================================================================
// Data Classes and Sealed Types
// ============================================================================

/**
 * Represents the result of an audio recording operation.
 * Can be either successful audio data or an error.
 */
sealed class AudioResult {
    /**
     * Successful audio chunk with raw PCM data.
     * @param data Raw PCM audio bytes
     * @param timestamp System timestamp when this chunk was recorded
     * @param sampleRate Sample rate of the audio data
     * @param channelCount Number of audio channels (1 for mono, 2 for stereo)
     */
    data class Success(
        val data: ByteArray,
        val timestamp: Long,
        val sampleRate: Int,
        val channelCount: Int
    ) : AudioResult() {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false
            other as Success
            return data.contentEquals(other.data) &&
                    timestamp == other.timestamp &&
                    sampleRate == other.sampleRate &&
                    channelCount == other.channelCount
        }

        override fun hashCode(): Int {
            var result = data.contentHashCode()
            result = 31 * result + timestamp.hashCode()
            result = 31 * result + sampleRate
            result = 31 * result + channelCount
            return result
        }
    }

    /**
     * Error occurred during recording.
     * @param error The specific error that occurred
     */
    data class Error(val error: AudioError) : AudioResult()
}

/**
 * Comprehensive error types for audio recording operations.
 */
sealed class AudioError {
    /** Microphone permission not granted */
    data object PermissionDenied : AudioError()

    /** No audio input device available */
    data object DeviceNotAvailable : AudioError()

    /** Failed to initialize or start recording */
    data object RecordingFailed : AudioError()

    /** Audio device was disconnected during recording */
    data class DeviceDisconnected(val deviceName: String) : AudioError()

    /** Recording was interrupted (e.g., by phone call) */
    data object RecordingInterrupted : AudioError()

    /** AudioRecord initialization failed */
    data class InitializationFailed(val errorCode: Int) : AudioError()

    /** Unknown error with message */
    data class Unknown(val message: String, val cause: Throwable? = null) : AudioError()

    fun toDisplayMessage(): String = when (this) {
        is PermissionDenied -> "Microphone permission is required"
        is DeviceNotAvailable -> "No microphone available"
        is RecordingFailed -> "Failed to record audio"
        is DeviceDisconnected -> "Microphone disconnected: $deviceName"
        is RecordingInterrupted -> "Recording was interrupted"
        is InitializationFailed -> "Failed to initialize recorder (code: $errorCode)"
        is Unknown -> "Error: $message"
    }
}

/**
 * Represents the current status of the audio recorder.
 */
sealed class RecorderStatus {
    /** Recorder is idle, not recording */
    data object Idle : RecorderStatus()

    /** Recorder is initializing (getting permissions, setting up AudioRecord) */
    data object Initializing : RecorderStatus()

    /** Actively recording from the specified device */
    data class Recording(
        val deviceInfo: AudioDeviceInfo?,
        val deviceName: String
    ) : RecorderStatus()

    /** Switching to a different audio device */
    data class SwitchingDevice(
        val fromDevice: String?,
        val toDevice: String
    ) : RecorderStatus()

    /** An error occurred */
    data class Error(val error: AudioError) : RecorderStatus()

    /** Recording was stopped */
    data object Stopped : RecorderStatus()
}

/**
 * Configuration for audio recording.
 * Defaults are optimized for speech recognition (STT).
 */
data class AudioConfig(
    /** Sample rate in Hz. 16000 is optimal for most STT services */
    val sampleRate: Int = 16000,

    /** Audio channel configuration */
    val channelConfig: Int = AudioFormat.CHANNEL_IN_MONO,

    /** Audio encoding format */
    val audioFormat: Int = AudioFormat.ENCODING_PCM_16BIT,

    /** Duration of each audio chunk in milliseconds */
    val chunkDurationMs: Int = 100,

    /** Maximum retry attempts for transient failures */
    val maxRetryAttempts: Int = 3,

    /** Initial retry delay in milliseconds (doubles with each retry) */
    val retryDelayMs: Long = 100L
) {
    /** Number of channels based on channel config */
    val channelCount: Int
        get() = if (channelConfig == AudioFormat.CHANNEL_IN_STEREO) 2 else 1

    /** Bytes per sample based on audio format */
    val bytesPerSample: Int
        get() = when (audioFormat) {
            AudioFormat.ENCODING_PCM_8BIT -> 1
            AudioFormat.ENCODING_PCM_16BIT -> 2
            AudioFormat.ENCODING_PCM_FLOAT -> 4
            else -> 2
        }

    /** Size of each audio chunk in bytes */
    val chunkSizeBytes: Int
        get() = (sampleRate * bytesPerSample * channelCount * chunkDurationMs) / 1000

    /** Minimum buffer size required by AudioRecord */
    fun getMinBufferSize(): Int {
        val minSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        // Use at least 2x chunk size for smooth operation
        return maxOf(minSize, chunkSizeBytes * 2)
    }
}

// ============================================================================
// AudioRecorder Singleton
// ============================================================================

/**
 * Production-grade audio recorder singleton.
 *
 * Features:
 * - Automatic start/stop based on flow subscriptions
 * - Multiple concurrent collectors supported
 * - Priority-based device selection (USB > Wired > Bluetooth > Built-in)
 * - Automatic device switching on connect/disconnect
 * - Comprehensive error handling with retry logic
 * - ~100ms audio chunks (configurable)
 *
 * Usage:
 * ```
 * // Initialize once (typically in Application class)
 * AudioRecorder.initialize(applicationContext)
 *
 * // Collect audio chunks - recording starts automatically
 * AudioRecorder.audioChunks.collect { result ->
 *     when (result) {
 *         is AudioResult.Success -> processAudio(result.data)
 *         is AudioResult.Error -> handleError(result.error)
 *     }
 * }
 * // Recording stops automatically when all collectors are gone
 * ```
 */
object AudioRecorder {
    private const val TAG = "AudioRecorder"

    // ========================================================================
    // State
    // ========================================================================

    private var isInitialized = false
    private lateinit var applicationContext: Context
    private lateinit var audioManager: AudioManager

    private var config = AudioConfig()
    private val configMutex = Mutex()

    // Recording state
    private var audioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    private val recordingMutex = Mutex()

    // Subscriber management
    private val subscriberCount = AtomicInteger(0)

    // Coroutine scope for recording operations
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Manual device override (null = auto-select by priority)
    private var manualDeviceOverride: AudioDeviceInfo? = null

    // Current active device
    private var currentDevice: AudioDeviceInfo? = null

    // ========================================================================
    // Flows
    // ========================================================================

    private val _audioFlow = MutableSharedFlow<AudioResult>(
        replay = 0,
        extraBufferCapacity = 64, // Buffer ~6.4 seconds at 100ms chunks
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )

    private val _status = MutableStateFlow<RecorderStatus>(RecorderStatus.Idle)

    /**
     * Flow of audio chunks. Recording automatically starts when the first
     * collector subscribes and stops when all collectors are gone.
     *
     * Emits [AudioResult.Success] for audio data and [AudioResult.Error] for errors.
     */
    val audioChunks: Flow<AudioResult> = _audioFlow
        .onStart {
            val count = subscriberCount.incrementAndGet()
            Log.d(TAG, "Subscriber added, count: $count")
            if (count == 1) {
                startRecordingInternal()
            }
        }
        .onCompletion {
            val count = subscriberCount.decrementAndGet()
            Log.d(TAG, "Subscriber removed, count: $count")
            if (count == 0) {
                stopRecordingInternal()
            }
        }

    /**
     * Current status of the recorder.
     */
    val status: StateFlow<RecorderStatus> = _status.asStateFlow()

    /**
     * Raw shared flow for audio chunks (without auto start/stop).
     * Use this only if you need direct access without subscription management.
     */
    val rawAudioFlow: SharedFlow<AudioResult> = _audioFlow.asSharedFlow()

    // ========================================================================
    // Device Callback
    // ========================================================================

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            Log.d(TAG, "Audio devices added: ${addedDevices.map { it.productName }}")
            handleDeviceChange()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            Log.d(TAG, "Audio devices removed: ${removedDevices.map { it.productName }}")

            // Check if current device was removed
            currentDevice?.let { current ->
                val wasRemoved = removedDevices.any { it.id == current.id }
                if (wasRemoved) {
                    Log.w(TAG, "Current recording device was removed: ${current.productName}")
                    scope.launch {
                        _audioFlow.emit(
                            AudioResult.Error(
                                AudioError.DeviceDisconnected(current.productName?.toString() ?: "Unknown")
                            )
                        )
                    }
                }
            }

            handleDeviceChange()
        }
    }

    private fun handleDeviceChange() {
        // Only handle device changes if we're actively recording
        if (subscriberCount.get() > 0 && _status.value is RecorderStatus.Recording) {
            scope.launch {
                switchToOptimalDevice()
            }
        }
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Initialize the AudioRecorder. Must be called before collecting audio.
     * Typically called in Application.onCreate().
     *
     * @param context Application context
     */
    fun initialize(context: Context) {
        if (isInitialized) {
            Log.w(TAG, "AudioRecorder already initialized")
            return
        }

        applicationContext = context.applicationContext
        audioManager = applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // Register device callback
        audioManager.registerAudioDeviceCallback(deviceCallback, Handler(Looper.getMainLooper()))

        isInitialized = true
        Log.i(TAG, "AudioRecorder initialized")
    }

    /**
     * Check if the recorder has been initialized.
     */
    fun isInitialized(): Boolean = isInitialized

    // ========================================================================
    // Configuration
    // ========================================================================

    /**
     * Update the audio configuration.
     * Takes effect on the next recording session (or immediately if not recording).
     *
     * @param newConfig The new audio configuration
     */
    suspend fun configure(newConfig: AudioConfig) {
        configMutex.withLock {
            config = newConfig
            Log.i(TAG, "Configuration updated: $newConfig")
        }

        // If currently recording, restart with new config
        if (subscriberCount.get() > 0) {
            restartRecording()
        }
    }

    /**
     * Get the current audio configuration.
     */
    fun getConfig(): AudioConfig = config

    // ========================================================================
    // Device Management
    // ========================================================================

    /**
     * Get list of available audio input devices.
     */
    fun getAvailableDevices(): List<AudioDeviceInfo> {
        checkInitialized()
        return audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
    }

    /**
     * Manually select a specific audio device.
     * Pass null to return to automatic priority-based selection.
     *
     * @param device The device to use, or null for auto-selection
     */
    suspend fun selectDevice(device: AudioDeviceInfo?) {
        Log.i(TAG, "Manual device selection: ${device?.productName ?: "auto"}")
        manualDeviceOverride = device

        // If currently recording, switch to the new device
        if (subscriberCount.get() > 0) {
            switchToOptimalDevice()
        }
    }

    /**
     * Get the currently active recording device.
     */
    fun getCurrentDevice(): AudioDeviceInfo? = currentDevice

    /**
     * Get the device priority for automatic selection.
     * Higher value = higher priority.
     */
    private fun getDevicePriority(device: AudioDeviceInfo): Int {
        return when (device.type) {
            AudioDeviceInfo.TYPE_USB_DEVICE -> 100
            AudioDeviceInfo.TYPE_USB_HEADSET -> 95
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> 90
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> 85
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> 70
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> 65
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> 50
            else -> 10
        }
    }

    /**
     * Select the optimal device based on priority or manual override.
     */
    private fun selectOptimalDevice(): AudioDeviceInfo? {
        // If manual override is set and device is still available, use it
        manualDeviceOverride?.let { override ->
            val available = getAvailableDevices()
            if (available.any { it.id == override.id }) {
                return override
            } else {
                Log.w(TAG, "Manual device override no longer available, switching to auto")
                manualDeviceOverride = null
            }
        }

        // Auto-select by priority
        return getAvailableDevices()
            .filter { it.isSource } // Input devices only
            .maxByOrNull { getDevicePriority(it) }
    }

    private suspend fun switchToOptimalDevice() {
        val newDevice = selectOptimalDevice()
        val oldDevice = currentDevice

        // No change needed
        if (newDevice?.id == oldDevice?.id) {
            return
        }

        Log.i(TAG, "Switching device: ${oldDevice?.productName} -> ${newDevice?.productName}")

        _status.value = RecorderStatus.SwitchingDevice(
            fromDevice = oldDevice?.productName?.toString(),
            toDevice = newDevice?.productName?.toString() ?: "None"
        )

        // Restart recording with new device
        restartRecording()
    }

    // ========================================================================
    // Recording Control
    // ========================================================================

    /**
     * Force restart the recording.
     * Useful when you need to apply configuration changes or recover from errors.
     */
    suspend fun forceRestart() {
        Log.i(TAG, "Force restart requested")
        if (subscriberCount.get() > 0) {
            restartRecording()
        }
    }

    private suspend fun restartRecording() {
        recordingMutex.withLock {
            stopRecordingInternalLocked()
            delay(50) // Brief delay to ensure clean restart
            startRecordingInternalLocked()
        }
    }

    private fun startRecordingInternal() {
        scope.launch {
            recordingMutex.withLock {
                startRecordingInternalLocked()
            }
        }
    }

    private suspend fun startRecordingInternalLocked() {
        checkInitialized()

        if (recordingJob?.isActive == true) {
            Log.d(TAG, "Recording already active")
            return
        }

        _status.value = RecorderStatus.Initializing

        // Check permission
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.e(TAG, "RECORD_AUDIO permission not granted")
            _status.value = RecorderStatus.Error(AudioError.PermissionDenied)
            _audioFlow.emit(AudioResult.Error(AudioError.PermissionDenied))
            return
        }

        // Select device
        val device = selectOptimalDevice()
        if (device == null) {
            Log.e(TAG, "No audio input device available")
            _status.value = RecorderStatus.Error(AudioError.DeviceNotAvailable)
            _audioFlow.emit(AudioResult.Error(AudioError.DeviceNotAvailable))
            return
        }

        // Initialize AudioRecord with retry logic
        var lastError: AudioError? = null
        var currentConfig: AudioConfig

        configMutex.withLock {
            currentConfig = config
        }

        for (attempt in 1..currentConfig.maxRetryAttempts) {
            try {
                val bufferSize = currentConfig.getMinBufferSize()

                if (bufferSize == AudioRecord.ERROR || bufferSize == AudioRecord.ERROR_BAD_VALUE) {
                    throw IllegalStateException("Invalid buffer size: $bufferSize")
                }

                val record = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    currentConfig.sampleRate,
                    currentConfig.channelConfig,
                    currentConfig.audioFormat,
                    bufferSize
                )

                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    record.release()
                    throw IllegalStateException("AudioRecord failed to initialize, state: ${record.state}")
                }

                // Set preferred device if available
                record.preferredDevice = device

                audioRecord = record
                currentDevice = device

                // Start recording
                record.startRecording()

                if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    record.stop()
                    record.release()
                    throw IllegalStateException("Failed to start recording, state: ${record.recordingState}")
                }

                Log.i(TAG, "Recording started on device: ${device.productName}")
                _status.value = RecorderStatus.Recording(
                    deviceInfo = device,
                    deviceName = device.productName?.toString() ?: "Unknown"
                )

                // Start recording coroutine
                recordingJob = scope.launch(Dispatchers.IO) {
                    recordingLoop(record, currentConfig)
                }

                return // Success!

            } catch (e: Exception) {
                Log.e(TAG, "Failed to start recording (attempt $attempt): ${e.message}")
                lastError = when (e) {
                    is SecurityException -> AudioError.PermissionDenied
                    is IllegalStateException -> AudioError.InitializationFailed(
                        audioRecord?.state ?: -1
                    )
                    else -> AudioError.Unknown(e.message ?: "Unknown error", e)
                }

                if (attempt < currentConfig.maxRetryAttempts) {
                    delay(currentConfig.retryDelayMs * attempt) // Exponential backoff
                }
            }
        }

        // All retries failed
        lastError?.let { error ->
            _status.value = RecorderStatus.Error(error)
            _audioFlow.emit(AudioResult.Error(error))
        }
    }

    private suspend fun recordingLoop(record: AudioRecord, config: AudioConfig) {
        val buffer = ByteArray(config.chunkSizeBytes)
        var consecutiveErrors = 0
        val maxConsecutiveErrors = 5

        try {
            while (currentCoroutineContext().isActive && record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val bytesRead = record.read(buffer, 0, buffer.size)

                when {
                    bytesRead > 0 -> {
                        consecutiveErrors = 0
                        val chunk = if (bytesRead == buffer.size) {
                            buffer.copyOf()
                        } else {
                            buffer.copyOf(bytesRead)
                        }

                        _audioFlow.emit(
                            AudioResult.Success(
                                data = chunk,
                                timestamp = System.currentTimeMillis(),
                                sampleRate = config.sampleRate,
                                channelCount = config.channelCount
                            )
                        )
                    }

                    bytesRead == AudioRecord.ERROR_INVALID_OPERATION -> {
                        Log.e(TAG, "ERROR_INVALID_OPERATION in recording loop")
                        consecutiveErrors++
                        if (consecutiveErrors >= maxConsecutiveErrors) {
                            _audioFlow.emit(AudioResult.Error(AudioError.RecordingFailed))
                            break
                        }
                        delay(10)
                    }

                    bytesRead == AudioRecord.ERROR_BAD_VALUE -> {
                        Log.e(TAG, "ERROR_BAD_VALUE in recording loop")
                        consecutiveErrors++
                        if (consecutiveErrors >= maxConsecutiveErrors) {
                            _audioFlow.emit(AudioResult.Error(AudioError.RecordingFailed))
                            break
                        }
                        delay(10)
                    }

                    bytesRead == AudioRecord.ERROR_DEAD_OBJECT -> {
                        Log.e(TAG, "ERROR_DEAD_OBJECT - device may have been disconnected")
                        _audioFlow.emit(
                            AudioResult.Error(
                                AudioError.DeviceDisconnected(
                                    currentDevice?.productName?.toString() ?: "Unknown"
                                )
                            )
                        )
                        break
                    }

                    bytesRead == 0 -> {
                        // No data available, brief wait
                        delay(1)
                    }

                    else -> {
                        Log.w(TAG, "Unexpected read result: $bytesRead")
                        consecutiveErrors++
                        if (consecutiveErrors >= maxConsecutiveErrors) {
                            _audioFlow.emit(
                                AudioResult.Error(
                                    AudioError.Unknown("Unexpected read result: $bytesRead")
                                )
                            )
                            break
                        }
                        delay(10)
                    }
                }
            }
        } catch (e: CancellationException) {
            Log.d(TAG, "Recording loop cancelled")
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Error in recording loop", e)
            _audioFlow.emit(AudioResult.Error(AudioError.Unknown(e.message ?: "Unknown error", e)))
        } finally {
            Log.d(TAG, "Recording loop ended")
        }
    }

    private fun stopRecordingInternal() {
        scope.launch {
            recordingMutex.withLock {
                stopRecordingInternalLocked()
            }
        }
    }

    private fun stopRecordingInternalLocked() {
        Log.d(TAG, "Stopping recording")

        recordingJob?.cancel()
        recordingJob = null

        audioRecord?.let { record ->
            try {
                if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    record.stop()
                }
                record.release()
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping AudioRecord", e)
            }
        }
        audioRecord = null
        currentDevice = null

        _status.value = RecorderStatus.Stopped
        Log.i(TAG, "Recording stopped")
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    /**
     * Release all resources. Call when the recorder is no longer needed.
     * After calling cleanup(), the recorder must be re-initialized before use.
     */
    fun cleanup() {
        Log.i(TAG, "Cleanup requested")

        scope.launch {
            recordingMutex.withLock {
                stopRecordingInternalLocked()
            }
        }

        if (isInitialized) {
            try {
                audioManager.unregisterAudioDeviceCallback(deviceCallback)
            } catch (e: Exception) {
                Log.e(TAG, "Error unregistering device callback", e)
            }
        }

        manualDeviceOverride = null
        isInitialized = false
        _status.value = RecorderStatus.Idle

        Log.i(TAG, "Cleanup complete")
    }

    // ========================================================================
    // Utility
    // ========================================================================

    private fun checkInitialized() {
        if (!isInitialized) {
            throw IllegalStateException(
                "AudioRecorder not initialized. Call AudioRecorder.initialize(context) first."
            )
        }
    }

    /**
     * Get a human-readable description of an audio device.
     */
    fun getDeviceDescription(device: AudioDeviceInfo): String {
        val typeName = when (device.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in Mic"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth SCO"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired Headset"
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired Headphones"
            AudioDeviceInfo.TYPE_USB_DEVICE -> "USB Device"
            AudioDeviceInfo.TYPE_USB_HEADSET -> "USB Headset"
            else -> "Unknown (${device.type})"
        }
        return "${device.productName} ($typeName)"
    }
}

