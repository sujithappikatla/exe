using System.Collections;

namespace MagicInk
{
    internal static class Program
    {

        static ArrayList FormsList;
        static ChromeOverlayManager cm;


        [STAThread]
        static void Main()
        {
            
            ApplicationConfiguration.Initialize();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            cm = new ChromeOverlayManager();

            //ProcessOverlayCreator creator = new ProcessOverlayCreator();



            //creator.OverlayFor("chrome");
            //creator.OverlayFor("POWERPNT");
            //FormsList = creator.CreateOverlays();


                
            //Application.Run((Form)FormsList[0]);
            
            Controller cc= new Controller(cm);
            cc.Show();

            Application.Run();
        }

    }
}