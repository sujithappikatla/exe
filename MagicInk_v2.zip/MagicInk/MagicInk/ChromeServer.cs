﻿using System;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MagicInk
{
    public class ChromeServer
    {
        public event EventHandler<string> MessageReceived;
        private HttpListener _httpListener;

        public ChromeServer(string uriPrefix)
        {
            _httpListener = new HttpListener();
            _httpListener.Prefixes.Add(uriPrefix);
        }

        public async Task StartAsync()
        {
            _httpListener.Start();
            Console.WriteLine("WebSocket Server started.");
            //MessageBox.Show("Server Started");

            while (true)
            {
                HttpListenerContext httpContext = await _httpListener.GetContextAsync();
                if (httpContext.Request.IsWebSocketRequest)
                {
                    WebSocketContext webSocketContext = await httpContext.AcceptWebSocketAsync(subProtocol: null);
                    ProcessWebSocket(webSocketContext.WebSocket);
                }
                else
                {
                    httpContext.Response.StatusCode = 400;
                    httpContext.Response.Close();
                }
            }
        }

        private async void ProcessWebSocket(WebSocket webSocket)
        {
            var buffer = new byte[1024 * 4];
            try
            {
                while (webSocket.State == WebSocketState.Open)
                {
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                    if (result.MessageType == WebSocketMessageType.Text)
                    {
                        var message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                        OnMessageReceived(message);
                        // Echo the message back to the client
                        await webSocket.SendAsync(new ArraySegment<byte>(buffer, 0, result.Count), WebSocketMessageType.Text, result.EndOfMessage, CancellationToken.None);
                    }
                    else if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, CancellationToken.None);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"WebSocket error: {e.Message}");
            }
            finally
            {
                if (webSocket != null)
                    webSocket.Dispose();
            }
        }

        protected virtual void OnMessageReceived(string message)
        {
            EventHandler<string> handler = MessageReceived;
            handler?.Invoke(this, message);
        }
    }
}
