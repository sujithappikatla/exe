﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagicInk
{
    public class ChromeOverlayManager : IProcessOverlay
    {
        public Dictionary<string, ChromeCanvas> forms = new Dictionary<string, ChromeCanvas>();
        Queue<string> messages = new Queue<string>();
        private System.Windows.Forms.Timer processingTimer = new System.Windows.Forms.Timer();
        public string FocusedId = "";

        public ChromeOverlayManager()
        {
            InitializeChromeServer();

            processingTimer.Interval = 100; // Update interval in milliseconds
            processingTimer.Tick += (sender, e) => processMessages();
            processingTimer.Start();

        }

        void processMessages()
        {
            while (messages.Count > 0)
            {
                var msg = messages.Dequeue();
                var json = JsonSerializer.Deserialize<Dictionary<string, object>>(msg);

                
                if (json.ContainsKey("focus"))
                {
                    if(json["focus"].ToString() == "No")
                    {
                        if (FocusedId == "")
                            return;
                        
                        if (forms[FocusedId].InvokeRequired)
                        {
                            forms[FocusedId].Invoke(new MethodInvoker(() => forms[FocusedId].Hide()));
                        }
                        else
                        {
                            forms[FocusedId].Hide();
                        }

                        FocusedId = "";
                        return;
                    }
                    else
                    {
                        var _overlayId = json["windowId"].ToString() + json["tabId"].ToString();

                        if (forms.ContainsKey(_overlayId) == false)
                        {
                            CreateOverlay(_overlayId);

                        }
                        FocusedId = _overlayId;
                    }
                }

                if (FocusedId == "")
                    return;

                var overlayId = json["windowId"].ToString() + json["tabId"].ToString();

                if (FocusedId != "" && FocusedId != overlayId)
                   return;

                if (forms.ContainsKey(overlayId) == false)
                {
                    CreateOverlay(overlayId);

                }

                FocusedId = overlayId;



                foreach (var item in forms)
                {
                    if (item.Key == FocusedId)
                    {
                        if (item.Value.InvokeRequired)
                        {
                            item.Value.Invoke(new MethodInvoker(() => item.Value.Show()));
                        }
                        else
                        {
                            item.Value.Show();
                        }
                    }
                    else
                    {
                        if (item.Value.InvokeRequired)
                        {
                            item.Value.Invoke(new MethodInvoker(() => item.Value.Hide()));
                        }
                        else
                        {
                            item.Value.Hide();
                        }
                    }
                }
                if (json.ContainsKey("viewportWidth"))
                {
                    forms[FocusedId].SetOverlayPosition(
                        int.Parse(json["windowLeft"].ToString()),
                        int.Parse(json["windowTop"].ToString()),
                        int.Parse(json["windowWidth"].ToString()),
                        int.Parse(json["windowHeight"].ToString()),
                        int.Parse(json["viewportWidth"].ToString()),
                        int.Parse(json["viewportHeight"].ToString())
                    );
                }
                if (json.ContainsKey("scrollX"))
                {
                    float scrollX = float.Parse(json["scrollX"].ToString());
                    float scrollY = float.Parse(json["scrollY"].ToString());

                    forms[FocusedId].SetScrollInfo(scrollX, scrollY);
                }



            }
        }

        private async void InitializeChromeServer()
        {

            ChromeServer server = new ChromeServer("http://localhost:8088/");
            server.MessageReceived += Server_MessageReceived;
            await server.StartAsync();
        }

        private void Server_MessageReceived(object sender, string e)
        {

            Console.WriteLine($"Message Received: {e}");

            messages.Enqueue(e);

        }


        public void CreateOverlay(string overlayID)
        {
            if (forms.ContainsKey(overlayID))
                return;


            forms[overlayID] = new ChromeCanvas();
            forms[overlayID].Show();


        }



    }
}
