﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MagicInk.WindowInterop;

namespace MagicInk
{
    public partial class Controller : Form
    {
        Button button1;
        ChromeOverlayManager overlayManager;
        bool Annotate = true;


        public Controller(ChromeOverlayManager cm)
        {
            overlayManager = cm;
            InitializeComponent();

            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.None;

            button1 = new Button();
            button1.Left = 0;
            button1.Top = 0;
            button1.Width = 50;
            button1.Height = 50;
            button1.Text = "C/A";
            this.Controls.Add(this.button1);

            button1.Click += Button1_Click;

            this.Location = new Point(30, 30);
            this.Width = 50;
            PerformLayout();

        }
        private void Button1_Click(object? sender, EventArgs e)
        {
            Annotate = !Annotate;
            foreach (var item in overlayManager.forms)
            {
                if (item.Value.InvokeRequired)
                {
                    item.Value.Invoke(new MethodInvoker(() => item.Value.ToggleMode(Annotate)));
                }
                else
                {
                    item.Value.ToggleMode(Annotate);
                }
            }
        }

        private void Controller_Load(object sender, EventArgs e)
        {

        }
    }
}
