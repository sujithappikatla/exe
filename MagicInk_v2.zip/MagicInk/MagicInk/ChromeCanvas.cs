﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MagicInk.WindowInterop;

namespace MagicInk
{
    public partial class ChromeCanvas : Form
    {

        private CustomPanel drawingPanel;
        private Bitmap drawingBitmap;
        private Point previousPoint = Point.Empty;
        private bool isDrawing = false;
        private int overlayWidth = 0;
        private int overlayHeight = 0;


        public ChromeCanvas()
        {
            InitializeComponent();
            InitializeWindowStyles();
            InitializeDrawingPanel();
            InitializeBitmap();
        }


        private void InitializeWindowStyles()
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void InitializeDrawingPanel()
        {
            drawingPanel = new CustomPanel();
            drawingPanel.Dock = DockStyle.Fill;
            drawingPanel.AutoScroll = true;
            drawingPanel.BackColor = Color.Transparent;

            drawingPanel.MouseDown += onMouseDown;
            drawingPanel.MouseMove += onMouseMove;
            drawingPanel.MouseUp += onMouseUp;
            drawingPanel.Paint += onPaint;
            drawingPanel.Resize += onResize;
            drawingPanel.Scroll += onScroll;
            this.Controls.Add(drawingPanel);
        }

        private void onMouseDown(object sender, MouseEventArgs e)
        {

            isDrawing = true;
            // Adjust the point for the current scroll position
            previousPoint = new Point(e.X - drawingPanel.AutoScrollPosition.X, e.Y - drawingPanel.AutoScrollPosition.Y);
        }

        private void onMouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                using (Graphics g = Graphics.FromImage(drawingBitmap))
                {
                    Point currentPoint = new Point(e.X - drawingPanel.AutoScrollPosition.X, e.Y - drawingPanel.AutoScrollPosition.Y);
                    if (previousPoint != Point.Empty)
                    {
                        g.DrawLine(Pens.Beige, previousPoint, currentPoint);
                    }
                    previousPoint = currentPoint;
                }
                drawingPanel.Invalidate(); // Invalidate to trigger a repaint
            }
        }

        private void onMouseUp(object sender, MouseEventArgs e)
        {
            isDrawing = false;
            previousPoint = Point.Empty; // Reset previous point
        }

        private void onPaint(object sender, PaintEventArgs e)
        {
            // Draw the bitmap at adjusted position based on the current scroll position
            e.Graphics.DrawImage(drawingBitmap, drawingPanel.AutoScrollPosition.X, drawingPanel.AutoScrollPosition.Y);
        }

        private void onResize(object sender, EventArgs e)
        {
            drawingPanel.Invalidate(); // Redraw when the panel is resized
        }

        private void onScroll(object sender, EventArgs e)
        {
            drawingPanel.Refresh(); // Redraw when the panel is resized
        }

        private void InitializeBitmap()
        {
            drawingBitmap = new Bitmap(6000, 10000); // Adjust size as necessary
            using (Graphics g = Graphics.FromImage(drawingBitmap))
            {
                g.Clear(Color.BurlyWood); // Start with a blank canvas
            }
        }

        public void SetOverlaySize(int w, int h)
        {
            overlayWidth = (int)(w * 1.5);
            overlayHeight = (int)(h * 1.5);
            //MessageBox.Show($"width {width} height {height}");
        }

        public void SetOverlayPosition(int left, int top, int w, int h, int vw, int vh)
        {
            int topOffest = (int) (h*1.5 - vh*1.5);
            int overlayLeft = (int)(left * 1.5);
            int overlayTop = (int)(top * 1.5);
            overlayWidth = (int)(vw * 1.5);
            overlayHeight = (int)(vh * 1.5);
            int scrollOffset = 30;
            SetBounds(overlayLeft+10, overlayTop + topOffest, overlayWidth- scrollOffset, overlayHeight- scrollOffset);
        }

        public void SetScrollInfo(float scrollX, float scrollY)
        {
            float scrollFactor = 1.5f;
            drawingPanel.AutoScrollPosition = new Point(Math.Abs((int)(scrollX * scrollFactor)), Math.Abs((int)(scrollY * scrollFactor)));
        }

        public void ToggleMode(bool makeFocusable)
        {
            int exStyle = WindowInterop.GetWindowLong(this.Handle, WindowInterop.GWL_EXSTYLE);
            if (makeFocusable)
            {
                // Remove WS_EX_NOACTIVATE to make the window focusable
                exStyle &= ~(WindowInterop.WS_EX_NOACTIVATE | WindowInterop.WS_EX_TRANSPARENT);
            }
            else
            {
                // Add WS_EX_NOACTIVATE to make the window not focusable
                exStyle |= (WindowInterop.WS_EX_NOACTIVATE | WindowInterop.WS_EX_TRANSPARENT);
            }
            WindowInterop.SetWindowLong(this.Handle, WindowInterop.GWL_EXSTYLE, exStyle);

        }

    }
}
