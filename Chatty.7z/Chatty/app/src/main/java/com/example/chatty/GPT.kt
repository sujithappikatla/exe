package com.example.chatty
//
//import io.ktor.client.*
//import io.ktor.client.call.*
//import io.ktor.client.plugins.HttpTimeout
//import io.ktor.client.request.*
//import io.ktor.client.statement.*
//import io.ktor.client.plugins.contentnegotiation.*
//import io.ktor.http.*
//import kotlinx.serialization.Serializable
//import kotlinx.serialization.json.Json
//import io.ktor.serialization.kotlinx.json.*
////
//@Serializable
//data class GPTRequest(
//    val model: String,
//    val messages: List<Message>
//)
//
//@Serializable
//data class Message(
//    val role: String,
//    val content: String
//)
//
//@Serializable
//data class GPTResponse(
//    val choices: List<Choice>
//)
//
//@Serializable
//data class Choice(
//    val message: Message
//)
//
//suspend fun GPT(prompt: String): String {
//    val client = HttpClient {
//        install(ContentNegotiation) {
//            json(Json {
//                ignoreUnknownKeys = true
//                isLenient = true
//                encodeDefaults = true
//            })
//        }
//    }
//
//    val request = GPTRequest(
//        model = "gpt-4",
//        messages = listOf(Message(role = "user", content = prompt))
//    )
//
//    val response: HttpResponse = client.post("https://api.openai.com/v1/chat/completions") {
//        header(HttpHeaders.Authorization, "Bearer sk-proj-b00XfjSx8Dugfl5m73dMT3BlbkFJYTwtOTkixnj9jixcTLGr")
//        contentType(ContentType.Application.Json)
//        setBody(request)
//    }
//
//    val gptResponse: GPTResponse = response.body()
//    client.close()
//
//    return gptResponse.choices.firstOrNull()?.message?.content ?: "No response"
//}
//
//
//@Serializable
//data class GPTRequest(
//    val model: String,
//    val messages: List<Message>
//)
//
//@Serializable
//data class Message(
//    val role: String,
//    val content: String
//)
//
//@Serializable
//data class GPTResponse(
//    val choices: List<Choice>
//)
//
//@Serializable
//data class Choice(
//    val message: Message
//)
//
//suspend fun GPT(prompt: String): String {
//    val client = HttpClient {
//        install(ContentNegotiation) {
//            json(Json {
//                ignoreUnknownKeys = true
//                isLenient = true
//                encodeDefaults = true
//
//            })
//        }
//        install(HttpTimeout) {
//            requestTimeoutMillis = 60000 // Request timeout
//            connectTimeoutMillis = 60000 // Connect timeout
//            socketTimeoutMillis = 60000 // Socket timeout
//        }
//    }
//
//    val request = GPTRequest(
//        model = "gpt-4o",
//        messages = listOf(
//            Message(role = "system", content = "Surround block latex statements start and end with $ . Surround inline latex statements start and end with $$"),
//            Message(role = "user", content = prompt))
//    )
//
//    val response: HttpResponse = client.post("https://api.openai.com/v1/chat/completions") {
//        header(HttpHeaders.Authorization, "Bearer sk-proj-b00XfjSx8Dugfl5m73dMT3BlbkFJYTwtOTkixnj9jixcTLGr")
//        contentType(ContentType.Application.Json)
//        setBody(request)
//    }
//
//    val gptResponse: GPTResponse = response.body()
//    client.close()
//
//    return gptResponse.choices.firstOrNull()?.message?.content ?: "No response"
//}

import android.util.Log
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.utils.io.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.json.JSONObject

@Serializable
data class GPTRequest(
    val model: String,
    val messages: List<Message>,
    val stream: Boolean = true
)

@Serializable
data class Message(
    val role: String,
    val content: String
)

suspend fun GPT(prompt: String): Flow<String> = flow {
    val client = HttpClient {
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                isLenient = true
                encodeDefaults = true
            })
        }
        install(HttpTimeout) {
            requestTimeoutMillis = 60000 // Request timeout
            connectTimeoutMillis = 60000 // Connect timeout
            socketTimeoutMillis = 60000 // Socket timeout
        }
    }

    val request = GPTRequest(
        model = "gpt-4o",
        messages = listOf(
            Message(role = "system", content = "Surround block latex statements start and end with $ . Surround inline latex statements start and end with $$"),
            Message(role = "user", content = prompt))
    )

    val response: HttpResponse = client.post("https://api.openai.com/v1/chat/completions") {
        header(HttpHeaders.Authorization, "Bearer sk-proj-b00XfjSx8Dugfl5m73dMT3BlbkFJYTwtOTkixnj9jixcTLGr")
        contentType(ContentType.Application.Json)
        setBody(request)
    }

    val channel: ByteReadChannel = response.bodyAsChannel()

    while (!channel.isClosedForRead) {
        val line = channel.readUTF8Line()
        if (line != null && line.isNotBlank()) {

            val jsonString = line.substring(6)

            Log.i("AAAA", "===========  $jsonString")

            if(jsonString.trim() != "[DONE]")
            {

                val jsonObject = JSONObject(jsonString)
                // Check if the "choices" array exists
                if (jsonObject.has("choices")) {
                    val choicesArray = jsonObject.getJSONArray("choices")

                    // Check if the "choices" array is not empty
                    if (choicesArray.length() > 0) {
                        val firstChoice = choicesArray.getJSONObject(0)

                        // Check if the "delta" object exists
                        if (firstChoice.has("delta")) {
                            val deltaObject = firstChoice.getJSONObject("delta")

                            // Check if the "content" tag exists
                            if (deltaObject.has("content")) {
                                val content = deltaObject.getString("content")
                                emit(content.toString())
                            }
                        }
                    }
                }
            }




        }
    }

    client.close()
}
