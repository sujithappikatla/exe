package com.example.chatty

import io.noties.prism4j.GrammarLocator
import io.noties.prism4j.Prism4j
import io.noties.prism4j.annotations.PrismBundle

@PrismBundle(includeAll = true)
class GrammarLocatorDef : GrammarLocator {
    override fun grammar(prism4j: Prism4j, language: String): Prism4j.Grammar? {
        return when (language) {
            "cpp" -> Prism_cpp.create(prism4j)
            "c" -> Prism_c.create(prism4j)
            "clike" -> Prism_clike.create(prism4j)
            "java" -> prism4j.grammar("java")
            else -> null
        }
    }

    override fun languages(): MutableSet<String> {
        return mutableSetOf("cpp", "java")
    }
}