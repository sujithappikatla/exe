package com.example.chatty

import android.content.Context
import android.graphics.drawable.ColorDrawable
import androidx.compose.ui.graphics.Color
import io.noties.markwon.Markwon
import io.noties.markwon.SoftBreakAddsNewLinePlugin
import io.noties.markwon.ext.latex.JLatexMathPlugin
import io.noties.markwon.ext.latex.JLatexMathTheme
import io.noties.markwon.html.HtmlPlugin
import io.noties.markwon.image.ImagesPlugin
import io.noties.markwon.inlineparser.MarkwonInlineParserPlugin
import io.noties.markwon.linkify.LinkifyPlugin
import io.noties.markwon.syntax.Prism4jThemeDarkula
import io.noties.markwon.syntax.SyntaxHighlightPlugin
import io.noties.prism4j.Prism4j
import ru.noties.jlatexmath.JLatexMathDrawable

object MarkwonHelper {

    fun create(context: Context): Markwon
    {
        val prism4j = Prism4j(GrammarLocatorDef())
        val prism4jTheme = Prism4jThemeDarkula.create()
        return Markwon.builder(context)
//        .usePlugin(object : AbstractMarkwonPlugin() {
//            override fun configureTheme(builder: MarkwonTheme.Builder) {
//                builder
//                    .codeTextColor(0xFFFFFFFF.toInt())
//                    .codeBackgroundColor(android.graphics.Color.GREEN)
//            }
//        })
            .usePlugin(ImagesPlugin.create())
            .usePlugin(LinkifyPlugin.create())
            .usePlugin(HtmlPlugin.create())
            .usePlugin(SoftBreakAddsNewLinePlugin.create())
            .usePlugin(SyntaxHighlightPlugin.create(prism4j, prism4jTheme))
            .usePlugin(MarkwonInlineParserPlugin.create())
            .usePlugin(JLatexMathPlugin.create(50F) { builder ->

                builder.inlinesEnabled(true)

                builder.theme().backgroundProvider { ColorDrawable(0xFF444444.toInt()) }

                builder.theme().blockFitCanvas(true)

                builder.theme().blockHorizontalAlignment(JLatexMathDrawable.ALIGN_CENTER)

                builder.theme().padding(JLatexMathTheme.Padding.all(8))

                builder.theme().inlinePadding(JLatexMathTheme.Padding.symmetric(16, 8))

                builder.theme().blockPadding(JLatexMathTheme.Padding(0, 1, 2, 3))

                builder.theme().textColor(Color.Blue.value.toInt())
            })
            .build()

    }
}