package com.example.chatty






import android.graphics.drawable.ColorDrawable
import android.text.method.LinkMovementMethod
import android.util.Log
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.AbstractMarkwonPlugin
import io.noties.markwon.Markwon
import io.noties.markwon.SoftBreakAddsNewLinePlugin
import io.noties.markwon.core.MarkwonTheme
import io.noties.markwon.ext.latex.JLatexMathPlugin
import io.noties.markwon.ext.latex.JLatexMathTheme
import io.noties.markwon.html.HtmlPlugin
import io.noties.markwon.image.AsyncDrawableLoader
import io.noties.markwon.image.ImagesPlugin
import io.noties.markwon.inlineparser.MarkwonInlineParserPlugin
import io.noties.markwon.linkify.LinkifyPlugin
import io.noties.markwon.syntax.Prism4jSyntaxHighlight
import io.noties.markwon.syntax.Prism4jThemeDarkula
import io.noties.markwon.syntax.Prism4jThemeDefault
import io.noties.markwon.syntax.SyntaxHighlightPlugin
import io.noties.prism4j.GrammarLocator
import io.noties.prism4j.Prism4j
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import ru.noties.jlatexmath.JLatexMathDrawable


@Composable
fun App()
{
    var outputResponse by remember { mutableStateOf("") }

    Box(
        modifier = Modifier.fillMaxSize()
    )
    {
        Column {
            Box(modifier = Modifier
                .fillMaxSize()
                .weight(0.8f)) {
                Output(outputResponse)
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(0.1f),
            ) {
                Input{ it ->
                    outputResponse += it as String
                }
            }

        }
    }
}


@Composable
fun Output(outputResponse: String)
{
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ){
        item {
//            Text(text = outputResponse, modifier = Modifier.fillMaxSize())
            MarkdownText(outputResponse)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Input(setOutput: (Any?) -> Unit)
{
    var text by remember { mutableStateOf("") }


    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        TextField(
            value = text,
            onValueChange = { newText -> text = newText },
            label = { Text("Enter text") },
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        Button(
            onClick = {

                CoroutineScope(Dispatchers.IO).launch {

                        GPT(text).collect { responseChunk ->
                            Log.i("AAAAAAAA", "------------------------ $responseChunk")
                            withContext(Dispatchers.Main) {
                                setOutput(responseChunk)
                            }

                        }
//                        Log.i("AAAAAAAA", "------------------------ $str")
                        text = ""

                }


//                setOutput(text)

            }
        ) {
            Text("Send")
        }
    }
}


@Composable
fun MarkdownText(markdown: String) {
    val context = LocalContext.current
    val markwon = remember { MarkwonHelper.create(context) }


    AndroidView(
        factory = { ctx ->
            TextView(ctx).apply {

                setTextIsSelectable(true)
                movementMethod = LinkMovementMethod.getInstance()

            }
        },
        update = { textView ->
            textView.setTextColor(android.graphics.Color.parseColor("#FFFFFF"))
            textView.setTextSize(16f)
            markwon.setMarkdown(textView, markdown)
        }
    )
}
