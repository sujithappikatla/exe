from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
import firebase_admin
from firebase_admin import messaging

# Initialize Firebase Admin SDK using Application Default Credentials
firebase_admin.initialize_app()

app = FastAPI(title="FCM Notification Server")
templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Serve the HTML form for sending FCM messages."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/send")
async def send_fcm_message(
    fcm_token: str = Form(...),
    data_text: str = Form(...)
):
    """
    Send a high-priority data message to a device via FCM.
    
    Args:
        fcm_token: The FCM registration token of the target device
        data_text: The data payload to send
    
    Returns:
        JSON response with success status and message ID or error details
    """
    try:
        # Create the message with high priority for both Android and iOS
        message = messaging.Message(
            data={
                "message": data_text,
            },
            token=fcm_token,
            android=messaging.AndroidConfig(
                priority="high",
            ),
            apns=messaging.APNSConfig(
                headers={
                    "apns-priority": "10",
                },
            ),
        )
        
        # Send the message
        response = messaging.send(message)
        
        return JSONResponse(
            status_code=200,
            content={
                "success": True,
                "message_id": response,
                "detail": "Message sent successfully"
            }
        )
    
    except messaging.UnregisteredError:
        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "error": "invalid_token",
                "detail": "The FCM token is invalid or unregistered"
            }
        )
    
    except messaging.SenderIdMismatchError:
        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "error": "sender_mismatch",
                "detail": "The FCM token does not belong to this Firebase project"
            }
        )
    
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": "send_failed",
                "detail": str(e)
            }
        )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

