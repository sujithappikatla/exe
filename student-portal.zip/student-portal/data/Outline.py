from pydantic import BaseModel, Field
from typing import List

class SubSectionOutline(BaseModel):
    title: str = Field(description="The title of the sub-section")
    sub_section_about: str = Field(description="A short description of the sub-section. list out the points to be covered in the sub-section")

class SectionHeading(BaseModel):
    title: str = Field(description="The title of the section")
    sub_sections: List[SubSectionOutline] = Field(default_factory=list, description="The sub-sections of the section")

class Outline(BaseModel):
    title: str = Field(description="The title of the Blog")
    sections: List[SectionHeading] = Field(default_factory=list, description="The sections of the outline")
