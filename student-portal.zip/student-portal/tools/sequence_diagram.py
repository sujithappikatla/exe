from seqdiag import parser, builder, drawer
import asyncio
import uuid
import os   

async def generate_sequence_diagram(diagram_definition: str) -> str:
    os.makedirs("output/assets", exist_ok=True)
    tree = parser.parse_string(diagram_definition)
    diagram = builder.ScreenNodeBuilder.build(tree)
    filename = uuid.uuid4()
    draw = drawer.DiagramDraw('PNG', diagram, filename=f"output/assets/sequence_diagram_{filename}.png")
    draw.draw()
    draw.save()
    return f"assets/sequence_diagram_{filename}.png"


async def main():
    diagram_definition = """
    seqdiag {
        browser -> webserver [label = "GET /index.html"];
        browser <-- webserver;
        browser -> webserver [label = "POST /blog/comment"];
        webserver -> database [label = "INSERT comment"];
        webserver <-- database;
        browser <-- webserver;
    }
    """
    await generate_sequence_diagram(diagram_definition)

if __name__ == "__main__":
    asyncio.run(main())

