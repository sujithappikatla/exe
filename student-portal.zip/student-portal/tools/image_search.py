import os
import asyncio
import aiohttp
from typing import List
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.environ.get("GOOGLE_PSE_API_KEY")
SEARCH_ENGINE_ID = os.environ.get("GOOGLE_PSE_SEARCH_ENGINE_ID")

async def search_images(query: str) -> List[str]:
    """
    Asynchronously searches for images using Google Custom Search JSON API.

    Args:
        query: The search query.

    Returns:
        A list of top 3 image URLs.
    """
    if not API_KEY or not SEARCH_ENGINE_ID:
        raise ValueError("Please set GOOGLE_PSE_API_KEY and GOOGLE_PSE_SEARCH_ENGINE_ID environment variables.")

    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        'key': API_KEY,
        'cx': SEARCH_ENGINE_ID,
        'q': query,
        'searchType': 'image',
        'num': 3
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                response.raise_for_status()
                result = await response.json()

                if 'items' in result:
                    return [item['link'] for item in result['items']]
                else:
                    return []
    except aiohttp.ClientError as e:
        print(f"An error occurred: {e}")
        return []

async def main():
    image_urls = await search_images("latest advancements in AI")
    if image_urls:
        print("Found image URLs:")
        for url in image_urls:
            print(url)
    else:
        print("No images found.")

if __name__ == '__main__':
    # To run this async script
    asyncio.run(main())
