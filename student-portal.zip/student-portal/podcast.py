import os
from google import genai
from google.genai import types
import wave
import asyncio

# --- IMPORTANT ---
# Set your Google AI API key as an environment variable or replace the placeholder below.
# For example:
# genai.configure(api_key="YOUR_API_KEY")
API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyCvG0NYMBuQ_Dg_pke4UaoSIOMqLKXEBmc")
if API_KEY == "YOUR_API_KEY_HERE":
    print("Warning: GEMINI_API_KEY is not set. Please replace 'YOUR_API_KEY_HERE' in podcast.py with your actual key.")
# else:
#     genai.configure(api_key=API_KEY)


def _wave_file(filename, pcm, channels=1, rate=24000, sample_width=2):
   """Saves PCM audio data to a WAV file."""
   with wave.open(filename, "wb") as wf:
      wf.setnchannels(channels)
      wf.setsampwidth(sample_width)
      wf.setframerate(rate)
      wf.writeframes(pcm)

async def _generate_podcast_script(transcript: str, client) -> str:
    """
    Generates a two-speaker podcast script from a given transcript using the client.
    """
    print("Generating podcast script...")
    try:
        prompt = f"""
        You are a scriptwriter. Your task is to convert the following lecture transcript into an engaging, two-speaker podcast script.
        The speakers are "Alex", a curious host, and "Anya", a knowledgeable expert.

        - Alex should ask clarifying questions and guide the conversation.
        - Anya should provide the core information from the transcript in an accessible way.
        - The script should be formatted exactly as follows, with each line starting with the speaker's name followed by a colon.
        - Ensure the script flows naturally as a conversation.
        - The entire conversation must be returned in the format: "SPEAKER: Dialogue".

        Example Format:
        Alex: Welcome back to 'Learning Unpacked'! Today, we have expert Anya with us.
        Anya: It's a pleasure to be here, Alex.
        Alex: So, let's dive into our topic. What can you tell us about it?

        Here is the transcript:
        ---
        {transcript}
        ---
        """
        response = await client.aio.models.generate_content(model="gemini-2.5-pro", contents=[prompt])
        print("Podcast script generated successfully.")
        return response.text
    except Exception as e:
        print(f"Error generating podcast script: {e}")
        raise

async def generate_podcast_audio(transcript: str, output_path: str) -> str:
    """
    Generates a podcast audio file from a transcript.
    This function first generates a two-speaker script and then uses a
    text-to-speech model to create the audio file.
    """
    if API_KEY == "YOUR_API_KEY_HERE":
        raise ValueError("API key for Gemini is not configured in podcast.py")
    
    # Use a single, synchronous function that can be run in a thread
    async def async_generation():
        client = genai.Client(api_key=API_KEY)
        
        # 1. Generate script
        script = await _generate_podcast_script(transcript, client)

        # 2. Generate audio from script
        print("Generating podcast audio from script...")
        config = types.GenerateContentConfig(
            response_modalities=["AUDIO"],
            speech_config=types.SpeechConfig(
                multi_speaker_voice_config=types.MultiSpeakerVoiceConfig(
                    speaker_voice_configs=[
                        types.SpeakerVoiceConfig(
                            speaker='Alex',
                            voice_config=types.VoiceConfig(prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name='Puck'))
                        ),
                        types.SpeakerVoiceConfig(
                            speaker='Anya',
                            voice_config=types.VoiceConfig(prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name='Kore'))
                        ),
                    ]
                )
            )
        )
        
        tts_response = await client.aio.models.generate_content(
           model="gemini-2.5-flash-preview-tts",
           contents=[script],
           config=config,
        )
        
        return tts_response.candidates[0].content.parts[0].inline_data.data

    try:
        # Run the entire synchronous generation process in a background thread
        audio_data = await async_generation()
        
        output_dir = os.path.dirname(output_path)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        _wave_file(output_path, audio_data)
            
        print(f"Podcast audio saved successfully to {output_path}")
        return output_path

    except Exception as e:
        print(f"Error generating podcast audio: {e}")
        import traceback
        traceback.print_exc()
        raise



# Example usage (for testing purposes)
async def main():
    test_transcript = "The Jallianwala Bagh massacre, also known as the Amritsar massacre, took place on 13 April 1919. A large peaceful crowd had gathered at the Jallianwala Bagh in Amritsar, Punjab to protest against the Rowlatt Act. In response, the British military commander, Colonel Reginald Dyer, ordered his troops to fire on the crowd, killing hundreds."
    output_file = "output/test_podcast.wav"
    await generate_podcast_audio(test_transcript, output_file)

if __name__ == '__main__':
    asyncio.run(main())
