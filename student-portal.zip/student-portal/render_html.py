import json
import markdown
import re
from jinja2 import Environment, FileSystemLoader

def slugify(s):
    """Converts a string to a URL-friendly slug."""
    s = s.lower().strip()
    s = re.sub(r'[^\w\s-]', '', s)
    s = re.sub(r'[\s_-]+', '-', s)
    s = re.sub(r'^-+|-+$', '', s)
    return s

def render_template():
    # Load data from content.json
    with open('content.json', 'r') as f:
        data = json.load(f)

    # Set up Jinja2 environment and add custom filters
    env = Environment(loader=FileSystemLoader('.'))
    env.filters['markdown'] = lambda text: markdown.markdown(text, extensions=['fenced_code', 'codehilite'])
    env.filters['slugify'] = slugify

    # Render the template with the data
    template = env.get_template('template.html')
    output_html = template.render(data)

    # Write the output to a new HTML file
    with open('output/output.html', 'w') as f:
        f.write(output_html)

    print("Successfully rendered content to output.html")

if __name__ == '__main__':
    render_template()
