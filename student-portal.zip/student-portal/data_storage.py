import json
import os
from datetime import datetime
from typing import Dict, List, Optional
import uuid

class DataStorage:
    def __init__(self, data_dir: str = "student_data"):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        os.makedirs(f"{self.data_dir}/classes", exist_ok=True)
        os.makedirs(f"{self.data_dir}/users", exist_ok=True)

    def _read_class_file(self, class_id: str) -> Optional[Dict]:
        class_file = f"{self.data_dir}/classes/{class_id}.json"
        if os.path.exists(class_file):
            with open(class_file, 'r') as f:
                return json.load(f)
        return None

    def _write_class_file(self, class_id: str, data: Dict):
        class_file = f"{self.data_dir}/classes/{class_id}.json"
        with open(class_file, 'w') as f:
            json.dump(data, f, indent=2)

    def create_class(self, class_name: str, transcript: str, focus_area: str, description: str = "", quizzes: Optional[List[Dict]] = None) -> str:
        """Create a new class and return class ID"""
        class_id = str(uuid.uuid4())
        
        # If quizzes is None, it means it wasn't provided, so we create defaults.
        # If it's an empty list [], we respect that and create no quizzes.
        final_quizzes = quizzes
        
        class_data = {
            "id": class_id,
            "name": class_name,
            "description": description,
            "transcript": transcript,
            "focus_area": focus_area,
            "created_at": datetime.now().isoformat(),
            "quizzes": final_quizzes,
            "content_status": "pending",  # pending, generating, completed, failed
            "podcast_status": "pending",  # pending, generating, completed, failed
            "generated_content_path": None,
            "podcast_path": None,
            "last_updated": datetime.now().isoformat()
        }
        
        self._write_class_file(class_id, class_data)
        return class_id
    
    def get_class(self, class_id: str) -> Optional[Dict]:
        """Get class data by ID"""
        return self._read_class_file(class_id)
    
    def get_all_classes(self) -> List[Dict]:
        """Get all classes"""
        classes = []
        classes_dir = f"{self.data_dir}/classes"
        if os.path.exists(classes_dir):
            for filename in os.listdir(classes_dir):
                if filename.endswith('.json') and not filename.endswith('_content.json'):
                    try:
                        with open(f"{classes_dir}/{filename}", 'r') as f:
                            class_data = json.load(f)
                            # Add default statuses if they don't exist for older data
                            class_data.setdefault('content_status', 'pending' if not class_data.get('generated_content_path') else 'completed')
                            class_data.setdefault('podcast_status', 'pending' if not class_data.get('podcast_path') else 'completed')
                            classes.append(class_data)
                    except Exception as e:
                        print(f"Error reading class file {filename}: {e}")
                        continue
        return sorted(classes, key=lambda x: x.get('created_at', ''), reverse=True)
    
    def update_class_status(self, class_id: str, content_status: Optional[str] = None, podcast_status: Optional[str] = None):
        """Update the generation status of a class."""
        class_data = self._read_class_file(class_id)
        if class_data:
            if content_status:
                class_data['content_status'] = content_status
            if podcast_status:
                class_data['podcast_status'] = podcast_status
            class_data['last_updated'] = datetime.now().isoformat()
            self._write_class_file(class_id, class_data)

    def save_generated_content(self, class_id: str, content_json: Dict):
        """Save generated content for a class and update status."""
        content_file_path = f"{self.data_dir}/classes/{class_id}_content.json"
        with open(content_file_path, 'w') as f:
            json.dump(content_json, f, indent=2)
            
        class_data = self._read_class_file(class_id)
        if class_data:
            class_data['generated_content_path'] = content_file_path
            class_data['content_status'] = 'completed'
            class_data['last_updated'] = datetime.now().isoformat()
            self._write_class_file(class_id, class_data)
    
    def save_podcast_path(self, class_id: str, podcast_path: str):
        """Save the path to the generated podcast file and update status."""
        class_data = self._read_class_file(class_id)
        if class_data:
            class_data['podcast_path'] = podcast_path
            class_data['podcast_status'] = 'completed'
            class_data['last_updated'] = datetime.now().isoformat()
            self._write_class_file(class_id, class_data)
    
    def get_generated_content(self, class_id: str) -> Optional[Dict]:
        """Get generated content for a class"""
        class_data = self.get_class(class_id)
        if class_data and class_data.get('generated_content_path'):
            content_path = class_data['generated_content_path']
            # Make sure path exists before reading
            if os.path.exists(content_path):
                with open(content_path, 'r') as f:
                    return json.load(f)
        return None
