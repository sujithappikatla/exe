from fastapi import FastAPI, Request, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import uvicorn
import os
from typing import List, Dict, Optional
import uuid
import asyncio

# Imports from main.py
from agents.outline_generator import OutlineGenerator
from agents.content_generator import ContentGenerator
from agents.visual_content_generator import VisualContentGenerator
import json
import markdown
import re
from data_storage import DataStorage
from podcast import generate_podcast_audio

app = FastAPI()

# --- Template Configuration ---
def markdown_filter(text):
    return markdown.markdown(text, extensions=['fenced_code', 'codehilite', 'sane_lists'])

def slugify(s):
    """Converts a string to a URL-friendly slug."""
    s = s.lower().strip()
    s = re.sub(r'[^\w\s-]', '', s)
    s = re.sub(r'[\s_-]+', '-', s)
    s = re.sub(r'^-+|-+$', '', s)
    return s

templates = Jinja2Templates(directory="templates")
templates.env.filters['markdown'] = markdown_filter
templates.env.filters['slugify'] = slugify
# --- End Template Configuration ---

storage = DataStorage()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

# Static files
app.mount("/output", StaticFiles(directory="output"), name="output")
app.mount("/student_data", StaticFiles(directory="student_data"), name="student_data")


# --- Background Task Runners ---
async def do_generate_content(class_id: str):
    """Worker for generating study material."""
    storage.update_class_status(class_id, content_status='generating')
    try:
        class_data = storage.get_class(class_id)
        if not class_data:
            print(f"Content generation skipped for {class_id}: class deleted.")
            return
            
        transcript = class_data['transcript']
        area_to_focus = class_data.get('focus_area', '')
        
        outline = await OutlineGenerator().generate(transcript, area_to_focus)
        content = await ContentGenerator().generate(outline, transcript)
        content = await VisualContentGenerator().generate_visuals(content)
        
        # Re-check if class still exists before saving
        if storage.get_class(class_id):
            storage.save_generated_content(class_id, json.loads(content.model_dump_json()))
        else:
            print(f"Content saving skipped for {class_id}: class deleted.")
    except Exception as e:
        print(f"Error generating content for {class_id}: {e}")
        # Check if class exists before updating status
        if storage.get_class(class_id):
            storage.update_class_status(class_id, content_status='failed')


async def do_generate_podcast(class_id: str):
    """Worker for generating podcast."""
    # The status is already set to 'generating'
    try:
        class_data = storage.get_class(class_id)
        if not class_data:
            print(f"Podcast generation skipped for {class_id}: class deleted.")
            return

        transcript = class_data.get('transcript')
        if not transcript:
            raise Exception("Transcript not found for podcast generation")
            
        output_dir = f"student_data/classes/{class_id}/podcasts"
        os.makedirs(output_dir, exist_ok=True)
        
        podcast_filename = f"podcast_{uuid.uuid4()}.wav"
        output_path = os.path.join(output_dir, podcast_filename)

        await generate_podcast_audio(transcript, output_path)
        
        # Re-check if class still exists before saving
        if storage.get_class(class_id):
            frontend_path = f"/student_data/classes/{class_id}/podcasts/{podcast_filename}"
            storage.save_podcast_path(class_id, frontend_path)
        else:
            print(f"Podcast saving skipped for {class_id}: class deleted.")
    except Exception as e:
        print(f"Error generating podcast for {class_id}: {e}")
        # Check if class exists before updating status
        if storage.get_class(class_id):
            storage.update_class_status(class_id, podcast_status='failed')


# --- Pydantic Models ---
class QuizRequest(BaseModel):
    title: str
    teacher: str
    score: str
    date: str = ""

class CreateClassRequest(BaseModel):
    name: str
    description: str = ""
    transcript: str
    focus_area: str = ""
    quizzes: Optional[List[QuizRequest]] = None

class GenerateAllRequest(BaseModel):
    class_id: str

# --- Page Routes ---
@app.get("/", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/management", response_class=HTMLResponse)
async def management_page(request: Request):
    return templates.TemplateResponse("management.html", {"request": request})
    
@app.get("/study-material/{class_id}", response_class=HTMLResponse)
async def view_study_material_page(request: Request, class_id: str):
    class_data = storage.get_class(class_id)
    content_json = storage.get_generated_content(class_id)
    
    if not class_data or not content_json:
        raise HTTPException(status_code=404, detail="Study material not found")
    
    context = {
        "request": request,
        "class_data": class_data,
        "content": content_json
    }
    return templates.TemplateResponse("study_material.html", context)

# --- API Routes ---
@app.get("/api/classes")
async def get_classes():
    return storage.get_all_classes()
    
@app.get("/api/class/{class_id}")
async def get_class_status(class_id: str):
    class_data = storage.get_class(class_id)
    if not class_data:
        raise HTTPException(status_code=404, detail="Class not found")
    return class_data

@app.post("/api/create-class")
async def create_class(request: CreateClassRequest):
    try:
        quizzes_data = [quiz.model_dump() for quiz in request.quizzes] if request.quizzes else None
        class_id = storage.create_class(
            request.name, request.transcript, request.focus_area,
            request.description, quizzes=quizzes_data
        )
        return {"class_id": class_id, "message": "Class created successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/generate-all")
async def generate_all(request: GenerateAllRequest, background_tasks: BackgroundTasks):
    """Triggers both study material and podcast generation."""
    class_id = request.class_id
    
    # Check if the class exists before proceeding
    if not storage.get_class(class_id):
        raise HTTPException(status_code=404, detail="Class not found")

    # Set both statuses to 'generating' from the start
    storage.update_class_status(class_id, content_status='generating', podcast_status='generating')
    
    tasks = []
    tasks.append(asyncio.create_task(do_generate_content(class_id)))
    tasks.append(asyncio.create_task(do_generate_podcast(class_id)))
    await asyncio.gather(*tasks)
    
    return {"message": "Study material and podcast generation have started in the background."}

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8080)
