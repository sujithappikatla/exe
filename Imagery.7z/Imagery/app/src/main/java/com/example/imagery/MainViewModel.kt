package com.example.imagery

import android.app.Application
import android.graphics.*
import android.net.Uri
import android.util.Base64
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    var isLoading by mutableStateOf(false)
        private set

    var dalleResponseUrls by mutableStateOf<List<String>>(emptyList())
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var generatedPrompt by mutableStateOf<String?>(null)
        private set

    fun processImage(uri: Uri) {
        viewModelScope.launch {
            isLoading = true
            errorMessage = null
            dalleResponseUrls = emptyList()
            generatedPrompt = null
            try {
                val imageBase64 = getBase64EncodedImage(uri)
                generatedPrompt = generatePromptWithGPT4(imageBase64)
                dalleResponseUrls = generateImagesWithDALLE(generatedPrompt ?: "")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error processing image", e)
                errorMessage = "Error: ${e.message}"
            } finally {
                isLoading = false            }
        }
    }

    private suspend fun getBase64EncodedImage(uri: Uri): String = withContext(Dispatchers.IO) {
        getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
            val bitmap = BitmapFactory.decodeStream(input)
//            val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 512, 512, true)
            val resizedBitmap = bitmap
            val byteArrayOutputStream = ByteArrayOutputStream()
            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
            val byteArray = byteArrayOutputStream.toByteArray()
            Base64.encodeToString(byteArray, Base64.DEFAULT)
        } ?: throw IOException("Failed to read image")
    }

    private suspend fun generatePromptWithGPT4(imageBase64: String): String = withContext(Dispatchers.IO) {
        val requestBody = JSONObject().apply {
            put("model", "gpt-4o")
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", """
                        Analyze the given image and respond with a DALL-E prompt based on the following rules:
                        1. If the image contains text with instructions or a question about generating an image, create a DALL-E prompt that fulfills that request. For example, if the image says "Create a futuristic city," your prompt should be "A futuristic cityscape with tall, sleek buildings, flying vehicles, and advanced technology visible throughout."
                        2. If the image contains words or text without specific instructions, create a DALL-E prompt to visualize those words. For instance, if the image contains the text "Enchanted Forest," your prompt should be "An magical forest scene with towering trees, glowing fireflies, mystical creatures, and a soft, ethereal light filtering through the canopy."
                        3. If the image doesn't fall into the above categories, generate a DALL-E prompt to create a similar type of image, focusing on the key visual elements, style, and mood of the original. For example, if the image is a landscape painting of mountains, your prompt could be "A breathtaking mountain landscape with snow-capped peaks, a serene lake reflecting the sky, and lush green forests in the foreground, painted in a style reminiscent of classic landscape artists."
                        Remember to be specific about colors, textures, lighting, and composition in your DALL-E prompt. Aim for a balance between detail and creative freedom to allow DALL-E to generate interesting and varied results.
                        Respond only with the DALL-E prompt, without any additional explanation or context.
                    """.trimIndent())
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().apply {
                            put("type", "text")
                            put("text", "Analyze this image and create a prompt according to the given rules.")
                        })
                        put(JSONObject().apply {
                            put("type", "image_url")
                            put("image_url", JSONObject().apply {
                                put("url", "data:image/jpeg;base64,$imageBase64")
                            })
                        })
                    })
                })
            })
            put("max_tokens", 300)
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer sk-proj-OGI5p0RfWmk8Ji8T4nr5T3BlbkFJbyub698XJM5brXvOxuic")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Unexpected code $response")
            val responseBody = response.body?.string() ?: throw IOException("Empty response body")
            JSONObject(responseBody)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }
    }

    private suspend fun generateImagesWithDALLE(basePrompt: String): List<String> = withContext(Dispatchers.IO) {
        val styles = listOf(
            "Create a hyper-realistic version of this: ",
            "Create a well-drawn sketch of this: ",
            "Create an anime/cartoon style version of this: ",
            "Create a unique artistic interpretation of this: "
        )

        val results = mutableListOf<String>()
        val deferredResults = styles.map { style ->
            async {
                try {
                    val url =
                        retryWithExponentialBackoff { generateSingleImage("$style $basePrompt") }
                    results.add(url)
                } catch (e: Exception) {
                    Log.e("MainViewModel", "Failed to generate image for style: $style", e)
                    results.add("") // Return an empty string if image generation fails
                }
            }
        }

        deferredResults.awaitAll()
        results
    }



    private suspend fun generateSingleImage(prompt: String): String = withContext(Dispatchers.IO) {
        val requestBody = JSONObject().apply {
            put("model", "dall-e-2")
            put("prompt", prompt)
            put("n", 1)
            put("size", "256x256")
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/images/generations")
            .header("Authorization", "Bearer sk-proj-OGI5p0RfWmk8Ji8T4nr5T3BlbkFJbyub698XJM5brXvOxuic")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "Unknown error"
                throw IOException("API Error: ${response.code}. $errorBody")
            }
            val responseBody = response.body?.string() ?: throw IOException("Empty response body")
            JSONObject(responseBody)
                .getJSONArray("data")
                .getJSONObject(0)
                .getString("url")
        }
    }

    private suspend fun <T> retryWithExponentialBackoff(
        maxAttempts: Int = 5,
        initialDelay: Long = 1000,
        maxDelay: Long = 20000,
        factor: Double = 2.0,
        block: suspend () -> T
    ): T {
        var currentDelay = initialDelay
        repeat(maxAttempts - 1) { attempt ->
            try {
                return block()
            } catch (e: IOException) {
                Log.w("MainViewModel", "Attempt ${attempt + 1} failed, retrying...", e)
            }
            delay(currentDelay)
            currentDelay = (currentDelay * factor).toLong().coerceAtMost(maxDelay)
        }
        return block() // last attempt
    }
}