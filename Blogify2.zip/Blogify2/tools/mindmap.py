from plantweb.render import render
import asyncio
import uuid


async def generate_mindmap(diagram_code: str) -> str:
    output = render(
        diagram_code,
        engine="plantuml",
        format="png",  # or "svg"
        cacheopts={"use_cache": False}
    )
    filename = uuid.uuid4()
    with open(f"output/assets/mindmap_{filename}.png", "wb") as f:
        f.write(output[0])
    return f"assets/mindmap_{filename}.png"

async def main():
    diagram_code = """
@startmindmap
* AI
** Machine Learning
*** Supervised Learning
*** Unsupervised Learning
** Deep Learning
** Applications
*** NLP
*** Vision
@endmindmap
"""
    await generate_mindmap(diagram_code)

if __name__ == "__main__":
    asyncio.run(main())