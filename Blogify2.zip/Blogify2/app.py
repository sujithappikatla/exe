from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import os

# Imports from main.py
from agents.outline_generator import OutlineGenerator
from agents.content_generator import ContentGenerator
from agents.visual_content_generator import VisualContentGenerator
import json
import markdown
import re
from jinja2 import Environment, FileSystemLoader

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
if os.path.exists("output"):
    app.mount("/output", StaticFiles(directory="output"), name="output")

# slugify function from main.py
def slugify(s):
    """Converts a string to a URL-friendly slug."""
    s = s.lower().strip()
    s = re.sub(r'[^\w\s-]', '', s)
    s = re.sub(r'[\s_-]+', '-', s)
    s = re.sub(r'^-+|-+$', '', s)
    return s

# Pydantic model for request body
class GenerateRequest(BaseModel):
    transcript: str
    area_to_focus: str = ""

@app.post("/generate")
async def generate_blog_post(request: GenerateRequest):
    transcript = request.transcript
    area_to_focus = request.area_to_focus

    outline_generator = OutlineGenerator()
    outline = await outline_generator.generate(transcript, area_to_focus)

    content_generator = ContentGenerator()
    content = await content_generator.generate(outline, transcript)

    visual_content_generator = VisualContentGenerator()
    content = await visual_content_generator.generate_visuals(content)

    with open("content.json", "w") as f:
        f.write(content.model_dump_json(indent=4))

    data = json.loads(content.model_dump_json())

    env = Environment(loader=FileSystemLoader('.'))
    env.filters['markdown'] = lambda text: markdown.markdown(text, extensions=['fenced_code', 'codehilite'])
    env.filters['slugify'] = slugify

    template = env.get_template('template.html')
    output_html_content = template.render(data)

    output_file_path = 'output/output.html'
    os.makedirs(os.path.dirname(output_file_path), exist_ok=True)
    with open(output_file_path, 'w') as f:
        f.write(output_html_content)
    
    # Mount static directory if it wasn't mounted at startup
    if not any(route.name == "output" for route in app.routes):
        app.mount("/output", StaticFiles(directory="output"), name="output")


    return JSONResponse(content={"url": f"/{output_file_path}"})

@app.get("/", response_class=HTMLResponse)
async def read_root():
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Blogify - AI Content Generation</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <style>
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(-10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .fade-in {
                animation: fadeIn 0.5s ease-out forwards;
            }
            .lds-ellipsis {
              display: inline-block;
              position: relative;
              width: 80px;
              height: 80px;
            }
            .lds-ellipsis div {
              position: absolute;
              top: 33px;
              width: 13px;
              height: 13px;
              border-radius: 50%;
              background: #fff;
              animation-timing-function: cubic-bezier(0, 1, 1, 0);
            }
            .lds-ellipsis div:nth-child(1) {
              left: 8px;
              animation: lds-ellipsis1 0.6s infinite;
            }
            .lds-ellipsis div:nth-child(2) {
              left: 8px;
              animation: lds-ellipsis2 0.6s infinite;
            }
            .lds-ellipsis div:nth-child(3) {
              left: 32px;
              animation: lds-ellipsis2 0.6s infinite;
            }
            .lds-ellipsis div:nth-child(4) {
              left: 56px;
              animation: lds-ellipsis3 0.6s infinite;
            }
            @keyframes lds-ellipsis1 {
              0% {
                transform: scale(0);
              }
              100% {
                transform: scale(1);
              }
            }
            @keyframes lds-ellipsis3 {
              0% {
                transform: scale(1);
              }
              100% {
                transform: scale(0);
              }
            }
            @keyframes lds-ellipsis2 {
              0% {
                transform: translate(0, 0);
              }
              100% {
                transform: translate(24px, 0);
              }
            }
        </style>
    </head>
    <body class="bg-gray-900 text-gray-200 font-sans">
        <div class="container mx-auto px-4 py-8 max-w-4xl">
            <header class="text-center mb-10 fade-in">
                <h1 class="text-5xl font-bold text-white">
                    Blogify<span class="text-orange-500">.</span>
                </h1>
                <p class="text-lg text-gray-400 mt-2">Generate engaging blog posts from transcripts with AI</p>
            </header>

            <main>
                <form id="generate-form" class="bg-gray-800 p-8 rounded-lg shadow-2xl space-y-6 fade-in" style="animation-delay: 0.2s;">
                    <div>
                        <label for="transcript" class="block text-sm font-medium text-gray-300 mb-2">Transcript</label>
                        <textarea id="transcript" name="transcript" rows="10" class="w-full bg-gray-700 border-gray-600 rounded-md shadow-sm text-gray-200 p-4 focus:ring-orange-500 focus:border-orange-500 transition duration-300" placeholder="Paste your transcript here..." required></textarea>
                    </div>

                    <div>
                        <div id="focus-area-header" class="cursor-pointer flex justify-between items-center">
                            <label for="area_to_focus" class="block text-sm font-medium text-gray-300">Area to Focus (Optional)</label>
                            <svg id="focus-arrow" class="w-5 h-5 text-gray-400 transform transition-transform" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div id="focus-area-content" class="hidden mt-2">
                            <textarea id="area_to_focus" name="area_to_focus" rows="5" class="w-full bg-gray-700 border-gray-600 rounded-md shadow-sm text-gray-200 p-4 focus:ring-orange-500 focus:border-orange-500 transition duration-300" placeholder="e.g., Explain the importance of photosynthesis..."></textarea>
                        </div>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="w-full sm:w-auto bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-orange-500 focus:ring-opacity-50">
                            Generate Article
                        </button>
                    </div>
                </form>

                <div id="loading" style="display:none;" class="text-center mt-10 p-6 bg-gray-800 rounded-lg shadow-xl">
                     <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
                    <p class="text-lg mt-2 text-gray-300 font-semibold">Generating content... This might take a moment.</p>
                </div>

                <div id="result" class="mt-10"></div>
            </main>
        </div>

        <script>
            document.getElementById('focus-area-header').addEventListener('click', function() {
                const content = document.getElementById('focus-area-content');
                const arrow = document.getElementById('focus-arrow');
                content.classList.toggle('hidden');
                arrow.classList.toggle('rotate-180');
            });

            document.getElementById('generate-form').addEventListener('submit', async function(event) {
                event.preventDefault();
                document.getElementById('loading').style.display = 'block';
                document.getElementById('result').innerHTML = '';

                const transcript = document.getElementById('transcript').value;
                const area_to_focus = document.getElementById('area_to_focus').value;

                try {
                    const response = await fetch('/generate', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            transcript: transcript,
                            area_to_focus: area_to_focus
                        })
                    });
                    
                    document.getElementById('loading').style.display = 'none';

                    if (response.ok) {
                        const data = await response.json();
                        const successHtml = `
                            <div class="p-6 bg-green-900 bg-opacity-30 border border-green-700 rounded-lg shadow-lg text-center fade-in">
                               <h3 class="text-2xl font-bold text-green-400">Success!</h3>
                               <p class="mt-2 text-gray-300">Your blog post has been generated.</p>
                               <a href="${data.url}" target="_blank" class="mt-4 inline-block bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transform hover:scale-105 transition duration-300">
                                   View Article
                               </a>
                            </div>
                        `;
                        document.getElementById('result').innerHTML = successHtml;
                        window.open(data.url, '_blank');
                    } else {
                        const error = await response.text();
                        const errorHtml = `
                            <div class="p-6 bg-red-900 bg-opacity-50 border border-red-700 rounded-lg shadow-lg text-center fade-in">
                                <h3 class="text-2xl font-bold text-red-400">Error</h3>
                                <p class="mt-2 text-gray-300">${error}</p>
                            </div>
                        `;
                        document.getElementById('result').innerHTML = errorHtml;
                    }
                } catch (error) {
                    document.getElementById('loading').style.display = 'none';
                    const errorHtml = `
                        <div class="p-6 bg-red-900 bg-opacity-50 border border-red-700 rounded-lg shadow-lg text-center fade-in">
                            <h3 class="text-2xl font-bold text-red-400">Network Error</h3>
                            <p class="mt-2 text-gray-300">${error}</p>
                        </div>
                    `;
                    document.getElementById('result').innerHTML = errorHtml;
                }
            });
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)

