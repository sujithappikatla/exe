from agents.outline_generator import OutlineGenerator
from agents.content_generator import ContentGenerator
from agents.visual_content_generator import VisualContentGenerator
import time
import json
import markdown
import re
from jinja2 import Environment, FileSystemLoader

def slugify(s):
    """Converts a string to a URL-friendly slug."""
    s = s.lower().strip()
    s = re.sub(r'[^\w\s-]', '', s)
    s = re.sub(r'[\s_-]+', '-', s)
    s = re.sub(r'^-+|-+$', '', s)
    return s


async def main():
    outline_generator = OutlineGenerator() 
    transcript = """
’ve daydreamed before about what it’d be like  to have a special ability that other organisms  
can do. Something that humans - or amoebas -  cannot. For example, to be able to fly like  
a peregrine falcon. Or to be able to walk up walls  without any gear – like a Texas banded gecko.  
But if I told you I really wish  I could have a special ability of  
a plant – you’d probably be confused.  What can a plant do that’s so amazing?
There’s a lot of cool things about plants  actually. But, in particular, I really wish  
I could do photosynthesis. And it’s not just  plants that can do this process. For example, some  
Why does photosynthesis matter?
protists and some bacteria can too. But  plants will be our focus for this video clip.  
Animals and amoebas may have missed out on this  ability, but we benefit from it greatly as this  
process also produces oxygen. A gas that we need.  Any process that plants themselves need to survive  
is important to us – because plants in general  are major producers making them indispensable  
in food webs. Many of our medications and  foods come from plants. We need plants.  
So understanding the nature of the process that  plants use to make their own food is paramount.
So when I say make their own food, I’m  talking about making a sugar that they need.  
Specifically, glucose. You need glucose too,  
but you get it from what you eat. Plants, however,  get to make their own glucose in photosynthesis.
Photosyn vs Cellular Resp Equations
Here is the balanced overall equation for  photosynthesis, similar to what you’ll find  
in many introductory biology textbooks. As  you will notice, it has some similarities to  
aerobic cellular respiration. Recall that  cellular respiration is used to make ATP,  
which is an energy currency, and it’s  done by plants as well as animals  
and a lot of other organisms too. You can see  how these reactants (inputs) of photosynthesis  
are included in the products (outputs)  in cellular respiration. And the products  
(outputs) of photosynthesis are included in the  reactants (inputs) of cellular respiration. While  
this doesn’t mean that they’re simply reversed,  it is interesting to see what they have in common.
So while both plants and animals need glucose for  cellular respiration, plants don’t have to be in  
search of glucose. Because they make it. Plants  have adaptations to carry out photosynthesis in  
a variety of environments. One thing plants have  to do is capture light. Plants can use light  
Chlorophyll and other pigments
capturing molecules called pigments. Recall that  visible light has different wavelengths and those  
different wavelengths of light have different  colors. If you’ve ever played with a prism before,  
you can see how light can be separated into a  rainbow of colors due to different wavelengths.
So, a pigment that plants commonly use to capture  light is chlorophyll. Chlorophyll does a great  
job at absorbing red and blue light – but not so  much green light. Chlorophyll reflects green light  
and this is one reason why many  plants appear green to our eyes.  
There are pigments besides chlorophyll that  work with different wavelengths of light,  
and this can explain why green is  not the only color you see in plants.
Chlorophyll is a pigment that can be found in the  chloroplasts of plants cells. There are two major  
reactions that occur in the chloroplast  that, together, make up photosynthesis.  
They are: the light dependent reactions  and the light independent reactions.  
The light independent reactions  can also be called the Calvin Cycle  
or even…less commonly…the dark  reaction. Sounds intriguing.
We’re going to talk about both of these briefly  and please remember, like most of our videos,  
this is pretty general. We’ve got  some further reading links in the  
video description where you  can explore a lot more detail.
Light dependent reactions
So light dependent reactions: happen in  the thylakoids. Little compartments in the  
chloroplasts that contain pigment. A collective  stack would be a granum…multiple stacks would  
be grana. In the light dependent reactions, light  is captured and water (which is a reactant in the  
photosynthesis equation) is “split.” That means  if you think of the chemical formula for water  
which is H20---it is split so that you  get electrons, protons, and oxygen.  
So, oxygen is also a product of  the light dependent reactions.
The light dependent reactions also produce ATP  and NADPH, which we’ll get to in a little bit.  
Both the ATP and the NADPH will be needed  for the next process: the light independent  
reactions. Also known as the Calvin Cycle or  Dark Reaction. The name is bit misleading. While,  
yes, this process isn’t directly capturing  light, it doesn’t require darkness either.  
And, again, it will need items from the light  dependent reactions like the ATP and NADPH. The  
Light independent reactions (Calvin Cycle)
light independent reactions still happen in  the chloroplast. But specifically, the light  
independent reactions happen in the stroma. The  stroma is a fluid outside of the thylakoids.
In the Light Independent Reactions -or Calvin  Cycle- carbon dioxide enters. It is taken in  
through pores – that are often but not always on  the bottom of leaves – and those pores are called  
stomata. Plants have the ability to open and  close their stomata. The carbon dioxide gas enters  
the stomata and will be fixed. By fixed, I mean  that, with the additional help of a major enzyme,  
the inorganic carbon dioxide is changed to a more  usable organic form. The ATP that had come from  
the light dependent reactions will act as an  energy currency for the Calvin Cycle. The NADPH  
that had come from the light dependent  reactions will supply reducing power----by  
that, I mean that it helps add high  energy electrons to this process.  
So, in a very complex series of pathways,  the fixed carbon dioxide, ATP, and NADPH  
are used to make a product that- ultimately -  can be converted into glucose. A sugar. Phew.
So, let’s take a look at this equation. Last time,  I promise. So, we have here the circled items  
Big picture overview
from the light dependent reactions. And  now, notice the other items----the CO2  
on the reactant side and the glucose on the  product side---those were from the Calvin Cycle.
Remember, there is so much more detail  to explore in this amazing process.  
You can learn about the photosystems  that are in the light dependent reactions  
or the detail of all the steps in the Calvin  Cycle and how ATP and NADPH will be converted  
to ADP and NADP+ which can then be used  again by the light dependent reactions.
But before we end our short video, we do want to  mention that plants have some amazing adaptations  
that help them perform photosynthesis  efficiently in different environments.  
Many of these adaptations can involve  the diversity of leaf shapes, coverings,  
Examples of adaptations for photosyn
and pigments. This is definitely worthy  of a completely separate video topic, but  
to give a neat example of an adaptation  involving photosynthesis: consider the cactus.
Cacti have a potential problem. They often  live in a hot desert, and so if they open their  
stomata during the hot day to get their carbon  dioxide, they can easily lose more water than  
would be ideal. The precious water can escape  through the stomata if the stomata are open,  
and that will happen at a faster rate in the hot  desert sun. But cacti, and some other plants too,  
can do something called CAM photosynthesis. In CAM  photosynthesis, plants can open their stomata at  
night – when it’s not so hot -and they can capture  carbon dioxide and chemically store it. They can  
then use this carbon dioxide the next day when the  sun is shining and yet have their stomata closed,  
allowing them to avoid having to open  their stomata in the heat of the day. Well,  
that’s it for the Amoeba Sisters,  and we remind you to stay curious.
    """
    area_to_focus = """
1. What is the primary pigment plants use for photosynthesis, and why does it cause them to appear green?

2. What is the key difference in how and when cacti (using CAM photosynthesis) take in carbon dioxide compared to other plants?

3. What are the two main stages of photosynthesis, and where does each stage take place within the chloroplast?
"""
    start_time = time.time()
    outline = await outline_generator.generate(transcript, area_to_focus)
    end_time = time.time()
    print(f"Generated Outline in {end_time - start_time} seconds")

    content_generator = ContentGenerator()
    content = await content_generator.generate(outline, transcript)
    end_time = time.time()
    print(f"Generated Content in {end_time - start_time} seconds")

    visual_content_generator = VisualContentGenerator()
    content = await visual_content_generator.generate_visuals(content)
    end_time = time.time()
    print(f"Generated Visuals in {end_time - start_time} seconds")

    print("Writing to file")
    with open("content.json", "w") as f:
        f.write(content.model_dump_json(indent=4))

    data = json.loads(content.model_dump_json())

    # Set up Jinja2 environment and add custom filters
    env = Environment(loader=FileSystemLoader('.'))
    env.filters['markdown'] = lambda text: markdown.markdown(text, extensions=['fenced_code', 'codehilite'])
    env.filters['slugify'] = slugify

    # Render the template with the data
    template = env.get_template('template.html')
    output_html = template.render(data)

    # Write the output to a new HTML file
    with open('output/output.html', 'w') as f:
        f.write(output_html)

    print("Successfully rendered content to output/output.html")
    


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())