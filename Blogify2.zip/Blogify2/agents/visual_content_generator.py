from langchain_google_vertexai import ChatVertexAI
from langchain_core.messages import SystemMessage, HumanMessage
from data.Content import SubSectionContent, Component, ComponentType, ImageComponent, MainContent, SectionContent
from data.Visuals import Visuals, VisualType
from tools.image_search import search_images
import asyncio
from data.Visuals import ImageDetailsList
import base64
import httpx
import io
from PIL import Image
from tools.sequence_diagram import generate_sequence_diagram
from tools.mindmap import generate_mindmap





class VisualContentGenerator:
    def __init__(self):
        self.system_prompt = """
        You are a helpful assistant that generates visuals for a sub-section content.
        You will be receiving subsection content. Each paragraph has block number given.
        your task is to reason about the content and generate a list of visuals with thier placement in the content based on the block number.
        The visuals should be completely based on the content and should be relevant to the content.
        If text content alone is good enough for student understanding, then dont generate any visuals.
        Generate only one visual per section with high importance, again only if content alone is not good enough for student understanding. Only if felt absolute need for more than one, then you can generate more than one but keep it to minimum.

        Visual Types:
        Image : For image, we will use PSE API in backend to search for images, so content should be a search query for an image. Dont make search query too long or look like something to generate image, we are just searching image. Also by adding this image, it should complete the content.
        Sequence Diagram : For sequence diagram, we will use seqdiag to generate the diagram. So content should be a sequence diagram code in seqdiag format.
        Mind Map : For mind map, we will use plantweb to generate the diagram. So content should be a mind map code in plantuml format.

        Here is sequnce diagram code refernce. this uses seqdiag library.
<seqdiag_documentation>        
	•	seqdiag is a command-line tool that generates sequence-diagram images from simple .diag files, similar to Graphviz’s DOT format  ￼ ￼.
	•	Diagrams are declared within a diagram { … } block, and each interaction is specified with arrow syntax and terminated by a semicolon  ￼.

Basic Syntax

Declaring the Diagram
	•	Begin the file with:

diagram {
  … 
}

￼

	•	Close the block with a matching }.  ￼

Statement Structure
	•	Every statement inside the block must end with a semicolon (;).  ￼
	•	Whitespace and line breaks are flexible; indentation can improve readability.  ￼

Defining Messages
	•	Synchronous call:

A -> B;

Use -> for a direct (solid) arrow from sender to receiver.  ￼

	•	Asynchronous (dotted) call:

A --> B;

Use --> to render a dotted arrow.  ￼

	•	Return or response:

B <-- A;

Use <-- (or <---) to depict a return message.  ￼

	•	Adding labels:

A -> B [label = "message text"];

Attach a [label = "…"] attribute to include descriptive text.  ￼

	•	Nesting or grouping:
Indent messages to visually group related calls.  ￼

Compact Example

Below is a minimal seqdiag script illustrating a code-generation workflow:

diagram {
  coder    -> llm        [label = "Provide function signature"];
  llm      -> parser     [label = "Generate AST"];
  parser   -> validator  [label = "Check syntax"];
  validator-> executor   [label = "Compile code"];
  executor <-- validator [label = "Return compilation status"];
}

	•	Each line ends with ; and uses arrows to denote message flow.  ￼

 </seqdiag_documentation>

Here is mind map code refernce. this uses plantweb library.
<mindmap_documentation>
Summary

PlantUML’s MindMap feature allows you to describe mind maps using simple, text-based syntax that’s ideal for brainstorming and project planning  ￼. The diagram is defined between @startmindmap and @endmindmap markers, with hierarchical nodes indicated by asterisk (*) or arithmetic (+/–) notation  ￼. You can customize branch direction, styling (colors, CSS-like classes), multi‐line content, and even remove node boxes for a clean look  ￼.

⸻

Basic Structure

Diagram Delimiters
	•	Begin with @startmindmap and end with @endmindmap to define the mind map boundaries  ￼.
	•	No additional diagram-type declaration is needed; PlantUML infers MindMap from the context  ￼.

Node Definition

OrgMode-Compatible Syntax
	•	Use one or more asterisks to denote node depth:
	•	* for a root node
	•	** for first-level children
	•	*** for second-level children
	•	Example:

@startmindmap
* Root
** Child A
*** Grandchild A1
@endmindmap
```  [oai_citation:5‡PlantUML.com](https://plantuml.com/mindmap-diagram)



Markdown-Compatible Syntax
	•	Indentation with tabs or spaces replicates Markdown lists:

@startmindmap
* root node
    * first-level node
        * second-level node
@endmindmap
```  [oai_citation:6‡PlantUML.com](https://plantuml.com/mindmap-diagram)



⸻

Branch Direction & Arithmetic Notation
	•	Prefix nodes with + (plus) to create branches on the right, and – (minus) for branches on the left  ￼.
	•	Example:

@startmindmap
+ RightSide
++ SubRight
-- LeftSide
--- SubLeft
@endmindmap

￼

	•	Import tools like draw.io can convert indented text lists into mind maps, leveraging this syntax for automated layout  ￼ and advanced layout options exist for large maps  ￼.

⸻

Multiline Node Content
	•	Begin a node’s content with : and end with ; to include multi-line text or code blocks within a single node  ￼.
	•	Example:

@startmindmap
* Class Templates
**:Example 1
<code>
template <typename T>
class C { /*…*/ }
</code>
;
@endmindmap
```  [oai_citation:12‡PlantUML.com](https://plantuml.com/mindmap-diagram)



⸻

Multiple Roots
	•	Simply repeat the root-level syntax to define multiple unconnected roots:

@startmindmap
* Root 1
* Root 2
@endmindmap
```  [oai_citation:13‡PlantUML.com](https://plantuml.com/mindmap-diagram)



⸻

Styling & Colors

Inline Coloring
	•	Attach [#ColorName] immediately after the node marker for inline background coloring:

@startmindmap
*[#Orange] Colors
**[#lightgreen] Green
@endmindmap
```  [oai_citation:14‡PlantUML.com](https://plantuml.com/mindmap-diagram)



CSS-Style Declarations
	•	Define styles in a <style> block and apply them with <<className>> annotations:

@startmindmap
<style>
  mindmapDiagram {
    .highlight { BackgroundColor lightblue }
  }
</style>
* Topic <<highlight>>
@endmindmap
```  [oai_citation:15‡PlantUML.com](https://plantuml.com/mindmap-diagram)



⸻

Removing Node Boxes
	•	Append an underscore _ to a node marker to render it without the surrounding box:

@startmindmap
**_ Boxless Node
@endmindmap
```  [oai_citation:16‡PlantUML.com](https://plantuml.com/mindmap-diagram)



⸻

Diagram Orientation
	•	Change the overall layout direction with one of the following keywords at any point after @startmindmap:
	•	top to bottom direction  ￼
	•	right to left direction  ￼
	•	bottom to top direction (workaround required)  ￼

⸻

Complete Example

@startmindmap
caption Figure 1
title Super Mind Map
top to bottom direction
* Project Plan
** Research
*** Literature Review
*** Stakeholder Interviews
** Development
*** Prototyping
*** Testing
@endmindmap
```  [oai_citation:20‡PlantUML.com](https://plantuml.com/mindmap-diagram)  

---

Use this compact reference to prompt an LLM or integrate directly into your Python code for PlantWeb (PlantUML) mind map generation.
</mindmap_documentation>

        Input Example:
        Sub Section Heading:
        Neural Network Architectures

        Block 1:
        Neural networks are a type of machine learning model that are designed to learn from data.

        Block 2:
        Neural networks are a type of machine learning model that are designed to learn from data.

        Output Example:
        [
            {
                "type": "image",
                "after_block_number": 1,
                "content": "A diagram of a neural network architecture.",
                "importance": 5
            }
        ]
        """
        self.image_rating_system_prompt = """
        You are a helpful assistant that rates the relevance of an each image to the given description.
        You will be receiving a list of images and a description.
        Also provide a caption for each image.

        When image matches descrption, give higher relevance score. If not sure, give lower score.
        """

    async def generate_visuals(self, content: MainContent) -> MainContent:

        async def _generate_visuals_for_sub_section(sub_section_content: SubSectionContent) -> SubSectionContent:
            updated_sub_section_content = await self.generate_visuals_for_sub_section(sub_section_content)
            return updated_sub_section_content


        tasks = []
        for section in content.sections:
            for sub_section in section.sub_sections:
                tasks.append(_generate_visuals_for_sub_section(sub_section))
        results = await asyncio.gather(*tasks)
        
        
        # Create a new MainContent object with the updated sub-sections
        updated_content = MainContent(title=content.title, sections=[])
        
        for section in content.sections:
            updated_section = SectionContent(title=section.title, sub_sections=[])
            
            for sub_section in section.sub_sections:
                # Find the matching updated sub-section from results
                updated_sub_section = next((result for result in results if result.title == sub_section.title), None)
                if updated_sub_section:
                    updated_section.sub_sections.append(updated_sub_section)
            
            updated_content.sections.append(updated_section)
        
        return updated_content

    async def generate_visuals_for_sub_section(self, sub_section_content: SubSectionContent) -> SubSectionContent:

        
        content = sub_section_content.title + "\n" 
        for block_number, block in enumerate(sub_section_content.content):
            content += f"Block {block_number + 1}: \n{block.content}\n"

        user_prompt = content
        
        llm = ChatVertexAI(model_name="gemini-2.5-pro")
        llm_with_structured_output = llm.with_structured_output(Visuals)
        messages = [
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=user_prompt)
        ]
        response = await llm_with_structured_output.ainvoke(messages)
        sub_section_content = await self.generate_visuals_with_tools(response, sub_section_content)
        return sub_section_content
        
    async def generate_visuals_with_tools(self, visuals: Visuals, sub_section: SubSectionContent) -> SubSectionContent:
        
        for visual in visuals.visuals:
            try:

                if visual.type == VisualType.IMAGE:
                    image_url = await search_images(visual.content)
                    images = await self.rate_images(visual.content, image_url)
                    idx, best_image = max(enumerate(images.images), key=lambda item: item[1].relevance)
                    if best_image and best_image.relevance > 0.7:
                        image_component = Component(type=ComponentType.IMAGE, content=[ImageComponent(url=image_url[idx], alt_text=visual.content, caption=best_image.caption)])
                        sub_section.content.insert(visual.after_block_number, image_component)
                elif visual.type == VisualType.SEQUENCE_DIAGRAM:
                    image_url = await generate_sequence_diagram(visual.content)
                    images = await self.rate_images(visual.content, [image_url], local_images=True)
                    idx, best_image = max(enumerate(images.images), key=lambda item: item[1].relevance)
                    if best_image and best_image.relevance > 0.7:
                        image_component = Component(type=ComponentType.IMAGE, content=[ImageComponent(url=image_url, alt_text=best_image.caption, caption=best_image.caption)])
                        sub_section.content.insert(visual.after_block_number, image_component)
                elif visual.type == VisualType.MIND_MAP:
                    image_url = await generate_mindmap(visual.content)
                    images = await self.rate_images(visual.content, [image_url], local_images=True)
                    idx, best_image = max(enumerate(images.images), key=lambda item: item[1].relevance)
                    if best_image and best_image.relevance > 0.7:
                        image_component = Component(type=ComponentType.IMAGE, content=[ImageComponent(url=image_url, alt_text=best_image.caption, caption=best_image.caption)])
                        sub_section.content.insert(visual.after_block_number, image_component)
            except Exception as e:
                print(f"Error generating visual {visual.type}: {e}")

        return sub_section

    async def rate_images(self, description: str, image_urls: list[str], local_images: bool = False) -> ImageDetailsList:

        image_details = [
            {"type": "text", "text": "description : " + description}
        ]
        if not local_images:
            async with httpx.AsyncClient() as client:
                tasks = [client.get(url, follow_redirects=True) for url in image_urls]
                responses = await asyncio.gather(*tasks, return_exceptions=True)

                for i, response in enumerate(responses):
                    if isinstance(response, httpx.Response) and response.status_code == 200:
                        content_type = response.headers.get("content-type", "").lower()
                        if "image" in content_type:
                            try:
                                image = Image.open(io.BytesIO(response.content))
                                if image.format == 'WEBP':
                                    image = image.convert('RGB')
                                    buffer = io.BytesIO()
                                    image.save(buffer, format='JPEG')
                                    image_data = base64.b64encode(buffer.getvalue()).decode("utf-8")
                                    mime_type = "image/jpeg"
                                elif image.format == 'SVG':
                                    image_data = base64.b64encode(response.content).decode("utf-8")
                                    mime_type = "image/svg+xml"
                                elif image.format == 'PNG':
                                    image_data = base64.b64encode(response.content).decode("utf-8")
                                    mime_type = "image/png"
                                elif image.format == 'GIF':
                                    image_data = base64.b64encode(response.content).decode("utf-8")
                                    mime_type = "image/gif"
                                else:
                                    image_data = base64.b64encode(response.content).decode("utf-8")
                                    mime_type = content_type or "image/jpeg"
                                
                                image_details.append(
                                    {
                                        "type": "image_url",
                                        "image_url": {"url": f"data:{mime_type};base64,{image_data}"},
                                    }
                                )
                            except Exception as e:
                                print(f"Error processing image from {image_urls[i]}: {e}")
                        else:
                            print(f"Skipping non-image URL: {image_urls[i]} with content-type: {content_type}")
                    elif isinstance(response, Exception):
                        print(f"Error fetching URL {image_urls[i]}: {response}")
                    elif isinstance(response, httpx.Response):
                        print(f"Failed to fetch {image_urls[i]}: status code {response.status_code}")
        else:
            for image_url in image_urls:
                mime_type = "image/jpeg"
                image_data = base64.b64encode(open("output/"+image_url, "rb").read()).decode("utf-8")
                image_details.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{mime_type};base64,{image_data}"},
                    }
                )


        if len(image_details) == 0:
            return ImageDetailsList(images=[])

        llm = ChatVertexAI(model_name="gemini-2.5-pro")
        llm_with_structured_output = llm.with_structured_output(ImageDetailsList)
        messages = [
            SystemMessage(content=self.image_rating_system_prompt),
            HumanMessage(content=image_details)
        ]
        response = await llm_with_structured_output.ainvoke(messages)
        return response




async def main():
    visual_content_generator = VisualContentGenerator()
    
    data = {
                    "title": "From Early Facial Generation to Modern Capabilities",
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [
                                "Just a decade ago, the state-of-the-art in deep learning-based facial generation produced images that, while groundbreaking for their time, lacked significant realism. This marked the early stages of what was possible."
                            ]
                        },
                        {
                            "type": "paragraph",
                            "content": [
                                "A few years later, progress in image generation advanced tremendously, with models creating much more photorealistic faces. Soon after, these images began to incorporate temporal information, evolving from static pictures to dynamic videos."
                            ]
                        },
                        {
                            "type": "paragraph",
                            "content": [
                                "However, even the advanced models of just a few years ago required a tremendous amount of resources. For example, creating a single two-minute video of a person speaking from a predefined script involved a significant investment of time, data, and money."
                            ]
                        },
                        {
                            "type": "paragraph",
                            "content": [
                                "**Resources required for a 2-minute generative video in 2020 included:**"
                            ]
                        },
                        {
                            "type": "list",
                            "content": [
                                "Approximately **2 hours** of professional audio data.",
                                "Around **50 hours** of professional, high-definition video data.",
                                "About **$15,000** in computing costs."
                            ]
                        },
                        {
                            "type": "paragraph",
                            "content": [
                                "This resource-intensive process resulted in a static, inflexible output that could not be interacted with."
                            ]
                        },
                        {
                            "type": "paragraph",
                            "content": [
                                "In contrast, modern generative AI demonstrates a massive leap in capability. It is now possible to perform an \"instant clone\" of a voice after listening to it for only a brief period. This allows for live, unedited, and dynamic conversations with the AI model."
                            ]
                        },
                        {
                            "type": "paragraph",
                            "content": [
                                "The flexibility of today's models is a key advancement. They can be interrupted mid-sentence and given a completely new task—like telling a wild story about a turtle who goes to space—showcasing a shift from rigid, pre-scripted generation to dynamic and interactive content creation."
                            ]
                        }
                    ]
                }
    # sub_section_content = SubSectionContent(**data)
    # visuals = await visual_content_generator.generate_visuals(sub_section_content)
    # print(visuals.model_dump_json(indent=4))

    ret = await visual_content_generator.rate_images("A diagram of a neural network architecture.", ["https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png"])
    print(ret.model_dump_json(indent=4))

if __name__ == "__main__":
    asyncio.run(main())