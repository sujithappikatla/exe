from pydantic import BaseModel, Field
from typing import List, Any
from enum import Enum


class ComponentType(str, Enum):
    """Enum for the different types of content blocks."""
    PARAGRAPH = "paragraph"
    LIST = "list"
    QUOTE = "quote"
    CODE = "code"
    SVG = "svg"
    IMAGE = "image"
    VIDEO = "video"

class ImageComponent(BaseModel):
    url: str
    alt_text: str
    caption: str



class Component(BaseModel):
    """A block of content, which can be a paragraph, a list of items, a quote, or a code block."""
    type: ComponentType = Field(..., description="The type of the content block.")
    content: List[Any] = Field(..., description="The content of the Component.")



class SubSectionContent(BaseModel):
    title: str
    content: List[Component]

class SectionContent(BaseModel):
    title: str
    sub_sections: List[SubSectionContent]


class MainContent(BaseModel):
    title: str
    sections: List[SectionContent]