from pydantic import BaseModel, Field
from typing import List
from enum import Enum

class VisualType(str, Enum):
    """Enum for the different types of visuals."""
    IMAGE = "image"
    SEQUENCE_DIAGRAM = "sequence_diagram"
    MIND_MAP = "mind_map"

class Visual(BaseModel):
    """A block of content, which can be a image, video, sequence_diagram, or chart."""
    type: VisualType = Field(..., description="The type of the visual.")
    after_block_number: int = Field(..., description="The number of the block after which the visual should be placed.")
    content: str = Field(..., description="The content required to create the visual. For example, for an image, it will be the description of the image. For sequence diagram, it will be the sequence diagram code in seqdiag format. For mind map, it will be the mind map code in plantuml format, will be using plantweb library.")
    importance: int = Field(..., description="The importance of the visual. 1 is the most important and 5 is the least important.")

class Visuals(BaseModel):
    """A list of visuals."""
    visuals: List[Visual] = Field(..., description="The list of visuals.")



# #########################################################

class ImageDetails(BaseModel):
    """Details of an image."""
    relevance: float = Field(..., description="Relevance of the image to the content. Float between 0 and 1.")
    caption: str = Field(..., description="The caption of the image.")
    image_number: int = Field(..., description="The number of the image in the list of images. 0 based index.")

class ImageDetailsList(BaseModel):
    """A list of image details."""
    images: List[ImageDetails] = Field(..., description="The list of image details.")






