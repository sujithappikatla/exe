from pydantic import BaseModel, Field
from typing import List
from enum import Enum

class ContentType(str, Enum):
    """Enum for the different types of content blocks."""
    PARAGRAPH = "paragraph"
    LIST = "list"
    QUOTE = "quote"
    CODE = "code"

class ContentBlock(BaseModel):
    """A block of content, which can be a paragraph, a list of items, a quote, or a code block."""
    type: ContentType = Field(..., description="The type of the content block.")
    content: List[str] = Field(..., description="The content of the block. For a paragraph, quote, or code, this will be a list containing a single string. For a list, it will contain multiple strings, one for each list item.")

class SubSection(BaseModel):
    """Represents a subsection of a document, containing a title and a list of content blocks."""
    title: str
    content: List[ContentBlock]
