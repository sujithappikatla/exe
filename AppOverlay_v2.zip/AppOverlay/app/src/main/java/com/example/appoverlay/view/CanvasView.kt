package com.example.appoverlay.view


import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import com.example.appoverlay.util.LOGTAG
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PathData(val path:Path, val paint:Paint)

class CanvasView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private lateinit var job: Job
    private var pathsToDraw:MutableList<PathData> = mutableListOf()
    private var currentPath = Path()
    private var currentPaint = Paint()
    private var currentStrokeWidth = 5f
    private var currentColor = Color.BLACK
    private lateinit var CB : (Int) -> Unit
    private var mode = 0
    private var currentTool = "pen"

    init {
        Log.i(LOGTAG, "Creating CanvasView...")
        currentPaint.apply {
            color = currentColor
            style = Paint.Style.STROKE
            isAntiAlias = true
            strokeWidth = currentStrokeWidth
        }

    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for ( pd in pathsToDraw) {
            canvas.drawPath(pd.path, pd.paint)
        }
        canvas.drawPath(currentPath, currentPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        Log.d(LOGTAG, "onTouchEvent: "+event.size*1000 + " mode : "+mode)
        if(mode==0) {
            if (event.size * 1000 > 25.0f) {
                CB(2)
                job = GlobalScope.launch((Dispatchers.Default)) {
                    delay(500)
                    Log.d(LOGTAG, "---onTouchEvent: ")
                    withContext(Dispatchers.Main)
                    {
                        CB(1)
                    }

                }
                return false
            }
        }

        val x = event.x
        val y = event.y



        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                currentPath.moveTo(x, y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                currentPath.lineTo(x, y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                // Nothing to do here for now
            }
        }

        return false
    }

    fun addCurrentPathDataToList()
    {
        pathsToDraw.add(PathData(currentPath, currentPaint))
    }

    fun createNewPath()
    {
        currentPath = Path()
        currentPaint = Paint()

        var _strokeWidth = currentStrokeWidth
        var _alpha = 255
        if(currentTool == "highlighter")
        {
            _alpha = 70
            _strokeWidth *= 1.5f
        }
        if(currentTool == "eraser")
        {
            _strokeWidth *= 2
        }

        currentPaint.apply {
            color = currentColor
            strokeWidth = _strokeWidth
            isAntiAlias = true
            style = Paint.Style.STROKE
            alpha = _alpha
        }
        if(currentTool == "eraser")
        {
            currentPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }

    fun setStrokeWidth(_width : Float)
    {
        addCurrentPathDataToList()
        currentStrokeWidth = _width
        createNewPath()
        Log.i(LOGTAG, "Stroke Width set to : $_width")
    }

    fun changeToEraser()
    {
        currentTool = "eraser"
        addCurrentPathDataToList()
        createNewPath()

        Log.i(LOGTAG, "Changed to Eraser")
    }

    fun changePenColor(_color:Int)
    {

        addCurrentPathDataToList()
        currentColor = _color
        createNewPath()
        Log.i(LOGTAG, "Changed Color ")
    }

    fun changeToPen()
    {
        currentTool = "pen"
        addCurrentPathDataToList()
        createNewPath()
        Log.i(LOGTAG, "Changed to Pen ")
    }

    fun changeToHighlighter()
    {
        currentTool = "highlighter"
        addCurrentPathDataToList()
        createNewPath()
        Log.i(LOGTAG, "Changed to Highligther ")
    }

    fun setCallback(cbFunc: (Int) -> Unit) {
        CB = cbFunc
    }

    fun setMode(m: Int) {
        mode = m
    }
}
