package com.example.appoverlay.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import com.example.appoverlay.R
import com.example.appoverlay.util.LOGTAG

class SelectionBarOverlay(
    cxt: Context,
    windowManager: WindowManager,
    drawingCanvasOverlay: DrawingCanvasOverlay,
    val stopService: () -> Unit
) {
    private var selectionBarView: View? = null
    private var CXT: Context? = null
    private var WM:WindowManager? = null
    private var layoutParams:WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )
    private val CANVAS = drawingCanvasOverlay

    private var isColorSliderVisible = false
    private var isWidthSliderVisible = false
    private var mode = 0

    init {
        CXT = cxt
        WM = windowManager
    }

    public fun create()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView create ")

        val inflater = CXT!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        selectionBarView = inflater.inflate(R.layout.selection_bar_layout, null)

        layoutParams.gravity = Gravity.LEFT
        WM!!.addView(selectionBarView, layoutParams)
        //addColorItemsToView()
        //addEraserItemToView()
        //addToolSelectionItemToView()
        //addCloseToView()

        addColorSelectionLogic()
        addStrokeWidthLogic()
        addEraserLogic()
        addHighlighterLogic()
        addPenLogic()
        addModeLogic()
        addCloseLogic()

    }

    fun addColorSelectionLogic()
    {
        val colorSelection: LinearLayout = selectionBarView!!.findViewById(R.id.colorSelection)

        colorSelection.setOnClickListener {
            ToggleColorSelectionSlidingLayout()
        }

        val color1: View = selectionBarView!!.findViewById(R.id.color1)
        color1.setOnClickListener {
            onColorSelect(Color.RED);
            ToggleColorSelectionSlidingLayout()
        }

        val color2: View = selectionBarView!!.findViewById(R.id.color2)
        color2.setOnClickListener {
            onColorSelect(Color.GREEN);
            ToggleColorSelectionSlidingLayout()
        }

        val color3: View = selectionBarView!!.findViewById(R.id.color3)
        color3.setOnClickListener {
            onColorSelect(Color.BLUE);
            ToggleColorSelectionSlidingLayout()
        }

        val color4: View = selectionBarView!!.findViewById(R.id.color4)
        color4.setOnClickListener {
            onColorSelect(Color.WHITE);
            ToggleColorSelectionSlidingLayout()
        }

        val color5: View = selectionBarView!!.findViewById(R.id.color5)
        color5.setOnClickListener {
            onColorSelect(Color.BLACK);
            ToggleColorSelectionSlidingLayout()
        }
    }

    fun ToggleColorSelectionSlidingLayout()
    {
        val slidingLayout = selectionBarView!!.findViewById<View>(R.id.slidingColorsLayout)
        val slideInAnimation = AnimationUtils.loadAnimation(CXT, R.anim.slide_in)
        val slideOutAnimation = AnimationUtils.loadAnimation(CXT, R.anim.slide_out)

        if (!isColorSliderVisible) {
            slidingLayout.visibility = View.VISIBLE
            slidingLayout.startAnimation(slideInAnimation)
        } else {
            slidingLayout.startAnimation(slideOutAnimation)
            slideOutAnimation.setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(animation: Animation?) {
                    // Code to run when the animation starts (if needed)
                }

                override fun onAnimationEnd(animation: Animation?) {
                    slidingLayout.visibility = View.GONE
                }

                override fun onAnimationRepeat(animation: Animation?) {
                    // Code to run if the animation repeats (if needed)
                }
            })
        }

        isColorSliderVisible = !isColorSliderVisible
    }


    fun addStrokeWidthLogic()
    {
        val widthSelection: LinearLayout = selectionBarView!!.findViewById(R.id.strokeWidthSelection)

        widthSelection.setOnClickListener {

           ToggleStrokeWidthSelectionSlidingLayout()
        }

        val wdith1: View = selectionBarView!!.findViewById(R.id.width1)
        wdith1.setOnClickListener {
            onStrokeWidthSelect(5f)
            ToggleStrokeWidthSelectionSlidingLayout()
        }
        val wdith2: View = selectionBarView!!.findViewById(R.id.width2)
        wdith2.setOnClickListener {
            onStrokeWidthSelect(15f)
            ToggleStrokeWidthSelectionSlidingLayout()
        }
        val wdith3: View = selectionBarView!!.findViewById(R.id.width3)
        wdith3.setOnClickListener {
            onStrokeWidthSelect(25f)
            ToggleStrokeWidthSelectionSlidingLayout()
        }

    }

    fun ToggleStrokeWidthSelectionSlidingLayout()
    {
        val slidingLayout = selectionBarView!!.findViewById<View>(R.id.slidingWidthsLayout)
        val slideInAnimation = AnimationUtils.loadAnimation(CXT, R.anim.slide_in)
        val slideOutAnimation = AnimationUtils.loadAnimation(CXT, R.anim.slide_out)

        if (!isWidthSliderVisible) {
            slidingLayout.visibility = View.VISIBLE
            slidingLayout.startAnimation(slideInAnimation)
        } else {
            slidingLayout.startAnimation(slideOutAnimation)
            slideOutAnimation.setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(animation: Animation?) {
                    // Code to run when the animation starts (if needed)
                }

                override fun onAnimationEnd(animation: Animation?) {
                    slidingLayout.visibility = View.GONE
                }

                override fun onAnimationRepeat(animation: Animation?) {
                    // Code to run if the animation repeats (if needed)
                }
            })
        }

        isWidthSliderVisible = !isWidthSliderVisible
    }


    fun addEraserLogic()
    {
        val eraser: View = selectionBarView!!.findViewById(R.id.eraserLayout)
        eraser.setOnClickListener {
            onEraserSelect()
        }
    }

    fun addHighlighterLogic()
    {
        val highlighter : View = selectionBarView!!.findViewById(R.id.highlighterLayout)

        highlighter.setOnClickListener {
            CANVAS.setToHighlighter()
        }
    }

    fun addPenLogic()
    {
        val pen : View = selectionBarView!!.findViewById(R.id.penLayout)

        pen.setOnClickListener {
            CANVAS.setToPen()
        }

    }

    fun addModeLogic()
    {
        val modeL : View = selectionBarView!!.findViewById(R.id.modeLayout)

        modeL.setOnClickListener {
            val annotate = selectionBarView!!.findViewById<View>(R.id.modeAnnotate)
            val control = selectionBarView!!.findViewById<View>(R.id.modeControl)
            val control_annotate = selectionBarView!!.findViewById<View>(R.id.modeControlAndAnnotate)

            mode = (mode +1 ) % 3
            if(mode==0)
            {
                control_annotate.visibility = View.VISIBLE
                annotate.visibility = View.GONE
                control.visibility = View.GONE

            }
            else if(mode ==1)
            {
                control_annotate.visibility = View.GONE
                annotate.visibility = View.VISIBLE
                control.visibility = View.GONE

            }
            else if(mode==2)
            {
                control_annotate.visibility = View.GONE
                annotate.visibility = View.GONE
                control.visibility = View.VISIBLE
            }
            CANVAS.SetMode(mode)
        }

    }

    fun addCloseLogic()
    {
        val closeL: View = selectionBarView!!.findViewById(R.id.closeLayout)
        closeL.setOnClickListener {
            stopService()
        }

    }

    private fun onColorSelect(_color:Int)
    {
        Log.i(LOGTAG, "Selecting Color : $_color")
        CANVAS.setPenColor(_color)
    }

    private fun onStrokeWidthSelect(_width:Float)
    {
        Log.i(LOGTAG, "Selecting Stroke Width : $_width")

        CANVAS.setStrokeWidth(_width)
    }

    private fun onEraserSelect()
    {
        Log.i(LOGTAG, "Selecting Eraser")

        CANVAS.setToEraser()
    }

    private fun addColorItemsToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val colors = intArrayOf(
            Color.BLACK,
            Color.WHITE,
            Color.RED,
            Color.GREEN,
            Color.BLUE
            // Add more colors as needed
        )

        // Inflate and add small circles to the GridLayout
        for (colorResId in colors) {
            val circleView = View(CXT)
            val circleDrawable = ContextCompat.getDrawable(CXT!!, R.drawable.circle) as GradientDrawable
            circleDrawable.setColor(colorResId)
            circleView.background = circleDrawable

            circleView.setOnClickListener {
                onColorSelect(colorResId)
            }

            val layoutParams = GridLayout.LayoutParams().apply {
                width = 100
                height = 100
                bottomMargin = 20
            }

            colorSelectionGrid.addView(circleView, layoutParams)
        }
    }

    private fun addEraserItemToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val imageV = ImageView(CXT)
        imageV.setImageResource(R.drawable.eraser)
        imageV.setBackgroundResource(R.drawable.circular_background)

        val layoutParams = GridLayout.LayoutParams().apply {
            width = 100
            height = 100
            bottomMargin = 20
            topMargin = 20
        }

        imageV.setOnClickListener {
            CANVAS.setToEraser()
        }
        colorSelectionGrid.addView(imageV, layoutParams)
    }

    private fun addToolSelectionItemToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val imageV = ImageView(CXT)
        imageV.setImageResource(R.drawable.pen)
        imageV.setBackgroundResource(R.drawable.circular_background)

        //imageV.background = ColorDrawable(Color.LTGRAY)
        //imageV.setBackgroundResource(R.drawable.circular_background)

        //val _params = ViewGroup.LayoutParams(80, ViewGroup.LayoutParams.WRAP_CONTENT)
        //imageV.layoutParams = _params

        val layoutParams = GridLayout.LayoutParams().apply {
            width = 100
            height = 100
            bottomMargin = 20
            topMargin = 20
        }

        imageV.setOnClickListener {
            CANVAS.toggleInteractionMode()
        }

        colorSelectionGrid.addView(imageV, layoutParams)
    }

    public fun addCloseToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val imageV = ImageView(CXT)
        imageV.setImageResource(R.drawable.close)
        imageV.setBackgroundResource(R.drawable.circular_background)

        val layoutParams = GridLayout.LayoutParams().apply {
            width = 100
            height = 100
            bottomMargin = 20
            topMargin = 20
        }

        imageV.setOnClickListener {
            stopService()
        }
        colorSelectionGrid.addView(imageV, layoutParams)
    }

    public fun destroy()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView destroy ")
        if (WM != null && selectionBarView != null) {
            WM!!.removeView(selectionBarView)
        }
    }

}