package com.ska.richtext.richtext

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.commonmark.node.*

/**
 * Represents a segment of text that may contain inline math.
 * Used during text tokenization to separate regular text from LaTeX expressions.
 */
sealed class TextSegment {
    /** Regular text content */
    data class Plain(val text: String) : TextSegment()

    /** Inline math content (between single $...$) */
    data class InlineMath(val latex: String) : TextSegment()
}

/**
 * Tokenizes a string, separating regular text from inline math expressions.
 * Supports:
 * - Inline math: $...$ (single dollar signs)
 * - Escaped dollars: \$ (renders as literal $)
 *
 * Block math ($$...$$) should be handled at the block level before calling this.
 *
 * @param input The raw text that may contain inline math
 * @return List of TextSegments representing alternating text and math
 */
fun tokenizeInlineMath(input: String): List<TextSegment> {
    val segments = mutableListOf<TextSegment>()
    val currentText = StringBuilder()
    var i = 0

    while (i < input.length) {
        when {
            // Handle escaped dollar sign: \$
            i < input.length - 1 && input[i] == '\\' && input[i + 1] == '$' -> {
                currentText.append('$')
                i += 2
            }

            // Handle inline math: $...$
            input[i] == '$' -> {
                // Flush any accumulated plain text
                if (currentText.isNotEmpty()) {
                    segments.add(TextSegment.Plain(currentText.toString()))
                    currentText.clear()
                }

                // Find the closing $
                val start = i + 1
                var end = start
                while (end < input.length && input[end] != '$') {
                    // Handle escaped $ inside math (shouldn't happen, but be safe)
                    if (end < input.length - 1 && input[end] == '\\' && input[end + 1] == '$') {
                        end += 2
                    } else {
                        end++
                    }
                }

                if (end < input.length) {
                    // Found closing $
                    val latex = input.substring(start, end)
                    if (latex.isNotEmpty()) {
                        segments.add(TextSegment.InlineMath(latex))
                    }
                    i = end + 1
                } else {
                    // No closing $ found, treat as literal
                    currentText.append('$')
                    i++
                }
            }

            else -> {
                currentText.append(input[i])
                i++
            }
        }
    }

    // Flush remaining text
    if (currentText.isNotEmpty()) {
        segments.add(TextSegment.Plain(currentText.toString()))
    }

    return segments
}

/**
 * Checks if a paragraph contains block math ($$...$$).
 * Block math should be rendered as a separate centered block.
 *
 * @param text The paragraph text content
 * @return Pair of (isBlockMath, latexContent) or (false, "") if not block math
 */
fun extractBlockMath(text: String): Pair<Boolean, String> {
    val trimmed = text.trim()
    if (trimmed.startsWith("$$") && trimmed.endsWith("$$") && trimmed.length > 4) {
        val latex = trimmed.substring(2, trimmed.length - 2).trim()
        return Pair(true, latex)
    }
    return Pair(false, "")
}

/**
 * Data class to hold the result of building inline content.
 * Contains both the AnnotatedString and the map of inline content for math.
 */
data class InlineContentResult(
    val annotatedString: AnnotatedString,
    val inlineContent: Map<String, InlineTextContent>,
)

/**
 * Builds an AnnotatedString from CommonMark inline nodes, with support for inline math.
 * Traverses the node tree and applies appropriate styles.
 *
 * @param node The root inline node (usually first child of a Paragraph)
 * @param style The RichTextStyle containing style information
 * @param baseStyle The base SpanStyle to apply (from parent context)
 * @return InlineContentResult with annotated string and inline content map
 */
@Composable
fun buildInlineContent(
    node: Node?,
    style: RichTextStyle,
    baseStyle: SpanStyle = SpanStyle(),
): InlineContentResult {
    val inlineContentMap = mutableMapOf<String, InlineTextContent>()
    var mathCounter = 0
    val density = LocalDensity.current

    val annotatedString = buildAnnotatedString {
        // Recursive function to process nodes
        fun processNode(currentNode: Node?, currentStyle: SpanStyle) {
            var child = currentNode
            while (child != null) {
                when (child) {
                    is Text -> {
                        // Tokenize text for inline math
                        val segments = tokenizeInlineMath(child.literal)
                        for (segment in segments) {
                            when (segment) {
                                is TextSegment.Plain -> {
                                    withStyle(currentStyle) {
                                        append(segment.text)
                                    }
                                }

                                is TextSegment.InlineMath -> {
                                    // Create a unique ID for this math expression
                                    val mathId = "math_${mathCounter++}"

                                    // Measure the LaTeX to get dimensions
                                    val textSizePx = with(density) { style.mathInlineSizeSp * this.density }
                                    val dimensions = LatexRenderer.measureDimensions(
                                        segment.latex,
                                        textSizePx
                                    )

                                    if (dimensions != null) {
                                        val (width, height) = dimensions
                                        val widthDp = with(density) { width.toDp() }
                                        val heightDp = with(density) { height.toDp() }

                                        // Create inline content for this math expression
                                        inlineContentMap[mathId] = InlineTextContent(
                                            placeholder = Placeholder(
                                                width = widthDp.value.sp,
                                                height = heightDp.value.sp,
                                                placeholderVerticalAlign = PlaceholderVerticalAlign.TextCenter
                                            )
                                        ) {
                                            // The composable that renders the math
                                            InlineMathContent(
                                                latex = segment.latex,
                                                textSizeSp = style.mathInlineSizeSp,
                                                color = style.mathColor,
                                                modifier = Modifier
                                                    .width(widthDp)
                                                    .height(heightDp)
                                            )
                                        }

                                        // Insert placeholder for inline content
                                        appendInlineContent(mathId, segment.latex)
                                    } else {
                                        // Fallback: render as text if LaTeX parsing fails
                                        withStyle(currentStyle.copy(fontStyle = FontStyle.Italic)) {
                                            append("$${segment.latex}$")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    is Emphasis -> {
                        // Italic text
                        processNode(
                            child.firstChild,
                            currentStyle.copy(fontStyle = FontStyle.Italic)
                        )
                    }

                    is StrongEmphasis -> {
                        // Bold text
                        processNode(
                            child.firstChild,
                            currentStyle.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    is Code -> {
                        // Inline code
                        withStyle(
                            style.codeInline.toSpanStyle().copy(
                                background = style.codeInlineBackground
                            )
                        ) {
                            append(child.literal)
                        }
                    }

                    is Link -> {
                        // Clickable link (annotation for click handling)
                        val linkStyle = currentStyle.copy(
                            color = style.linkColor,
                            textDecoration = TextDecoration.Underline
                        )
                        pushStringAnnotation(tag = "URL", annotation = child.destination)
                        processNode(child.firstChild, linkStyle)
                        pop()
                    }

                    is SoftLineBreak -> {
                        append(" ")
                    }

                    is HardLineBreak -> {
                        append("\n")
                    }

                    // Handle GFM strikethrough
                    is org.commonmark.ext.gfm.strikethrough.Strikethrough -> {
                        processNode(
                            child.firstChild,
                            currentStyle.copy(textDecoration = TextDecoration.LineThrough)
                        )
                    }

                    else -> {
                        // For unknown nodes, try to process children
                        if (child.firstChild != null) {
                            processNode(child.firstChild, currentStyle)
                        }
                    }
                }
                child = child.next
            }
        }

        processNode(node, baseStyle)
    }

    return InlineContentResult(annotatedString, inlineContentMap)
}

/**
 * Composable that renders an inline math expression as an Image.
 */
@Composable
private fun InlineMathContent(
    latex: String,
    textSizeSp: Float,
    color: Color,
    modifier: Modifier = Modifier,
) {
    val bitmap = rememberLatexBitmap(latex, textSizeSp, color)
    if (bitmap != null) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Image(
                bitmap = bitmap,
                contentDescription = "Math: $latex",
            )
        }
    }
}

/**
 * Extension to get the plain text content from a node and its children.
 * Useful for extracting raw text for block math detection.
 */
fun Node.getTextContent(): String {
    val sb = StringBuilder()
    var child = this.firstChild
    while (child != null) {
        when (child) {
            is Text -> sb.append(child.literal)
            is SoftLineBreak -> sb.append(" ")
            is HardLineBreak -> sb.append("\n")
            else -> sb.append(child.getTextContent())
        }
        child = child.next
    }
    return sb.toString()
}

