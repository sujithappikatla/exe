package com.ska.richtext.richtext

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import ru.noties.jlatexmath.JLatexMathDrawable

/**
 * Utility object for rendering LaTeX expressions to ImageBitmap.
 * Uses JLaTeXMath library to convert LaTeX strings into Android Drawables,
 * then converts those to Compose-compatible ImageBitmap.
 */
object LatexRenderer {

    /**
     * Renders a LaTeX string to an ImageBitmap.
     *
     * @param latex The LaTeX expression (without delimiters like $ or $$)
     * @param textSizePx The text size in pixels
     * @param color The text color
     * @return ImageBitmap containing the rendered LaTeX, or null if rendering fails
     */
    fun render(
        latex: String,
        textSizePx: Float,
        color: Color,
    ): ImageBitmap? {
        return try {
            // Build the JLaTeXMath drawable with specified styling
            val drawable = JLatexMathDrawable.builder(latex)
                .textSize(textSizePx)
                .color(color.toArgb())
                .padding(0)
                .build()

            // Get intrinsic dimensions from the drawable
            val width = drawable.intrinsicWidth.coerceAtLeast(1)
            val height = drawable.intrinsicHeight.coerceAtLeast(1)

            // Create a bitmap and draw the LaTeX onto it
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, width, height)
            drawable.draw(canvas)

            // Convert to Compose ImageBitmap
            bitmap.asImageBitmap()
        } catch (e: Exception) {
            // LaTeX parsing can fail for invalid expressions
            // Return null to allow fallback rendering (e.g., show raw text)
            null
        }
    }

    /**
     * Calculates the dimensions of rendered LaTeX without actually creating the bitmap.
     * Useful for layout calculations.
     *
     * @param latex The LaTeX expression
     * @param textSizePx The text size in pixels
     * @return Pair of (width, height) in pixels, or null if calculation fails
     */
    fun measureDimensions(
        latex: String,
        textSizePx: Float,
    ): Pair<Int, Int>? {
        return try {
            val drawable = JLatexMathDrawable.builder(latex)
                .textSize(textSizePx)
                .padding(0)
                .build()

            Pair(
                drawable.intrinsicWidth.coerceAtLeast(1),
                drawable.intrinsicHeight.coerceAtLeast(1)
            )
        } catch (e: Exception) {
            null
        }
    }
}

/**
 * Composable helper that renders LaTeX and caches the result.
 * The bitmap is recalculated only when latex, textSizeSp, or color changes.
 *
 * @param latex The LaTeX expression to render
 * @param textSizeSp Text size in sp (will be converted to px using density)
 * @param color Text color for the LaTeX expression
 * @return Cached ImageBitmap, or null if rendering fails
 */
@Composable
fun rememberLatexBitmap(
    latex: String,
    textSizeSp: Float,
    color: Color,
): ImageBitmap? {
    val density = LocalDensity.current
    return remember(latex, textSizeSp, color, density) {
        val textSizePx = with(density) { textSizeSp * this.density }
        LatexRenderer.render(latex, textSizePx, color)
    }
}

/**
 * Composable helper to measure LaTeX dimensions with caching.
 *
 * @param latex The LaTeX expression to measure
 * @param textSizeSp Text size in sp
 * @return Pair of (width, height) in pixels, or null if measurement fails
 */
@Composable
fun rememberLatexDimensions(
    latex: String,
    textSizeSp: Float,
): Pair<Int, Int>? {
    val density = LocalDensity.current
    return remember(latex, textSizeSp, density) {
        val textSizePx = with(density) { textSizeSp * this.density }
        LatexRenderer.measureDimensions(latex, textSizePx)
    }
}

/**
 * Convert sp to px for LaTeX rendering.
 */
fun spToPx(sp: Float, density: Density): Float {
    return sp * density.density
}

