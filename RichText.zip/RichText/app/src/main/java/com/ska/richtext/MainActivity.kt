package com.ska.richtext

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.ska.richtext.richtext.RichText
import com.ska.richtext.richtext.RichTextDefaults
import com.ska.richtext.ui.theme.RichTextTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RichTextTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    RichTextDemo(
                        modifier = Modifier
                            .padding(innerPadding)
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    )
                }
            }
        }
    }
}

/**
 * Demo composable showcasing RichText features.
 */
@Composable
fun RichTextDemo(modifier: Modifier = Modifier) {
    // Sample markdown with LaTeX
    val sampleMarkdown = """
Here is a comprehensive markdown document demonstrating various formatting elements, mathematical typesetting using LaTeX, and proper character escaping.

***

# A Comprehensive Guide to Technical Markdown

## 1. Introduction to Financial Modeling
Markdown is a lightweight markup language with plain text formatting syntax. It is often used to format `README` files, for writing messages in online discussion forums, and to create rich text using a plain text editor. 

When discussing finances, it is important to distinguish between mathematical variables and currency. For example, if a cloud server costs **\${'$'}0.04 per hour**, and we run it for ${'$'}t${'$'} hours, the total cost ${'$'}C${'$'} can be defined.

### 1.1 The Cost Function
We can define a simple linear function for cost. Let ${'$'}r${'$'} be the rate in dollars.

${'$'}${'$'} C(t) = r \cdot t + \text{overhead} ${'$'}${'$'}

If the overhead is **\${'$'}10.50** (flat fee), and the variable rate is defined as ${'$'}r = \${'$'}0.04${'$'}, then for 100 hours:

${'$'}${'$'} C(100) = 0.04(100) + 10.50 = \${'$'}14.50 ${'$'}${'$'}

---

## 2. Advanced Mathematical Concepts
Markdown supports rendering LaTeX for complex scientific documentation. Below are examples of Calculus, Linear Algebra, and Physics equations.

### 2.1 The Gaussian Integral
One of the most beautiful results in mathematics is the Gaussian integral. It states that the area under the bell curve ${'$'}e^{-x^2}${'$'} is the square root of ${'$'}\pi${'$'}.

${'$'}${'$'} \int_{-\infty}^{\infty} e^{-x^2} dx = \sqrt{\pi} ${'$'}${'$'}

> **Note:** This integral is fundamental to probability theory and quantum mechanics.

### 2.2 Maxwell's Equations
Electromagnetism is described by a set of partial differential equations. In a vacuum, they look like this:

${'$'}${'$'}
\begin{aligned}
\nabla \cdot \mathbf{E} &= 0 \\
\nabla \cdot \mathbf{B} &= 0 \\
\nabla \times \mathbf{E} &= -\frac{\partial \mathbf{B}}{\partial t} \\
\nabla \times \mathbf{B} &= \mu_0 \epsilon_0 \frac{\partial \mathbf{E}}{\partial t}
\end{aligned}
${'$'}${'$'}

### 2.3 Matrix Operations
We can also represent linear transformations using matrices. Let ${'$'}A${'$'} be a ${'$'}2 \times 2${'$'} matrix:

${'$'}${'$'} A = \begin{bmatrix} \alpha & \beta \\ \gamma & \delta \end{bmatrix} ${'$'}${'$'}

The determinant of ${'$'}A${'$'}, denoted as ${'$'}\det(A)${'$'} or ${'$'}|A|${'$'}, is calculated as:

${'$'}${'$'} |A| = \alpha\delta - \beta\gamma ${'$'}${'$'}

---

## 3. Formatting Elements
To ensure this document serves as a full test suite, we must include various standard markdown elements.

### Lists
**Unordered List (Ingredients for a recipe costing < \${'$'}20):**
*   Flour
*   Sugar
*   Chocolate Chips (Approx. \${'$'}4.99)
*   *Secret Ingredient*

**Ordered List (Steps to solve ${'$'}x^2 - 4 = 0${'$'}):**
1.  Add 4 to both sides: ${'$'}x^2 = 4${'$'}
2.  Take the square root: ${'$'}x = \pm\sqrt{4}${'$'}
3.  Result: ${'$'}x = \pm 2${'$'}

**Task List:**
- [x] Write documentation
- [x] Check math syntax
- [ ] Buy milk (Budget: \${'$'}3.50)

### Code Blocks
Below is a Python function that calculates the **Fibonacci sequence** mathematically defined as ${'$'}F_n = F_{n-1} + F_{n-2}${'$'}.

```python
def fibonacci(n):
    ""${'"'}
    Returns the nth Fibonacci number.
    Cost of execution: ~${'$'}0.0001 per call on AWS Lambda.
    ""${'"'}
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n-1) + fibonacci(n-2)

# Calculate the 10th number
print(fibonacci(10))
```

### Tables
Here is a comparison of different physical constants.

| Constant Name | Symbol | Value (Approx) | Discovery Year |
| :--- | :---: | :--- | :---: |
| Speed of Light | ${'$'}c${'$'} | ${'$'}2.99 \times 10^8${'$'} m/s | 1676 |
| Planck's Constant | ${'$'}h${'$'} | ${'$'}6.626 \times 10^{-34}${'$'} J${'$'}\cdot${'$'}s | 1900 |
| Gravitational Constant | ${'$'}G${'$'} | ${'$'}6.674 \times 10^{-11}${'$'} N${'$'}\cdot${'$'}m${'$'}^2${'$'}/kg${'$'}^2${'$'} | 1798 |

---

## 4. Text Emphasis and Escaping
Sometimes you need to emphasize specific parts of the text or handle special characters.

*   **Bold Text:** This is very important.
*   *Italic Text:* This is somewhat emphasized.
*   ***Bold and Italic:*** This is critical.
*   ~~Strikethrough:~~ This text is no longer valid.
*   `Inline Code`: Use this for mentioning functions like `print()` or file paths like `/etc/hosts`.

### The Dollar Sign Dilemma
When writing technical documentation involving LaTeX, one must be careful with the dollar sign.
*   To start math mode, use the dollar sign normally: ${'$'}x = y${'$'}.
*   To talk about money, use the backslash: **The price is \${'$'}100.00**.
*   To show a literal dollar sign inside a code span: `${'$'}` or `\${'$'}`.

## 5. Conclusion
We have covered:
1.  Standard text formatting.
2.  Inline math: ${'$'}\sum_{i=1}^{n} i = \frac{n(n+1)}{2}${'$'}.
3.  Block math:
    ${'$'}${'$'} \lim_{x \to 0} \frac{\sin(x)}{x} = 1 ${'$'}${'$'}
4.  Escaping currency symbols (e.g., \${'$'}50 vs \${'$'}100).

Thank you for reading this test document.
    """.trimIndent()


    var mdText by remember {
        mutableStateOf("")
    }

    LaunchedEffect(Unit) {

        sampleMarkdown.forEach {
            mdText += it
            kotlinx.coroutines.delay(10)
        }

    }

    RichText.Content(
        markdown = mdText,
        modifier = modifier,
        style = RichTextDefaults.style(
            paragraph = TextStyle(
                color = Color.Red,

            )
        ),
    )
}

@Preview(showBackground = true)
@Composable
fun RichTextDemoPreview() {
    RichTextTheme {
        RichTextDemo(
            modifier = Modifier.padding(16.dp),

        )

    }
}