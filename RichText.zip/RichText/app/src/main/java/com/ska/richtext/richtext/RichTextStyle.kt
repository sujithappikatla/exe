package com.ska.richtext.richtext

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Holds all styling configuration for the RichText composable.
 * Group typography, colors, and spacing in one place for easy customization.
 *
 * Usage:
 * ```
 * RichText.Content(
 *     markdown = "...",
 *     style = RichTextStyle(
 *         paragraph = TextStyle(fontSize = 16.sp),
 *         linkColor = Color.Blue,
 *         // ... other customizations
 *     )
 * )
 * ```
 */
@Immutable
data class RichTextStyle(
    // ──────────────────────────────────────────────────────────────────────────
    // Typography: TextStyles for different markdown elements
    // ──────────────────────────────────────────────────────────────────────────

    /** Style for regular paragraph text */
    val paragraph: TextStyle,

    /** Style for level 1 headings (# Heading) */
    val h1: TextStyle,

    /** Style for level 2 headings (## Heading) */
    val h2: TextStyle,

    /** Style for level 3 headings (### Heading) */
    val h3: TextStyle,

    /** Style for level 4 headings (#### Heading) */
    val h4: TextStyle,

    /** Style for level 5 headings (##### Heading) */
    val h5: TextStyle,

    /** Style for level 6 headings (###### Heading) */
    val h6: TextStyle,

    /** Style for inline code (`code`) */
    val codeInline: TextStyle,

    /** Style for code blocks (```code```) */
    val codeBlock: TextStyle,

    /** Style for blockquote text */
    val quote: TextStyle,

    /** Style for table header cells */
    val tableHeader: TextStyle,

    /** Style for table body cells */
    val tableCell: TextStyle,

    /** Style for list items */
    val listItem: TextStyle,

    // ──────────────────────────────────────────────────────────────────────────
    // Colors: For links, backgrounds, and borders
    // ──────────────────────────────────────────────────────────────────────────

    /** Color for clickable links */
    val linkColor: Color,

    /** Background color for inline code */
    val codeInlineBackground: Color,

    /** Background color for code blocks */
    val codeBlockBackground: Color,

    /** Left border color for blockquotes */
    val quoteBorderColor: Color,

    /** Background color for blockquotes */
    val quoteBackground: Color,

    /** Border color for tables */
    val tableBorderColor: Color,

    /** Background color for table header row */
    val tableHeaderBackground: Color,

    /** Color for math expressions (LaTeX) */
    val mathColor: Color,

    // ──────────────────────────────────────────────────────────────────────────
    // Spacing & Metrics: Control layout and sizing
    // ──────────────────────────────────────────────────────────────────────────

    /** Vertical spacing between block elements (paragraphs, headings, etc.) */
    val blockSpacing: Dp,

    /** Horizontal indent for each nesting level in lists */
    val listIndent: Dp,

    /** Width of the left border for blockquotes */
    val quoteBorderWidth: Dp,

    /** Horizontal padding inside blockquotes */
    val quotePaddingHorizontal: Dp,

    /** Font size for inline math expressions (in sp) */
    val mathInlineSizeSp: Float,

    /** Font size for block math expressions (in sp) */
    val mathBlockSizeSp: Float,

    /** Padding inside code blocks */
    val codeBlockPadding: Dp,

    /** Padding inside table cells */
    val tableCellPadding: Dp,

    /** Border width for tables */
    val tableBorderWidth: Dp,

    /** Bullet character for unordered lists */
    val bulletChar: String,
)

/**
 * Provides default styling that integrates with Material Theme.
 * Call these functions inside a @Composable context to access theme colors/typography.
 */
object RichTextDefaults {

    /**
     * Creates a default RichTextStyle using MaterialTheme values.
     * Override specific properties as needed.
     */
    @Composable
    fun style(
        // Typography defaults derived from MaterialTheme
        paragraph: TextStyle = MaterialTheme.typography.bodyLarge,
        h1: TextStyle = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
        h2: TextStyle = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        h3: TextStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        h4: TextStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        h5: TextStyle = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
        h6: TextStyle = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
        codeInline: TextStyle = MaterialTheme.typography.bodyMedium.copy(
            fontFamily = FontFamily.Monospace
        ),
        codeBlock: TextStyle = MaterialTheme.typography.bodyMedium.copy(
            fontFamily = FontFamily.Monospace
        ),
        quote: TextStyle = MaterialTheme.typography.bodyLarge.copy(
            color = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        tableHeader: TextStyle = MaterialTheme.typography.bodyMedium.copy(
            fontWeight = FontWeight.Bold
        ),
        tableCell: TextStyle = MaterialTheme.typography.bodyMedium,
        listItem: TextStyle = MaterialTheme.typography.bodyLarge,

        // Color defaults
        linkColor: Color = MaterialTheme.colorScheme.primary,
        codeInlineBackground: Color = MaterialTheme.colorScheme.surfaceVariant,
        codeBlockBackground: Color = MaterialTheme.colorScheme.surfaceVariant,
        quoteBorderColor: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
        quoteBackground: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        tableBorderColor: Color = MaterialTheme.colorScheme.outlineVariant,
        tableHeaderBackground: Color = MaterialTheme.colorScheme.surfaceVariant,
        mathColor: Color = MaterialTheme.colorScheme.onSurface,

        // Spacing defaults
        blockSpacing: Dp = 12.dp,
        listIndent: Dp = 24.dp,
        quoteBorderWidth: Dp = 4.dp,
        quotePaddingHorizontal: Dp = 12.dp,
        mathInlineSizeSp: Float = 16f,
        mathBlockSizeSp: Float = 20f,
        codeBlockPadding: Dp = 12.dp,
        tableCellPadding: Dp = 8.dp,
        tableBorderWidth: Dp = 1.dp,
        bulletChar: String = "•",
    ): RichTextStyle = RichTextStyle(
        paragraph = paragraph,
        h1 = h1,
        h2 = h2,
        h3 = h3,
        h4 = h4,
        h5 = h5,
        h6 = h6,
        codeInline = codeInline,
        codeBlock = codeBlock,
        quote = quote,
        tableHeader = tableHeader,
        tableCell = tableCell,
        listItem = listItem,
        linkColor = linkColor,
        codeInlineBackground = codeInlineBackground,
        codeBlockBackground = codeBlockBackground,
        quoteBorderColor = quoteBorderColor,
        quoteBackground = quoteBackground,
        tableBorderColor = tableBorderColor,
        tableHeaderBackground = tableHeaderBackground,
        mathColor = mathColor,
        blockSpacing = blockSpacing,
        listIndent = listIndent,
        quoteBorderWidth = quoteBorderWidth,
        quotePaddingHorizontal = quotePaddingHorizontal,
        mathInlineSizeSp = mathInlineSizeSp,
        mathBlockSizeSp = mathBlockSizeSp,
        codeBlockPadding = codeBlockPadding,
        tableCellPadding = tableCellPadding,
        tableBorderWidth = tableBorderWidth,
        bulletChar = bulletChar,
    )
}

/**
 * Helper extension to get the TextStyle for a specific heading level.
 * Returns paragraph style if level is out of range.
 */
fun RichTextStyle.headingStyle(level: Int): TextStyle = when (level) {
    1 -> h1
    2 -> h2
    3 -> h3
    4 -> h4
    5 -> h5
    6 -> h6
    else -> paragraph
}

