package com.ska.richtext.richtext

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.commonmark.ext.gfm.strikethrough.StrikethroughExtension
import org.commonmark.ext.gfm.tables.*
import org.commonmark.node.*
import org.commonmark.parser.Parser

/**
 * Parses Markdown text and returns the root Document node.
 * Uses CommonMark parser with GFM extensions for tables and strikethrough.
 */
fun parseMarkdown(markdown: String): Document {
    val extensions = listOf(
        TablesExtension.create(),
        StrikethroughExtension.create()
    )
    val parser = Parser.builder()
        .extensions(extensions)
        .build()
    return parser.parse(markdown) as Document
}

/**
 * Main composable that renders a CommonMark Document AST.
 * Iterates through block-level nodes and renders each appropriately.
 *
 * @param document The parsed CommonMark Document
 * @param style The RichTextStyle containing all styling options
 * @param onLinkClick Optional callback when a link is clicked
 * @param modifier Modifier for the root Column
 */
@Composable
fun MarkdownContent(
    document: Document,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(style.blockSpacing)
    ) {
        var child = document.firstChild
        while (child != null) {
            RenderBlock(node = child, style = style, onLinkClick = onLinkClick)
            child = child.next
        }
    }
}

/**
 * Renders a single block-level node.
 * Dispatches to specific renderers based on node type.
 */
@Composable
private fun RenderBlock(
    node: Node,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
    listDepth: Int = 0,
) {
    when (node) {
        is Heading -> HeadingBlock(node, style, onLinkClick)
        is Paragraph -> ParagraphBlock(node, style, onLinkClick)
        is BulletList -> BulletListBlock(node, style, onLinkClick, listDepth)
        is OrderedList -> OrderedListBlock(node, style, onLinkClick, listDepth)
        is BlockQuote -> BlockQuoteBlock(node, style, onLinkClick)
        is FencedCodeBlock -> CodeBlockFenced(node, style)
        is IndentedCodeBlock -> CodeBlockIndented(node, style)
        is ThematicBreak -> ThematicBreakBlock(style)
        is TableBlock -> TableBlockRenderer(node, style, onLinkClick)
        else -> {
            // For unknown blocks, try to render children
            var child = node.firstChild
            while (child != null) {
                RenderBlock(child, style, onLinkClick, listDepth)
                child = child.next
            }
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Block Renderers
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Renders a heading (# to ######).
 * Uses the appropriate TextStyle from RichTextStyle based on heading level.
 */
@Composable
private fun HeadingBlock(
    node: Heading,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
) {
    val textStyle = style.headingStyle(node.level)
    val (annotatedString, inlineContent) = buildInlineContent(
        node = node.firstChild,
        style = style,
        baseStyle = textStyle.toSpanStyle()
    )

    ClickableTextWithInlineContent(
        text = annotatedString,
        inlineContent = inlineContent,
        style = textStyle,
        onLinkClick = onLinkClick
    )
}

/**
 * Renders a paragraph.
 * First checks if the paragraph contains block math ($$...$$).
 * If so, renders as centered math block; otherwise renders as text with inline content.
 */
@Composable
private fun ParagraphBlock(
    node: Paragraph,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
) {
    // Extract text content to check for block math
    val textContent = node.getTextContent()
    val (isBlockMath, latex) = extractBlockMath(textContent)

    if (isBlockMath) {
        // Render as centered block math
        BlockMathContent(latex = latex, style = style)
    } else {
        // Render as normal paragraph with inline content
        val (annotatedString, inlineContent) = buildInlineContent(
            node = node.firstChild,
            style = style,
            baseStyle = style.paragraph.toSpanStyle()
        )

        ClickableTextWithInlineContent(
            text = annotatedString,
            inlineContent = inlineContent,
            style = style.paragraph,
            onLinkClick = onLinkClick
        )
    }
}

/**
 * Renders a block math expression ($$...$$) as a centered image.
 */
@Composable
private fun BlockMathContent(
    latex: String,
    style: RichTextStyle,
) {
    val bitmap = rememberLatexBitmap(
        latex = latex,
        textSizeSp = style.mathBlockSizeSp,
        color = style.mathColor
    )

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = "Math: $latex",
                modifier = Modifier.padding(vertical = 8.dp)
            )
        } else {
            // Fallback: show raw LaTeX if rendering fails
            BasicText(
                text = "$$${latex}$$",
                style = style.paragraph.copy(color = Color.Red)
            )
        }
    }
}

/**
 * Renders an unordered (bullet) list.
 * Supports nesting via listDepth parameter.
 */
@Composable
private fun BulletListBlock(
    node: BulletList,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
    listDepth: Int,
) {
    Column(
        modifier = Modifier.padding(start = style.listIndent * listDepth)
    ) {
        var item = node.firstChild
        while (item != null) {
            if (item is ListItem) {
                ListItemBlock(
                    node = item,
                    style = style,
                    onLinkClick = onLinkClick,
                    listDepth = listDepth,
                    bullet = style.bulletChar
                )
            }
            item = item.next
        }
    }
}

/**
 * Renders an ordered (numbered) list.
 * Numbers start from the list's startNumber property.
 */
@Composable
private fun OrderedListBlock(
    node: OrderedList,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
    listDepth: Int,
) {
    Column(
        modifier = Modifier.padding(start = style.listIndent * listDepth)
    ) {
        var number = node.startNumber
        var item = node.firstChild
        while (item != null) {
            if (item is ListItem) {
                ListItemBlock(
                    node = item,
                    style = style,
                    onLinkClick = onLinkClick,
                    listDepth = listDepth,
                    bullet = "${number}."
                )
                number++
            }
            item = item.next
        }
    }
}

/**
 * Renders a single list item (bullet or numbered).
 * Handles nested content including nested lists.
 */
@Composable
private fun ListItemBlock(
    node: ListItem,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
    listDepth: Int,
    bullet: String,
) {
    Row(
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        // Bullet or number
        BasicText(
            text = bullet,
            style = style.listItem,
            modifier = Modifier.width(style.listIndent)
        )

        // Item content
        Column {
            var child = node.firstChild
            while (child != null) {
                when (child) {
                    is Paragraph -> {
                        // Inline content of the list item
                        val (annotatedString, inlineContent) = buildInlineContent(
                            node = child.firstChild,
                            style = style,
                            baseStyle = style.listItem.toSpanStyle()
                        )
                        ClickableTextWithInlineContent(
                            text = annotatedString,
                            inlineContent = inlineContent,
                            style = style.listItem,
                            onLinkClick = onLinkClick
                        )
                    }
                    is BulletList -> {
                        Spacer(modifier = Modifier.height(4.dp))
                        BulletListBlock(child, style, onLinkClick, listDepth + 1)
                    }
                    is OrderedList -> {
                        Spacer(modifier = Modifier.height(4.dp))
                        OrderedListBlock(child, style, onLinkClick, listDepth + 1)
                    }
                    else -> {
                        RenderBlock(child, style, onLinkClick, listDepth + 1)
                    }
                }
                child = child.next
            }
        }
    }
}

/**
 * Renders a blockquote with a left border.
 * Recursively renders children for nested quotes.
 */
@Composable
private fun BlockQuoteBlock(
    node: BlockQuote,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
) {
    val borderColor = style.quoteBorderColor
    val borderWidth = style.quoteBorderWidth

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(style.quoteBackground, RoundedCornerShape(4.dp))
            .drawBehind {
                // Draw left border
                drawLine(
                    color = borderColor,
                    start = Offset(0f, 0f),
                    end = Offset(0f, size.height),
                    strokeWidth = borderWidth.toPx()
                )
            }
            .padding(
                start = style.quotePaddingHorizontal + borderWidth,
                end = style.quotePaddingHorizontal,
                top = 8.dp,
                bottom = 8.dp
            )
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(style.blockSpacing / 2)
        ) {
            var child = node.firstChild
            while (child != null) {
                when (child) {
                    is Paragraph -> {
                        val (annotatedString, inlineContent) = buildInlineContent(
                            node = child.firstChild,
                            style = style,
                            baseStyle = style.quote.toSpanStyle()
                        )
                        ClickableTextWithInlineContent(
                            text = annotatedString,
                            inlineContent = inlineContent,
                            style = style.quote,
                            onLinkClick = onLinkClick
                        )
                    }
                    is BlockQuote -> {
                        // Nested blockquote
                        BlockQuoteBlock(child, style, onLinkClick)
                    }
                    else -> {
                        RenderBlock(child, style, onLinkClick)
                    }
                }
                child = child.next
            }
        }
    }
}

/**
 * Renders a fenced code block (```code```).
 * Uses monospace font with background and horizontal scroll.
 */
@Composable
private fun CodeBlockFenced(
    node: FencedCodeBlock,
    style: RichTextStyle,
) {
    val code = node.literal.trimEnd('\n')

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(style.codeBlockBackground, RoundedCornerShape(8.dp))
            .horizontalScroll(rememberScrollState())
            .padding(style.codeBlockPadding)
    ) {
        BasicText(
            text = code,
            style = style.codeBlock,
        )
    }
}

/**
 * Renders an indented code block.
 */
@Composable
private fun CodeBlockIndented(
    node: IndentedCodeBlock,
    style: RichTextStyle,
) {
    val code = node.literal.trimEnd('\n')

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(style.codeBlockBackground, RoundedCornerShape(8.dp))
            .horizontalScroll(rememberScrollState())
            .padding(style.codeBlockPadding)
    ) {
        BasicText(
            text = code,
            style = style.codeBlock,
        )
    }
}

/**
 * Renders a horizontal rule / thematic break (---, ***, ___).
 */
@Composable
private fun ThematicBreakBlock(style: RichTextStyle) {
    HorizontalDivider(
        modifier = Modifier.padding(vertical = 8.dp),
        color = style.tableBorderColor
    )
}

// ──────────────────────────────────────────────────────────────────────────────
// Table Renderer
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Renders a GFM table.
 * Uses Row and Box for cells with borders.
 * Horizontally scrollable for wide tables.
 */
@Composable
private fun TableBlockRenderer(
    node: TableBlock,
    style: RichTextStyle,
    onLinkClick: ((String) -> Unit)?,
) {
    val borderColor = style.tableBorderColor
    val borderWidth = style.tableBorderWidth

    Box(
        modifier = Modifier
            .horizontalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .drawBehind {
                    // Draw outer border
                    drawRect(
                        color = borderColor,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = borderWidth.toPx()
                        )
                    )
                }
        ) {
            var child = node.firstChild
            while (child != null) {
                when (child) {
                    is TableHead -> {
                        var row = child.firstChild
                        while (row != null) {
                            if (row is TableRow) {
                                TableRowRenderer(
                                    row = row,
                                    style = style,
                                    isHeader = true,
                                    onLinkClick = onLinkClick
                                )
                            }
                            row = row.next
                        }
                    }
                    is TableBody -> {
                        var row = child.firstChild
                        while (row != null) {
                            if (row is TableRow) {
                                TableRowRenderer(
                                    row = row,
                                    style = style,
                                    isHeader = false,
                                    onLinkClick = onLinkClick
                                )
                            }
                            row = row.next
                        }
                    }
                }
                child = child.next
            }
        }
    }
}

/**
 * Renders a single table row.
 */
@Composable
private fun TableRowRenderer(
    row: TableRow,
    style: RichTextStyle,
    isHeader: Boolean,
    onLinkClick: ((String) -> Unit)?,
) {
    val backgroundColor = if (isHeader) style.tableHeaderBackground else Color.Transparent
    val textStyle = if (isHeader) style.tableHeader else style.tableCell
    val borderColor = style.tableBorderColor

    Row(
        modifier = Modifier
            .background(backgroundColor)
            .drawBehind {
                // Draw bottom border for each row
                drawLine(
                    color = borderColor,
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = style.tableBorderWidth.toPx()
                )
            }
    ) {
        var cell = row.firstChild
        while (cell != null) {
            if (cell is TableCell) {
                TableCellRenderer(
                    cell = cell,
                    style = style,
                    textStyle = textStyle,
                    onLinkClick = onLinkClick
                )
            }
            cell = cell.next
        }
    }
}

/**
 * Renders a single table cell.
 */
@Composable
private fun TableCellRenderer(
    cell: TableCell,
    style: RichTextStyle,
    textStyle: androidx.compose.ui.text.TextStyle,
    onLinkClick: ((String) -> Unit)?,
) {
    val borderColor = style.tableBorderColor

    Box(
        modifier = Modifier
            .defaultMinSize(minWidth = 80.dp)
            .drawBehind {
                // Draw right border for each cell
                drawLine(
                    color = borderColor,
                    start = Offset(size.width, 0f),
                    end = Offset(size.width, size.height),
                    strokeWidth = style.tableBorderWidth.toPx()
                )
            }
            .padding(style.tableCellPadding),
        contentAlignment = Alignment.CenterStart
    ) {
        val (annotatedString, inlineContent) = buildInlineContent(
            node = cell.firstChild,
            style = style,
            baseStyle = textStyle.toSpanStyle()
        )

        ClickableTextWithInlineContent(
            text = annotatedString,
            inlineContent = inlineContent,
            style = textStyle,
            onLinkClick = onLinkClick,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Helper Composables
// ──────────────────────────────────────────────────────────────────────────────

/**
 * A ClickableText that also supports InlineTextContent (for inline math).
 * Handles link clicks by checking for URL annotations.
 */
@Composable
private fun ClickableTextWithInlineContent(
    text: AnnotatedString,
    inlineContent: Map<String, InlineTextContent>,
    style: androidx.compose.ui.text.TextStyle,
    onLinkClick: ((String) -> Unit)?,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    val uriHandler = LocalUriHandler.current

    if (inlineContent.isEmpty()) {
        // No inline content, use standard ClickableText
        ClickableText(
            text = text,
            style = style,
            maxLines = maxLines,
            overflow = overflow,
            onClick = { offset ->
                text.getStringAnnotations(tag = "URL", start = offset, end = offset)
                    .firstOrNull()?.let { annotation ->
                        if (onLinkClick != null) {
                            onLinkClick(annotation.item)
                        } else {
                            // Default: open URL in browser
                            try {
                                uriHandler.openUri(annotation.item)
                            } catch (_: Exception) {
                                // Ignore invalid URLs
                            }
                        }
                    }
            }
        )
    } else {
        // Has inline content, use BasicText with inlineContent
        // Note: BasicText doesn't support click handling directly,
        // so we use a workaround with ClickableText wrapped around
        androidx.compose.foundation.text.BasicText(
            text = text,
            style = style,
            inlineContent = inlineContent,
            maxLines = maxLines,
            overflow = overflow,
        )
        // TODO: Add click handling for links when inline content is present
        // This would require a more complex implementation with pointer input
    }
}

