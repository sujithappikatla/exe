package com.ska.richtext.richtext

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier

/**
 * RichText - A Jetpack Compose component for rendering Markdown with LaTeX support.
 *
 * Features:
 * - Full CommonMark Markdown support (headings, paragraphs, bold, italic, code, etc.)
 * - GFM extensions (tables, strikethrough)
 * - LaTeX math rendering (inline $...$ and block $$...$$)
 * - Customizable styling via RichTextStyle
 * - Link click handling
 *
 * Usage:
 * ```kotlin
 * RichText.Content(
 *     markdown = "# Hello\nThis is **bold** and $E=mc^2$",
 *     modifier = Modifier.fillMaxWidth(),
 *     style = RichTextDefaults.style(),
 *     onLinkClick = { url -> /* handle link */ }
 * )
 * ```
 *
 * To customize styling:
 * ```kotlin
 * RichText.Content(
 *     markdown = "...",
 *     style = RichTextDefaults.style(
 *         linkColor = Color.Blue,
 *         h1 = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold),
 *         blockSpacing = 16.dp
 *     )
 * )
 * ```
 */
object RichText {

    /**
     * Renders Markdown content with LaTeX support.
     *
     * This is the main entry point for the RichText library.
     * Pass a string containing Markdown (with optional LaTeX) and it will be
     * rendered as styled Compose UI.
     *
     * @param markdown The Markdown string to render. Can contain:
     *   - Standard Markdown: headings, paragraphs, bold, italic, code, lists, etc.
     *   - GFM extensions: tables (|col|col|), strikethrough (~~text~~)
     *   - Inline LaTeX: $E=mc^2$ (single dollar signs)
     *   - Block LaTeX: $$\int_0^1 x^2 dx$$ (double dollar signs, centered)
     *   - Escaped dollars: \$ renders as literal $
     *
     * @param modifier Modifier to apply to the root container.
     *   Use for sizing, padding, scrolling, etc.
     *
     * @param style Styling configuration for all elements.
     *   Use RichTextDefaults.style() for Material-themed defaults,
     *   or customize individual properties as needed.
     *
     * @param onLinkClick Optional callback when a link is clicked.
     *   If null, links will open in the default browser.
     *   Receives the URL as a parameter.
     */
    @Composable
    fun Content(
        markdown: String,
        modifier: Modifier = Modifier,
        style: RichTextStyle = RichTextDefaults.style(),
        onLinkClick: ((String) -> Unit)? = null,
    ) {
        // Parse the markdown into a CommonMark AST
        // Memoize parsing to avoid re-parsing on recomposition
        val document = remember(markdown) {
            parseMarkdown(markdown)
        }

        // Render the AST as Compose UI
        MarkdownContent(
            document = document,
            style = style,
            onLinkClick = onLinkClick,
            modifier = modifier,
        )
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Convenience Extensions
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Extension function for easy RichText rendering.
 * Alternative to calling RichText.Content() directly.
 *
 * Usage:
 * ```kotlin
 * "# Hello World".RichText()
 * ```
 */
@Composable
fun String.RichText(
    modifier: Modifier = Modifier,
    style: RichTextStyle = RichTextDefaults.style(),
    onLinkClick: ((String) -> Unit)? = null,
) {
    RichText.Content(
        markdown = this,
        modifier = modifier,
        style = style,
        onLinkClick = onLinkClick,
    )
}

