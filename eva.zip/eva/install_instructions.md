## Run below Commands to setup 
```
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```


### Before running Applications, Make sure to Create and Setup Google Cloud Account ADC(Application Default Credentials)





