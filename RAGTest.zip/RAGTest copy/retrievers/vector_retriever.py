"""Vector similarity retrieval using ChromaDB"""

import os
from typing import List, Dict, Tuple
from langchain_chroma import Chroma
from langchain_core.documents import Document

from interfaces.base_embedding import BaseEmbedding


class VectorRetriever:
    """ChromaDB vector similarity retriever
    
    Stores document chunks as embeddings in ChromaDB and retrieves
    using vector similarity search.
    """
    
    def __init__(self, collection_name: str, embedding_model: BaseEmbedding, persist_directory: str):
        """Initialize Vector Retriever
        
        Args:
            collection_name: Unique name for this ChromaDB collection
            embedding_model: Embedding model instance
            persist_directory: Base directory for ChromaDB storage
        """
        self.collection_name = collection_name
        self.embedding_model = embedding_model
        self.persist_directory = os.path.join(persist_directory, collection_name)
        
        # Ensure directory exists
        os.makedirs(self.persist_directory, exist_ok=True)
        
        # Initialize ChromaDB
        self.vectorstore = Chroma(
            collection_name=collection_name,
            embedding_function=embedding_model,
            persist_directory=self.persist_directory
        )
    
    def add_documents(self, chunks: List[Dict]):
        """Add document chunks to vector store
        
        Args:
            chunks: List of chunk dictionaries with text and metadata
        """
        print(f"    Embedding and storing {len(chunks)} chunks in ChromaDB...")
        
        # Convert chunks to LangChain documents
        documents = []
        for chunk in chunks:
            doc = Document(
                page_content=chunk['text'],
                metadata={
                    'chunk_id': chunk['chunk_id'],
                    'source_file': chunk['source_file'],
                    'chunk_index': chunk['chunk_index'],
                }
            )
            documents.append(doc)
        
        # Add to vector store (batch processing)
        batch_size = 100
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i+batch_size]
            self.vectorstore.add_documents(batch)
            print(f"      Processed {min(i+batch_size, len(documents))}/{len(documents)} chunks...", end='\r')
        
        print(f"\n    Stored {len(chunks)} chunks in {self.persist_directory}")
    
    def retrieve(self, query: str, k: int) -> List[Tuple[str, float, Dict]]:
        """Retrieve top-k most similar chunks
        
        Args:
            query: Query text
            k: Number of chunks to retrieve
            
        Returns:
            List of (chunk_text, similarity_score, metadata) tuples
        """
        try:
            # Use similarity_search_with_score for both content and scores
            results = self.vectorstore.similarity_search_with_score(query, k=k)
            
            # Format results
            formatted_results = []
            for doc, score in results:
                formatted_results.append((
                    doc.page_content,
                    float(score),
                    doc.metadata
                ))
            
            return formatted_results
        
        except Exception as e:
            print(f"Error retrieving from vector store: {e}")
            return []

