"""Hybrid retrieval combining vector and BM25"""

from typing import List, Tuple, Dict
from retrievers.vector_retriever import VectorRetriever
from retrievers.bm25_retriever import BM25Retriever


class HybridRetriever:
    """Hybrid retriever combining vector similarity and BM25
    
    Fetches results from both retrievers, normalizes scores, and
    combines them with configurable weights.
    """
    
    def __init__(
        self, 
        vector_retriever: VectorRetriever, 
        bm25_retriever: BM25Retriever,
        vector_weight: float = 0.7,
        bm25_weight: float = 0.3
    ):
        """Initialize Hybrid Retriever
        
        Args:
            vector_retriever: Vector retriever instance
            bm25_retriever: BM25 retriever instance
            vector_weight: Weight for vector scores (default: 0.7)
            bm25_weight: Weight for BM25 scores (default: 0.3)
        """
        self.vector_retriever = vector_retriever
        self.bm25_retriever = bm25_retriever
        self.vector_weight = vector_weight
        self.bm25_weight = bm25_weight
    
    def _normalize_scores(self, scores: List[float], is_distance: bool = False) -> List[float]:
        """Normalize scores to [0, 1] range
        
        Args:
            scores: List of scores to normalize
            is_distance: If True, treats scores as distances (lower=better) and inverts them
                        If False, treats scores as similarities (higher=better)
            
        Returns:
            Normalized scores where higher is always better
        """
        if not scores or len(scores) == 0:
            return []
        
        min_score = min(scores)
        max_score = max(scores)
        
        # Avoid division by zero
        if max_score == min_score:
            return [1.0] * len(scores)
        
        # Normalize to [0, 1]
        normalized = [(s - min_score) / (max_score - min_score) for s in scores]
        
        # If these are distance scores (lower=better), invert them
        # so that higher normalized scores = better matches
        if is_distance:
            normalized = [1.0 - s for s in normalized]
        
        return normalized
    
    def retrieve(self, query: str, k: int) -> List[Tuple[str, float, Dict]]:
        """Retrieve using hybrid approach
        
        Fetches top-2k results from both retrievers, combines scores,
        and returns top-k based on combined score.
        
        Args:
            query: Query text
            k: Number of final results to return
            
        Returns:
            List of (chunk_text, combined_score, metadata) tuples
        """
        # Fetch more results than needed for better fusion
        fetch_k = k * 2
        
        # Get results from both retrievers
        vector_results = self.vector_retriever.retrieve(query, k=fetch_k)
        bm25_results = self.bm25_retriever.retrieve(query, k=fetch_k)
        
        # Normalize scores
        # ChromaDB returns distances (lower=better), so we invert them
        vector_scores_norm = self._normalize_scores([r[1] for r in vector_results], is_distance=True)
        # BM25 returns relevance scores (higher=better), no inversion needed
        bm25_scores_norm = self._normalize_scores([r[1] for r in bm25_results], is_distance=False)
        
        # Build score dictionary by chunk_id
        combined_scores = {}
        
        # Add vector scores
        for i, (text, score, metadata) in enumerate(vector_results):
            chunk_id = metadata['chunk_id']
            combined_scores[chunk_id] = {
                'text': text,
                'metadata': metadata,
                'score': vector_scores_norm[i] * self.vector_weight
            }
        
        # Add BM25 scores
        for i, (text, score, metadata) in enumerate(bm25_results):
            chunk_id = metadata['chunk_id']
            if chunk_id in combined_scores:
                # Add to existing score
                combined_scores[chunk_id]['score'] += bm25_scores_norm[i] * self.bm25_weight
            else:
                # New chunk from BM25
                combined_scores[chunk_id] = {
                    'text': text,
                    'metadata': metadata,
                    'score': bm25_scores_norm[i] * self.bm25_weight
                }
        
        # Sort by combined score and return top-k
        sorted_results = sorted(
            combined_scores.items(),
            key=lambda x: x[1]['score'],
            reverse=True
        )[:k]
        
        # Format results
        final_results = [
            (data['text'], data['score'], data['metadata'])
            for chunk_id, data in sorted_results
        ]
        
        return final_results

