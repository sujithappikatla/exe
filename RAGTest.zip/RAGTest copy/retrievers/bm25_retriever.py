"""BM25 keyword-based retrieval"""

import os
import pickle
from typing import List, Dict, Tuple
from rank_bm25 import BM25Okapi


class BM25Retriever:
    """BM25 keyword-based retriever
    
    Uses BM25 algorithm for keyword-based retrieval.
    Good for exact keyword matches and traditional search.
    """
    
    def __init__(self, strategy_name: str, persist_directory: str):
        """Initialize BM25 Retriever
        
        Args:
            strategy_name: Chunking strategy name (for file naming)
            persist_directory: Directory to save BM25 index
        """
        self.strategy_name = strategy_name
        self.persist_directory = persist_directory
        self.persist_path = os.path.join(persist_directory, f"{strategy_name}_bm25.pkl")
        
        # Ensure directory exists
        os.makedirs(persist_directory, exist_ok=True)
        
        self.bm25 = None
        self.chunks = []
        self.tokenized_corpus = []
    
    def add_documents(self, chunks: List[Dict]):
        """Build BM25 index from document chunks
        
        Args:
            chunks: List of chunk dictionaries with text and metadata
        """
        print(f"    Building BM25 index for {len(chunks)} chunks...")
        
        self.chunks = chunks
        
        # Tokenize corpus (simple word splitting)
        self.tokenized_corpus = [
            chunk['text'].lower().split()
            for chunk in chunks
        ]
        
        # Build BM25 index
        self.bm25 = BM25Okapi(self.tokenized_corpus)
        
        # Persist index
        with open(self.persist_path, 'wb') as f:
            pickle.dump({
                'bm25': self.bm25,
                'chunks': self.chunks,
                'tokenized_corpus': self.tokenized_corpus
            }, f)
        
        print(f"    BM25 index saved to {self.persist_path}")
    
    def load_index(self):
        """Load existing BM25 index from disk"""
        if os.path.exists(self.persist_path):
            with open(self.persist_path, 'rb') as f:
                data = pickle.load(f)
                self.bm25 = data['bm25']
                self.chunks = data['chunks']
                self.tokenized_corpus = data['tokenized_corpus']
            print(f"    Loaded BM25 index from {self.persist_path}")
            return True
        return False
    
    def retrieve(self, query: str, k: int) -> List[Tuple[str, float, Dict]]:
        """Retrieve top-k chunks using BM25
        
        Args:
            query: Query text
            k: Number of chunks to retrieve
            
        Returns:
            List of (chunk_text, bm25_score, metadata) tuples
        """
        if self.bm25 is None:
            raise ValueError("BM25 index not initialized. Call add_documents() first.")
        
        try:
            # Tokenize query
            tokenized_query = query.lower().split()
            
            # Get BM25 scores
            scores = self.bm25.get_scores(tokenized_query)
            
            # Get top-k indices
            top_k_indices = sorted(
                range(len(scores)), 
                key=lambda i: scores[i], 
                reverse=True
            )[:k]
            
            # Format results
            results = []
            for idx in top_k_indices:
                chunk = self.chunks[idx]
                results.append((
                    chunk['text'],
                    float(scores[idx]),
                    {
                        'chunk_id': chunk['chunk_id'],
                        'source_file': chunk['source_file'],
                        'chunk_index': chunk['chunk_index'],
                    }
                ))
            
            return results
        
        except Exception as e:
            print(f"Error retrieving with BM25: {e}")
            return []

