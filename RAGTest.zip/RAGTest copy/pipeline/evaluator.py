"""Evaluation pipeline for RAG retrieval"""

from typing import List, Dict, Tuple
from utils.metrics import (
    calculate_mrr,
    calculate_hit_rate_at_k,
    calculate_average_rank,
    calculate_ndcg_at_k
)


def evaluate_single_question(
    question: Dict,
    ground_truth_chunks: List[str],
    retrieved_results: List[Tuple[str, float, Dict]],
    k_values: List[int]
) -> Dict:
    """Evaluate retrieval for a single question
    
    Args:
        question: Question dictionary
        ground_truth_chunks: List of relevant chunk IDs
        retrieved_results: List of (text, score, metadata) tuples
        k_values: List of K values for evaluation
        
    Returns:
        Dictionary with detailed evaluation results
    """
    # Extract chunk IDs from retrieved results
    retrieved_chunk_ids = [meta['chunk_id'] for _, _, meta in retrieved_results]
    
    # Calculate metrics
    reciprocal_rank = calculate_mrr(retrieved_chunk_ids, ground_truth_chunks)
    rank_of_first = calculate_average_rank(retrieved_chunk_ids, ground_truth_chunks)
    
    metrics = {
        'reciprocal_rank': reciprocal_rank,
        'rank_of_first_relevant': rank_of_first,
    }
    
    # Calculate Hit Rate and NDCG for each K
    for k in k_values:
        metrics[f'hit@{k}'] = calculate_hit_rate_at_k(retrieved_chunk_ids, ground_truth_chunks, k)
        metrics[f'ndcg@{k}'] = calculate_ndcg_at_k(retrieved_chunk_ids, ground_truth_chunks, k)
    
    # Build detailed retrieved chunks info
    retrieved_chunks_detail = []
    for rank, (text, score, meta) in enumerate(retrieved_results, start=1):
        chunk_id = meta['chunk_id']
        retrieved_chunks_detail.append({
            'rank': rank,
            'chunk_id': chunk_id,
            'chunk_text': text[:200] + '...' if len(text) > 200 else text,  # Truncate for storage
            'similarity_score': float(score),
            'is_relevant': chunk_id in ground_truth_chunks
        })
    
    return {
        'question_id': question['question_id'],
        'question': question['question'],
        'ground_truth_chunks': ground_truth_chunks,
        'retrieved_chunks': retrieved_chunks_detail,
        'metrics': metrics
    }


def evaluate_combination(
    qa_dataset: List[Dict],
    ground_truth_mapping: Dict[str, List[str]],
    retriever,
    combo: Dict,
    k_values: List[int]
) -> List[Dict]:
    """Evaluate a complete combination (chunking + embedding + retrieval)
    
    Args:
        qa_dataset: List of QA pairs
        ground_truth_mapping: Mapping of question_id to relevant chunk_ids
        retriever: Retriever instance (Vector, BM25, or Hybrid)
        combo: Combination configuration dictionary
        k_values: List of K values for evaluation
        
    Returns:
        List of detailed per-question evaluation results
    """
    print(f"\n  Evaluating {len(qa_dataset)} questions...")
    
    detailed_results = []
    max_k = max(k_values)
    
    for i, qa in enumerate(qa_dataset):
        if (i + 1) % 10 == 0:
            print(f"    Progress: {i+1}/{len(qa_dataset)} questions...", end='\r')
        
        question_id = qa['question_id']
        question_text = qa['question']
        ground_truth_chunks = ground_truth_mapping.get(question_id, [])
        
        # Skip if no ground truth for this chunking strategy
        if not ground_truth_chunks:
            continue
        
        try:
            # Retrieve top-K chunks
            retrieved_results = retriever.retrieve(question_text, k=max_k)
            
            # Evaluate
            result = evaluate_single_question(
                qa,
                ground_truth_chunks,
                retrieved_results,
                k_values
            )
            
            detailed_results.append(result)
        
        except Exception as e:
            print(f"\n    Warning: Error evaluating question {question_id}: {e}")
            continue
    
    print(f"\n  Completed evaluation: {len(detailed_results)} questions evaluated")
    
    return detailed_results

