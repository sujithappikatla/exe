"""Document chunking strategies"""

from typing import List, Dict
from utils.text_processing import chunk_text_by_tokens


def chunk_document(text: str, strategy: Dict, source_file: str = "") -> List[Dict]:
    """Chunk a single document using specified strategy
    
    Args:
        text: Document text to chunk
        strategy: Chunking strategy configuration
        source_file: Source filename for metadata
        
    Returns:
        List of chunk dictionaries with metadata
    """
    chunk_size = strategy.get('chunk_size', 512)
    chunk_overlap = strategy.get('chunk_overlap', 100)
    
    # Chunk text by approximate tokens
    raw_chunks = chunk_text_by_tokens(text, chunk_size, chunk_overlap)
    
    # Add metadata
    chunks = []
    for i, chunk in enumerate(raw_chunks):
        chunk_id = f"{source_file}_chunk_{i}"
        chunks.append({
            'chunk_id': chunk_id,
            'text': chunk['text'],
            'source_file': source_file,
            'chunk_index': i,
            'char_start': chunk['char_start'],
            'char_end': chunk['char_end'],
            'strategy': strategy['name']
        })
    
    return chunks


def chunk_documents(documents: List[Dict], strategy: Dict) -> List[Dict]:
    """Chunk multiple documents using specified strategy
    
    Args:
        documents: List of document dictionaries with 'filename' and 'content'
        strategy: Chunking strategy configuration
        
    Returns:
        List of all chunks across all documents
    """
    all_chunks = []
    
    for doc in documents:
        filename = doc['filename']
        content = doc['content']
        
        chunks = chunk_document(content, strategy, source_file=filename)
        all_chunks.extend(chunks)
    
    print(f"  Chunked {len(documents)} documents into {len(all_chunks)} chunks using {strategy['name']}")
    
    return all_chunks

