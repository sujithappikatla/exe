"""Map ground truth answers to chunks"""

from typing import List, Dict


def find_overlapping_chunks(answer_text: str, chunks: List[Dict], threshold: float = 0.5) -> List[str]:
    """Find chunks that contain significant overlap with answer text
    
    Args:
        answer_text: The ground truth answer text
        chunks: List of chunk dictionaries
        threshold: Minimum overlap ratio to consider a match (0.0 to 1.0)
        
    Returns:
        List of chunk IDs that contain the answer
    """
    matching_chunks = []
    answer_lower = answer_text.lower().strip()
    
    for chunk in chunks:
        chunk_text = chunk['text'].lower().strip()
        
        # Check if answer text is substantially contained in chunk
        # or if chunk is substantially contained in answer
        if answer_lower in chunk_text:
            matching_chunks.append(chunk['chunk_id'])
        elif chunk_text in answer_lower and len(chunk_text) > 50:
            # Chunk is contained in answer (for cases where chunking is larger)
            matching_chunks.append(chunk['chunk_id'])
        elif len(answer_lower) > 100 and len(chunk_text) > 100:
            # For longer texts, check character-level overlap
            overlap = sum(1 for a, b in zip(answer_lower, chunk_text) if a == b)
            overlap_ratio = overlap / min(len(answer_lower), len(chunk_text))
            if overlap_ratio >= threshold:
                matching_chunks.append(chunk['chunk_id'])
    
    return matching_chunks


def map_ground_truth_chunks(qa_dataset: List[Dict], chunks: List[Dict]) -> Dict[str, List[str]]:
    """Map each question to its relevant chunks
    
    For each question in the QA dataset, find which chunks in the current
    chunking strategy contain the answer text.
    
    Args:
        qa_dataset: List of QA pair dictionaries
        chunks: List of chunk dictionaries (from a specific chunking strategy)
        
    Returns:
        Dictionary mapping question_id to list of relevant chunk_ids
    """
    ground_truth_mapping = {}
    
    for qa in qa_dataset:
        question_id = qa['question_id']
        answer_text = qa['answer_text']
        
        # Find chunks that contain this answer
        relevant_chunks = find_overlapping_chunks(answer_text, chunks)
        
        ground_truth_mapping[question_id] = relevant_chunks
    
    # Count how many questions have ground truth in this chunking
    questions_with_gt = sum(1 for chunks in ground_truth_mapping.values() if chunks)
    print(f"  Ground truth found for {questions_with_gt}/{len(qa_dataset)} questions")
    
    return ground_truth_mapping

