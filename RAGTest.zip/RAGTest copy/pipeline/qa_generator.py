"""Question-Answer pair generation from documents"""

import json
import gc
import random
from typing import List, Dict
from interfaces.base_llm import BaseLLM
from pipeline.chunker import chunk_documents


QA_GENERATION_PROMPT = """You are a helpful assistant that generates high-quality questions from text.

Given the following text chunk, generate {num_questions} specific questions that can be answered using ONLY the information in this chunk.

Text Chunk:
\"\"\"
{chunk_text}
\"\"\"

Requirements:
1. Questions should require specific information from this chunk to answer
2. Avoid generic questions that could apply to any text
3. Vary question types (factual, conceptual, specific details)
4. Questions should be clear and unambiguous
5. Each question should have a definite answer in the chunk

Return your response as a JSON array with this exact format:
[
  {{"question": "Your first question here?", "difficulty": "easy"}},
  {{"question": "Your second question here?", "difficulty": "medium"}}
]

Only return the JSON array, nothing else."""


def generate_questions_for_chunk(chunk: Dict, llm: BaseLLM, num_questions: int = 2) -> List[Dict]:
    """Generate questions for a single chunk
    
    Args:
        chunk: Chunk dictionary with text and metadata
        llm: LLM model for question generation
        num_questions: Number of questions to generate
        
    Returns:
        List of question dictionaries
    """
    # Limit chunk text to 1000 chars to reduce memory usage
    chunk_text = chunk['text'][:1000] if len(chunk['text']) > 1000 else chunk['text']
    
    prompt = QA_GENERATION_PROMPT.format(
        num_questions=num_questions,
        chunk_text=chunk_text
    )
    
    try:
        questions = llm.generate_structured(prompt)
        
        # Ensure it's a list
        if isinstance(questions, dict):
            questions = [questions]
        
        # Add metadata to each question
        for q in questions:
            q['answer_text'] = chunk['text']
            q['source_document'] = chunk['source_file']
            q['char_start'] = chunk['char_start']
            q['char_end'] = chunk['char_end']
        
        return questions
    
    except Exception as e:
        print(f"  Warning: Failed to generate questions for chunk: {e}")
        return []


def sample_chunks_randomly(chunks: List[Dict], sample_size: int, seed: int = None) -> List[Dict]:
    """Randomly sample chunks without replacement
    
    Args:
        chunks: All available chunks
        sample_size: Number of chunks to sample
        seed: Random seed for reproducibility (None for random)
        
    Returns:
        Sampled chunks
    """
    # Set random seed if provided for reproducibility
    if seed is not None:
        random.seed(seed)
    
    # Sample min(sample_size, len(chunks)) to avoid errors
    actual_sample_size = min(sample_size, len(chunks))
    
    # Random sample without replacement
    sampled = random.sample(chunks, actual_sample_size)
    
    return sampled


def filter_quality_questions(questions: List[Dict]) -> List[Dict]:
    """Filter out low-quality questions
    
    Args:
        questions: List of question dictionaries
        
    Returns:
        Filtered list of questions
    """
    filtered = []
    
    for q in questions:
        question_text = q.get('question', '')
        
        # Basic quality checks
        if len(question_text.split()) < 4:
            continue  # Too short
        
        if not question_text.strip().endswith('?'):
            continue  # Not a proper question
        
        # Check for overly generic questions
        generic_phrases = ['what is this about', 'summarize', 'main idea']
        if any(phrase in question_text.lower() for phrase in generic_phrases):
            continue
        
        filtered.append(q)
    
    return filtered


def generate_qa_dataset(documents: List[Dict], llm: BaseLLM, config: Dict) -> List[Dict]:
    """Generate QA dataset from documents
    
    Args:
        documents: List of document dictionaries
        llm: LLM model for question generation
        config: QA generation configuration
        
    Returns:
        List of QA pair dictionaries
    """
    print("\n" + "="*60)
    print("GENERATING QA DATASET")
    print("="*60)
    
    # Create baseline chunking for QA generation
    baseline_strategy = {
        'name': 'baseline',
        'chunk_size': config['baseline_chunk_size'],
        'chunk_overlap': config['baseline_chunk_overlap']
    }
    
    print(f"Creating baseline chunks (size: {config['baseline_chunk_size']}, overlap: {config['baseline_chunk_overlap']})...")
    baseline_chunks = chunk_documents(documents, baseline_strategy)
    
    # Determine which chunks to process based on sampling mode
    sampling_mode = config.get('sampling_mode', 'all')
    
    if sampling_mode == 'random':
        sample_size = config.get('random_chunk_sample_size', 10)
        seed = config.get('random_seed', None)
        chunks_to_process = sample_chunks_randomly(baseline_chunks, sample_size, seed)
        print(f"  Randomly sampled {len(chunks_to_process)}/{len(baseline_chunks)} chunks (seed={seed})")
    else:
        chunks_to_process = baseline_chunks
        print(f"  Processing all {len(baseline_chunks)} chunks")
    
    # Generate questions for selected chunks
    print(f"Generating {config['questions_per_chunk']} questions per chunk...")
    all_questions = []
    processed_pairs = set()  # Track (chunk_id, question_text) to avoid duplicates
    
    for i, chunk in enumerate(chunks_to_process):
        print(f"  Processing chunk {i+1}/{len(chunks_to_process)}...")
        
        try:
            questions = generate_questions_for_chunk(
                chunk, 
                llm, 
                num_questions=config['questions_per_chunk']
            )
            
            # Filter out duplicates
            new_questions = 0
            for q in questions:
                pair_key = (chunk['chunk_id'], q['question'].lower().strip())
                if pair_key not in processed_pairs:
                    all_questions.append(q)
                    processed_pairs.add(pair_key)
                    new_questions += 1
            
            print(f"    Generated {new_questions} new questions (total: {len(all_questions)})")
            
            # Explicit garbage collection to free memory
            if i % 5 == 0:  # Every 5 chunks
                gc.collect()
                
        except Exception as e:
            print(f"    Error generating questions for chunk {i+1}: {e}")
            import traceback
            traceback.print_exc()
            continue
        
        # Check if we've hit the limit
        if config['total_questions_limit'] and len(all_questions) >= config['total_questions_limit']:
            print(f"  Reached question limit of {config['total_questions_limit']}")
            all_questions = all_questions[:config['total_questions_limit']]
            break
    
    print(f"\n  Generated {len(all_questions)} questions")
    
    # Filter quality
    print("  Applying quality filters...")
    filtered_questions = filter_quality_questions(all_questions)
    print(f"  {len(filtered_questions)} questions passed quality checks")
    
    # Add unique IDs
    qa_dataset = []
    for i, q in enumerate(filtered_questions):
        q['question_id'] = f"q_{i:04d}"
        qa_dataset.append(q)
    
    return qa_dataset

