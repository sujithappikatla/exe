"""
RAG Evaluation Framework - Main Orchestrator

This is the main entry point for the RAG evaluation pipeline.
Run with: python app.py
"""

import os
import itertools
from typing import List, Dict

# Import configuration
from config import (
    K_VALUES,
    QA_CONFIG,
    OLLAMA_CONFIG,
    CHUNKING_STRATEGIES,
    RETRIEVAL_STRATEGIES,
    HYBRID_WEIGHTS,
    PATHS
)

# Import models
from models import OllamaLLMModel, OllamaEmbeddingModel

# Import pipeline components
from pipeline import (
    chunk_documents,
    generate_qa_dataset,
    map_ground_truth_chunks,
    evaluate_combination
)

# Import retrievers
from retrievers import VectorRetriever, BM25Retriever, HybridRetriever

# Import storage
from storage import (
    save_detailed_results,
    save_summary,
    generate_comparison_report,
    save_qa_dataset,
    load_qa_dataset
)

# Import utilities
from utils import load_documents, create_combination_name, aggregate_metrics


def create_combinations() -> List[Dict]:
    """Create all combinations of chunking, embedding, and retrieval strategies
    
    Returns:
        List of combination dictionaries
    """
    combinations = []
    
    for chunking, embedding, retrieval in itertools.product(
        CHUNKING_STRATEGIES,
        OLLAMA_CONFIG['embedding_models'],
        RETRIEVAL_STRATEGIES
    ):
        combo_name = create_combination_name(chunking['name'], embedding, retrieval)
        combinations.append({
            'name': combo_name,
            'chunking': chunking,
            'embedding_model': embedding,
            'retrieval_strategy': retrieval
        })
    
    return combinations


def initialize_retriever(combo: Dict, chunks: List[Dict], embedding_model, bm25_retriever=None):
    """Initialize appropriate retriever based on strategy
    
    Args:
        combo: Combination configuration
        chunks: List of document chunks
        embedding_model: Embedding model instance
        bm25_retriever: Pre-initialized BM25 retriever (for hybrid)
        
    Returns:
        Retriever instance
    """
    retrieval_strategy = combo['retrieval_strategy']
    combo_name = combo['name']
    
    if retrieval_strategy == 'vector':
        retriever = VectorRetriever(
            collection_name=combo_name,
            embedding_model=embedding_model,
            persist_directory=PATHS['chromadb_base']
        )
        retriever.add_documents(chunks)
        return retriever
    
    elif retrieval_strategy == 'bm25':
        if bm25_retriever is None:
            bm25_retriever = BM25Retriever(
                strategy_name=combo['chunking']['name'],
                persist_directory=PATHS['bm25_indices']
            )
            # Check if index exists
            if not bm25_retriever.load_index():
                bm25_retriever.add_documents(chunks)
        return bm25_retriever
    
    elif retrieval_strategy == 'hybrid':
        # Create vector retriever
        vector_retriever = VectorRetriever(
            collection_name=combo_name,
            embedding_model=embedding_model,
            persist_directory=PATHS['chromadb_base']
        )
        vector_retriever.add_documents(chunks)
        
        # Use existing BM25 retriever or create new one
        if bm25_retriever is None:
            bm25_retriever = BM25Retriever(
                strategy_name=combo['chunking']['name'],
                persist_directory=PATHS['bm25_indices']
            )
            if not bm25_retriever.load_index():
                bm25_retriever.add_documents(chunks)
        
        # Create hybrid retriever
        hybrid_retriever = HybridRetriever(
            vector_retriever=vector_retriever,
            bm25_retriever=bm25_retriever,
            vector_weight=HYBRID_WEIGHTS['vector_weight'],
            bm25_weight=HYBRID_WEIGHTS['bm25_weight']
        )
        return hybrid_retriever
    
    else:
        raise ValueError(f"Unknown retrieval strategy: {retrieval_strategy}")


def main():
    """Main execution pipeline"""
    
    print("="*60)
    print("RAG EVALUATION FRAMEWORK")
    print("="*60)
    
    # Create timestamped run directory
    from config import get_run_directory, initialize_paths
    run_dir = get_run_directory()
    initialize_paths(run_dir)
    
    print(f"\n📁 Run Directory: {run_dir}")
    print(f"   All outputs will be saved here.\n")
    
    # ═══════════════════════════════════════════════════════════
    # PHASE 1: ONE-TIME QA GENERATION
    # ═══════════════════════════════════════════════════════════
    
    if os.path.exists(PATHS['qa_dataset']):
        print("\n[PHASE 1] Loading existing QA dataset...")
        qa_dataset = load_qa_dataset(PATHS['qa_dataset'])
        print(f"Loaded {len(qa_dataset)} QA pairs")
    else:
        print("\n[PHASE 1] Generating QA dataset...")
        
        # Load documents
        print(f"Loading documents from: {PATHS['input_documents']}")
        documents = load_documents(PATHS['input_documents'])
        print(f"Loaded {len(documents)} documents")
        
        # Initialize Ollama LLM
        print(f"Initializing Ollama LLM: {OLLAMA_CONFIG['llm_model']}")
        llm = OllamaLLMModel(
            model_name=OLLAMA_CONFIG['llm_model'],
            base_url=OLLAMA_CONFIG['base_url'],
            temperature=OLLAMA_CONFIG['temperature']
        )
        
        # Generate QA dataset
        qa_dataset = generate_qa_dataset(documents, llm, QA_CONFIG)
        
        # Save QA dataset with configuration metadata
        save_qa_dataset(qa_dataset, PATHS['qa_dataset'], config=QA_CONFIG)
    
    # ═══════════════════════════════════════════════════════════
    # PHASE 2: CREATE ALL COMBINATIONS
    # ═══════════════════════════════════════════════════════════
    
    print("\n[PHASE 2] Creating combinations...")
    combinations = create_combinations()
    print(f"Total combinations to evaluate: {len(combinations)}")
    print(f"  - Chunking strategies: {len(CHUNKING_STRATEGIES)}")
    print(f"  - Embedding models: {len(OLLAMA_CONFIG['embedding_models'])}")
    print(f"  - Retrieval strategies: {len(RETRIEVAL_STRATEGIES)}")
    
    # Load documents for chunking
    documents = load_documents(PATHS['input_documents'])
    
    # ═══════════════════════════════════════════════════════════
    # PHASE 3: PROCESS EACH COMBINATION
    # ═══════════════════════════════════════════════════════════
    
    print("\n[PHASE 3] Evaluating all combinations...")
    all_summaries = []
    all_detailed_results = {}  # Store detailed results for Excel generation
    
    # Track BM25 retrievers by chunking strategy (to reuse)
    bm25_retrievers = {}
    
    for idx, combo in enumerate(combinations, 1):
        print(f"\n{'='*60}")
        print(f"Combination {idx}/{len(combinations)}: {combo['name']}")
        print(f"{'='*60}")
        print(f"  Chunking: {combo['chunking']['name']}")
        print(f"  Embedding: {combo['embedding_model']}")
        print(f"  Retrieval: {combo['retrieval_strategy']}")
        
        try:
            # 3.1: Chunk documents
            print(f"\n  Step 1: Chunking documents...")
            chunks = chunk_documents(documents, combo['chunking'])
            
            # 3.2: Map ground truth chunks
            print(f"  Step 2: Mapping ground truth...")
            ground_truth_mapping = map_ground_truth_chunks(qa_dataset, chunks)
            
            # 3.3: Initialize embedding model
            print(f"  Step 3: Initializing embedding model...")
            embedding_model = OllamaEmbeddingModel(
                model_name=combo['embedding_model'],
                base_url=OLLAMA_CONFIG['base_url']
            )
            print(f"    Model: {embedding_model.get_model_name()}")
            print(f"    Dimension: {embedding_model.get_dimension()}")
            
            # 3.4: Initialize retriever
            print(f"  Step 4: Initializing {combo['retrieval_strategy']} retriever...")
            
            # Check if we need BM25 retriever
            chunking_name = combo['chunking']['name']
            if combo['retrieval_strategy'] in ['bm25', 'hybrid']:
                if chunking_name not in bm25_retrievers:
                    bm25_retrievers[chunking_name] = BM25Retriever(
                        strategy_name=chunking_name,
                        persist_directory=PATHS['bm25_indices']
                    )
                    if not bm25_retrievers[chunking_name].load_index():
                        bm25_retrievers[chunking_name].add_documents(chunks)
            
            bm25_retriever = bm25_retrievers.get(chunking_name)
            retriever = initialize_retriever(combo, chunks, embedding_model, bm25_retriever)
            
            # 3.5: Evaluate
            print(f"  Step 5: Running evaluation...")
            detailed_results = evaluate_combination(
                qa_dataset=qa_dataset,
                ground_truth_mapping=ground_truth_mapping,
                retriever=retriever,
                combo=combo,
                k_values=K_VALUES
            )
            
            # 3.6: Store detailed results
            save_detailed_results(detailed_results, combo, PATHS['evaluations'])
            
            # Store for Excel generation
            all_detailed_results[combo['name']] = {
                'detailed': detailed_results,
                'config': combo
            }
            
            # 3.7: Aggregate metrics
            aggregated = aggregate_metrics(detailed_results, K_VALUES)
            
            summary = {
                'combination': combo['name'],
                'metrics': aggregated,
                'configuration': {
                    'chunking': combo['chunking']['name'],
                    'embedding': combo['embedding_model'],
                    'retrieval': combo['retrieval_strategy'],
                    'k_values': K_VALUES
                },
                'total_chunks': len(chunks),
            }
            
            # Display key metrics
            print(f"\n  Results:")
            print(f"    MRR: {aggregated.get('mrr', 0):.4f}")
            print(f"    Hit@5: {aggregated.get('hit_rate@5', 0):.4f}")
            print(f"    Avg Rank: {aggregated.get('average_rank', 0):.2f}")
            
            save_summary(summary, combo, PATHS['evaluations'])
            all_summaries.append(summary)
        
        except Exception as e:
            print(f"\n  ERROR processing combination: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    # ═══════════════════════════════════════════════════════════
    # PHASE 4: GENERATE COMPARISON REPORT
    # ═══════════════════════════════════════════════════════════
    
    print(f"\n[PHASE 4] Generating comparison report...")
    generate_comparison_report(all_summaries, PATHS['evaluations'])
    
    # ═══════════════════════════════════════════════════════════
    # PHASE 5: GENERATE EXCEL REPORT
    # ═══════════════════════════════════════════════════════════
    
    from config import EXCEL_CONFIG
    
    if EXCEL_CONFIG.get('include_excel_report', True):
        print(f"\n[PHASE 5] Generating Excel report...")
        
        try:
            from storage import generate_excel_report
            
            excel_path = os.path.join(PATHS['evaluations'], 'evaluation_report.xlsx')
            generate_excel_report(
                all_summaries=all_summaries,
                all_detailed_results=all_detailed_results,
                output_path=excel_path,
                run_metadata={
                    'run_directory': PATHS['run_directory'],
                    'qa_config': QA_CONFIG,
                    'k_values': K_VALUES,
                },
                max_chunks_display=EXCEL_CONFIG.get('max_retrieved_chunks_display', 10)
            )
        except Exception as e:
            print(f"  ⚠ Excel generation failed: {e}")
            print(f"  (JSON results are still available)")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*60)
    print("EVALUATION COMPLETE!")
    print("="*60)
    print(f"Results saved to: {PATHS['evaluations']}")
    if EXCEL_CONFIG.get('include_excel_report', True):
        print(f"Excel report: {os.path.join(PATHS['evaluations'], 'evaluation_report.xlsx')}")


if __name__ == "__main__":
    main()

