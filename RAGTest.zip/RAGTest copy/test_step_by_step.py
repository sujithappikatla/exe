"""Test step by step with detailed logging"""

import sys
import os

print("=== STEP 1: Basic imports ===")
from utils.text_processing import load_documents
print("✓ Imported load_documents")

print("\n=== STEP 2: Load documents ===")
print(f"Current dir: {os.getcwd()}")
print(f"Documents path exists: {os.path.exists('./documents')}")

try:
    documents = load_documents("./documents")
    print(f"✓ Loaded {len(documents)} documents")
    for doc in documents:
        print(f"  - {doc['filename']}: {len(doc['content'])} chars")
except Exception as e:
    print(f"✗ Error loading documents: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n=== STEP 3: Import chunker ===")
try:
    from pipeline.chunker import chunk_documents
    print("✓ Imported chunk_documents")
except Exception as e:
    print(f"✗ Error importing: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n=== STEP 4: Create strategy ===")
strategy = {
    'name': 'baseline',
    'chunk_size': 500,
    'chunk_overlap': 50
}
print(f"✓ Strategy: {strategy}")

print("\n=== STEP 5: Call chunk_documents ===")
print("About to call chunk_documents...")
sys.stdout.flush()

try:
    chunks = chunk_documents(documents, strategy)
    print(f"✓ Created {len(chunks)} chunks")
except Exception as e:
    print(f"✗ Error chunking: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n=== SUCCESS ===")

