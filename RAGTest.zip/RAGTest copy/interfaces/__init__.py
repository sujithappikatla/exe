"""Abstract interfaces for LLM and Embedding models"""

from interfaces.base_llm import BaseLLM
from interfaces.base_embedding import BaseEmbedding

__all__ = ["BaseLLM", "BaseEmbedding"]

