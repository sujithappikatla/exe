"""Abstract base class for LLM models"""

from abc import ABC, abstractmethod
from typing import Dict


class BaseLLM(ABC):
    """Abstract interface for LLM models
    
    This interface allows easy swapping of different LLM implementations.
    Implement this interface for any LLM provider (Ollama, OpenAI, Anthropic, etc.)
    """
    
    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> str:
        """Generate text from prompt
        
        Args:
            prompt: The input prompt
            **kwargs: Additional model-specific parameters
            
        Returns:
            Generated text response
        """
        pass
    
    @abstractmethod
    def generate_structured(self, prompt: str, schema: Dict, **kwargs) -> Dict:
        """Generate structured output (e.g., JSON)
        
        Args:
            prompt: The input prompt
            schema: Expected output schema/structure
            **kwargs: Additional model-specific parameters
            
        Returns:
            Parsed structured output as dictionary
        """
        pass
    
    @abstractmethod
    def get_model_name(self) -> str:
        """Return model identifier
        
        Returns:
            String identifier for the model
        """
        pass

