"""Abstract base class for Embedding models"""

from abc import ABC, abstractmethod
from typing import List


class BaseEmbedding(ABC):
    """Abstract interface for embedding models
    
    This interface allows easy swapping of different embedding implementations.
    Implement this interface for any embedding provider (Ollama, OpenAI, Cohere, etc.)
    """
    
    @abstractmethod
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple documents
        
        Args:
            texts: List of text strings to embed
            
        Returns:
            List of embedding vectors (each vector is a list of floats)
        """
        pass
    
    @abstractmethod
    def embed_query(self, text: str) -> List[float]:
        """Generate embedding for a single query
        
        Args:
            text: Query text to embed
            
        Returns:
            Embedding vector as list of floats
        """
        pass
    
    @abstractmethod
    def get_model_name(self) -> str:
        """Return model identifier
        
        Returns:
            String identifier for the model
        """
        pass
    
    @abstractmethod
    def get_dimension(self) -> int:
        """Return embedding dimension
        
        Returns:
            Dimensionality of the embedding vectors
        """
        pass

