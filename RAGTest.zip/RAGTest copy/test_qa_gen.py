"""Test QA generation specifically"""

import gc
from models.ollama_llm import OllamaLLMModel
from utils.text_processing import load_documents
from pipeline.qa_generator import generate_qa_dataset

print("Testing QA Generation...")

# Load documents
print("Loading documents...")
documents = load_documents("./documents")
print(f"✓ Loaded {len(documents)} documents")

# Initialize LLM
print("Initializing LLM...")
llm = OllamaLLMModel(
    model_name="qwen2.5-coder:14b",
    base_url="http://localhost:11434"
)
print("✓ LLM initialized")

# Test configuration
test_config = {
    "questions_per_chunk": 1,
    "total_questions_limit": 3,  # Only 3 questions for test
    "baseline_chunk_size": 500,
    "baseline_chunk_overlap": 50,
}

print(f"Generating QA dataset (limit: {test_config['total_questions_limit']} questions)...")

try:
    qa_dataset = generate_qa_dataset(documents, llm, test_config)
    print(f"\n✓ SUCCESS - Generated {len(qa_dataset)} questions!")
    
    # Show first question
    if qa_dataset:
        print(f"\nSample question:")
        print(f"  Q: {qa_dataset[0]['question']}")
        
except Exception as e:
    print(f"\n✗ ERROR: {e}")
    import traceback
    traceback.print_exc()

finally:
    # Cleanup
    gc.collect()

