# RAG Evaluation Metrics Guide

A comprehensive guide to understanding evaluation metrics used in this RAG (Retrieval-Augmented Generation) evaluation framework.

---

## Table of Contents

1. [Introduction](#introduction)
2. [Core Metrics](#core-metrics)
   - [Mean Reciprocal Rank (MRR)](#mean-reciprocal-rank-mrr)
   - [Hit Rate@K](#hit-ratek)
   - [Average Rank](#average-rank)
   - [NDCG@K](#ndcgk-normalized-discounted-cumulative-gain)
3. [When to Use Each Metric](#when-to-use-each-metric)
4. [Interpretation Guidelines](#interpretation-guidelines)
5. [Comparison Table](#comparison-table)

---

## Introduction

RAG systems retrieve relevant document chunks to provide context for generating answers. The quality of retrieval directly impacts the quality of generated answers. This framework evaluates retrieval quality using multiple metrics that capture different aspects of performance.

### What We're Measuring

For each question:
- We have a **ground truth chunk** (the chunk that contains the answer)
- We **retrieve top-K chunks** using embeddings/BM25/hybrid search
- We **measure how well** the retrieval identified the correct chunk

---

## Core Metrics

### Mean Reciprocal Rank (MRR)

**What it measures**: How high the first correct chunk appears in the retrieval results.

**Formula**:
```
For a single question:
  Reciprocal Rank (RR) = 1 / rank_of_first_correct_chunk

For all questions:
  MRR = (1/N) × Σ(RR for each question)
```

**Example**:

```
Question 1: "What year was Python created?"
Retrieved chunks: [ChunkB, ChunkA(correct), ChunkD, ChunkE]
Rank of correct chunk: 2
RR = 1/2 = 0.5

Question 2: "Who invented Python?"
Retrieved chunks: [ChunkC(correct), ChunkF, ChunkG]
Rank of correct chunk: 1
RR = 1/1 = 1.0

Question 3: "What is Python used for?"
Retrieved chunks: [ChunkX, ChunkY, ChunkZ(correct)]
Rank of correct chunk: 3
RR = 1/3 = 0.333

MRR = (0.5 + 1.0 + 0.333) / 3 = 0.611
```

**Interpretation**:
- **1.0** = Perfect! The correct chunk is always at position 1
- **0.5** = On average, the correct chunk is at position 2
- **0.333** = On average, the correct chunk is at position 3
- **0.1** = Poor performance, correct chunk is far down the list
- **0.0** = No correct chunks found

**When to optimize**: When you only use the top result (single-answer systems).

---

### Hit Rate@K

**What it measures**: In what percentage of queries was the correct chunk found in the top-K results?

**Formula**:
```
For a single question:
  Hit@K = 1 if correct chunk in top-K, else 0

For all questions:
  Hit Rate@K = (Number of questions with hits) / (Total questions)
```

**Example**:

```
Evaluating Hit@5 (top-5 results):

Question 1: Correct chunk at position 2 → Hit@5 = 1 ✓
Question 2: Correct chunk at position 7 → Hit@5 = 0 ✗
Question 3: Correct chunk at position 4 → Hit@5 = 1 ✓
Question 4: Correct chunk at position 1 → Hit@5 = 1 ✓

Hit Rate@5 = 3/4 = 0.75 = 75%
```

**Multiple K Values**:
```
Question: "What is machine learning?"
Correct chunk at position 3

Hit@1 = 0  (not in top 1)
Hit@3 = 1  (yes, in top 3)
Hit@5 = 1  (yes, in top 5)
Hit@10 = 1 (yes, in top 10)
```

**Interpretation**:
- **1.0** (100%) = Every query found the correct chunk in top-K
- **0.9** (90%) = 90% of queries successful
- **0.5** (50%) = Half of queries failed to find correct chunk
- **0.0** (0%) = No queries found correct chunks

**When to optimize**: For minimum baseline performance. Users expect to find relevant information.

---

### Average Rank

**What it measures**: On average, at what position is the correct chunk found?

**Formula**:
```
Average Rank = (1/N) × Σ(rank_of_correct_chunk for each question)
```

**Example**:

```
Question 1: Correct chunk at position 1 → Rank = 1
Question 2: Correct chunk at position 3 → Rank = 3
Question 3: Correct chunk at position 2 → Rank = 2
Question 4: Correct chunk at position 1 → Rank = 1

Average Rank = (1 + 3 + 2 + 1) / 4 = 1.75
```

**Interpretation**:
- **1.0** = Perfect! Correct chunk always at position 1
- **1.5** = Excellent, usually at position 1-2
- **3.0** = Decent, typically in top 3
- **10.0** = Poor, far down the list
- **Higher = Worse** (unlike other metrics)

**When to optimize**: For intuitive understanding of retrieval quality. Easy to explain to stakeholders.

---

### NDCG@K (Normalized Discounted Cumulative Gain)

**What it measures**: Ranking quality with position-based discounting. Higher positions are weighted more heavily.

**Formula**:
```
DCG@K = Σ(relevance_i / log₂(position_i + 1)) for i=1 to K

IDCG@K = DCG for ideal ranking (all relevant docs at top)

NDCG@K = DCG@K / IDCG@K
```

**Example**:

```
Retrieved top-5 chunks:
Position 1: ChunkA (relevant=1)   → 1/log₂(2) = 1.000
Position 2: ChunkB (relevant=0)   → 0/log₂(3) = 0.000
Position 3: ChunkC (relevant=1)   → 1/log₂(4) = 0.500
Position 4: ChunkD (relevant=0)   → 0/log₂(5) = 0.000
Position 5: ChunkE (relevant=0)   → 0/log₂(6) = 0.000

DCG = 1.000 + 0 + 0.500 + 0 + 0 = 1.500

Ideal ranking (both relevant at top):
Position 1: Relevant → 1.000
Position 2: Relevant → 0.631

IDCG = 1.631

NDCG@5 = 1.500 / 1.631 = 0.920
```

**Why Log Discount?**
The log₂(position+1) discount means:
- Position 1: discount = 1.000 (no penalty)
- Position 2: discount = 0.631 (37% penalty)
- Position 3: discount = 0.500 (50% penalty)
- Position 4: discount = 0.431 (57% penalty)
- Position 5: discount = 0.387 (61% penalty)

**Interpretation**:
- **1.0** = Perfect ranking (all relevant chunks at top)
- **0.9** = Excellent ranking
- **0.7** = Good ranking
- **0.5** = Mediocre ranking
- **< 0.3** = Poor ranking

**When to optimize**: When position matters significantly (first result much more important than fifth).

---

## When to Use Each Metric

| Metric | Use Case |
|--------|----------|
| **MRR** | Single-answer systems where only the top result matters |
| **Hit Rate@K** | Ensuring minimum baseline performance across all queries |
| **Average Rank** | Explaining performance to non-technical stakeholders |
| **NDCG@K** | Academic benchmarking, when ranking quality is critical |

### Recommended Combination

For most RAG systems, use:
1. **MRR** - Primary metric for overall quality
2. **Hit Rate@5** - Ensure high success rate
3. **Average Rank** - Easy interpretation

Add **NDCG** for research/publication or when optimizing ranking algorithms.

---

## Interpretation Guidelines

### MRR Benchmarks

| MRR Score | Interpretation | Action |
|-----------|----------------|--------|
| 0.9 - 1.0 | Excellent | Production-ready |
| 0.7 - 0.9 | Good | Minor optimization needed |
| 0.5 - 0.7 | Acceptable | Consider improvements |
| 0.3 - 0.5 | Poor | Significant issues, needs work |
| < 0.3 | Very Poor | Major problems with retrieval |

### Hit Rate@5 Benchmarks

| Hit@5 Score | Interpretation | Action |
|-------------|----------------|--------|
| > 0.95 | Excellent | Production-ready |
| 0.85 - 0.95 | Good | Acceptable for most use cases |
| 0.70 - 0.85 | Acceptable | Improvement recommended |
| 0.50 - 0.70 | Poor | Needs significant work |
| < 0.50 | Very Poor | Critical issues |

### Average Rank Benchmarks

| Avg Rank | Interpretation |
|----------|----------------|
| 1.0 - 1.5 | Excellent |
| 1.5 - 2.5 | Good |
| 2.5 - 4.0 | Acceptable |
| 4.0 - 7.0 | Poor |
| > 7.0 | Very Poor |

---

## Comparison Table

| Metric | Range | Higher = Better? | Handles Position? | Easy to Explain? | Best For |
|--------|-------|------------------|-------------------|------------------|----------|
| **MRR** | 0-1 | ✓ Yes | ✓ Yes (first position) | ✓ Yes | Overall quality |
| **Hit Rate@K** | 0-1 | ✓ Yes | ✗ No | ✓✓ Very Easy | Minimum baseline |
| **Average Rank** | 1-∞ | ✗ No (lower better) | ✓ Yes | ✓✓ Very Easy | Stakeholder communication |
| **NDCG@K** | 0-1 | ✓ Yes | ✓✓ Yes (all positions) | ✗ Complex | Academic rigor |

---

## Real-World Examples

### Example 1: E-commerce Product Search

```
Scenario: User searches "wireless bluetooth headphones"

Results:
1. Bluetooth Speaker (irrelevant)
2. Wireless Headphones (correct) ✓
3. Wired Headphones (irrelevant)
4. Phone Case (irrelevant)
5. Bluetooth Mouse (irrelevant)

Metrics:
- MRR = 1/2 = 0.5
- Hit@5 = 1 (found in top 5)
- Average Rank = 2
- NDCG@5 = 0.63 (penalized for wrong item at position 1)

Interpretation: System works but needs improvement. Correct item should be at position 1.
```

### Example 2: Technical Documentation Search

```
Scenario: Developer searches "how to install Python packages"

Results:
1. Installation Guide (correct) ✓
2. Package Management Tutorial (relevant)
3. Python Basics (somewhat relevant)
4. Troubleshooting (relevant)
5. API Reference (irrelevant)

Metrics:
- MRR = 1/1 = 1.0 (perfect)
- Hit@5 = 1
- Average Rank = 1
- NDCG@5 = 1.0 (perfect ranking)

Interpretation: Excellent performance! Ready for production.
```

### Example 3: Legal Document Search

```
Scenario: Lawyer searches for "contract termination clause precedent"

Results:
1. Copyright Law (irrelevant)
2. Employment Law (irrelevant)
3. Contract Law Overview (somewhat relevant)
4. Termination Clause Examples (correct) ✓
5. General Legal Terms (irrelevant)

Metrics:
- MRR = 1/4 = 0.25
- Hit@5 = 1
- Average Rank = 4
- NDCG@5 = 0.43

Interpretation: Poor performance. In legal contexts, precision is critical. System needs significant improvement.
```

---

## Tips for Improving Metrics

### To Improve MRR and Average Rank:
1. Use better embedding models (larger dimensions, domain-specific)
2. Improve chunking strategy (optimal chunk size for your content)
3. Fine-tune chunk overlap
4. Add metadata filtering
5. Use hybrid retrieval (vector + BM25)

### To Improve Hit Rate:
1. Increase K (retrieve more candidates)
2. Use reranking models
3. Ensure comprehensive indexing
4. Check for missing/corrupted data

### To Improve NDCG:
1. Implement learning-to-rank algorithms
2. Use query expansion techniques
3. Add relevance feedback loops
4. Fine-tune similarity thresholds

---

## Conclusion

This framework provides multiple metrics to evaluate RAG retrieval quality from different angles:

- **MRR** tells you if the best result is at the top
- **Hit Rate** ensures you're finding relevant content
- **Average Rank** gives intuitive understanding
- **NDCG** measures overall ranking quality

Use them together to get a comprehensive view of your RAG system's performance and guide optimization efforts.

---

**Last Updated**: 2025-10-21
**Framework Version**: 1.0

