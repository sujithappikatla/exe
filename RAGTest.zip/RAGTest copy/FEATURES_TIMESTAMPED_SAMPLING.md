# New Features: Timestamped Runs & Random Sampling

## Feature 1: Timestamped Output Folders

### Overview
Every run now creates a timestamped folder to keep results organized and prevent overwriting.

### Directory Structure

**Before:**
```
outputs/
├── qa_dataset.json
├── chromadb/
├── bm25_indices/
└── evaluations/
```

**After:**
```
outputs/
├── run_2025-10-21_23-15-30/
│   ├── qa_dataset.json
│   ├── chromadb/
│   ├── bm25_indices/
│   └── evaluations/
├── run_2025-10-22_10-45-12/
│   ├── qa_dataset.json
│   ├── chromadb/
│   ├── bm25_indices/
│   └── evaluations/
└── ...
```

### Usage

No configuration needed! Just run:
```bash
python app.py
```

Output:
```
============================================================
RAG EVALUATION FRAMEWORK
============================================================

📁 Run Directory: ./outputs/run_2025-10-21_23-15-30
   All outputs will be saved here.
```

### Benefits

- ✅ **No overwriting**: Previous results are preserved
- ✅ **Easy comparison**: Compare metrics across different runs
- ✅ **Organized**: Know exactly when each experiment ran
- ✅ **Reproducible**: Keep complete history of experiments

---

## Feature 2: Random Chunk Sampling

### Overview
Control QA dataset size by randomly sampling chunks instead of processing all chunks.

### Configuration

Edit `config.py`:

```python
QA_CONFIG = {
    "questions_per_chunk": 2,
    "total_questions_limit": None,
    
    # Sampling Configuration
    "sampling_mode": "all",          # "all" or "random"
    "random_chunk_sample_size": 10,  # Only used if mode="random"
    "random_seed": 42,               # For reproducibility (None=random)
    
    "baseline_chunk_size": 500,
    "baseline_chunk_overlap": 50,
}
```

### Usage Examples

#### Example 1: Process All Chunks (Default)
```python
QA_CONFIG = {
    "questions_per_chunk": 2,
    "sampling_mode": "all",  # Process all chunks
}
```

**Result**: 16 chunks × 2 questions = 32 questions

#### Example 2: Random Sample for Quick Testing
```python
QA_CONFIG = {
    "questions_per_chunk": 2,
    "sampling_mode": "random",
    "random_chunk_sample_size": 5,  # Only 5 chunks
    "random_seed": 42,
}
```

**Result**: 5 chunks × 2 questions = ~10 questions

#### Example 3: Large Dataset with Sampling
```python
QA_CONFIG = {
    "questions_per_chunk": 3,
    "total_questions_limit": 100,
    "sampling_mode": "random",
    "random_chunk_sample_size": 50,
    "random_seed": 42,
}
```

**Result**: Up to 100 questions from 50 randomly selected chunks

### Output

When using random sampling:
```
Creating baseline chunks (size: 500, overlap: 50)...
  Chunked 4 documents into 16 chunks using baseline
  Randomly sampled 5/16 chunks (seed=42)
Generating 2 questions per chunk...
  Processing chunk 1/5...
    Generated 2 new questions (total: 2)
  ...
```

### QA Dataset Metadata

The saved `qa_dataset.json` includes sampling information:

```json
{
  "metadata": {
    "created_date": "2025-10-21T23:15:30",
    "num_questions": 10,
    "version": "1.0",
    "sampling_mode": "random",
    "random_chunk_sample_size": 5,
    "random_seed": 42
  },
  "qa_pairs": [...]
}
```

### Benefits

- ✅ **Faster iteration**: Test with fewer questions during development
- ✅ **Reproducible**: Same seed = same chunks selected
- ✅ **Flexible**: Easy to switch between full and sampled datasets
- ✅ **No duplicates**: Automatic detection of duplicate questions
- ✅ **Representative**: Random sampling covers diverse content

### Reproducibility

Using the same seed ensures identical chunk selection:

```python
# Run 1 with seed=42
"random_seed": 42
# Selects: chunk_3, chunk_0, chunk_8, chunk_7, chunk_16

# Run 2 with seed=42
"random_seed": 42
# Selects: chunk_3, chunk_0, chunk_8, chunk_7, chunk_16  ✓ Same!

# Run 3 with seed=None (random)
"random_seed": None
# Selects: chunk_1, chunk_15, chunk_4, chunk_11, chunk_9  ✓ Different
```

---

## Combining Both Features

Both features work together seamlessly:

```bash
# Run 1: Full dataset
python app.py
# Creates: outputs/run_2025-10-21_10-00-00/
# Processes: All chunks

# Run 2: Quick test with sampling (change config.py first)
python app.py
# Creates: outputs/run_2025-10-21_10-15-30/
# Processes: Only sampled chunks

# Compare results
ls outputs/
# run_2025-10-21_10-00-00/  ← Full dataset results
# run_2025-10-21_10-15-30/  ← Sampled dataset results
```

---

## Implementation Details

### Files Modified

1. **config.py**
   - Added `get_run_directory()` function
   - Added `initialize_paths()` function
   - Added sampling configuration to `QA_CONFIG`

2. **app.py**
   - Creates timestamped folder at startup
   - Initializes paths dynamically
   - Passes config to `save_qa_dataset()`

3. **pipeline/qa_generator.py**
   - Added `sample_chunks_randomly()` function
   - Modified `generate_qa_dataset()` to support sampling modes
   - Added duplicate detection using `(chunk_id, question)` pairs

4. **storage/result_store.py**
   - Updated `save_qa_dataset()` to accept config parameter
   - Saves sampling metadata in QA dataset JSON

### Duplicate Detection

The system tracks `(chunk_id, question_text)` pairs to prevent duplicates:

```python
processed_pairs = set()

for chunk in chunks_to_process:
    questions = generate_questions_for_chunk(chunk, llm, ...)
    
    for q in questions:
        pair_key = (chunk['chunk_id'], q['question'].lower().strip())
        if pair_key not in processed_pairs:
            all_questions.append(q)
            processed_pairs.add(pair_key)
```

This ensures:
- No duplicate questions from the same chunk
- Case-insensitive comparison
- Whitespace normalized

---

## Migration Guide

### From Old Version

If you have existing results in `outputs/`:

```bash
# Backup old results
mkdir -p outputs/run_archive_old
mv outputs/qa_dataset.json outputs/run_archive_old/
mv outputs/chromadb outputs/run_archive_old/
mv outputs/bm25_indices outputs/run_archive_old/
mv outputs/evaluations outputs/run_archive_old/

# Now run new version
python app.py
```

### Configuration Update

Your existing `config.py` will work as-is! New options have defaults:

```python
# If not specified, defaults are:
"sampling_mode": "all",          # Processes all chunks (old behavior)
"random_chunk_sample_size": 10,  # Only matters if mode="random"
"random_seed": 42,               # Reproducible sampling
```

---

## Troubleshooting

### Issue: "PATHS not initialized"

**Cause**: Importing PATHS before `initialize_paths()` is called.

**Solution**: In `app.py`, paths are initialized at startup:
```python
from config import get_run_directory, initialize_paths
run_dir = get_run_directory()
initialize_paths(run_dir)
```

### Issue: Different chunks each run with same seed

**Cause**: Not setting `random_seed` in config.

**Solution**:
```python
QA_CONFIG = {
    "sampling_mode": "random",
    "random_seed": 42,  # Make sure this is set!
}
```

### Issue: Too many questions generated

**Cause**: Sample size too large or no limit set.

**Solution**:
```python
QA_CONFIG = {
    "random_chunk_sample_size": 5,  # Reduce this
    "total_questions_limit": 20,     # Or set a limit
}
```

---

## Testing

All features have been tested and verified:

✅ Timestamped directories created correctly  
✅ Subdirectories (chromadb, bm25_indices, evaluations) created  
✅ Random sampling works with and without seed  
✅ Same seed produces identical chunk selection  
✅ QA dataset metadata includes sampling information  
✅ Duplicate detection works correctly  
✅ No linting errors  

---

**Version**: 1.1  
**Date**: October 21, 2025  
**Status**: ✅ Production Ready

