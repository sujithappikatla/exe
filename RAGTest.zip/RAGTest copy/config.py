"""
Configuration for RAG Evaluation Framework
"""

import os
from datetime import datetime


def get_run_directory(base_path: str = "./outputs") -> str:
    """Create and return timestamped run directory
    
    Args:
        base_path: Base outputs directory
        
    Returns:
        Path to timestamped run directory
    """
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    run_dir = os.path.join(base_path, f"run_{timestamp}")
    os.makedirs(run_dir, exist_ok=True)
    return run_dir


# K Values for Evaluation (configurable array)
K_VALUES = [1, 3, 5, 10]

# QA Generation Settings
QA_CONFIG = {
    "questions_per_chunk": 2,        # Number of questions to generate per chunk
    "total_questions_limit": None,   # None = no limit, or set a number
    
    # Sampling options
    "sampling_mode": "all",          # "all" or "random"
    "random_chunk_sample_size": 10,  # Only used if sampling_mode="random"
    "random_seed": 42,               # For reproducibility (None for random)
    
    "baseline_chunk_size": 500,      # Token size for baseline chunking (QA generation)
    "baseline_chunk_overlap": 50,    # Overlap for baseline chunking
}

# Ollama Configuration
OLLAMA_CONFIG = {
    "base_url": "http://localhost:11434",
    "llm_model": "qwen2.5-coder:14b",                    # Model for question generation
    "embedding_models": [                        # Embedding models to test
        "nomic-embed-text",
        "mxbai-embed-large",  # Temporarily disabled for testing
        "embeddinggemma"      # Temporarily disabled for testing
    ],
    "temperature": 0.7,
    "timeout": 120,
}

# Chunking Strategies to Test
CHUNKING_STRATEGIES = [
    {
        "name": "small_chunks",
        "chunk_size": 256,
        "chunk_overlap": 50,
    },
    {
        "name": "medium_chunks",
        "chunk_size": 512,
        "chunk_overlap": 100,
    },
    {
        "name": "large_chunks",
        "chunk_size": 1024,
        "chunk_overlap": 200,
    },
]

# Retrieval Strategies
RETRIEVAL_STRATEGIES = ["vector", "bm25", "hybrid"]  # Start with just vector for testing

# Hybrid Retrieval Weights
HYBRID_WEIGHTS = {
    "vector_weight": 0.7,
    "bm25_weight": 0.3,
}

# Evaluation Metrics
METRICS = [
    "mrr",              # Mean Reciprocal Rank
    "hit_rate",         # Hit Rate@K
    "average_rank",     # Average position of correct chunk
    "ndcg",             # Normalized Discounted Cumulative Gain (optional)
]

# Excel Report Settings
EXCEL_CONFIG = {
    "include_excel_report": True,    # Enable/disable Excel generation
    "max_retrieved_chunks_display": 10,  # Show top N chunks in Excel
    "auto_column_width": True,       # Auto-adjust column widths
    "freeze_headers": True,          # Freeze top rows
}

# Storage Paths (dynamically set by app.py based on run directory)
# These are default paths - will be overridden at runtime
PATHS = {
    "input_documents": "./documents",
    "run_directory": None,  # Set at runtime
    "qa_dataset": None,     # Set at runtime
    "chromadb_base": None,  # Set at runtime
    "bm25_indices": None,   # Set at runtime
    "evaluations": None,    # Set at runtime
}


def initialize_paths(run_dir: str):
    """Initialize all paths based on run directory
    
    Args:
        run_dir: Path to the timestamped run directory
    """
    global PATHS
    PATHS["run_directory"] = run_dir
    PATHS["qa_dataset"] = os.path.join(run_dir, "qa_dataset.json")
    PATHS["chromadb_base"] = os.path.join(run_dir, "chromadb")
    PATHS["bm25_indices"] = os.path.join(run_dir, "bm25_indices")
    PATHS["evaluations"] = os.path.join(run_dir, "evaluations")
    
    # Create subdirectories
    os.makedirs(PATHS["chromadb_base"], exist_ok=True)
    os.makedirs(PATHS["bm25_indices"], exist_ok=True)
    os.makedirs(PATHS["evaluations"], exist_ok=True)

