"""Test script for timestamped folders and random sampling"""

import os
import json
from config import get_run_directory, initialize_paths, QA_CONFIG

print("="*60)
print("TESTING NEW FEATURES")
print("="*60)

# Test 1: Timestamped directory creation
print("\n[Test 1] Timestamped Directory Creation")
print("-" * 40)

run_dir_1 = get_run_directory()
print(f"✓ Created run directory: {run_dir_1}")
print(f"  Directory exists: {os.path.exists(run_dir_1)}")

# Initialize paths
initialize_paths(run_dir_1)

from config import PATHS
print(f"✓ Paths initialized:")
print(f"  - QA Dataset: {PATHS['qa_dataset']}")
print(f"  - ChromaDB: {PATHS['chromadb_base']}")
print(f"  - BM25: {PATHS['bm25_indices']}")
print(f"  - Evaluations: {PATHS['evaluations']}")

# Verify subdirectories exist
subdirs_exist = all([
    os.path.exists(PATHS['chromadb_base']),
    os.path.exists(PATHS['bm25_indices']),
    os.path.exists(PATHS['evaluations'])
])
print(f"✓ All subdirectories created: {subdirs_exist}")

# Test 2: Random sampling configuration
print("\n[Test 2] Random Sampling Configuration")
print("-" * 40)

print(f"Current QA_CONFIG:")
print(f"  - sampling_mode: {QA_CONFIG['sampling_mode']}")
print(f"  - random_chunk_sample_size: {QA_CONFIG.get('random_chunk_sample_size', 'N/A')}")
print(f"  - random_seed: {QA_CONFIG.get('random_seed', 'N/A')}")

# Test 3: Test sample_chunks_randomly function
print("\n[Test 3] Random Chunk Sampling Function")
print("-" * 40)

from pipeline.qa_generator import sample_chunks_randomly

# Create dummy chunks
dummy_chunks = [
    {'chunk_id': f'chunk_{i}', 'text': f'text {i}'}
    for i in range(20)
]

# Test with seed for reproducibility
sampled_1 = sample_chunks_randomly(dummy_chunks, sample_size=5, seed=42)
sampled_2 = sample_chunks_randomly(dummy_chunks, sample_size=5, seed=42)

print(f"✓ Sampled {len(sampled_1)} chunks from {len(dummy_chunks)}")
print(f"  Sample 1 IDs: {[c['chunk_id'] for c in sampled_1]}")
print(f"  Sample 2 IDs: {[c['chunk_id'] for c in sampled_2]}")

# Verify reproducibility
reproducible = [c['chunk_id'] for c in sampled_1] == [c['chunk_id'] for c in sampled_2]
print(f"✓ Reproducible with same seed: {reproducible}")

# Test without seed (should be different)
sampled_3 = sample_chunks_randomly(dummy_chunks, sample_size=5, seed=None)
sampled_4 = sample_chunks_randomly(dummy_chunks, sample_size=5, seed=None)
different = [c['chunk_id'] for c in sampled_3] != [c['chunk_id'] for c in sampled_4]
print(f"✓ Different without seed: {different}")

# Test 4: Verify metadata in saved QA dataset
print("\n[Test 4] QA Dataset Metadata")
print("-" * 40)

from storage.result_store import save_qa_dataset

dummy_qa = [
    {'question_id': 'q_001', 'question': 'Test question 1?'},
    {'question_id': 'q_002', 'question': 'Test question 2?'},
]

test_config = {
    'sampling_mode': 'random',
    'random_chunk_sample_size': 5,
    'random_seed': 42
}

test_filepath = os.path.join(run_dir_1, "test_qa.json")
save_qa_dataset(dummy_qa, test_filepath, config=test_config)

# Load and verify
with open(test_filepath, 'r') as f:
    data = json.load(f)

print(f"✓ Saved QA dataset")
print(f"  Metadata:")
for key, value in data['metadata'].items():
    print(f"    - {key}: {value}")

# Verify sampling info is included
has_sampling_info = 'sampling_mode' in data['metadata']
print(f"✓ Sampling info included: {has_sampling_info}")

print("\n" + "="*60)
print("✅ ALL TESTS PASSED!")
print("="*60)

print("\n📌 Summary:")
print("  1. Timestamped directories work correctly")
print("  2. Random sampling is reproducible with seeds")
print("  3. QA dataset metadata includes sampling information")
print("\nReady to run full pipeline!")

