"""Test to verify hybrid retriever fix"""

# Test that score normalization works correctly
def test_score_normalization():
    """Test that distance and similarity scores are normalized correctly"""
    
    from retrievers.hybrid_retriever import HybridRetriever
    
    # Create a dummy hybrid retriever (we only need the normalization method)
    class DummyRetriever:
        pass
    
    hr = HybridRetriever(DummyRetriever(), DummyRetriever())
    
    # Test 1: Distance scores (lower = better, like ChromaDB)
    # Raw distances: [0.1, 0.3, 0.5, 0.7, 0.9]
    # After normalization with inversion:
    # - 0.1 (best) should become 1.0
    # - 0.9 (worst) should become 0.0
    distances = [0.1, 0.3, 0.5, 0.7, 0.9]
    normalized_dist = hr._normalize_scores(distances, is_distance=True)
    
    print("Distance scores (lower=better):")
    print(f"  Raw:        {distances}")
    print(f"  Normalized: {normalized_dist}")
    print(f"  Best score (0.1) → {normalized_dist[0]:.2f} (should be ~1.0)")
    print(f"  Worst score (0.9) → {normalized_dist[4]:.2f} (should be ~0.0)")
    
    assert normalized_dist[0] > normalized_dist[4], "❌ Best distance should have higher normalized score"
    assert abs(normalized_dist[0] - 1.0) < 0.01, "❌ Best distance should normalize to ~1.0"
    assert abs(normalized_dist[4] - 0.0) < 0.01, "❌ Worst distance should normalize to ~0.0"
    print("  ✅ Distance normalization correct!\n")
    
    # Test 2: Relevance scores (higher = better, like BM25)
    # Raw relevances: [10, 30, 50, 70, 90]
    # After normalization without inversion:
    # - 90 (best) should become 1.0
    # - 10 (worst) should become 0.0
    relevances = [10, 30, 50, 70, 90]
    normalized_rel = hr._normalize_scores(relevances, is_distance=False)
    
    print("Relevance scores (higher=better):")
    print(f"  Raw:        {relevances}")
    print(f"  Normalized: {normalized_rel}")
    print(f"  Best score (90) → {normalized_rel[4]:.2f} (should be ~1.0)")
    print(f"  Worst score (10) → {normalized_rel[0]:.2f} (should be ~0.0)")
    
    assert normalized_rel[4] > normalized_rel[0], "❌ Best relevance should have higher normalized score"
    assert abs(normalized_rel[4] - 1.0) < 0.01, "❌ Best relevance should normalize to ~1.0"
    assert abs(normalized_rel[0] - 0.0) < 0.01, "❌ Worst relevance should normalize to ~0.0"
    print("  ✅ Relevance normalization correct!\n")
    
    print("="*60)
    print("✅ ALL TESTS PASSED - Hybrid retriever fix is correct!")
    print("="*60)

if __name__ == "__main__":
    test_score_normalization()

