"""Ollama LLM implementation using LangChain"""

import json
import re
from typing import Dict
from langchain_ollama import OllamaLLM
from interfaces.base_llm import BaseLLM


class OllamaLLMModel(BaseLLM):
    """Ollama LLM implementation
    
    Uses LangChain's OllamaLLM for interaction with local Ollama instance.
    """
    
    def __init__(self, model_name: str, base_url: str = "http://localhost:11434", **kwargs):
        """Initialize Ollama LLM
        
        Args:
            model_name: Name of the Ollama model (e.g., "llama3.2")
            base_url: Ollama server URL
            **kwargs: Additional parameters for OllamaLLM
        """
        self.model_name = model_name
        self.base_url = base_url
        self.llm = OllamaLLM(
            model=model_name,
            base_url=base_url,
            **kwargs
        )
    
    def generate(self, prompt: str, **kwargs) -> str:
        """Generate text from prompt
        
        Args:
            prompt: The input prompt
            **kwargs: Additional parameters
            
        Returns:
            Generated text
        """
        try:
            response = self.llm.invoke(prompt, **kwargs)
            return response
        except Exception as e:
            print(f"Error generating response: {e}")
            raise
    
    def generate_structured(self, prompt: str, schema: Dict = None, **kwargs) -> Dict:
        """Generate structured JSON output
        
        Args:
            prompt: The input prompt (should request JSON output)
            schema: Expected output schema (optional, for documentation)
            **kwargs: Additional parameters
            
        Returns:
            Parsed JSON as dictionary
        """
        try:
            response = self.llm.invoke(prompt, **kwargs)
            
            # Try to extract JSON from response
            # Sometimes LLMs wrap JSON in markdown code blocks
            json_match = re.search(r'```json\s*(.*?)\s*```', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                # Try to find JSON array or object
                json_match = re.search(r'(\[.*\]|\{.*\})', response, re.DOTALL)
                if json_match:
                    json_str = json_match.group(1)
                else:
                    json_str = response
            
            # Parse JSON
            parsed = json.loads(json_str)
            return parsed
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON from response: {e}")
            print(f"Response was: {response}")
            raise
        except Exception as e:
            print(f"Error generating structured response: {e}")
            raise
    
    def get_model_name(self) -> str:
        """Return model identifier
        
        Returns:
            Model name
        """
        return self.model_name

