"""Ollama Embedding implementation using LangChain"""

from typing import List
from langchain_ollama import OllamaEmbeddings
from interfaces.base_embedding import BaseEmbedding


class OllamaEmbeddingModel(BaseEmbedding):
    """Ollama Embedding implementation
    
    Uses LangChain's OllamaEmbeddings for generating embeddings via local Ollama.
    """
    
    def __init__(self, model_name: str, base_url: str = "http://localhost:11434"):
        """Initialize Ollama Embedding model
        
        Args:
            model_name: Name of the Ollama embedding model (e.g., "nomic-embed-text")
            base_url: Ollama server URL
        """
        self.model_name = model_name
        self.base_url = base_url
        self.embeddings = OllamaEmbeddings(
            model=model_name,
            base_url=base_url
        )
        self._dimension = None  # Cache dimension after first call
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple documents
        
        Args:
            texts: List of text strings to embed
            
        Returns:
            List of embedding vectors
        """
        try:
            embeddings = self.embeddings.embed_documents(texts)
            return embeddings
        except Exception as e:
            print(f"Error embedding documents: {e}")
            raise
    
    def embed_query(self, text: str) -> List[float]:
        """Generate embedding for a single query
        
        Args:
            text: Query text to embed
            
        Returns:
            Embedding vector
        """
        try:
            embedding = self.embeddings.embed_query(text)
            return embedding
        except Exception as e:
            print(f"Error embedding query: {e}")
            raise
    
    def get_model_name(self) -> str:
        """Return model identifier
        
        Returns:
            Model name
        """
        return self.model_name
    
    def get_dimension(self) -> int:
        """Return embedding dimension
        
        Caches the dimension after first call.
        
        Returns:
            Dimensionality of embeddings
        """
        if self._dimension is None:
            # Get dimension by embedding a test string
            test_embedding = self.embed_query("test")
            self._dimension = len(test_embedding)
        return self._dimension

