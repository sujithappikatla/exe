"""Test imports one by one"""

import sys

print("Testing imports step by step...")

try:
    print("1. Importing gc...")
    import gc
    print("   ✓ gc imported")
    
    print("2. Importing models...")
    from models.ollama_llm import OllamaLLMModel
    print("   ✓ models imported")
    
    print("3. Importing utils...")
    from utils.text_processing import load_documents
    print("   ✓ utils imported")
    
    print("4. Importing pipeline.chunker...")
    from pipeline import chunker
    print("   ✓ chunker imported")
    
    print("5. Importing pipeline.qa_generator...")
    from pipeline import qa_generator
    print("   ✓ qa_generator imported")
    
    print("6. Importing retrievers...")
    from retrievers import VectorRetriever
    print("   ✓ retrievers imported")
    
    print("\n✓ ALL IMPORTS SUCCESSFUL")
    
except Exception as e:
    print(f"\n✗ IMPORT FAILED: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

