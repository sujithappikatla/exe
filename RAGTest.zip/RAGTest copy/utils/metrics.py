"""Evaluation metrics calculation"""

import numpy as np
from typing import List, Dict


def calculate_mrr(retrieved_chunks: List[str], ground_truth_chunks: List[str]) -> float:
    """Calculate Mean Reciprocal Rank
    
    MRR measures the rank of the first relevant result.
    Formula: 1 / rank_of_first_relevant_chunk
    
    Args:
        retrieved_chunks: List of retrieved chunk IDs in rank order
        ground_truth_chunks: List of relevant chunk IDs
        
    Returns:
        Reciprocal rank (0 if no relevant chunk found)
    """
    for rank, chunk_id in enumerate(retrieved_chunks, start=1):
        if chunk_id in ground_truth_chunks:
            return 1.0 / rank
    return 0.0


def calculate_hit_rate_at_k(retrieved_chunks: List[str], ground_truth_chunks: List[str], k: int) -> int:
    """Calculate Hit Rate at K (binary: 1 if found, 0 if not)
    
    Args:
        retrieved_chunks: List of retrieved chunk IDs
        ground_truth_chunks: List of relevant chunk IDs
        k: Number of top results to consider
        
    Returns:
        1 if any relevant chunk found in top-k, else 0
    """
    top_k = retrieved_chunks[:k]
    for chunk_id in top_k:
        if chunk_id in ground_truth_chunks:
            return 1
    return 0


def calculate_average_rank(retrieved_chunks: List[str], ground_truth_chunks: List[str]) -> float:
    """Calculate average rank of first relevant chunk
    
    Args:
        retrieved_chunks: List of retrieved chunk IDs in rank order
        ground_truth_chunks: List of relevant chunk IDs
        
    Returns:
        Rank of first relevant chunk (0 if not found)
    """
    for rank, chunk_id in enumerate(retrieved_chunks, start=1):
        if chunk_id in ground_truth_chunks:
            return float(rank)
    return 0.0


def calculate_ndcg_at_k(retrieved_chunks: List[str], ground_truth_chunks: List[str], k: int) -> float:
    """Calculate Normalized Discounted Cumulative Gain at K
    
    NDCG measures ranking quality with position-based discounting.
    Higher positions are weighted more heavily.
    
    Args:
        retrieved_chunks: List of retrieved chunk IDs in rank order
        ground_truth_chunks: List of relevant chunk IDs
        k: Number of top results to consider
        
    Returns:
        NDCG score between 0 and 1
    """
    # Calculate DCG
    dcg = 0.0
    for i, chunk_id in enumerate(retrieved_chunks[:k], start=1):
        if chunk_id in ground_truth_chunks:
            # Relevance is 1 if relevant, 0 otherwise
            relevance = 1
            dcg += relevance / np.log2(i + 1)
    
    # Calculate IDCG (ideal DCG - all relevant docs at top)
    num_relevant = min(len(ground_truth_chunks), k)
    idcg = sum(1.0 / np.log2(i + 2) for i in range(num_relevant))
    
    # Avoid division by zero
    if idcg == 0:
        return 0.0
    
    return dcg / idcg


def aggregate_metrics(all_results: List[Dict], k_values: List[int]) -> Dict:
    """Aggregate metrics across all questions
    
    Args:
        all_results: List of per-question evaluation results
        k_values: List of K values used in evaluation
        
    Returns:
        Dictionary with aggregated metrics
    """
    if not all_results:
        return {}
    
    aggregated = {
        "total_questions": len(all_results),
        "mrr": np.mean([r['metrics']['reciprocal_rank'] for r in all_results]),
        "average_rank": np.mean([r['metrics']['rank_of_first_relevant'] for r in all_results if r['metrics']['rank_of_first_relevant'] > 0]),
    }
    
    # Aggregate Hit Rate for each K
    for k in k_values:
        hit_key = f"hit@{k}"
        if hit_key in all_results[0]['metrics']:
            aggregated[f"hit_rate@{k}"] = np.mean([r['metrics'][hit_key] for r in all_results])
    
    # Aggregate NDCG for each K
    for k in k_values:
        ndcg_key = f"ndcg@{k}"
        if ndcg_key in all_results[0]['metrics']:
            aggregated[f"ndcg@{k}"] = np.mean([r['metrics'][ndcg_key] for r in all_results])
    
    return aggregated

