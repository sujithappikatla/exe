"""Text processing utilities"""

import os
from typing import List, Dict


def load_documents(folder_path: str) -> List[Dict]:
    """Load all TXT files from a folder
    
    Args:
        folder_path: Path to folder containing TXT files
        
    Returns:
        List of dictionaries with 'filename' and 'content' keys
    """
    documents = []
    
    if not os.path.exists(folder_path):
        raise FileNotFoundError(f"Document folder not found: {folder_path}")
    
    for filename in os.listdir(folder_path):
        if filename.endswith('.txt'):
            filepath = os.path.join(folder_path, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    documents.append({
                        'filename': filename,
                        'content': content,
                        'filepath': filepath
                    })
            except Exception as e:
                print(f"Warning: Could not read {filename}: {e}")
    
    if not documents:
        raise ValueError(f"No TXT files found in {folder_path}")
    
    return documents


def create_combination_name(chunking: str, embedding: str, retrieval: str) -> str:
    """Generate unique name for a combination
    
    Args:
        chunking: Chunking strategy name
        embedding: Embedding model name
        retrieval: Retrieval strategy name
        
    Returns:
        Combination name as string
    """
    # Clean model names (remove special characters)
    embedding_clean = embedding.replace('-', '_').replace('.', '_')
    return f"{chunking}_{embedding_clean}_{retrieval}"


def estimate_tokens(text: str) -> int:
    """Rough estimation of token count
    
    Uses simple heuristic: ~4 characters per token
    
    Args:
        text: Input text
        
    Returns:
        Estimated token count
    """
    return len(text) // 4


def chunk_text_by_tokens(text: str, chunk_size: int, overlap: int) -> List[Dict]:
    """Chunk text by approximate token count
    
    Args:
        text: Text to chunk
        chunk_size: Target size in tokens
        overlap: Overlap size in tokens
        
    Returns:
        List of chunk dictionaries with text and character ranges
    """
    # Convert tokens to approximate character count
    char_chunk_size = chunk_size * 4
    char_overlap = overlap * 4
    
    chunks = []
    start = 0
    chunk_index = 0
    
    while start < len(text):
        end = min(start + char_chunk_size, len(text))
        
        chunk_text = text[start:end]
        chunks.append({
            'text': chunk_text,
            'char_start': start,
            'char_end': end,
            'chunk_index': chunk_index
        })
        
        chunk_index += 1
        
        # If we've reached the end, stop
        if end >= len(text):
            break
            
        # Move start forward
        start = end - char_overlap
        
        # Avoid infinite loop - ensure we're making progress
        if start >= end or char_overlap >= char_chunk_size:
            break
    
    return chunks

