"""Storage and result management"""

from storage.result_store import (
    save_detailed_results,
    save_summary,
    generate_comparison_report,
    save_qa_dataset,
    load_qa_dataset
)

from storage.excel_reporter import generate_excel_report

__all__ = [
    "save_detailed_results",
    "save_summary",
    "generate_comparison_report",
    "save_qa_dataset",
    "load_qa_dataset",
    "generate_excel_report"
]

