"""Excel report generation for RAG evaluation results"""

import os
from typing import List, Dict
from datetime import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


def format_retrieved_chunks(retrieved_list: List[Dict], ground_truth_ids: List[str], max_display: int = 10) -> str:
    """Format retrieved chunks as multi-line string with relevance markers
    
    Args:
        retrieved_list: List of retrieved chunk dictionaries
        ground_truth_ids: List of ground truth chunk IDs
        max_display: Maximum number of chunks to display
        
    Returns:
        Formatted string with line breaks
    """
    lines = []
    for i, chunk_info in enumerate(retrieved_list[:max_display], 1):
        chunk_id = chunk_info.get('chunk_id', 'unknown')
        score = chunk_info.get('similarity_score', 0.0)
        is_relevant = '✓' if chunk_id in ground_truth_ids else ''
        lines.append(f"{i}. {chunk_id} ({score:.3f}) {is_relevant}")
    
    return '\n'.join(lines)


def create_summary_sheet(workbook, all_summaries: List[Dict], run_metadata: Dict):
    """Create summary comparison sheet
    
    Args:
        workbook: openpyxl Workbook object
        all_summaries: List of summary dictionaries for all combinations
        run_metadata: Metadata about the run
    """
    ws = workbook.create_sheet("Summary", 0)
    
    # Title and metadata
    ws['A1'] = "RAG Evaluation Report"
    ws['A1'].font = Font(size=16, bold=True)
    
    ws['A2'] = f"Run Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    ws['A3'] = f"Total Combinations: {len(all_summaries)}"
    ws['A4'] = f"Run Directory: {run_metadata.get('run_directory', 'N/A')}"
    
    # Headers
    headers = ['Combination', 'Chunking', 'Embedding', 'Retrieval', 'MRR', 'Hit@1', 'Hit@3', 'Hit@5', 'Hit@10', 'Avg Rank', 'NDCG@5']
    header_row = 6
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=header_row, column=col, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        cell.alignment = Alignment(horizontal='center', vertical='center')
    
    # Sort summaries by MRR descending
    sorted_summaries = sorted(all_summaries, key=lambda x: x['metrics'].get('mrr', 0), reverse=True)
    
    # Find best values for highlighting
    best_mrr = max(s['metrics'].get('mrr', 0) for s in all_summaries)
    best_hit5 = max(s['metrics'].get('hit_rate@5', 0) for s in all_summaries)
    best_avg_rank = min(s['metrics'].get('average_rank', float('inf')) for s in all_summaries if s['metrics'].get('average_rank', float('inf')) != float('inf'))
    
    # Data rows
    for row_idx, summary in enumerate(sorted_summaries, header_row + 1):
        config = summary.get('configuration', {})
        metrics = summary.get('metrics', {})
        
        # Extract configuration details
        combination = summary.get('combination', '')
        chunking = config.get('chunking', '')
        embedding = config.get('embedding', '')
        retrieval = config.get('retrieval', '')
        
        # Write data
        ws.cell(row=row_idx, column=1, value=combination)
        ws.cell(row=row_idx, column=2, value=chunking)
        ws.cell(row=row_idx, column=3, value=embedding)
        ws.cell(row=row_idx, column=4, value=retrieval)
        
        # Metrics
        mrr = metrics.get('mrr', 0)
        hit1 = metrics.get('hit_rate@1', 0)
        hit3 = metrics.get('hit_rate@3', 0)
        hit5 = metrics.get('hit_rate@5', 0)
        hit10 = metrics.get('hit_rate@10', 0)
        avg_rank = metrics.get('average_rank', 0)
        ndcg5 = metrics.get('ndcg@5', 0)
        
        ws.cell(row=row_idx, column=5, value=round(mrr, 4))
        ws.cell(row=row_idx, column=6, value=round(hit1, 4))
        ws.cell(row=row_idx, column=7, value=round(hit3, 4))
        ws.cell(row=row_idx, column=8, value=round(hit5, 4))
        ws.cell(row=row_idx, column=9, value=round(hit10, 4))
        ws.cell(row=row_idx, column=10, value=round(avg_rank, 2))
        ws.cell(row=row_idx, column=11, value=round(ndcg5, 4))
        
        # Highlight best values
        if mrr == best_mrr:
            ws.cell(row=row_idx, column=5).fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        if hit5 == best_hit5:
            ws.cell(row=row_idx, column=8).fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        if avg_rank == best_avg_rank:
            ws.cell(row=row_idx, column=10).fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    
    # Auto-adjust column widths
    for col in range(1, len(headers) + 1):
        ws.column_dimensions[get_column_letter(col)].width = 20
    
    # Freeze header row
    ws.freeze_panes = f'A{header_row + 1}'


def create_combination_sheet(workbook, combination_name: str, detailed_results: List[Dict], 
                             summary: Dict, config: Dict, max_chunks_display: int = 10):
    """Create detailed sheet for one combination
    
    Args:
        workbook: openpyxl Workbook object
        combination_name: Name of the combination
        detailed_results: List of per-question results
        summary: Summary metrics for this combination
        config: Configuration for this combination
        max_chunks_display: Maximum chunks to display in Retrieved Chunks column
    """
    # Sanitize sheet name (Excel has 31 char limit and special char restrictions)
    sheet_name = combination_name[:31].replace('/', '_').replace('\\', '_').replace('*', '_')
    ws = workbook.create_sheet(sheet_name)
    
    # Section 1: Configuration (Rows 1-10)
    ws['A1'] = "CONFIGURATION"
    ws['A1'].font = Font(size=14, bold=True)
    
    # Handle different config structures
    chunking_str = config.get('chunking', 'N/A')
    if isinstance(chunking_str, dict):
        chunking_display = f"{chunking_str['name']} ({chunking_str['chunk_size']} tokens, {chunking_str['chunk_overlap']} overlap)"
    else:
        chunking_display = str(chunking_str)
    
    embedding_str = config.get('embedding', config.get('embedding_model', 'N/A'))
    retrieval_str = config.get('retrieval', config.get('retrieval_strategy', 'N/A'))
    
    config_data = [
        ("Combination Name", combination_name),
        ("Chunking Strategy", chunking_display),
        ("Embedding Model", embedding_str),
        ("Retrieval Strategy", retrieval_str),
        ("Total Chunks", summary.get('total_chunks', 'N/A')),
        ("Questions Evaluated", len(detailed_results)),
    ]
    
    for row, (param, value) in enumerate(config_data, 2):
        ws.cell(row=row, column=1, value=param).font = Font(bold=True)
        ws.cell(row=row, column=2, value=str(value))
    
    # Section 2: Overall Metrics (Rows 9-18)
    metrics_start_row = len(config_data) + 3
    ws.cell(row=metrics_start_row, column=1, value="OVERALL METRICS").font = Font(size=14, bold=True)
    
    metrics = summary.get('metrics', {})
    metrics_data = [
        ("MRR", metrics.get('mrr', 0)),
        ("Hit Rate@1", metrics.get('hit_rate@1', 0)),
        ("Hit Rate@3", metrics.get('hit_rate@3', 0)),
        ("Hit Rate@5", metrics.get('hit_rate@5', 0)),
        ("Hit Rate@10", metrics.get('hit_rate@10', 0)),
        ("Average Rank", metrics.get('average_rank', 0)),
        ("NDCG@5", metrics.get('ndcg@5', 0)),
    ]
    
    for row, (metric_name, value) in enumerate(metrics_data, metrics_start_row + 1):
        ws.cell(row=row, column=1, value=metric_name).font = Font(bold=True)
        ws.cell(row=row, column=2, value=round(value, 4) if isinstance(value, float) else value)
    
    # Section 3: Per-Question Details (Row 20+)
    detail_start_row = metrics_start_row + len(metrics_data) + 2
    ws.cell(row=detail_start_row, column=1, value="DETAILED RESULTS").font = Font(size=14, bold=True)
    
    # Headers for detail table
    detail_headers = ['Q#', 'Question', 'Retrieved Chunks', 'Ground Truth', 'Rank', 'RR', 'Hit@1', 'Hit@3', 'Hit@5', 'Hit@10', 'NDCG@5']
    header_row = detail_start_row + 1
    
    for col, header in enumerate(detail_headers, 1):
        cell = ws.cell(row=header_row, column=col, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    
    # Detail rows
    for idx, result in enumerate(detailed_results, 1):
        row = header_row + idx
        
        question = result.get('question', '')
        retrieved_chunks = result.get('retrieved_chunks', [])
        ground_truth = ', '.join(result.get('ground_truth_chunks', []))
        metrics_q = result.get('metrics', {})
        
        # Format retrieved chunks
        retrieved_str = format_retrieved_chunks(retrieved_chunks, result.get('ground_truth_chunks', []), max_chunks_display)
        
        # Write data
        ws.cell(row=row, column=1, value=idx)
        ws.cell(row=row, column=2, value=question)
        ws.cell(row=row, column=3, value=retrieved_str)
        ws.cell(row=row, column=4, value=ground_truth)
        ws.cell(row=row, column=5, value=metrics_q.get('rank_of_first_relevant', 0))
        ws.cell(row=row, column=6, value=round(metrics_q.get('reciprocal_rank', 0), 4))
        ws.cell(row=row, column=7, value=metrics_q.get('hit@1', 0))
        ws.cell(row=row, column=8, value=metrics_q.get('hit@3', 0))
        ws.cell(row=row, column=9, value=metrics_q.get('hit@5', 0))
        ws.cell(row=row, column=10, value=metrics_q.get('hit@10', 0))
        ws.cell(row=row, column=11, value=round(metrics_q.get('ndcg@5', 0), 4))
        
        # Wrap text for retrieved chunks column
        ws.cell(row=row, column=3).alignment = Alignment(wrap_text=True, vertical='top')
        
        # Set row height for wrapped text
        ws.row_dimensions[row].height = max(15 * min(len(retrieved_chunks), max_chunks_display), 30)
    
    # Column widths
    ws.column_dimensions['A'].width = 5   # Q#
    ws.column_dimensions['B'].width = 50  # Question
    ws.column_dimensions['C'].width = 40  # Retrieved Chunks
    ws.column_dimensions['D'].width = 30  # Ground Truth
    ws.column_dimensions['E'].width = 8   # Rank
    ws.column_dimensions['F'].width = 8   # RR
    ws.column_dimensions['G'].width = 8   # Hit@1
    ws.column_dimensions['H'].width = 8   # Hit@3
    ws.column_dimensions['I'].width = 8   # Hit@5
    ws.column_dimensions['J'].width = 8   # Hit@10
    ws.column_dimensions['K'].width = 10  # NDCG@5
    
    # Freeze header row
    ws.freeze_panes = f'A{header_row + 1}'


def apply_excel_formatting(workbook):
    """Apply professional formatting to all sheets
    
    Args:
        workbook: openpyxl Workbook object
    """
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                # Add borders to all cells with content
                if cell.value is not None:
                    cell.border = thin_border
                    
                # Right-align numeric values
                if isinstance(cell.value, (int, float)) and not cell.font.bold:
                    cell.alignment = Alignment(horizontal='right', vertical='center')


def generate_excel_report(
    all_summaries: List[Dict],
    all_detailed_results: Dict[str, Dict],
    output_path: str,
    run_metadata: Dict,
    max_chunks_display: int = 10
) -> None:
    """Generate comprehensive Excel report with all evaluation results
    
    Args:
        all_summaries: List of summary dictionaries for all combinations
        all_detailed_results: Dictionary mapping combination names to detailed results
        output_path: Path to save Excel file
        run_metadata: Metadata about the run (run_directory, qa_config, k_values)
        max_chunks_display: Maximum chunks to display in Retrieved Chunks column
    """
    print(f"\nGenerating Excel report with {len(all_summaries)} combinations...")
    
    # Create workbook
    wb = openpyxl.Workbook()
    
    # Remove default sheet
    if 'Sheet' in wb.sheetnames:
        wb.remove(wb['Sheet'])
    
    # Create summary sheet
    print("  Creating summary sheet...")
    create_summary_sheet(wb, all_summaries, run_metadata)
    
    # Create sheet for each combination
    for i, (combo_name, data) in enumerate(all_detailed_results.items(), 1):
        print(f"  Creating sheet {i}/{len(all_detailed_results)}: {combo_name}...", end='\r')
        
        summary = next((s for s in all_summaries if s['combination'] == combo_name), None)
        if summary:
            create_combination_sheet(
                wb,
                combo_name,
                data['detailed'],
                summary,
                data['config'],
                max_chunks_display
            )
    
    print(f"\n  Applying formatting...")
    
    # Apply formatting
    apply_excel_formatting(wb)
    
    # Save
    wb.save(output_path)
    print(f"  ✓ Excel report saved: {output_path}")

