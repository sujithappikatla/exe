"""Storage and management of evaluation results"""

import os
import json
from typing import List, Dict
from datetime import datetime


def ensure_directory(path: str):
    """Ensure directory exists"""
    os.makedirs(path, exist_ok=True)


def save_qa_dataset(qa_dataset: List[Dict], filepath: str, config: Dict = None):
    """Save QA dataset to JSON file
    
    Args:
        qa_dataset: List of QA pair dictionaries
        filepath: Path to save file
        config: QA generation configuration (optional, for metadata)
    """
    ensure_directory(os.path.dirname(filepath))
    
    metadata = {
        'created_date': datetime.now().isoformat(),
        'num_questions': len(qa_dataset),
        'version': '1.0'
    }
    
    # Add sampling information if config provided
    if config:
        metadata['sampling_mode'] = config.get('sampling_mode', 'all')
        if config.get('sampling_mode') == 'random':
            metadata['random_chunk_sample_size'] = config.get('random_chunk_sample_size')
            metadata['random_seed'] = config.get('random_seed')
    
    data = {
        'metadata': metadata,
        'qa_pairs': qa_dataset
    }
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    print(f"\nQA dataset saved to: {filepath}")


def load_qa_dataset(filepath: str) -> List[Dict]:
    """Load QA dataset from JSON file
    
    Args:
        filepath: Path to QA dataset file
        
    Returns:
        List of QA pair dictionaries
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    return data['qa_pairs']


def save_detailed_results(results: List[Dict], combo: Dict, output_dir: str):
    """Save detailed per-question results
    
    Args:
        results: List of detailed question results
        combo: Combination configuration
        output_dir: Output directory path
    """
    ensure_directory(output_dir)
    
    combination_name = combo['name']
    filename = f"{combination_name}_detailed.json"
    filepath = os.path.join(output_dir, filename)
    
    data = {
        'metadata': {
            'combination': combination_name,
            'chunking_strategy': combo['chunking']['name'],
            'embedding_model': combo['embedding_model'],
            'retrieval_strategy': combo['retrieval_strategy'],
            'evaluation_date': datetime.now().isoformat(),
        },
        'results': results
    }
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    print(f"  Detailed results saved to: {filename}")


def save_summary(summary: Dict, combo: Dict, output_dir: str):
    """Save aggregated summary metrics
    
    Args:
        summary: Summary metrics dictionary
        combo: Combination configuration
        output_dir: Output directory path
    """
    ensure_directory(output_dir)
    
    combination_name = combo['name']
    filename = f"{combination_name}_summary.json"
    filepath = os.path.join(output_dir, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    
    print(f"  Summary saved to: {filename}")


def generate_comparison_report(all_summaries: List[Dict], output_dir: str):
    """Generate comparison report across all combinations
    
    Args:
        all_summaries: List of summary dictionaries for all combinations
        output_dir: Output directory path
    """
    ensure_directory(output_dir)
    
    # Find best performers for each metric
    best_performers = {}
    
    # Collect all metrics from first summary
    if all_summaries:
        sample_metrics = all_summaries[0]['metrics']
        for metric_name in sample_metrics.keys():
            # Find combination with best score for this metric
            best_combo = max(
                all_summaries,
                key=lambda x: x['metrics'].get(metric_name, 0)
            )
            best_performers[metric_name] = {
                'combination': best_combo['combination'],
                'score': best_combo['metrics'][metric_name]
            }
    
    # Create comparison matrix
    comparison_matrix = []
    for summary in all_summaries:
        comparison_matrix.append({
            'combination': summary['combination'],
            'chunking': summary['configuration']['chunking'],
            'embedding': summary['configuration']['embedding'],
            'retrieval': summary['configuration']['retrieval'],
            'metrics': summary['metrics']
        })
    
    # Sort by MRR (primary metric)
    comparison_matrix.sort(key=lambda x: x['metrics'].get('mrr', 0), reverse=True)
    
    report = {
        'metadata': {
            'generated_date': datetime.now().isoformat(),
            'total_combinations': len(all_summaries),
        },
        'best_performers': best_performers,
        'comparison_matrix': comparison_matrix,
        'top_5_overall': comparison_matrix[:5]
    }
    
    filepath = os.path.join(output_dir, 'comparison_report.json')
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"\nComparison report saved to: comparison_report.json")
    print("\n" + "="*60)
    print("TOP 5 COMBINATIONS (by MRR)")
    print("="*60)
    for i, combo in enumerate(comparison_matrix[:5], 1):
        print(f"\n{i}. {combo['combination']}")
        print(f"   MRR: {combo['metrics'].get('mrr', 0):.4f}")
        print(f"   Hit@5: {combo['metrics'].get('hit_rate@5', 0):.4f}")
        print(f"   Avg Rank: {combo['metrics'].get('average_rank', 0):.2f}")

