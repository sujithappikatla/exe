# Bug Fix: Infinite Loop in Chunking Function

## Issue
The application was being killed by the OS (exit code 137 - SIGKILL) due to memory exhaustion.

## Root Cause
There was an **infinite loop** in the `chunk_text_by_tokens()` function in `utils/text_processing.py`.

### The Problem:
```python
# OLD CODE (BUGGY):
while start < len(text):
    end = min(start + char_chunk_size, len(text))
    # ... create chunk ...
    start = end - char_overlap
    
    if start >= end:  # This check was insufficient!
        break
```

**What went wrong:**
- When reaching the end of the text, `end = len(text)`
- Then `start = len(text) - char_overlap` (e.g., `len(text) - 200`)
- Since `start < len(text)`, the loop continues
- Next iteration: `end = min(start + 2000, len(text)) = len(text)` again
- Then `start = len(text) - 200` AGAIN → **INFINITE LOOP!**

This created millions of chunk objects until the OS killed the process.

## Solution
Fixed the loop logic to properly detect when we've reached the end:

```python
# NEW CODE (FIXED):
while start < len(text):
    end = min(start + char_chunk_size, len(text))
    # ... create chunk ...
    
    # If we've reached the end, stop
    if end >= len(text):
        break
        
    # Move start forward
    start = end - char_overlap
    
    # Avoid infinite loop - ensure we're making progress
    if start >= end or char_overlap >= char_chunk_size:
        break
```

## Testing
After the fix:
- ✅ Chunking works correctly
- ✅ QA generation completes successfully
- ✅ Full pipeline runs without crashes
- ✅ Memory usage remains normal

## Files Modified
- `utils/text_processing.py` - Fixed `chunk_text_by_tokens()` function

## Date
October 21, 2025

