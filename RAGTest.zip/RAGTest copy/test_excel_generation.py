"""Test script for Excel report generation"""

import os
import json
from storage.excel_reporter import generate_excel_report

print("="*60)
print("TESTING EXCEL REPORT GENERATION")
print("="*60)

# Use existing evaluation data
run_dir = "./outputs/run_2025-10-21_23-39-56"
eval_dir = os.path.join(run_dir, "evaluations")

if not os.path.exists(eval_dir):
    print(f"❌ Evaluation directory not found: {eval_dir}")
    print("   Please run the full pipeline first to generate evaluation data.")
    exit(1)

# Load summaries and detailed results from individual files
all_summaries = []
all_detailed_results = {}

# List all summary files
import glob
summary_files = glob.glob(os.path.join(eval_dir, "*_summary.json"))

print(f"Found {len(summary_files)} summary files")

for summary_file in summary_files:
    # Load summary
    with open(summary_file, 'r') as f:
        summary_data = json.load(f)
    
    combo_name = summary_data.get('combination')
    all_summaries.append(summary_data)
    
    # Load corresponding detailed file
    detailed_file = summary_file.replace('_summary.json', '_detailed.json')
    
    if os.path.exists(detailed_file):
        with open(detailed_file, 'r') as f:
            detailed_data = json.load(f)
        
        all_detailed_results[combo_name] = {
            'detailed': detailed_data.get('results', []),
            'config': summary_data.get('configuration', {})
        }
        print(f"  ✓ {combo_name}: {len(detailed_data.get('results', []))} questions")
    else:
        print(f"  ⚠ Detailed file not found: {detailed_file}")

print(f"\n✓ Total combinations with detailed data: {len(all_detailed_results)}")

# Generate Excel report
excel_path = os.path.join(eval_dir, "evaluation_report.xlsx")

print(f"\nGenerating Excel report...")

try:
    generate_excel_report(
        all_summaries=all_summaries,
        all_detailed_results=all_detailed_results,
        output_path=excel_path,
        run_metadata={
            'run_directory': run_dir,
            'qa_config': {'sampling_mode': 'all'},
            'k_values': [1, 3, 5, 10],
        },
        max_chunks_display=10
    )
    
    # Verify file was created
    if os.path.exists(excel_path):
        file_size = os.path.getsize(excel_path) / 1024  # KB
        print(f"\n✅ SUCCESS!")
        print(f"   Excel file created: {excel_path}")
        print(f"   File size: {file_size:.2f} KB")
        print(f"\n   Open the file to verify:")
        print(f"   - Summary sheet with all combinations")
        print(f"   - One sheet per combination with detailed results")
        print(f"   - Professional formatting with colors and borders")
    else:
        print(f"\n❌ ERROR: Excel file was not created")
        
except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*60)

