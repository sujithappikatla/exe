"""Test document chunking"""

from utils.text_processing import load_documents
from pipeline.chunker import chunk_documents

print("Testing document chunking...")

# Load documents
print("Loading documents...")
documents = load_documents("./documents")
print(f"✓ Loaded {len(documents)} documents")

for doc in documents:
    print(f"  - {doc['filename']}: {len(doc['content'])} chars")

# Test chunking strategy
strategy = {
    'name': 'baseline',
    'chunk_size': 500,
    'chunk_overlap': 50
}

print(f"\nChunking with strategy: {strategy['name']} ({strategy['chunk_size']} tokens)...")
chunks = chunk_documents(documents, strategy)

print(f"✓ Created {len(chunks)} chunks")
print(f"  First chunk preview: {chunks[0]['text'][:100]}...")

print("\n✓ SUCCESS")

