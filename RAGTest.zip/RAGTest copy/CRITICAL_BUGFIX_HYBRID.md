# CRITICAL BUG: Hybrid Retriever Score Inversion

## Severity: HIGH - Incorrect Results

## Discovery
Hybrid retrieval was performing significantly worse than both vector and BM25 individually:
- Vector MRR: 0.62-0.82
- BM25 MRR: 0.55-0.80
- **Hybrid MRR: 0.00-0.22** ❌ (Should be BETTER than both!)

## Root Cause

### The Bug
ChromaDB's `similarity_search_with_score()` returns **distance metrics**, not similarity scores:
- **Lower distance = More similar** (0 = identical)
- **Higher distance = Less similar**

BM25's `get_scores()` returns **relevance scores**:
- **Higher relevance = More similar**
- **Lower relevance = Less similar**

### The Problem
The original normalization treated both the same way:

```python
# OLD CODE (BUGGY)
def _normalize_scores(self, scores):
    # Normalizes to [0, 1] range
    normalized = [(s - min_score) / (max_score - min_score)]
    return normalized
```

**Result**: 
- ChromaDB: HIGH normalized score = HIGH distance = **WORST matches** ❌
- BM25: HIGH normalized score = HIGH relevance = **BEST matches** ✓

The hybrid retriever was combining:
- The **worst** chunks from vector search +
- The **best** chunks from BM25
- = Terrible results!

## The Fix

Added `is_distance` parameter to handle distance vs similarity metrics correctly:

```python
# NEW CODE (FIXED)
def _normalize_scores(self, scores, is_distance=False):
    # Normalize to [0, 1]
    normalized = [(s - min_score) / (max_score - min_score)]
    
    # If these are distance scores, invert them
    if is_distance:
        normalized = [1.0 - s for s in normalized]
    
    return normalized

# Usage:
vector_scores_norm = self._normalize_scores(
    [r[1] for r in vector_results], 
    is_distance=True  # ChromaDB returns distances
)

bm25_scores_norm = self._normalize_scores(
    [r[1] for r in bm25_results], 
    is_distance=False  # BM25 returns relevance
)
```

## Impact

### Before Fix:
```
Combination: small_chunks_nomic_embed_text_hybrid
MRR: 0.0479
Hit@5: 0.0938
Avg Rank: 3.00
```

### Expected After Fix:
```
Combination: small_chunks_nomic_embed_text_hybrid
MRR: ~0.65-0.75 (between vector and BM25, likely better)
Hit@5: ~0.75-0.85
```

## Lessons Learned

1. **Always check metric direction**: Is lower better or higher better?
2. **Document score types**: Distance vs Similarity vs Relevance
3. **Test hybrid against components**: Hybrid should NEVER be significantly worse than its components
4. **Normalize consistently**: Ensure all scores are on the same scale AND direction

## Files Modified
- `retrievers/hybrid_retriever.py` - Fixed `_normalize_scores()` and `retrieve()` methods

## Testing Recommendations

Before considering any hybrid retrieval system working, verify:
1. Hybrid MRR >= min(vector_MRR, BM25_MRR) - 0.05
2. Hybrid Hit@5 >= min(vector_Hit@5, BM25_Hit@5) - 0.05
3. If hybrid is significantly worse, check score direction!

## Date
October 21, 2025

## Status
✅ FIXED - Re-run evaluation to verify

