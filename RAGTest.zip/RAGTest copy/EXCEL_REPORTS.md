# Excel Reports Feature

## Overview

The RAG Evaluation Framework now automatically generates comprehensive Excel reports with detailed results for all combinations, making it easy to analyze and share results.

## What's Generated

Every evaluation run creates an `evaluation_report.xlsx` file in the evaluations folder with:

1. **Summary Sheet**: Comparison of all combinations
2. **Combination Sheets**: One detailed sheet per combination (up to 27 sheets)

## File Location

```
outputs/
└── run_2025-10-21_23-39-56/
    └── evaluations/
        ├── evaluation_report.xlsx  ← Generated Excel file
        ├── comparison_report.json
        └── ... (individual JSON files)
```

## Summary Sheet

The first sheet provides a high-level comparison of all combinations.

### Layout

**Metadata (Rows 1-4)**
- Report title
- Run date and time
- Total combinations evaluated
- Run directory path

**Comparison Table (Row 6+)**

| Combination | Chunking | Embedding | Retrieval | MRR | Hit@1 | Hit@3 | Hit@5 | Hit@10 | Avg Rank | NDCG@5 |
|------------|----------|-----------|-----------|-----|-------|-------|-------|--------|----------|--------|
| medium_chunks_nomic_vector | medium | nomic | vector | 0.9375 | 0.8750 | 1.0000 | 1.0000 | 1.0000 | 1.25 | 0.9539 |
| ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... |

### Features

- **Sorted by MRR**: Best performers at the top
- **Color Highlighting**: Best values highlighted in green
  - Best MRR (Mean Reciprocal Rank)
  - Best Hit@5 (Hit Rate at 5)
  - Best Avg Rank (Average Rank - lower is better)
- **Frozen Headers**: Easy scrolling through many combinations
- **Professional Formatting**: Bold headers with blue background

## Combination Sheets

Each combination gets its own detailed sheet with three sections.

### Section 1: Configuration

Displays the parameters used for this combination:

```
CONFIGURATION
─────────────────────────────
Parameter                  | Value
---------------------------|------------------
Combination Name           | large_chunks_nomic_embed_text_vector
Chunking Strategy          | large_chunks
Embedding Model            | nomic_embed_text
Retrieval Strategy         | vector
Total Chunks               | 10
Questions Evaluated        | 17
```

### Section 2: Overall Metrics

Summary metrics for the entire combination:

```
OVERALL METRICS
─────────────────────────────
Metric            | Value
------------------|-------
MRR               | 0.8824
Hit Rate@1        | 0.7647
Hit Rate@3        | 0.9412
Hit Rate@5        | 1.0000
Hit Rate@10       | 1.0000
Average Rank      | 1.47
NDCG@5            | 0.9195
```

### Section 3: Per-Question Details

Detailed results for every question:

| Q# | Question | Retrieved Chunks | Ground Truth | Rank | RR | Hit@1 | Hit@3 | Hit@5 | Hit@10 | NDCG@5 |
|----|----------|------------------|--------------|------|----|-------|-------|-------|--------|--------|
| 1 | When was Python... | 1. python_chunk_1 (0.892) ✓<br>2. python_chunk_3 (0.721)<br>3. ml_chunk_2 (0.654) | python_chunk_1 | 1 | 1.0 | 1 | 1 | 1 | 1 | 1.0 |
| 2 | What is gradient... | 1. ml_chunk_5 (0.834)<br>2. ml_chunk_2 (0.782) ✓<br>3. python_chunk_1 (0.701) | ml_chunk_2 | 2 | 0.5 | 0 | 1 | 1 | 1 | 0.6309 |

**Retrieved Chunks Column** shows:
- Rank (1-10)
- Chunk ID
- Similarity score (3 decimal places)
- ✓ marker for relevant chunks (matching ground truth)

**Features:**
- **Wrapped Text**: Retrieved chunks column uses line breaks for readability
- **Auto Row Height**: Rows expand to fit retrieved chunks
- **Frozen Headers**: Column headers stay visible when scrolling
- **Professional Borders**: All cells have clean borders

## Configuration

Control Excel generation in `config.py`:

```python
# Excel Report Settings
EXCEL_CONFIG = {
    "include_excel_report": True,    # Enable/disable Excel generation
    "max_retrieved_chunks_display": 10,  # Show top N chunks in Excel
    "auto_column_width": True,       # Auto-adjust column widths
    "freeze_headers": True,          # Freeze top rows
}
```

### Options

- **include_excel_report**: Set to `False` to skip Excel generation
- **max_retrieved_chunks_display**: Number of retrieved chunks to show (default: 10)
- **auto_column_width**: Automatically adjust column widths (default: True)
- **freeze_headers**: Freeze header rows for easy scrolling (default: True)

## Usage

### Automatic Generation

Excel reports are generated automatically at the end of each evaluation run:

```bash
python app.py

# Output:
# ...
# [PHASE 5] Generating Excel report...
# Generating Excel report with 27 combinations...
#   Creating summary sheet...
#   Creating sheet 1/27: small_chunks_nomic_vector...
#   Creating sheet 2/27: small_chunks_nomic_bm25...
#   ...
#   Applying formatting...
#   ✓ Excel report saved: ./outputs/run_XXX/evaluations/evaluation_report.xlsx
# 
# ============================================================
# EVALUATION COMPLETE!
# ============================================================
# Results saved to: ./outputs/run_XXX/evaluations
# Excel report: ./outputs/run_XXX/evaluations/evaluation_report.xlsx
```

### Disable Excel Generation

To skip Excel generation (if you only need JSON results):

```python
# In config.py
EXCEL_CONFIG = {
    "include_excel_report": False,  # Disable Excel
}
```

### Regenerate Excel from Existing Data

You can regenerate the Excel report from existing JSON results:

```python
import os
import json
import glob
from storage.excel_reporter import generate_excel_report

# Load existing results
eval_dir = "./outputs/run_2025-10-21_23-39-56/evaluations"
all_summaries = []
all_detailed_results = {}

# Load all summary files
for summary_file in glob.glob(os.path.join(eval_dir, "*_summary.json")):
    with open(summary_file) as f:
        summary = json.load(f)
    all_summaries.append(summary)
    
    combo_name = summary['combination']
    detailed_file = summary_file.replace('_summary.json', '_detailed.json')
    
    with open(detailed_file) as f:
        detailed = json.load(f)
    
    all_detailed_results[combo_name] = {
        'detailed': detailed['results'],
        'config': summary['configuration']
    }

# Generate Excel
excel_path = os.path.join(eval_dir, "evaluation_report.xlsx")
generate_excel_report(
    all_summaries=all_summaries,
    all_detailed_results=all_detailed_results,
    output_path=excel_path,
    run_metadata={'run_directory': eval_dir}
)
```

## Benefits

✅ **Share-Ready**: Professional Excel files for presentations and reports  
✅ **Comprehensive**: All data in one file with multiple sheets  
✅ **Visual**: Color highlighting for best performers  
✅ **Detailed**: Per-question breakdown with retrieved chunks  
✅ **Portable**: Works on any platform with Excel, LibreOffice, Google Sheets  
✅ **Filterable**: Use Excel's built-in filtering and sorting  
✅ **Exportable**: Easy to create charts and pivot tables  

## Example Use Cases

### 1. Find Best Configuration

Open Summary sheet → Sort by MRR → See green highlights for best performers

### 2. Debug Low Performance

Open underperforming combination sheet → Check Per-Question Details → See which questions failed and why

### 3. Compare Retrieval Strategies

Filter Summary sheet by Retrieval column → Compare vector vs BM25 vs hybrid

### 4. Present Results

Share the Excel file with stakeholders → Professional format with all details

### 5. Create Custom Analysis

Export data to CSV → Run custom statistical analysis or create visualizations

## Troubleshooting

### Excel File Not Created

**Cause**: Excel generation failed (check console for error)

**Solution**: Check error message. JSON results are still available even if Excel generation fails.

### Sheet Name Warnings

**Warning**: "Title is more than 31 characters"

**Cause**: Combination names longer than Excel's 31-character limit

**Impact**: None - Excel automatically truncates names. All data is intact.

### Missing Data in Sheets

**Cause**: JSON files incomplete or corrupted

**Solution**: Re-run evaluation for affected combinations

### Cannot Open Excel File

**Cause**: File may be open in another application

**Solution**: Close the file in Excel/LibreOffice and regenerate

## Technical Details

### Dependencies

- `openpyxl>=3.1.0`: Excel file creation and manipulation

### File Format

- **Format**: `.xlsx` (Office Open XML)
- **Compatible with**: 
  - Microsoft Excel (2007+)
  - LibreOffice Calc
  - Google Sheets
  - Apple Numbers

### Performance

- **27 combinations**: ~100KB file, <5 seconds generation
- **100+ combinations**: ~300KB file, ~15 seconds generation

### Memory Usage

Excel generation uses minimal memory as it processes one sheet at a time.

## Limitations

1. **Sheet Names**: Limited to 31 characters (Excel limitation)
2. **Max Sheets**: Technically unlimited, but 100+ sheets may be slow to open
3. **Cell Content**: Retrieved chunks limited to 10 by default (configurable)

## Future Enhancements

Potential improvements:

- [ ] Add charts and graphs in Summary sheet
- [ ] Create pivot tables for analysis
- [ ] Add conditional formatting for metrics thresholds
- [ ] Export individual sheets to separate files
- [ ] Add custom styling themes
- [ ] Generate PDF reports from Excel

---

**Version**: 1.0  
**Date**: October 21, 2025  
**Status**: ✅ Production Ready

