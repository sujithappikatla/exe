# RAG Evaluation Framework

A comprehensive evaluation framework for testing different RAG (Retrieval-Augmented Generation) configurations including chunking strategies, embedding models, and retrieval methods.

## Overview

This framework allows you to systematically evaluate different combinations of:
- **Chunking strategies** (small, medium, large chunks)
- **Embedding models** (Ollama models: nomic-embed-text, mxbai-embed-large, etc.)
- **Retrieval methods** (Vector similarity, BM25 keyword search, Hybrid)

It generates questions from your documents, evaluates retrieval quality, and provides detailed metrics to identify the best configuration for your use case.

## Features

- 🔄 **Automated QA Generation**: Generates evaluation questions from your documents
- 📊 **Multiple Metrics**: MRR, Hit Rate@K, Average Rank, NDCG
- 🔍 **Three Retrieval Methods**: Vector, BM25, and Hybrid approaches
- 🎯 **Per-Question Analysis**: Detailed results for every question
- 📈 **Comparison Reports**: Identifies best-performing combinations
- 🔌 **Extensible Design**: Easy to add new models via abstract interfaces
- 💾 **Complete Traceability**: All intermediate results stored for analysis

## Prerequisites

### 1. Ollama Installation

Install Ollama and download required models:

```bash
# Install Ollama (macOS)
brew install ollama

# Or download from: https://ollama.ai

# Start Ollama server
ollama serve

# Pull required models (in a new terminal)
ollama pull llama3.2                # For question generation
ollama pull nomic-embed-text        # For embeddings
ollama pull mxbai-embed-large       # For embeddings
```

### 2. Python Environment

```bash
# Create virtual environment
python -m venv .venv

# Activate environment
source .venv/bin/activate  # On macOS/Linux
# or
.venv\Scripts\activate  # On Windows

# Install dependencies
pip install -r requirements.txt
```

## Quick Start

### 1. Add Your Documents

Place your TXT files in the `documents/` folder:

```bash
mkdir documents
cp your_documents/*.txt documents/
```

Or use the provided sample documents to test the framework.

### 2. Configure (Optional)

Edit `config.py` to customize:

```python
# K Values for evaluation
K_VALUES = [1, 3, 5, 10]

# Number of questions per chunk
QA_CONFIG = {
    "questions_per_chunk": 2,
}

# Ollama models
OLLAMA_CONFIG = {
    "llm_model": "llama3.2",
    "embedding_models": [
        "nomic-embed-text",
        "mxbai-embed-large",
    ],
}

# Chunking strategies
CHUNKING_STRATEGIES = [
    {"name": "small_chunks", "chunk_size": 256, "chunk_overlap": 50},
    {"name": "medium_chunks", "chunk_size": 512, "chunk_overlap": 100},
    {"name": "large_chunks", "chunk_size": 1024, "chunk_overlap": 200},
]
```

### 3. Run Evaluation

```bash
python app.py
```

The framework will:
1. Generate QA pairs from your documents (one-time)
2. Test all combinations of chunking × embedding × retrieval
3. Save detailed results and comparison reports

## Output Structure

```
outputs/
└── run_2025-10-21_23-15-30/                 # Timestamped folder
    ├── qa_dataset.json                       # Generated questions
    ├── chromadb/                             # Vector databases
    │   ├── small_chunks_nomic_embed_text_vector/
    │   ├── medium_chunks_mxbai_embed_large_hybrid/
    │   └── ...
    ├── bm25_indices/                         # BM25 indices
    │   ├── small_chunks_bm25.pkl
    │   └── ...
    └── evaluations/                          # Results
        ├── evaluation_report.xlsx            # Excel report (NEW!)
        ├── small_chunks_nomic_embed_text_vector_detailed.json
        ├── small_chunks_nomic_embed_text_vector_summary.json
        ├── ...
        └── comparison_report.json            # Best performers
```

## Understanding Results

### Comparison Report

The `comparison_report.json` shows:
- **Best performers** for each metric
- **Comparison matrix** of all combinations
- **Top 5 overall** configurations

Example:
```json
{
  "best_performers": {
    "mrr": {
      "combination": "medium_chunks_nomic_embed_text_hybrid",
      "score": 0.756
    },
    "hit_rate@5": {
      "combination": "large_chunks_mxbai_embed_large_vector",
      "score": 0.927
    }
  },
  "top_5_overall": [...]
}
```

### Metrics Explained

- **MRR (Mean Reciprocal Rank)**: How high is the correct chunk? (1.0 = always at position 1)
- **Hit Rate@K**: What % of queries found the correct chunk in top-K? (0.9 = 90% success)
- **Average Rank**: On average, at what position is the correct chunk? (1.5 = typically position 1-2)
- **NDCG@K**: Ranking quality with position-based discounting (1.0 = perfect ranking)

See [METRICS_GUIDE.md](METRICS_GUIDE.md) for detailed explanations and examples.

### Excel Reports (NEW!)

Every evaluation run now generates a comprehensive Excel workbook (`evaluation_report.xlsx`) with:

- **Summary Sheet**: Comparison table of all combinations with color-coded best performers
- **Combination Sheets**: Detailed results for each configuration including:
  - Configuration parameters
  - Overall metrics
  - Per-question breakdown with retrieved chunks

See [EXCEL_REPORTS.md](EXCEL_REPORTS.md) for the complete guide.

To disable Excel generation:
```python
# In config.py
EXCEL_CONFIG = {
    "include_excel_report": False,
}
```

## Extending the Framework

### Adding New Embedding Models

1. Ensure the model is available in Ollama:
```bash
ollama pull your-model-name
```

2. Add to `config.py`:
```python
OLLAMA_CONFIG = {
    "embedding_models": [
        "nomic-embed-text",
        "your-model-name",  # Add here
    ],
}
```

### Using Custom Models

Implement the abstract interfaces in `interfaces/`:

```python
# interfaces/base_embedding.py
class BaseEmbedding(ABC):
    @abstractmethod
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        pass
    
    @abstractmethod
    def embed_query(self, text: str) -> List[float]:
        pass
```

Then create your implementation:

```python
# models/custom_embedding.py
from interfaces.base_embedding import BaseEmbedding

class CustomEmbeddingModel(BaseEmbedding):
    def embed_documents(self, texts):
        # Your implementation
        pass
    
    def embed_query(self, text):
        # Your implementation
        pass
```

## Project Structure

```
RAGTest/
├── app.py                      # Main orchestrator
├── config.py                   # Configuration
├── requirements.txt            # Dependencies
├── README.md                   # This file
├── METRICS_GUIDE.md           # Metrics documentation
│
├── interfaces/                 # Abstract interfaces
│   ├── base_llm.py
│   └── base_embedding.py
│
├── models/                     # Model implementations
│   ├── ollama_llm.py
│   └── ollama_embedding.py
│
├── retrievers/                 # Retrieval strategies
│   ├── vector_retriever.py
│   ├── bm25_retriever.py
│   └── hybrid_retriever.py
│
├── pipeline/                   # Pipeline components
│   ├── chunker.py
│   ├── qa_generator.py
│   ├── ground_truth_mapper.py
│   └── evaluator.py
│
├── storage/                    # Result storage
│   └── result_store.py
│
├── utils/                      # Utilities
│   ├── text_processing.py
│   └── metrics.py
│
└── documents/                  # Your TXT files
```

## Configuration Options

### Chunking Strategies

```python
{
    "name": "medium_chunks",
    "chunk_size": 512,      # Size in approximate tokens
    "chunk_overlap": 100,   # Overlap between chunks
}
```

### Retrieval Strategies

- **vector**: Pure vector similarity using embeddings
- **bm25**: Keyword-based search (good for exact matches)
- **hybrid**: Weighted combination of vector + BM25 (often best)

### Hybrid Weights

```python
HYBRID_WEIGHTS = {
    "vector_weight": 0.7,   # 70% weight to vector similarity
    "bm25_weight": 0.3,     # 30% weight to BM25
}
```

## Troubleshooting

### Ollama Connection Error

```
Error: Could not connect to Ollama
```

**Solution**: Ensure Ollama is running:
```bash
ollama serve
```

### Model Not Found

```
Error: Model 'model-name' not found
```

**Solution**: Pull the model first:
```bash
ollama pull model-name
```

### Out of Memory

If you have many documents or large chunks:

1. Reduce `questions_per_chunk` in `config.py`
2. Use smaller embedding models
3. Process documents in batches

### No TXT Files Found

```
Error: No TXT files found in ./documents
```

**Solution**: Add TXT files to the `documents/` folder.

## Performance Considerations

### Speed
- **Vector retrieval**: Fast (~10-50ms per query)
- **BM25 retrieval**: Very fast (~1-5ms per query)
- **Hybrid retrieval**: Moderate (~20-70ms per query)

### Storage
- **Vector DB**: ~10-50 MB per 1000 chunks (depending on embedding dimension)
- **BM25 index**: ~1-5 MB per 1000 chunks

### Recommendations
- Start with 3-5 documents to test the pipeline
- Use hybrid retrieval for best quality
- Choose embedding dimension based on speed/quality tradeoff

## Citation

If you use this framework in your research, please cite:

```bibtex
@software{rag_evaluation_framework,
  title={RAG Evaluation Framework},
  author={Your Name},
  year={2025},
  url={https://github.com/yourusername/RAGTest}
}
```

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## Support

For questions and issues:
- Check [METRICS_GUIDE.md](METRICS_GUIDE.md) for metric explanations
- Review configuration in `config.py`
- Open an issue on GitHub

## Changelog

### Version 1.0 (2025-10-21)
- Initial release
- Support for Ollama models
- Vector, BM25, and Hybrid retrieval
- Comprehensive metrics (MRR, Hit Rate, Average Rank, NDCG)
- Automated QA generation
- Detailed per-question analysis

---

**Built with**: LangChain, ChromaDB, Ollama, Python 3.8+

