# Quick Start Guide

## Complete Implementation Summary

The RAG Evaluation Framework has been fully implemented with the following components:

### ✅ Core Infrastructure
- **Abstract Interfaces** (`interfaces/`)
  - `BaseLLM` - Interface for any LLM provider
  - `BaseEmbedding` - Interface for any embedding provider
  
- **Ollama Implementations** (`models/`)
  - `OllamaLLMModel` - Uses LangChain's Ollama integration
  - `OllamaEmbeddingModel` - Supports any Ollama embedding model

### ✅ Pipeline Components
- **Document Chunking** (`pipeline/chunker.py`)
  - Fixed-size chunking with overlap
  - Configurable strategies (small: 256, medium: 512, large: 1024 tokens)
  
- **QA Generation** (`pipeline/qa_generator.py`)
  - Automated question generation from documents
  - Quality filtering
  - Configurable number of questions per chunk
  
- **Ground Truth Mapping** (`pipeline/ground_truth_mapper.py`)
  - Maps questions to relevant chunks for each chunking strategy
  - Text overlap detection
  
- **Evaluation** (`pipeline/evaluator.py`)
  - Per-question evaluation
  - Multiple metrics calculation
  - Detailed result tracking

### ✅ Retrieval Strategies
- **Vector Retrieval** (`retrievers/vector_retriever.py`)
  - ChromaDB integration
  - Semantic similarity search
  - Separate collection per combination
  
- **BM25 Retrieval** (`retrievers/bm25_retriever.py`)
  - Keyword-based search
  - Shared index per chunking strategy
  - Pickle persistence
  
- **Hybrid Retrieval** (`retrievers/hybrid_retriever.py`)
  - Combines Vector + BM25
  - Configurable weights (default: 0.7 vector, 0.3 BM25)
  - Score normalization and fusion

### ✅ Utilities
- **Metrics** (`utils/metrics.py`)
  - MRR (Mean Reciprocal Rank)
  - Hit Rate@K
  - Average Rank
  - NDCG@K
  - Aggregation functions
  
- **Text Processing** (`utils/text_processing.py`)
  - Document loading
  - Token estimation
  - Text chunking
  - Combination naming

### ✅ Storage
- **Result Store** (`storage/result_store.py`)
  - QA dataset persistence
  - Detailed per-question results
  - Aggregated summaries
  - Comparison report generation

### ✅ Documentation
- **README.md** - Complete project documentation
- **METRICS_GUIDE.md** - Comprehensive metrics explanation with examples
- **Sample Documents** - 3 sample TXT files for testing

### ✅ Configuration
- **config.py** - All settings in one place
  - K values: `[1, 3, 5, 10]`
  - Chunking strategies: 3 predefined
  - Retrieval strategies: vector, bm25, hybrid
  - All paths configurable

---

## Prerequisites Setup

### 1. Install Ollama

```bash
# macOS
brew install ollama

# Or download from https://ollama.ai

# Start Ollama server (keep this running)
ollama serve
```

### 2. Pull Required Models

In a new terminal:

```bash
# LLM for question generation
ollama pull llama3.2

# Embedding models for testing
ollama pull nomic-embed-text
ollama pull mxbai-embed-large
```

### 3. Python Environment

```bash
# Navigate to project
cd /Users/sujith/Tech/RAGTest

# Activate your virtual environment
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

---

## Running the Framework

### Option 1: Use Sample Documents (Quickest)

```bash
python app.py
```

The framework will:
1. Load 3 sample documents (Python, ML, Web Dev)
2. Generate ~30-50 questions
3. Test 18 combinations (3 chunking × 2 embeddings × 3 retrieval)
4. Save all results to `outputs/`

**Expected Runtime**: 10-20 minutes depending on your machine

### Option 2: Use Your Own Documents

```bash
# Add your TXT files
cp /path/to/your/*.txt documents/

# Run evaluation
python app.py
```

---

## Configuration Examples

### Change K Values

Edit `config.py`:

```python
K_VALUES = [1, 5, 10]  # Evaluate at K=1, 5, 10
```

### Adjust Questions

```python
QA_CONFIG = {
    "questions_per_chunk": 3,        # More questions per chunk
    "total_questions_limit": 100,    # Cap at 100 questions
}
```

### Change Ollama Models

```python
OLLAMA_CONFIG = {
    "llm_model": "llama3.1",         # Different LLM
    "embedding_models": [
        "nomic-embed-text",
        "all-minilm",                # Add more models
    ],
}
```

### Add Chunking Strategy

```python
CHUNKING_STRATEGIES = [
    # ... existing strategies ...
    {
        "name": "extra_large_chunks",
        "chunk_size": 2048,
        "chunk_overlap": 400,
    },
]
```

### Adjust Hybrid Weights

```python
HYBRID_WEIGHTS = {
    "vector_weight": 0.8,  # More weight to vector search
    "bm25_weight": 0.2,    # Less weight to keyword search
}
```

---

## Understanding Output

### Directory Structure

```
outputs/
├── qa_dataset.json                    # Generated questions (one-time)
│
├── chromadb/                          # Vector databases
│   ├── small_chunks_nomic_embed_text_vector/
│   ├── medium_chunks_nomic_embed_text_hybrid/
│   └── ... (one per combination with vector/hybrid)
│
├── bm25_indices/                      # BM25 indices
│   ├── small_chunks_bm25.pkl
│   ├── medium_chunks_bm25.pkl
│   └── large_chunks_bm25.pkl
│
└── evaluations/                       # Results
    ├── {combination}_detailed.json    # Per-question results
    ├── {combination}_summary.json     # Aggregated metrics
    └── comparison_report.json         # Best performers
```

### Key Files

**comparison_report.json** - START HERE
- Shows best combination for each metric
- Top 5 overall combinations
- Full comparison matrix

**{combination}_summary.json**
- Aggregated metrics for one combination
- Total chunks, questions evaluated
- Configuration used

**{combination}_detailed.json**
- Every question's results
- Retrieved chunks with scores
- Relevance markers

---

## Interpreting Results

### Good Performance Indicators

```json
{
  "mrr": 0.75,              // ✓ Good (correct chunk usually in top 2)
  "hit_rate@5": 0.90,       // ✓ Great (90% success rate)
  "average_rank": 2.1,      // ✓ Good (typically position 2)
  "ndcg@5": 0.82           // ✓ Good ranking quality
}
```

### Poor Performance Indicators

```json
{
  "mrr": 0.25,              // ✗ Poor (correct chunk around position 4)
  "hit_rate@5": 0.50,       // ✗ Poor (50% of queries fail)
  "average_rank": 5.8,      // ✗ Poor (far down the list)
  "ndcg@5": 0.35           // ✗ Poor ranking
}
```

### What to Look For

1. **Best MRR** = Best overall retrieval quality
2. **Best Hit@5** = Most reliable retrieval
3. **Lowest Avg Rank** = Most consistent performance
4. **Best NDCG** = Best ranking optimization

---

## Troubleshooting

### "Could not connect to Ollama"
```bash
# Make sure Ollama is running
ollama serve
```

### "Model not found"
```bash
# Pull the model first
ollama pull model-name
```

### "No TXT files found"
```bash
# Add TXT files to documents folder
ls documents/*.txt
```

### Memory Issues
```python
# Reduce questions in config.py
QA_CONFIG = {
    "questions_per_chunk": 1,  # Generate fewer questions
}
```

---

## Next Steps

### 1. Run Initial Evaluation
```bash
python app.py
```

### 2. Review Results
```bash
# Check comparison report
cat outputs/evaluations/comparison_report.json | python -m json.tool

# Or open in text editor
open outputs/evaluations/comparison_report.json
```

### 3. Iterate
- Adjust chunking strategies based on results
- Try different embedding models
- Modify hybrid weights
- Add more questions for better evaluation

### 4. Use Best Configuration
The ChromaDB collection of your best combination is ready to use in production!

```python
# Example: Use the best performing combination
from retrievers import VectorRetriever
from models import OllamaEmbeddingModel

embedding = OllamaEmbeddingModel("nomic-embed-text", "http://localhost:11434")
retriever = VectorRetriever(
    collection_name="medium_chunks_nomic_embed_text_hybrid",
    embedding_model=embedding,
    persist_directory="./outputs/chromadb"
)

# Query
results = retriever.retrieve("your query here", k=5)
```

---

## Adding Custom Models

### Example: Adding OpenAI Embeddings

1. Create new implementation:

```python
# models/openai_embedding.py
from interfaces.base_embedding import BaseEmbedding
from openai import OpenAI

class OpenAIEmbeddingModel(BaseEmbedding):
    def __init__(self, model_name="text-embedding-3-small"):
        self.model_name = model_name
        self.client = OpenAI()
    
    def embed_documents(self, texts):
        response = self.client.embeddings.create(
            input=texts,
            model=self.model_name
        )
        return [item.embedding for item in response.data]
    
    def embed_query(self, text):
        return self.embed_documents([text])[0]
    
    def get_model_name(self):
        return self.model_name
    
    def get_dimension(self):
        return 1536  # for text-embedding-3-small
```

2. Use in app.py - just swap the implementation!

---

## Framework Features

✅ Modular design - easy to extend
✅ Complete traceability - every result stored
✅ Multiple retrieval strategies - vector, BM25, hybrid
✅ Comprehensive metrics - MRR, Hit Rate, Avg Rank, NDCG
✅ Production-ready DBs - use best combination directly
✅ Configurable everything - K values, strategies, models
✅ Sample documents included - test immediately

---

## Support

- **Metrics unclear?** → Read `METRICS_GUIDE.md`
- **Setup questions?** → Read `README.md`
- **Configuration?** → Check `config.py` comments

---

**Framework Version**: 1.0  
**Implementation Date**: 2025-10-21  
**Status**: ✅ Complete and Ready to Use

