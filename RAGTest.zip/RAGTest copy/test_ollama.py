"""Test if Ollama model works"""

from models.ollama_llm import OllamaLLMModel

print("Testing Ollama connection...")

try:
    llm = OllamaLLMModel(
        model_name="qwen2.5-coder:14b",
        base_url="http://localhost:11434"
    )
    
    print("✓ LLM initialized")
    print("Testing simple generation...")
    
    response = llm.generate("Say hello in one word.")
    print(f"✓ Response: {response}")
    
    print("\n SUCCESS - Ollama is working!")
    
except Exception as e:
    print(f"✗ ERROR: {e}")
    import traceback
    traceback.print_exc()

