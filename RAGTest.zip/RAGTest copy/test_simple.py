"""Simplest possible test"""

import os

print("Test 1: List files")
files = os.listdir("./documents")
print(f"Files: {files}")

print("\nTest 2: Read file")
with open("./documents/test_tiny.txt", 'r') as f:
    content = f.read()
    print(f"Content length: {len(content)} chars")
    print(f"First 100 chars: {content[:100]}")

print("\nTest 3: Import our modules")
from utils.text_processing import load_documents

print("Calling load_documents...")
docs = load_documents("./documents")
print(f"Loaded {len(docs)} documents")

print("\n✓ SUCCESS")

