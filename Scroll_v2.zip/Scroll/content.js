let throttleTimerScroll = false;
window.addEventListener("scroll", () => {
  if (!throttleTimerScroll) {
    throttleTimerScroll = true;
    setTimeout(() => {
      const message = {
        type: "scroll",
        scrollX:window.scrollX,
        scrollY: window.scrollY
      };

      chrome.runtime.sendMessage(message);
      throttleTimerScroll = false;
    }, 10); // Adjust throttle time as needed
  }
});


let throttleTimerSize = false;
window.addEventListener("resize", () => {
  if (!throttleTimerSize) {
    throttleTimerSize = true;
    setTimeout(() => {
      const message = {
        type: "size",
        "viewportWidth": window.innerWidth,
        "viewportHeight": window.innerHeight
      };

      chrome.runtime.sendMessage(message);
      throttleTimerSize = false;
    }, 10); // Adjust throttle time as needed
  }
});


function SendViewportSize()
{
    const message = {
        type: "size",
        "viewportWidth": window.innerWidth,
        "viewportHeight": window.innerHeight
    };

    chrome.runtime.sendMessage(message);

}


setInterval(SendViewportSize, 1000);

