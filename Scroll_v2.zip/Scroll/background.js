function getWindowSize(ws) {
  chrome.windows.getCurrent({ populate: true }, function (window) {
    json = {
      windowId: window.id,
      windowWidth: window.width,
      windowHeight: window.height,
      windowTop: window.top,
      windowLeft: window.left,
    };
    console.log("Window Size :");
    console.log(json);
  });
}

function TabActivationListener(ws) {
  chrome.tabs.onActivated.addListener(function (activeInfo) {
    chrome.windows.getCurrent({ populate: true }, function (window) {
      json = {
        windowId: window.id,
        tabId: activeInfo.tabId,
        windowWidth: window.width,
        windowHeight: window.height,
        windowTop: window.top,
        windowLeft: window.left,
      };
      //// viewport addition
      console.log("Tab Activation : ");
      console.log(json);
    });
  });
}

function WindowFocusListener(ws) {
  chrome.windows.onFocusChanged.addListener(function (windowId) {
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
      console.log("Browser window has lost focus");
    } else {
      chrome.tabs.query({ active: true, windowId: windowId }, function (tabs) {
        if (tabs.length > 0) {
          json = {
            windowId: tabs[0].windowId,
            tabId: tabs[0].id,
          };
          console.log("Window Focused");
          console.log(json);
        }
      });
    }
  });
}


function WindowScrollListener(ws) {
  chrome.runtime.onMessage.addListener(function (
    message,
    sender,
    sendResponse
  ) {
    if (message.type === "scroll") {
      chrome.tabs.query(
        { active: true, windowId: sender.tab.windowId },
        function (tabs) {
          if (tabs.length > 0) {
            json = {
              windowId: tabs[0].windowId,
              tabId: tabs[0].id,
              scrollX: message.scrollX,
              scrollY: message.scrollY,
            };
            console.log("Scroll Event : ");
            console.log(json);
          }
        }
      );
    }
  });
}

function WindowSizeListener(ws) {
  chrome.runtime.onMessage.addListener(function (
    message,
    sender,
    sendResponse
  ) {
    if (message.type === "size") {
      chrome.windows.getCurrent({ populate: true }, function (window) {
        chrome.tabs.query(
          { active: true, windowId: window.id },
          function (tabs) {
            if (tabs.length > 0) {
              json = {
                windowId: window.id,
                tabId: tabs[0].id,
                windowWidth: window.width,
                windowHeight: window.height,
                windowTop: window.top,
                windowLeft: window.left,
                viewportWidth: message.viewportWidth,
                viewportHeight: message.viewportHeight,
              };
              console.log("Resize Event : ");
              console.log(JSON.stringify(json));
            }
          }
        );
      });
    }
  });
}



function WindowBoundsListener(ws) {
  chrome.windows.onBoundsChanged.addListener(function (window) {
    chrome.tabs.query({ active: true, windowId: window.id }, function (tabs) {
      if (tabs.length > 0) {
        json = {
          windowId: tabs[0].windowId,
          tabId: tabs[0].id,
          windowWidth: window.width,
          windowHeight: window.height,
          windowTop: window.top,
          windowLeft: window.left,
        };
        console.log("Window Bounds Change :");
        console.log(json);
      }
    });
  });
}

function SubscribeEvents(ws)
{
  setInterval(getWindowSize, 15000);
  TabActivationListener(ws);
  WindowFocusListener(ws);
  WindowScrollListener(ws);
  WindowSizeListener(ws);
  WindowBoundsListener(ws);
}

function StartWSClient() {
  try {
    ws = new WebSocket("ws://localhost:8088/");

    ws.onopen = function () {
      console.log("WebSocket connection established");
      SubscribeEvents(ws);
    };

    ws.onmessage = function (event) {
      console.log("Received:", event.data);
    };

    ws.onerror = function (error) {
      console.error("WebSocket error:", error);
    };

    ws.onclose = function (event) {
      console.log("WebSocket connection closed:", event);
      setTimeout(StartWSClient, 1000);
    };
  } catch (error) {
    console.log(error);
  }
}

StartWSClient();