function ScrollAndPositionEvents(ws) {
  chrome.runtime.onMessage.addListener(function (
    message,
    sender,
    sendResponse
  ) {
    if (message.type === "scrollEvent") {
      console.log("Scroll Position:", message.position);
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        console.log("tab id  : " + tabs[0].id);
        var obj = {
          windowId: tabs[0].windowId,
          tabID: tabs[0].id,
          scrollX: message.position.x,
          scrollY: message.position.y,
        };
        ws.send(JSON.stringify(obj));
      });
    }
    if (message.type === "windowResize") {
      console.log("Window size:", message.size);
      // ws.send(message.size);
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        console.log("tab id  : " + tabs[0].id);
        var obj = {
          windowId: tabs[0].windowId,
          tabID: tabs[0].id,
          width: message.size.width,
          height: message.size.height,
        };
        ws.send(JSON.stringify(obj));
      });
    }
  });
}

function WindowFocusEvents(ws) {
  chrome.windows.onFocusChanged.addListener((windowId) => {
    // windowId contains the ID of the newly focused window
    console.log("Focus Changed");
    if (windowId !== chrome.windows.WINDOW_ID_NONE) {
      console.log(`Window focused: ${windowId}`);
      // You can also check which tab is active in the newly focused window
      chrome.tabs.query({ active: true, windowId: windowId }, function (tabs) {
        if (tabs.length > 0) {
          let activeTab = tabs[0];
          console.log(`Active tab in focused window: ${activeTab.url}`);
          var obj = {
            windowId: windowId,
            tabID: tabs[0].id,
          };
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: (injectedData) => {
              // This code runs in the context of the webpage
              // You can access injectedData directly here
          
              // Example: Set a global variable in the page's context
              window.myInjectedData = injectedData;
          
              // If you need to pass the data to an existing content script,
              // you can use window.dispatchEvent or other DOM methods
              const event = new CustomEvent('GetDocSize', { detail: injectedData });
              window.dispatchEvent(event);
            },
            args: [obj] // Passing data as an argument to the injected function
          });
          ws.send(JSON.stringify(obj));
        }
      });
    }
  });
}

function TabChangeEvents(ws) {
  chrome.tabs.onActivated.addListener((activeInfo) => {
    // activeInfo.tabId contains the ID of the activated tab
    // activeInfo.windowId contains the ID of the window the tab belongs to
    console.log(
      `Tab activated: ${activeInfo.tabId} in window ${activeInfo.windowId}`
    );

    // Optionally, get more information about the activated tab
    chrome.tabs.get(activeInfo.tabId, function (tab) {
      console.log(`Switched to URL: ${tab.url}`);
      var obj = {
        windowId: tab.windowId,
        tabID: tab.id,
      };
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: (injectedData) => {
          // This code runs in the context of the webpage
          // You can access injectedData directly here
      
          // Example: Set a global variable in the page's context
          window.myInjectedData = injectedData;
      
          // If you need to pass the data to an existing content script,
          // you can use window.dispatchEvent or other DOM methods
          const event = new CustomEvent('GetDocSize', { detail: injectedData });
          window.dispatchEvent(event);
        },
        args: [obj] // Passing data as an argument to the injected function
      });
      ws.send(JSON.stringify(obj));
    });
  });
}

function DocumentSizeEvents(ws) {
  // chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  //   // Check if the tab's status is 'complete' to ensure the page has finished loading
  //   if (changeInfo.status === "complete") {
  //     // Execute the content script to get document dimensions
  //     chrome.scripting.executeScript({
  //       target: { tabId: tabId },
  //       files: ["documentSize.js"],
  //     });
  //   }
  // });

  // chrome.tabs.onActivated.addListener((activeInfo) => {
  //   // Use setTimeout to give the tab some time to load
  //   setTimeout(() => {
  //     chrome.tabs.get(activeInfo.tabId, (tab) => {
  //       // Ensure the tab hasn't been closed
  //       // if (chrome.runtime.lastError) {
  //       //   console.log(chrome.runtime.lastError.message);
  //       //   return;
  //       // }
  //       if (tab.status === "complete") {
  //         // Execute the content script to get document dimensions
  //         chrome.scripting.executeScript({
  //           target: { tabId: activeInfo.tabId },
  //           files: ["documentSize.js"],
  //         });
  //       }
  //     });
  //   }, 1000); // Adjust delay as necessary
  // });

  // In background.js or popup.js

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    //console.log("Received dimensions:", message.width, "x", message.height);
    // Process the dimensions as needed
    console.log("---- "+JSON.stringify(message));
  });
}

function SubscribeEvents(ws) {
  ScrollAndPositionEvents(ws);
  WindowFocusEvents(ws);
  TabChangeEvents(ws);
  DocumentSizeEvents(ws);
}

function connectWebSocket() {
  ws = new WebSocket("ws://localhost:8088/");

  ws.onopen = function () {
    console.log("WebSocket connection established");
    //retryInterval = 1000; // Reset retry interval after a successful connection
    // ws.send("Hello");
    SubscribeEvents(ws);
  };

  ws.onmessage = function (event) {
    console.log("Received:", event.data);
  };

  ws.onerror = function (error) {
    console.error("WebSocket error:", error);
  };

  ws.onclose = function (event) {
    console.log("WebSocket connection closed:", event);
    // Attempt to reconnect with a delay
    setTimeout(connectWebSocket, 1000);
  };
}

connectWebSocket();

/*

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.type === "scrollEvent") {
        console.log("Scroll Position:", message.position);
        // Update popup or handle the scroll event as needed
        // This could involve updating some shared state or storing the scroll data
    }
    if (message.type === "windowResize") {
        console.log("Window size:", message.size);
        // Here, you could update some state or forward this information to a popup.
    }
});


// background.js

let lastX = null;
let lastY = null;

function checkWindowPosition() {
    chrome.windows.getCurrent({}, function(window) {
        const { left, top } = window;
        if (left !== lastX || top !== lastY) {
            console.log(`Window moved: New position X=${left}, Y=${top}`);
            // Here, you could do something with the new position, such as
            // sending a message to a content script or updating a badge.

            // Update last known position
            lastX = left;
            lastY = top;
        }
        ws.send(JSON.stringify({ message: 'Hello, server!' }));

    });
}

// Start polling with an interval of 1 second (1000 milliseconds).
// Adjust the interval as needed based on desired responsiveness and resource usage.
setInterval(checkWindowPosition, 5000);


chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    console.log("tab id  : "+tabs[0].id);
});


// background.js

// Listen for tab activation (switch) within the same window
chrome.tabs.onActivated.addListener(activeInfo => {
    // activeInfo.tabId contains the ID of the activated tab
    // activeInfo.windowId contains the ID of the window the tab belongs to
    console.log(`Tab activated: ${activeInfo.tabId} in window ${activeInfo.windowId}`);
    
    // Optionally, get more information about the activated tab
    chrome.tabs.get(activeInfo.tabId, function(tab) {
      console.log(`Switched to URL: ${tab.url}`);
    });
  });
  
  // Listen for window focus changes
  chrome.windows.onFocusChanged.addListener(windowId => {
    // windowId contains the ID of the newly focused window
    console.log("Focus Changed");
    if (windowId !== chrome.windows.WINDOW_ID_NONE) {
      console.log(`Window focused: ${windowId}`);
      // You can also check which tab is active in the newly focused window
      chrome.tabs.query({active: true, windowId: windowId}, function(tabs) {
        if (tabs.length > 0) {
          let activeTab = tabs[0];
          console.log(`Active tab in focused window: ${activeTab.url}`);
        }
      });
    }
  });
  






  */
