package com.example.chat3

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ChatState(
    val messages: List<ChatMessage> = emptyList()
)

data class ChatMessage(
    val content: String,
    val isUser: Boolean
)

class ChatViewModel : ViewModel() {
    private val _chatState = MutableStateFlow(ChatState())
    val chatState: StateFlow<ChatState> = _chatState.asStateFlow()

    fun sendMessage(message: String) {
        _chatState.update { currentState ->
            val updatedMessages = currentState.messages + ChatMessage(message, true)
            currentState.copy(messages = updatedMessages)
        }
        // Here you would typically call the LLM API and update the state with the response
        // For this example, we'll just echo the message
        _chatState.update { currentState ->
            val updatedMessages = currentState.messages + ChatMessage("You said: $message", false)
            currentState.copy(messages = updatedMessages)
        }
    }
}