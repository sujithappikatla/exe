package com.example.chat3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.chat3.followup.BottomRoundedDiv

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BottomRoundedDiv()
        }
    }
}

@Composable
fun ChatApp(viewModel: ChatViewModel = viewModel()) {
    val chatState by viewModel.chatState.collectAsState()

    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column {
                InputOptions(
                    onKeyboardInput = { viewModel.sendMessage(it) },
                    onMicInput = { /* Implement speech-to-text */ },
                    onDrawingInput = { /* Implement drawing-to-text */ }
                )
                ChatMessages(messages = chatState.messages)

            }
        }
    }
}