package com.example.chat3


import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LLMSelectorUI() {
    var selectedTextModel by remember { mutableStateOf<String?>(null) }
    var selectedImageModel by remember { mutableStateOf<String?>(null) }
    var selectedImageSize by remember { mutableStateOf<String?>(null) }
    var selectedSpeechToTextModel by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "LLM Model Selector",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            ModelSection(
                title = "Text Models",
                options = listOf("GPT-4", "Claude 3.5 Sonnet", "Gemini 1.5"),
                selectedOption = selectedTextModel,
                onOptionSelected = { selectedTextModel = it },
                icon = Icons.Default.ChatBubble
            )

            Spacer(modifier = Modifier.height(16.dp))

            ModelSection(
                title = "Image Models",
                options = listOf("DALL-E 2", "DALL-E 3", "Stable Diffusion", "Amazon Titan"),
                selectedOption = selectedImageModel,
                onOptionSelected = { selectedImageModel = it },
                icon = Icons.Default.Image
            )

            if (selectedImageModel == "DALL-E 2") {
                Spacer(modifier = Modifier.height(8.dp))
                ImageSizeSelector(
                    selectedSize = selectedImageSize,
                    onSizeSelected = { selectedImageSize = it }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            ModelSection(
                title = "Speech to Text Models",
                options = listOf("Whisper", "Deepgram's Nova-2", "Universal's Coherence"),
                selectedOption = selectedSpeechToTextModel,
                onOptionSelected = { selectedSpeechToTextModel = it },
                icon = Icons.Default.Mic
            )
        }
    }
}

@Composable
fun ModelSection(
    title: String,
    options: List<String>,
    selectedOption: String?,
    onOptionSelected: (String) -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            options.forEach { option ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = option == selectedOption,
                        onClick = { onOptionSelected(option) }
                    )
                    Text(
                        text = option,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ImageSizeSelector(
    selectedSize: String?,
    onSizeSelected: (String) -> Unit
) {
    val sizes = listOf("256x256", "512x512", "1024x1024")
    Column(
        modifier = Modifier.padding(start = 32.dp)
    ) {
        Text(
            "Image Size:",
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        sizes.forEach { size ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = size == selectedSize,
                    onClick = { onSizeSelected(size) }
                )
                Text(
                    text = size,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
    }
}