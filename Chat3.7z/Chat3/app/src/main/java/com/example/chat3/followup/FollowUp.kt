package com.example.chat3.followup

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaRecorder
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File


class DeepgramWebSocket(private val apiKey: String) : WebSocketListener() {
    private var webSocket: WebSocket? = null
    var onTranscriptionReceived: ((String) -> Unit)? = null

    fun connect() {
        val request = Request.Builder()
            .url("wss://api.deepgram.com/v1/listen?model=nova-2")
            .addHeader("Authorization", "Token $apiKey")
            .build()

        val client = OkHttpClient()
        webSocket = client.newWebSocket(request, this)
    }

    fun sendAudioData(audioData: ByteArray) {
        webSocket?.send(ByteString.of(*audioData))
    }

    override fun onMessage(webSocket: WebSocket, text: String) {
        val json = JSONObject(text)
        val transcript = json.getJSONObject("channel")
            .getJSONArray("alternatives")
            .getJSONObject(0)
            .getString("transcript")
        onTranscriptionReceived?.invoke(transcript)
    }

    fun close() {
        webSocket?.close(1000, null)
    }
}

fun safeStopRecording(mediaRecorder: MediaRecorder) {
    try {
        mediaRecorder.stop()
    } catch (e: IllegalStateException) {
        // Log the error or handle it as needed
        println("Error stopping MediaRecorder: ${e.message}")
    }
}

@Composable
fun VoiceRecordingDialog(
    onDismiss: () -> Unit,
    onTranscriptionComplete: (String) -> Unit
) {
    var isRecording by remember { mutableStateOf(false) }
    var transcription by remember { mutableStateOf("") }
    val mediaRecorder = remember { MediaRecorder() }
    val deepgramWebSocket = remember { DeepgramWebSocket("9103bae5d34c6fc24d557c4fea245a0f8ae21bf2") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasAudioPermission = isGranted
        if (isGranted) {
            startRecording(mediaRecorder) { audioData ->
                scope.launch {
                    deepgramWebSocket.sendAudioData(audioData)
                }
            }
            isRecording = true
        }
    }

    LaunchedEffect(Unit) {
        deepgramWebSocket.onTranscriptionReceived = { newTranscription ->
            transcription += " $newTranscription"
            launch {
                scrollState.animateScrollTo(scrollState.maxValue)
            }
        }
        deepgramWebSocket.connect()

        if (hasAudioPermission) {
            startRecording(mediaRecorder) { audioData ->
                scope.launch {
                    deepgramWebSocket.sendAudioData(audioData)
                }
            }
            isRecording = true
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            if (isRecording) {
                safeStopRecording(mediaRecorder)
            }
            mediaRecorder.release()
            deepgramWebSocket.close()
        }
    }

    val pulsateAnimation = rememberInfiniteTransition().animateFloat(
        initialValue = 1f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ), label = ""
    )

    Dialog(
        onDismissRequest = { /* Do nothing to prevent dismissal on outside click */ }
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.4f)  // Decreased height to 50% of screen height
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(3.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Spacer(modifier = Modifier.width(24.dp)) // To balance the close button
                    IconButton(
                        onClick = {
                            if (isRecording) {
                                safeStopRecording(mediaRecorder)
                            }
                            onDismiss()
                        },
                        modifier = Modifier.align(Alignment.Top)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }


                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(x=0.dp, y=-10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                )
                {
                    IconButton(
                        onClick = {
                            if (isRecording) {
                                safeStopRecording(mediaRecorder)
                            } else {
                                startRecording(mediaRecorder) { audioData ->
                                    scope.launch {
                                        deepgramWebSocket.sendAudioData(audioData)
                                    }
                                }
                            }
                            isRecording = !isRecording
                        },
                        modifier = Modifier
                            .size(64.dp)
                            .offset(x=0.dp, y=0.dp)
                            .scale(if (isRecording) pulsateAnimation.value else 1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = if (isRecording) "Stop Recording" else "Start Recording",
                            tint = if (isRecording) Color.Red else Color.Gray,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color.LightGray.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = if (hasAudioPermission) transcription else "Microphone permission is required to record audio.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Left,
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(scrollState)
                                .padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    IconButton(
                        onClick = {
                            if (isRecording) {
                                safeStopRecording(mediaRecorder)
                                isRecording = false
                            }
                            onTranscriptionComplete(transcription)
                            onDismiss()
                        },
                        enabled = transcription.isNotEmpty()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = if (transcription.isNotEmpty()) MaterialTheme.colorScheme.primary else Color.Gray
                        )
                    }
                }
            }
        }
    }
}


fun startRecording(mediaRecorder: MediaRecorder, onAudioData: (ByteArray) -> Unit) {
    val outputFile = File.createTempFile("audio", ".pcm")
    mediaRecorder.apply {
        setAudioSource(MediaRecorder.AudioSource.MIC)
        setOutputFormat(MediaRecorder.OutputFormat.AMR_NB)
        setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
        setOutputFile(outputFile.absolutePath)
        prepare()
        start()
    }

    // Start a coroutine to read and send audio data
    GlobalScope.launch(Dispatchers.IO) {
        val buffer = ByteArray(1024)
        outputFile.inputStream().use { input ->
            while (isActive) {
                val bytesRead = input.read(buffer)
                if (bytesRead > 0) {
                    onAudioData(buffer.copyOf(bytesRead))
                }
            }
        }
    }
}

fun stopRecording(mediaRecorder: MediaRecorder) {
    mediaRecorder.stop()
    mediaRecorder.reset()
}



@Composable
fun HandwritingCanvas(
    onDismiss: () -> Unit,
    onSend: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var paths by remember { mutableStateOf(listOf<Path>()) }
    val currentPath = remember { Path() }
    val drawColor = remember { Color.Black }
    val strokeWidth = 8f
    val density = LocalDensity.current

    var canvasWidth by remember { mutableStateOf(0f) }
    var canvasHeight by remember { mutableStateOf(0f) }

    Box(
        modifier = modifier
            .aspectRatio(16f / 9f)
            .shadow(elevation = 8.dp, shape = RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .padding(16.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            currentPath.moveTo(offset.x, offset.y)
                        },
                        onDrag = { change, _ ->
                            currentPath.lineTo(change.position.x, change.position.y)
                            paths = paths + Path().apply { addPath(currentPath) }
                        },
                        onDragEnd = {
                            paths = paths + Path().apply { addPath(currentPath) }
                            currentPath.reset()
                        }
                    )
                }
        ) {
            canvasWidth = size.width
            canvasHeight = size.height

            paths.forEach { path ->
                drawPath(
                    path = path,
                    color = drawColor,
                    style = Stroke(width = strokeWidth)
                )
            }
            drawPath(
                path = currentPath,
                color = drawColor,
                style = Stroke(width = strokeWidth)
            )
        }

        IconButton(
            onClick = onDismiss,
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Icon(Icons.Default.Close, contentDescription = "Close")
        }

        IconButton(
            onClick = {
                val base64Image = canvasToBase64(canvasWidth, canvasHeight, paths, drawColor, strokeWidth)
                onSend(base64Image)
            },
            modifier = Modifier.align(Alignment.BottomEnd)
        ) {
            Icon(Icons.Default.Send, contentDescription = "Send")
        }
    }
}

fun canvasToBase64(width: Float, height: Float, paths: List<Path>, color: Color, strokeWidth: Float): String {
    val bitmap = Bitmap.createBitmap(width.toInt(), height.toInt(), Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)

    val paint = android.graphics.Paint().apply {
        this.color = color.toArgb()
        this.strokeWidth = strokeWidth
        this.style = android.graphics.Paint.Style.STROKE
    }

    paths.forEach { path ->
        canvas.drawPath(path.asAndroidPath(), paint)
    }

    val outputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
    return Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT)
}



@Composable
fun RainbowBorderTextInput(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    val rainbowColors = listOf(
        Color.Red,
        Color(0xFFFF7F00),  // Orange
        Color.Yellow,
        Color.Green,
        Color.Blue,
        Color(0xFF4B0082),  // Indigo
        Color(0xFF9400D3)   // Violet
    )

    Box(
        modifier = modifier
            .shadow(elevation = 4.dp, shape = RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(colors = rainbowColors))
            .padding(2.dp)  // This creates the border effect
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .focusRequester(focusRequester),
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    decorationBox = { innerTextField ->
                        Box {
                            if (value.isEmpty()) {
                                Text(
                                    "Type your message...",
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                            innerTextField()
                        }
                    }
                )
                IconButton(onClick = onCancel) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                IconButton(onClick = onSend) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }
}

@Composable
fun BottomRoundedDiv() {
    var showTextInput by remember { mutableStateOf(false) }
    var showCanvas by remember { mutableStateOf(false) }
    var showVoiceRecording by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }
    var canvasImage by remember { mutableStateOf<String?>(null) }
    var transcription by remember { mutableStateOf("") }  // New state variable for transcription

    val gradientColors = listOf(
        Color(0xFF3D5A80),
        Color(0xFF2A4365),
        Color(0xFF1E3A8A)
    )
    val borderColor = Color.LightGray.copy(alpha = 0.5f)
    val cornerRadius = 28.dp

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (showTextInput) {
            RainbowBorderTextInput(
                value = inputText,
                onValueChange = { inputText = it },
                onSend = {
                    showTextInput = false
                    inputText = ""
                },
                onCancel = {
                    showTextInput = false
                    inputText = ""
                },
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .padding(horizontal = 16.dp)
            )
        }

        if (showCanvas) {
            HandwritingCanvas(
                onDismiss = { showCanvas = false },
                onSend = { base64Image ->
                    canvasImage = base64Image
                    showCanvas = false
                },
                modifier = Modifier
                    .fillMaxWidth(0.9f)
            )
        }

        if (showVoiceRecording) {
            VoiceRecordingDialog(
                onDismiss = { showVoiceRecording = false },
                onTranscriptionComplete = { newTranscription ->
                    transcription = newTranscription  // Store transcription in state variable
                    showVoiceRecording = false
                }
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(cornerRadius))
                    .shadow(
                        elevation = 8.dp,
                        shape = RoundedCornerShape(cornerRadius),
                        clip = true
                    ),
                shape = RoundedCornerShape(cornerRadius),
                border = BorderStroke(1.dp, borderColor),
                color = Color.Transparent
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(colors = gradientColors)
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        // Centered "Ask follow-up" text with '+' icon
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "Ask follow-up",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Spacer to push icons to the right
                        Spacer(modifier = Modifier.width(16.dp))

                        // Three icons side by side
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { showTextInput = !showTextInput }) {
                                Icon(
                                    imageVector = Icons.Default.Keyboard,
                                    contentDescription = "Keyboard",
                                    tint = Color.White
                                )
                            }
                            IconButton(onClick = { showCanvas = !showCanvas }) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Drawing board",
                                    tint = Color.White
                                )
                            }
                            IconButton(onClick = { showVoiceRecording = true }) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Microphone",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}