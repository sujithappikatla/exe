import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import rehypeHighlight from 'rehype-highlight';
import { FileText, Image, FileIcon, Download, ChevronDown, ChevronUp, Bot, User, Terminal } from 'lucide-react';
import 'katex/dist/katex.min.css';
import 'highlight.js/styles/github-dark.css';
import type { Message, MessagePart } from '../App';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { useState } from 'react';

interface AttachedFileDisplayProps {
  id: string;
  file: File;
  type: 'image' | 'pdf' | 'text' | 'other';
}

interface ChatMessageDisplayProps {
  message: Message;
}

export function ChatMessageDisplay({ message }: ChatMessageDisplayProps) {
  const { isUser, timestamp, modelName, attachedFiles, parts } = message;

  const getFileIcon = (type: AttachedFileDisplayProps['type']) => {
    switch (type) {
      case 'image': return <Image className="h-4 w-4" />;
      case 'pdf': return <FileText className="h-4 w-4" />;
      case 'text': return <FileText className="h-4 w-4" />;
      default: return <FileIcon className="h-4 w-4" />;
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileDownload = (file: File) => {
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const renderAttachedFiles = () => {
    if (!attachedFiles || attachedFiles.length === 0) return null;

    // If more than 2 files, show as list
    if (attachedFiles.length > 2) {
      return (
        <div className="mb-3">
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3 border border-gray-200/50 dark:border-gray-600/50">
            <div className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
              {attachedFiles.length} files attached
            </div>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {attachedFiles.map((attachedFile) => (
                <div key={attachedFile.id} className="flex items-center gap-2 text-sm">
                  <div className="flex-shrink-0">
                    {getFileIcon(attachedFile.type)}
                  </div>
                  <span className="flex-1 truncate">{attachedFile.file.name}</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {formatFileSize(attachedFile.file.size)}
                  </span>
                  <button
                    onClick={() => handleFileDownload(attachedFile.file)}
                    className="flex-shrink-0 p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition-colors"
                  >
                    <Download className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
    }

    // For 1-2 files, show individual cards/previews
    return (
      <div className="mb-3 space-y-2">
        {attachedFiles.map((attachedFile) => (
          <div key={attachedFile.id}>
            {attachedFile.type === 'image' ? (
              <div className="relative group">
                <img
                  src={URL.createObjectURL(attachedFile.file)}
                  alt={attachedFile.file.name}
                  className="max-w-full h-auto rounded-lg shadow-sm max-h-32 object-cover"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors rounded-lg flex items-center justify-center">
                  <button
                    onClick={() => handleFileDownload(attachedFile.file)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 dark:bg-gray-800/90 rounded-full p-2 shadow-lg"
                  >
                    <Download className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200/50 dark:border-gray-600/50">
                <div className="flex-shrink-0">
                  {getFileIcon(attachedFile.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{attachedFile.file.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {formatFileSize(attachedFile.file.size)}
                  </p>
                </div>
                <button
                  onClick={() => handleFileDownload(attachedFile.file)}
                  className="flex-shrink-0 p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition-colors"
                >
                  <Download className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  // Component to render individual message parts (text, tool_call_request, tool_call_result)
  const MessagePartDisplay = ({ part }: { part: MessagePart }) => {
    const [isToolContentOpen, setIsToolContentOpen] = useState(false);
    console.log(part);
    if (part.type === 'text') {
      console.log(part.text_content);
      return (
        <div className="prose prose-sm sm:prose-base dark:prose-invert max-w-none">
          <ReactMarkdown
            remarkPlugins={[remarkGfm, remarkMath]}
            rehypePlugins={[
              [rehypeKatex, {
                strict: false,
                trust: true,
                throwOnError: false,
                errorColor: '#cc0000',
                macros: {
                  "\\eqref": "\\href{###1}{(\\text{#1})}",
                  "\\ref": "\\href{###1}{\\text{#1}}",
                  "\\label": "\\htmlId{#1}{}"
                }
              }],
              [rehypeHighlight, { detect: true, ignoreMissing: true }]
            ]}
            components={{
              pre: ({node, ...props}) => (
                <pre className="rounded-lg bg-gray-900 p-4 overflow-x-auto my-4 hljs" {...props} />
              ),
              code: ({node, className, children, ...props}) => {
                const match = /language-(\w+)/.exec(className || '');
                if (!match) {
                  return (
                    <code 
                      className={`bg-gray-200 dark:bg-gray-700 px-1 py-0.5 rounded text-sm font-mono ${className || ''}`.trim()}
                      {...props}
                    >
                      {children}
                    </code>
                  );
                }
                return (
                  <code className={className} {...props}>
                    {children}
                  </code>
                );
              },
              // Inline math
              span: ({ className, children, ...props }: any) => {
                if (className === 'math math-inline') {
                  return (
                    <span className="katex-inline" {...props}>
                      {children}
                    </span>
                  );
                }
                return <span className={className} {...props}>{children}</span>;
              },
              // Block math
              div: ({ className, children, ...props }: any) => {
                if (className === 'math math-display') {
                  return (
                    <div className="katex-display my-4" {...props}>
                      {children}
                    </div>
                  );
                }
                return <div className={className} {...props}>{children}</div>;
              },
              // Paragraphs
              p: ({ children, ...props }: any) => (
                <p className="mb-2 last:mb-0 leading-relaxed" {...props}>
                  {children}
                </p>
              ),
              // Lists
              ul: ({ children, ...props }: any) => (
                <ul className="list-disc list-inside mb-2 space-y-1" {...props}>
                  {children}
                </ul>
              ),
              ol: ({ children, ...props }: any) => (
                <ol className="list-decimal list-inside mb-2 space-y-1" {...props}>
                  {children}
                </ol>
              ),
              li: ({ children, ...props }: any) => (
                <li className="ml-4 [&>p]:mb-0" {...props}>
                  {children}
                </li>
              ),
              // Headers
              h1: ({ children, ...props }: any) => (
                <h1 className="text-xl font-bold mb-2 mt-4" {...props}>
                  {children}
                </h1>
              ),
              h2: ({ children, ...props }: any) => (
                <h2 className="text-lg font-semibold mb-2 mt-3" {...props}>
                  {children}
                </h2>
              ),
              h3: ({ children, ...props }: any) => (
                <h3 className="text-base font-semibold mb-2 mt-3" {...props}>
                  {children}
                </h3>
              ),
              // Blockquotes
              blockquote: ({ children, ...props }: any) => (
                <blockquote className="border-l-4 border-gray-300 dark:border-gray-600 pl-4 italic my-2" {...props}>
                  {children}
                </blockquote>
              ),
              // Images
              img: ({node, src, alt, ...props}) => {
                // Ensure src is a string and not empty, otherwise ReactMarkdown might have issues or pass undefined
                const imageSrc = typeof src === 'string' && src.trim() !== '' ? src : undefined;
                // Render images from Markdown with a max height and object contain
                return (
                  <img 
                    src={imageSrc} 
                    alt={alt} 
                    {...props} 
                    className="max-w-full h-auto rounded-lg shadow-sm my-2" 
                    style={{ maxHeight: '40vh', objectFit: 'contain' }}
                  />
                );
              }
            }}
          >
            {part.text_content || ''}
          </ReactMarkdown>
        </div>
      );
    } else if (part.type === 'image') {
      // Render image part from MessagePart.type === 'image'
      if (part.data && part.mimeType) {
        const imageSrc = `data:${part.mimeType};base64,${part.data}`;
        return (
          <div className="my-2">
            <img 
              src={imageSrc} 
              alt="Generated content" 
              className="max-w-full h-auto rounded-lg shadow-sm"
              style={{ maxHeight: '50vh', objectFit: 'contain' }}
            />
          </div>
        );
      }
      return <p className="text-xs text-red-500">[Image data missing or invalid for image part]</p>;
    } else if (part.type === 'tool_call_request' && part.tool_name) {
      const { tool_name, tool_arguments } = part;
      let argsString = '';
      if (typeof tool_arguments === 'object' && tool_arguments !== null) {
        argsString = JSON.stringify(tool_arguments, null, 2);
      } else if (typeof tool_arguments === 'string') {
        argsString = tool_arguments;
      }

      return (
        <Collapsible open={isToolContentOpen} onOpenChange={setIsToolContentOpen} className="my-2">
          <CollapsibleTrigger asChild>
            <button className="flex items-center justify-between w-full p-2 text-sm font-medium text-left text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700/60 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg focus:outline-none focus-visible:ring focus-visible:ring-purple-500 focus-visible:ring-opacity-75">
              <span className="flex items-center">
                <Terminal className="h-4 w-4 mr-2 text-blue-500" /> 
                Tool Call: <span className="font-semibold ml-1 truncate">{tool_name}</span>
              </span>
              {isToolContentOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent className="p-3 mt-1 bg-gray-50 dark:bg-gray-700/40 rounded-b-lg border border-t-0 border-gray-200 dark:border-gray-600">
            <div className="text-xs text-gray-600 dark:text-gray-400 mb-1 font-semibold">Parameters:</div>
            <pre className="text-xs bg-white dark:bg-gray-800 p-2 rounded overflow-x-auto">
              {argsString}
            </pre>
          </CollapsibleContent>
        </Collapsible>
      );
    } else if (part.type === 'tool_call_result' && part.tool_name) {
      const { tool_name, tool_result } = part;
      const [isInnerToolContentOpen, setIsInnerToolContentOpen] = useState(false);

      return (
        <Collapsible open={isInnerToolContentOpen} onOpenChange={setIsInnerToolContentOpen} className="my-2">
          <CollapsibleTrigger asChild>
             <button className="flex items-center justify-between w-full p-2 text-sm font-medium text-left text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700/50 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg focus:outline-none focus-visible:ring focus-visible:ring-purple-500 focus-visible:ring-opacity-75">
              <span className="flex items-center">
                <Terminal className="h-4 w-4 mr-2 text-green-500" /> 
                Tool Result: <span className="font-semibold ml-1 truncate">{tool_name}</span>
              </span>
              {isInnerToolContentOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />} 
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent className="p-3 mt-1 bg-gray-50 dark:bg-gray-700/40 rounded-b-lg border border-t-0 border-gray-200 dark:border-gray-600">
            <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded overflow-x-auto whitespace-pre-wrap break-all">
              { typeof tool_result === 'object' || Array.isArray(tool_result) ? 
                  JSON.stringify(tool_result, null, 2) 
                  : String(tool_result) }
            </pre>
          </CollapsibleContent>
        </Collapsible>
      );
    }
    return null;
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4 fade-in`}>
      {!isUser && <Bot className="h-7 w-7 mr-2 mt-1 text-gray-500 dark:text-gray-400 flex-shrink-0" />} 
      <div
        className={`rounded-2xl px-4 py-3 message-bubble ${
          isUser
            ? 'max-w-[80%] bg-white/80 dark:bg-gray-800/80 text-foreground border border-gray-200/50 dark:border-gray-700/50 self-end'
            : 'max-w-[85%] bg-gradient-to-r from-gray-100/80 to-gray-200/80 dark:from-gray-800/80 dark:to-gray-700/80 text-foreground border border-gray-200/30 dark:border-gray-700/30 self-start'
        } backdrop-blur-sm shadow-md`}
      >
        {/* Attached Files for user messages */}
        {isUser && renderAttachedFiles()}

        {/* Model Name for AI messages */}
        {!isUser && modelName && (
          <div className="mb-2 pb-2 border-b border-gray-300/30 dark:border-gray-600/30">
            <span className="text-xs font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-2 py-1 rounded-full">
              {modelName}
            </span>
          </div>
        )}

        {/* Message Parts */}
        {parts && parts.length > 0 ? (
          parts.map((part) => <MessagePartDisplay key={part.id} part={part} />)
        ) : (
          !isUser && (
            <div className="flex space-x-1 items-center h-full">
              <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          )
        )}
        
        {/* Timestamp */}
        <div className="text-xs text-gray-400 dark:text-gray-500 mt-2 text-right">
          {new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
      {isUser && <User className="h-7 w-7 ml-2 mt-1 text-gray-500 dark:text-gray-400 flex-shrink-0" />} 
    </div>
  );
} 

export default ChatMessageDisplay;