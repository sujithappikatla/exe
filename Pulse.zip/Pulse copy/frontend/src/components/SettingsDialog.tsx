import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Moon, Sun } from 'lucide-react';

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  theme: 'light' | 'dark';
  onThemeChange: (theme: 'light' | 'dark') => void;
}

export function SettingsDialog({ open, onOpenChange, theme, onThemeChange }: SettingsDialogProps) {
  const [activeTab, setActiveTab] = useState("general");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 border-white/20 flex flex-col p-0">
        <DialogHeader className="p-6 pb-4 flex-shrink-0">
          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Settings
          </DialogTitle>
          <DialogDescription>
            Manage application settings.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-grow flex flex-col overflow-hidden">
          <TabsList className="mx-6 mt-2 mb-0 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg flex-shrink-0">
            <TabsTrigger value="general" className="flex-1 data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700 data-[state=active]:shadow-sm rounded-md text-sm">General</TabsTrigger>
          </TabsList>

          <div className="flex-grow overflow-y-auto p-6 space-y-6">
            <TabsContent value="general">
              <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Appearance</h3>
              <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700/50">
                <Label htmlFor="theme-toggle" className="text-sm font-medium text-gray-700 dark:text-gray-300">Theme</Label>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={theme === 'light' ? 'secondary' : 'ghost'}
                    size="sm"
                    onClick={() => onThemeChange('light')}
                    className={`px-3 py-1.5 rounded-md text-xs ${theme === 'light' ? 'bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-blue-100' : 'hover:bg-gray-200 dark:hover:bg-gray-700'}`}
                  >
                    <Sun className="h-4 w-4 mr-1.5" /> Light
                  </Button>
                  <Button
                    variant={theme === 'dark' ? 'secondary' : 'ghost'}
                    size="sm"
                    onClick={() => onThemeChange('dark')}
                    className={`px-3 py-1.5 rounded-md text-xs ${theme === 'dark' ? 'bg-purple-200 text-purple-800 dark:bg-purple-700 dark:text-purple-100' : 'hover:bg-gray-200 dark:hover:bg-gray-700'}`}
                  >
                    <Moon className="h-4 w-4 mr-1.5" /> Dark
                  </Button>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
} 