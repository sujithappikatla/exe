import React, { useEffect, useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { apiService } from '@/services/api';
import type { DisplayableTool, McpServerConfig, McpServerConfigInput } from '@/services/api';
import { toast } from 'sonner';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle2, PlusCircle, XCircle, Save } from 'lucide-react';

interface AvailableToolsDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  allConfiguredMcpServers: McpServerConfig[];
  selectedServerIds: string[];
  onSelectedServerIdsChange: (ids: string[]) => void;
  isChatSessionActive: boolean;
  onMcpServersRefresh: () => Promise<void>;
}

const AvailableToolsDialog: React.FC<AvailableToolsDialogProps> = ({
  isOpen,
  onOpenChange,
  allConfiguredMcpServers,
  selectedServerIds,
  onSelectedServerIdsChange,
  isChatSessionActive,
  onMcpServersRefresh,
}) => {
  const [availableTools, setAvailableTools] = useState<DisplayableTool[]>([]);
  const [isLoadingTools, setIsLoadingTools] = useState(false);

  const [showAddServerForm, setShowAddServerForm] = useState(false);
  const [newServerDisplayName, setNewServerDisplayName] = useState('');
  const [newServerTransport, setNewServerTransport] = useState<'stdio' | 'http'>('http');
  const [newServerCommand, setNewServerCommand] = useState('');
  const [newServerBaseUrl, setNewServerBaseUrl] = useState('');
  const [isAddingServer, setIsAddingServer] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const fetchTools = async () => {
        setIsLoadingTools(true);
        try {
          const fetchedTools = await apiService.listAvailableTools();
          setAvailableTools(fetchedTools);
        } catch (error) {
          console.error('Error fetching available tools:', error);
          toast.error('Failed to load available tools.');
          setAvailableTools([]);
        }
        setIsLoadingTools(false);
      };
      fetchTools();
    }
  }, [isOpen]);

  const handleServerToggle = (serverId: string, isActive: boolean) => {
    if (isChatSessionActive) return;
    let newSelectedIds;
    if (isActive) {
      newSelectedIds = [...selectedServerIds, serverId];
    } else {
      newSelectedIds = selectedServerIds.filter(id => id !== serverId);
    }
    onSelectedServerIdsChange(newSelectedIds);
  };

  const resetAddServerForm = () => {
    setNewServerDisplayName('');
    setNewServerTransport('http');
    setNewServerCommand('');
    setNewServerBaseUrl('');
    setShowAddServerForm(false);
    setIsAddingServer(false);
  }

  const handleSaveNewServer = async () => {
    if (!newServerDisplayName.trim()) {
      toast.error("Display Name is required for the new MCP server.");
      return;
    }
    if (newServerTransport === 'http' && !newServerBaseUrl.trim()) {
      toast.error("Base URL is required for HTTP transport.");
      return;
    }
    if (newServerTransport === 'stdio' && !newServerCommand.trim()) {
      toast.error("Command is required for STDIO transport.");
      return;
    }

    const newServerInput: McpServerConfigInput = {
      display_name: newServerDisplayName.trim(),
      transport: newServerTransport,
      command: newServerTransport === 'stdio' ? newServerCommand.trim() : undefined,
      base_url: newServerTransport === 'http' ? newServerBaseUrl.trim() : undefined,
    };

    setIsAddingServer(true);
    try {
      await apiService.addMcpServer(newServerInput);
      toast.success(`MCP Server "${newServerInput.display_name}" added successfully.`);
      await onMcpServersRefresh();
      resetAddServerForm();
    } catch (error) {
      console.error("Failed to add MCP server:", error);
      toast.error(`Failed to add MCP server: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    setIsAddingServer(false);
  };

  const renderParameters = (schema: Record<string, any> | undefined) => {
    if (!schema || !schema.properties || Object.keys(schema.properties).length === 0) {
      return <p className="text-sm text-muted-foreground">No parameters required.</p>;
    }
    const requiredParams = schema.required || [];
    return (
      <div className="mt-2 space-y-1">
        {Object.entries(schema.properties).map(([paramName, paramDetails]) => {
          const details = paramDetails as any;
          return (
            <div key={paramName} className="text-sm">
              <span className="font-semibold">{paramName}</span>
              {requiredParams.includes(paramName) && <Badge variant="outline" className="ml-2 text-xs">Required</Badge>}:
              <span className="text-muted-foreground ml-1">({details.type || 'any'})</span>
              {details.description && <span className="italic text-gray-500 ml-1">- {details.description}</span>}
            </div>
          );
        })}
      </div>
    );
  };

  const getToolsForServer = (serverId: string): DisplayableTool[] => {
    return availableTools.filter(tool => tool.source.includes(`(ID: ${serverId})`));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl flex flex-col max-h-[85vh]">
        <DialogHeader>
          <DialogTitle>Configure & View Available Tools</DialogTitle>
          <DialogDescription>
            Select which MCP Servers to use for the next chat session. This selection is locked once a chat starts.
            {isChatSessionActive && (
              <p className="text-sm text-yellow-600 dark:text-yellow-500 mt-1 flex items-center">
                <AlertCircle className="h-4 w-4 mr-1.5" /> Chat session active. MCP Server selection is locked.
              </p>
            )}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex-grow overflow-y-auto space-y-4 p-1 pr-3">
          <div className="px-1">
            {!showAddServerForm && (
              <div className="flex justify-end mb-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setShowAddServerForm(true)} 
                  disabled={isChatSessionActive}
                  className="text-sm"
                >
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add New MCP Server
                </Button>
              </div>
            )}
            {showAddServerForm && (
              <div className="p-3 border rounded-md bg-slate-50 dark:bg-slate-800/30 mb-4 space-y-3">
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Add New MCP Server</h4>
                <div>
                  <Label htmlFor="new-server-name" className="text-xs">Display Name*</Label>
                  <Input id="new-server-name" value={newServerDisplayName} onChange={(e) => setNewServerDisplayName(e.target.value)} placeholder="e.g., My Local Calculator" className="text-sm" />
                </div>
                <div>
                  <Label className="text-xs mb-1 block">Transport Type*</Label>
                  <RadioGroup defaultValue="http" value={newServerTransport} onValueChange={(value: 'stdio' | 'http') => setNewServerTransport(value)} className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="http" id="transport-http" />
                      <Label htmlFor="transport-http" className="text-sm font-normal">HTTP</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="stdio" id="transport-stdio" />
                      <Label htmlFor="transport-stdio" className="text-sm font-normal">STDIO</Label>
                    </div>
                  </RadioGroup>
                </div>
                {newServerTransport === 'http' && (
                  <div>
                    <Label htmlFor="new-server-baseurl" className="text-xs">Base URL* (e.g., http://localhost:8001/mcp)</Label>
                    <Input id="new-server-baseurl" value={newServerBaseUrl} onChange={(e) => setNewServerBaseUrl(e.target.value)} placeholder="http://localhost:8001/mcp" className="text-sm" />
                  </div>
                )}
                {newServerTransport === 'stdio' && (
                  <div>
                    <Label htmlFor="new-server-command" className="text-xs">Command* (e.g., python /path/to/mcp_stdio_server.py)</Label>
                    <Input id="new-server-command" value={newServerCommand} onChange={(e) => setNewServerCommand(e.target.value)} placeholder="python /path/to/server.py" className="text-sm"/>
                  </div>
                )}
                <div className="flex justify-end space-x-2 pt-2">
                  <Button variant="ghost" size="sm" onClick={resetAddServerForm} disabled={isAddingServer} className="text-sm"><XCircle className="h-4 w-4 mr-1.5"/>Cancel</Button>
                  <Button size="sm" onClick={handleSaveNewServer} disabled={isAddingServer} className="text-sm">
                    {isAddingServer ? (<><Save className="h-4 w-4 mr-1.5 animate-spin"/>Saving...</>) : (<><Save className="h-4 w-4 mr-1.5"/>Save Server</>)}
                  </Button>
                </div>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-md font-semibold mb-2 text-gray-800 dark:text-gray-200 px-1">MCP Server Selection</h3>
            <ScrollArea className="max-h-[25vh] p-0 border rounded-md bg-slate-50 dark:bg-slate-800/30">
              <div className="space-y-3 p-3">
                {allConfiguredMcpServers.length === 0 && <p className="text-sm text-muted-foreground">No MCP servers configured.</p>}
                {allConfiguredMcpServers.map(server => (
                  <div key={server.id} className="flex items-center justify-between space-x-2 p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-colors">
                    <Label htmlFor={`server-toggle-${server.id}`} className="flex-1 cursor-pointer">
                      <span className="font-medium text-gray-700 dark:text-gray-300">{server.display_name}</span>
                      <p className="text-xs text-muted-foreground">ID: {server.id} ({server.transport})</p>
                    </Label>
                    <Switch
                      id={`server-toggle-${server.id}`}
                      checked={selectedServerIds.includes(server.id)}
                      onCheckedChange={(checked: boolean) => handleServerToggle(server.id, checked)}
                      disabled={isChatSessionActive}
                      aria-label={`Toggle ${server.display_name} MCP Server`}
                    />
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>

          <div>
            <h3 className="text-md font-semibold mb-2 text-gray-800 dark:text-gray-200 px-1">Tools from Selected Servers</h3>
            <ScrollArea className="max-h-[35vh] p-0">
              <div className="p-1">
                {isLoadingTools && <p className="text-sm text-muted-foreground">Loading tools information...</p>}
                {!isLoadingTools && selectedServerIds.length === 0 && (
                    <p className="text-sm text-muted-foreground p-2">
                        No MCP servers selected, or selected servers have no tools. Enable servers above to see their tools.
                    </p>
                )}
                {!isLoadingTools && selectedServerIds.length > 0 && (
                  <Accordion type="multiple" className="w-full">
                    {selectedServerIds.map(serverId => {
                      const serverConfig = allConfiguredMcpServers.find(s => s.id === serverId);
                      const toolsForThisServer = getToolsForServer(serverId);
                      if (!serverConfig) return null;
                      return (
                        <AccordionItem value={serverId} key={serverId}>
                          <AccordionTrigger className="text-sm hover:no-underline px-2 py-2.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700/50">
                            <div className="flex items-center">
                              <CheckCircle2 className="h-4 w-4 mr-2 text-green-600 dark:text-green-500" /> 
                              {serverConfig.display_name} 
                              <Badge variant="outline" className="ml-2 text-xs">{toolsForThisServer.length} tool(s)</Badge>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="pt-1 pb-2 px-2 bg-slate-50 dark:bg-slate-800/30 rounded-b-md">
                            {toolsForThisServer.length === 0 && <p className="text-xs text-muted-foreground p-2">No tools discovered on this server.</p>}
                            {toolsForThisServer.map((tool, index) => (
                              <React.Fragment key={tool.name + index}>
                                <div className="py-2">
                                  <h4 className="text-sm font-semibold mb-0.5 text-gray-700 dark:text-gray-300">{tool.name.replace(`${serverId}__MCP__`, '')}</h4>
                                  <p className="text-xs text-muted-foreground mb-1">{tool.description}</p>
                                  <details className="text-xs">
                                    <summary className="cursor-pointer text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">Parameters</summary>
                                    <div className="pl-2 border-l-2 border-slate-200 dark:border-slate-700 ml-1 mt-1">
                                      {renderParameters(tool.parameters_schema)}
                                    </div>
                                  </details>
                                </div>
                                {index < toolsForThisServer.length - 1 && <Separator className="my-1" />}
                              </React.Fragment>
                            ))}
                          </AccordionContent>
                        </AccordionItem>
                      );
                    })}
                  </Accordion>
                )}
                {!isLoadingTools && availableTools.length > 0 && selectedServerIds.length === 0 && allConfiguredMcpServers.length > 0 && (
                    <p className="text-sm text-muted-foreground p-2">
                        Select at least one MCP server above to see its available tools.
                    </p>
                )}
                {!isLoadingTools && availableTools.length === 0 && allConfiguredMcpServers.length > 0 && selectedServerIds.length > 0 && (
                    <p className="text-sm text-muted-foreground p-2">
                        No tools could be loaded or discovered, even from selected servers.
                    </p>
                )}
              </div>
            </ScrollArea>
          </div>
        </div>

        <DialogFooter className="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700">
          <Button onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AvailableToolsDialog; 