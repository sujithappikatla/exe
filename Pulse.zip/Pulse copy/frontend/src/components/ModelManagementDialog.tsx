import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Trash2, Edit, PlusCircle, Save, XCircle, AlertTriangle, Eye, EyeOff } from 'lucide-react';
import { apiService } from '@/services/api';
import type { AIModelConfig, AIModelConfigInput } from '@/services/api';
import { toast } from 'sonner';
import { Separator } from './ui/separator';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface ModelManagementDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  configuredModels: AIModelConfig[];
  onModelsRefresh: () => Promise<void>;
}

type ModelProviderType = 'openai' | 'google';

const ModelManagementDialog: React.FC<ModelManagementDialogProps> = ({
  isOpen,
  onOpenChange,
  configuredModels,
  onModelsRefresh,
}) => {
  const [editingModel, setEditingModel] = useState<AIModelConfig | null>(null);
  const [isFormVisible, setIsFormVisible] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [modelToDelete, setModelToDelete] = useState<AIModelConfig | null>(null);
  const [showApiKey, setShowApiKey] = useState(false);

  // Form state
  const [displayName, setDisplayName] = useState('');
  const [modelIdOnProvider, setModelIdOnProvider] = useState('');
  const [provider, setProvider] = useState<ModelProviderType>('openai');
  const [apiKey, setApiKey] = useState('');
  const [baseUrl, setBaseUrl] = useState('');
  const [isVertex, setIsVertex] = useState(false);
  const [gcpProjectId, setGcpProjectId] = useState('');
  const [gcpLocation, setGcpLocation] = useState('');

  const [isSaving, setIsSaving] = useState(false);

  const resetForm = useCallback(() => {
    setDisplayName('');
    setModelIdOnProvider('');
    setProvider('openai');
    setApiKey('');
    setBaseUrl('');
    setIsVertex(false);
    setGcpProjectId('');
    setGcpLocation('');
    setShowApiKey(false);
  }, []);

  const handleAddNew = () => {
    resetForm();
    setEditingModel(null);
    setIsFormVisible(true);
  };

  const handleEdit = (model: AIModelConfig) => {
    setEditingModel(model);
    setDisplayName(model.display_name);
    setModelIdOnProvider(model.model_id_on_provider);
    setProvider(model.model_provider as ModelProviderType);
    setApiKey(model.api_key || '');
    setBaseUrl(model.base_url || '');
    setIsVertex(model.vertex_ai || false);
    setGcpProjectId(model.project_id || '');
    setGcpLocation(model.location || '');
    setShowApiKey(false);
    setIsFormVisible(true);
  };

  const handleCancelEdit = () => {
    setIsFormVisible(false);
    setEditingModel(null);
    resetForm();
  };

  const validateForm = (): boolean => {
    if (!displayName.trim()) { toast.error("Display Name is required."); return false; }
    if (!modelIdOnProvider.trim()) { toast.error("Model ID (from provider) is required."); return false; }
    if (!apiKey.trim()) { toast.error("API Key is required."); return false; }
    if (provider === 'google' && isVertex) {
      if (!gcpProjectId.trim()) { toast.error("GCP Project ID is required for Vertex AI models."); return false; }
      if (!gcpLocation.trim()) { toast.error("GCP Location is required for Vertex AI models."); return false; }
    }
    return true;
  }

  const handleSave = async () => {
    if (!validateForm()) return;

    const modelInput: AIModelConfigInput = {
      display_name: displayName.trim(),
      model_id_on_provider: modelIdOnProvider.trim(),
      model_provider: provider,
      api_key: apiKey.trim(),
      base_url: provider === 'openai' && baseUrl.trim() ? baseUrl.trim() : null,
      vertex_ai: provider === 'google' ? isVertex : null,
      project_id: provider === 'google' && isVertex && gcpProjectId.trim() ? gcpProjectId.trim() : null,
      location: provider === 'google' && isVertex && gcpLocation.trim() ? gcpLocation.trim() : null,
    };

    setIsSaving(true);
    try {
      if (editingModel && editingModel.config_id) {
        await apiService.updateAIModel(editingModel.config_id, modelInput);
        toast.success(`Model "${modelInput.display_name}" updated successfully.`);
      } else {
        await apiService.addAIModel(modelInput);
        toast.success(`Model "${modelInput.display_name}" added successfully.`);
      }
      await onModelsRefresh();
      handleCancelEdit();
    } catch (error) {
      console.error("Failed to save AI model:", error);
      toast.error(`Failed to save model: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    setIsSaving(false);
  };

  const openDeleteConfirmation = (model: AIModelConfig) => {
    setModelToDelete(model);
    setIsDeleting(true);
  };

  const handleDelete = async () => {
    if (!modelToDelete || !modelToDelete.config_id) return;
    setIsSaving(true);
    try {
      await apiService.deleteAIModel(modelToDelete.config_id);
      toast.success(`Model "${modelToDelete.display_name}" deleted.`);
      await onModelsRefresh();
      setIsDeleting(false);
      setModelToDelete(null);
      if (editingModel?.config_id === modelToDelete.config_id) {
        handleCancelEdit();
      }
    } catch (error) {
      console.error("Failed to delete AI model:", error);
      toast.error(`Failed to delete model: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    setIsSaving(false);
  };
  
  useEffect(() => {
    if (!isOpen) {
      setIsFormVisible(false);
      setEditingModel(null);
      resetForm();
    }
  }, [isOpen, resetForm]);

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl flex flex-col max-h-[85vh]">
        <DialogHeader>
          <DialogTitle>Manage AI Models</DialogTitle>
          <DialogDescription>
            Add, edit, or remove AI model configurations. API keys are stored securely.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-grow overflow-y-auto space-y-4 p-1 pr-3 -mr-1">
          {!isFormVisible ? (
            <>
              <div className="flex justify-end mb-2">
                <Button variant="outline" size="sm" onClick={handleAddNew} className="text-sm">
                  <PlusCircle className="h-4 w-4 mr-2" /> Add New Model
                </Button>
              </div>
              <ScrollArea className="max-h-[calc(85vh-200px)]">
                <div className="space-y-2 pr-1">
                {configuredModels.length === 0 && <p className="text-sm text-muted-foreground p-2">No AI models configured yet. Click "Add New Model" to start.</p>}
                {configuredModels.map(model => {
                  return (
                    <div key={model.config_id} className="p-3 border rounded-md hover:shadow-md transition-shadow bg-slate-50 dark:bg-slate-800/30">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-gray-800 dark:text-gray-200">{model.display_name}</h4>
                          <p className="text-xs text-muted-foreground">Provider: {model.model_provider} | ID: {model.model_id_on_provider}</p>
                          <p className="text-xs text-muted-foreground">Internal ID: {model.config_id}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(model)} className="h-7 w-7" title="Edit Model">
                            <Edit className="h-4 w-4" />
                          </Button>
                          
                          <Button variant="ghost" size="icon" onClick={() => openDeleteConfirmation(model)} className="h-7 w-7 text-red-500 hover:text-red-600" title="Delete Model">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })}
                </div>
              </ScrollArea>
            </>
          ) : (
            // Form View
            <ScrollArea className="max-h-[calc(85vh-180px)]">
            <div className="space-y-4 p-1">
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">{editingModel ? "Edit AI Model" : "Add New AI Model"}</h3>
              <div>
                <Label htmlFor="displayName" className="text-xs">Display Name*</Label>
                <Input id="displayName" value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="e.g., My GPT-4 Turbo" className="text-sm" />
              </div>
              <div>
                <Label htmlFor="modelIdOnProvider" className="text-xs">Model ID (from provider)*</Label>
                <Input id="modelIdOnProvider" value={modelIdOnProvider} onChange={e => setModelIdOnProvider(e.target.value)} placeholder="e.g., gpt-4-turbo-preview or gemini-pro" className="text-sm" />
              </div>
              <div>
                <Label htmlFor="provider" className="text-xs mb-1 block">Provider*</Label>
                <Select value={provider} onValueChange={(value: ModelProviderType) => setProvider(value)}>
                  <SelectTrigger className="w-full text-sm">
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="openai" className="text-sm">OpenAI</SelectItem>
                    <SelectItem value="google" className="text-sm">Google</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="apiKey" className="text-xs">API Key*</Label>
                <div className="relative">
                  <Input 
                    id="apiKey" 
                    type={showApiKey ? "text" : "password"} 
                    value={apiKey} 
                    onChange={e => setApiKey(e.target.value)} 
                    placeholder="Enter API Key" 
                    className="text-sm pr-10" />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-7 w-7"
                    onClick={() => setShowApiKey(!showApiKey)}
                    title={showApiKey ? "Hide API Key" : "Show API Key"}
                  >
                    {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              {provider === 'openai' && (
                <div>
                  <Label htmlFor="baseUrl" className="text-xs">Base URL (Optional)</Label>
                  <Input id="baseUrl" value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="e.g., https://api.openai.com/v1" className="text-sm" />
                  <p className="text-xs text-muted-foreground mt-1">For OpenAI compatible APIs or proxies. Leave blank for default.</p>
                </div>
              )}

              {provider === 'google' && (
                <>
                  <div className="flex items-center space-x-2 mt-3 mb-1">
                    <Switch id="isVertex" checked={isVertex} onCheckedChange={setIsVertex} />
                    <Label htmlFor="isVertex" className="text-sm cursor-pointer">Use Google Cloud Vertex AI</Label>
                  </div>
                  {isVertex && (
                    <>
                      <div>
                        <Label htmlFor="gcpProjectId" className="text-xs">GCP Project ID*</Label>
                        <Input id="gcpProjectId" value={gcpProjectId} onChange={e => setGcpProjectId(e.target.value)} placeholder="your-gcp-project-id" className="text-sm" />
                      </div>
                      <div>
                        <Label htmlFor="gcpLocation" className="text-xs">GCP Location*</Label>
                        <Input id="gcpLocation" value={gcpLocation} onChange={e => setGcpLocation(e.target.value)} placeholder="e.g., us-central1" className="text-sm" />
                      </div>
                    </>
                  )}
                  {!isVertex && (
                    <p className="text-xs text-muted-foreground mt-1">Using Google AI Studio (Generative Language API). API Key is used directly.</p>
                  )}
                </>
              )}
              <Separator className="my-3" />
              <div className="flex justify-end space-x-2">
                <Button variant="ghost" onClick={handleCancelEdit} disabled={isSaving} className="text-sm"><XCircle className="h-4 w-4 mr-1.5"/>Cancel</Button>
                <Button onClick={handleSave} disabled={isSaving} className="text-sm">
                  {isSaving ? <><Save className="h-4 w-4 mr-1.5 animate-spin"/>Saving...</> : <><Save className="h-4 w-4 mr-1.5"/>Save Model</>}
                </Button>
              </div>
            </div>
            </ScrollArea>
          )}
        </div>

        {!isFormVisible && (
          <DialogFooter className="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700">
            <DialogClose asChild>
              <Button variant="outline">Close</Button>
            </DialogClose>
          </DialogFooter>
        )}
        
        <AlertDialog open={isDeleting} onOpenChange={setIsDeleting}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center"><AlertTriangle className="h-5 w-5 mr-2 text-red-500"/>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the AI model configuration for 
                <span className="font-semibold"> {modelToDelete?.display_name} ({modelToDelete?.model_id_on_provider})</span>.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setModelToDelete(null)} disabled={isSaving}>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleDelete} 
                disabled={isSaving}
                className="bg-red-600 hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-800 text-white"
              >
                {isSaving ? "Deleting..." : "Yes, delete model"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

      </DialogContent>
    </Dialog>
  );
};

export default ModelManagementDialog; 