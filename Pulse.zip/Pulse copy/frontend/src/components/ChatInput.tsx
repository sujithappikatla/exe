import { useState, useRef, type Dispatch, type SetStateAction } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, Paperclip, X, FileText, Image, FileIcon, Wrench, ChevronDown } from 'lucide-react';
import { type AIModelConfig } from '@/services/api';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface AttachedFile {
  id: string;
  file: File;
  type: 'image' | 'pdf' | 'text' | 'other';
}

interface ChatInputProps {
  onSendMessage: (message: string, files?: AttachedFile[]) => void;
  isLoading?: boolean;
  className?: string;
  availableModels: AIModelConfig[];
  currentChatModelId: string | null;
  setCurrentChatModelId: Dispatch<SetStateAction<string | null>>;
  isChatSessionActive: boolean;
  getModelDisplayName: (configId: string | null) => string;
  onOpenToolsDialog: () => void;
  onOpenModelManagementDialog: () => void;
}

export function ChatInput({
  onSendMessage,
  isLoading = false,
  className = '',
  availableModels,
  currentChatModelId,
  setCurrentChatModelId,
  isChatSessionActive,
  getModelDisplayName,
  onOpenToolsDialog,
  onOpenModelManagementDialog
}: ChatInputProps) {
  const [message, setMessage] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((message.trim() || attachedFiles.length > 0) && !isLoading) {
      onSendMessage(message.trim(), attachedFiles);
      setMessage('');
      setAttachedFiles([]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newAttachedFiles: AttachedFile[] = files.map(file => ({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      file,
      type: getFileType(file),
    }));
    setAttachedFiles(prev => [...prev, ...newAttachedFiles]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getFileType = (file: File): AttachedFile['type'] => {
    if (file.type.startsWith('image/')) return 'image';
    if (file.type === 'application/pdf') return 'pdf';
    if (file.type.startsWith('text/')) return 'text';
    return 'other';
  };

  const removeFile = (id: string) => {
    setAttachedFiles(prev => prev.filter(file => file.id !== id));
  };

  const getFileIcon = (type: AttachedFile['type']) => {
    switch (type) {
      case 'image': return <Image className="h-3 w-3" />;
      case 'pdf': return <FileText className="h-3 w-3" />;
      case 'text': return <FileText className="h-3 w-3" />;
      default: return <FileIcon className="h-3 w-3" />;
    }
  };

  return (
    <div className={className}>
      {/* Unified Control Panel */}
      <div className="relative p-0.5 rounded-2xl bg-gradient-to-r from-blue-500/40 via-purple-500/40 to-pink-500/40 shadow-lg backdrop-blur-sm">
        <div className="rounded-xl overflow-hidden" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)' }}>
          {/* Dark mode background */}
          <div className="dark:bg-gray-900/90 dark:block hidden absolute inset-0 rounded-xl"></div>
          
          {/* Content Container */}
          <div className="relative">
            {/* Attached Files Row - Horizontal Scroll */}
            {attachedFiles.length > 0 && (
              <div className="px-3 pt-3">
                <div className="flex gap-2 overflow-x-auto scrollbar-hide">
                  {attachedFiles.map((attachedFile) => (
                    <div
                      key={attachedFile.id}
                      className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 rounded-lg px-2 py-1 text-xs whitespace-nowrap flex-shrink-0"
                    >
                      {getFileIcon(attachedFile.type)}
                      <span className="truncate max-w-[100px]">{attachedFile.file.name}</span>
                      <button
                        onClick={() => removeFile(attachedFile.id)}
                        className="text-gray-500 hover:text-red-500 transition-colors"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Textarea Container - Expand upward */}
            <div className="flex flex-col px-3 py-3">
              <div className="flex-1 flex flex-col justify-end">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type your message... (Shift+Enter for new line)"
                  className="min-h-[24px] max-h-[72px] resize-none border-0 focus:ring-0 focus:outline-none focus-visible:ring-0 focus-visible:ring-offset-0 overflow-y-auto p-0 shadow-none placeholder:text-gray-500"
                  style={{ 
                    backgroundColor: 'transparent',
                    lineHeight: '24px', 
                    boxShadow: 'none',
                    background: 'transparent'
                  }}
                  disabled={isLoading}
                  rows={1}
                />
              </div>
            </div>

            {/* Control Bar */}
            <div className="flex items-center justify-between px-3 pb-3">
              {/* Left side - Attach button and Tools button */}
              <div className="flex items-center gap-1">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFileSelect}
                  className="hidden"
                  accept="image/*,.pdf,.txt,.doc,.docx"
                />
                <Button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors"
                  disabled={isLoading}
                >
                  <Paperclip className="h-4 w-4 text-gray-500" />
                </Button>
                <Button
                  type="button"
                  onClick={onOpenToolsDialog}
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors"
                  disabled={isLoading}
                  title="View Available Tools"
                >
                  <Wrench className="h-4 w-4 text-gray-500" />
                </Button>

                {/* Model Selector Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2 flex items-center gap-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors text-xs focus:ring-0 focus:outline-none focus-visible:ring-0 focus-visible:ring-offset-0 border-0 shadow-none"
                      disabled={isChatSessionActive || isLoading}
                      title={isChatSessionActive ? "Model selection is disabled during an active chat" : "Select AI Model"}
                    >
                      <span>{getModelDisplayName(currentChatModelId)}</span>
                      <ChevronDown className="h-3 w-3 text-gray-500" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start">
                    {availableModels
                      .filter(model => model.config_id != null && model.config_id !== '')
                      .map((model) => (
                      <DropdownMenuItem
                        key={model.config_id}
                        onClick={() => setCurrentChatModelId(model.config_id)}
                        disabled={isChatSessionActive}
                        className={currentChatModelId === model.config_id ? "bg-gray-100 dark:bg-gray-700" : ""}
                      >
                        {model.display_name}
                      </DropdownMenuItem>
                    ))}
                    {availableModels.length > 0 && <hr className="my-1 border-gray-200 dark:border-gray-700" />}
                    <DropdownMenuItem
                        onClick={onOpenModelManagementDialog}
                        disabled={isChatSessionActive}
                        className="text-xs text-blue-600 dark:text-blue-400 hover:!bg-blue-50 dark:hover:!bg-blue-900/50"
                    >
                        + Add / Edit Models...
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

              </div>

              {/* Right side - Send button */}
              <Button
                type="submit"
                onClick={handleSubmit}
                disabled={(!message.trim() && attachedFiles.length === 0) || isLoading}
                className="h-8 px-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-md rounded-full text-white font-medium text-sm"
              >
                <Send className="h-3 w-3 mr-1" />
                Send
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* <AvailableToolsDialog isOpen={showToolsDialog} onOpenChange={setShowToolsDialog} /> */}
      {/* Dialog is now controlled by App.tsx */}
    </div>
  );
} 