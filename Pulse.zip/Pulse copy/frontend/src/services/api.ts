// API Service for Pulse Chat Backend

const API_BASE_URL = 'http://localhost:8000/api';

export interface ModelInfo {
  model_id: string;
  name: string;
  provider: 'openai' | 'google';
  description?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  timestamp: string;
  model_name?: string;
  files?: ApiFile[];
}

// New interface for file data in API requests
export interface ApiFile {
  name: string;
  type: 'image' | 'pdf' | 'text' | 'other'; // Simplified type from frontend
  mime_type: string; // Actual MIME type from File object
  data?: string;     // Base64 data URL for images (e.g., "data:image/jpeg;base64,...")
}

export interface ChatRequest {
  message: string;
  conversation_id?: string;
  model_id: string;
  files?: ApiFile[];
  stream?: boolean;
  active_mcp_server_ids?: string[]; // For specifying active MCP servers for the session
}

export interface ChatResponse {
  message: ChatMessage;
  conversation_id: string;
}

export interface ConversationHistory {
  conversation_id: string;
  messages: ChatMessage[];
  created_at: string;
  updated_at: string;
  title?: string;
}

// --- Streaming Part Interfaces for Tool Calls ---
export interface ToolCallRequestDetails {
  tool_name: string;
  tool_arguments: Record<string, any>;
}

export interface ToolCallResultDetails {
  tool_name: string;
  tool_result: any;
  // Optional: error?: string;
}

// --- New/Updated Interfaces for Image Data in Streaming ---
export interface ImageData {
  data: string;      // Base64 encoded image data
  mime_type: string; // e.g., 'image/png', 'image/jpeg'
}

// Augmented StreamChunk to include different part types
export interface StreamChunk {
  conversation_id: string;
  message_id: string; // ID of the AI message this chunk belongs to
  part_type: 'text' | 'tool_call_request' | 'tool_call_result' | 'image'; // Added 'image'
  text_content?: string; // Content for 'text' part_type
  tool_call_request_data?: ToolCallRequestDetails; // Data for 'tool_call_request'
  tool_call_result_data?: ToolCallResultDetails; // Data for 'tool_call_result'
  image_data?: ImageData; // Data for 'image' part_type
  done: boolean;
}

// --- New Configuration Interfaces ---

// This is what the backend expects for creating/updating a model config
export interface AIModelConfigInput {
  display_name: string;
  model_id_on_provider: string; // e.g., "gpt-4", "gemini-pro"
  model_provider: 'openai' | 'google';
  api_key: string; // Made non-optional for input consistency, backend can handle if needed
  base_url?: string | null;
  project_id?: string | null;
  location?: string | null;
  vertex_ai?: boolean | null;
}

// This is what the frontend receives (includes the internal config_id)
export interface AIModelConfig extends AIModelConfigInput { 
  config_id: string; // Unique internal ID for this configuration entry (e.g., UUID)
  // Note: model_id_on_provider, display_name etc. are inherited from AIModelConfigInput
}

export interface McpServerConfigInput {
  display_name: string;
  transport: 'stdio' | 'http';
  command?: string | null;
  base_url?: string | null;
}

export interface McpServerConfig extends McpServerConfigInput {
  id: string; // Unique ID for the MCP server config entry
}

// Interface for the new /api/tools/available endpoint
export interface DisplayableTool {
  name: string;
  description: string;
  parameters_schema?: Record<string, any>; // Using Record for object type
  source: string; // e.g., "Built-in LLM Function" or "MCP Server: <server_display_name>"
}

class ApiService {
  private baseUrl: string;
  private configUrl: string;

  constructor(baseUrl: string = API_BASE_URL) {
    this.baseUrl = baseUrl;
    this.configUrl = `${baseUrl}/config`; // Base URL for configuration endpoints
  }

  // Health check
  async healthCheck(): Promise<any> {
    const response = await fetch(`${this.baseUrl}/health`);
    return response.json();
  }

  // Get available models
  async getModels(): Promise<ModelInfo[]> {
    const response = await fetch(`${this.baseUrl}/models/`);
    if (!response.ok) {
      throw new Error('Failed to fetch models');
    }
    return response.json();
  }

  // --- AI Model Configuration CRUD --- 
  async listAIModels(): Promise<AIModelConfig[]> {
    const response = await fetch(`${this.configUrl}/models`);
    if (!response.ok) throw new Error('Failed to fetch AI model configurations');
    const modelsFromBackend = await response.json();
    
    return modelsFromBackend.map((model: any) => {
      // The user states that backend's unique key is 'model_id'
      const configId = model.model_id;
      // For model_id_on_provider, prefer an explicit field, otherwise fallback to model_id itself.
      const modelIdOnProvider = model.model_id_on_provider || model.model_id;

      return {
        ...model, // Spread other properties like display_name, api_key, etc.
        config_id: configId, 
        model_id_on_provider: modelIdOnProvider,
        // Ensure essential fields for AIModelConfigInput are present, even if null from backend
        display_name: model.display_name || '',
        model_provider: model.model_provider || 'openai', // Default if missing
        api_key: model.api_key || '',
        base_url: model.base_url !== undefined ? model.base_url : null,
        project_id: model.project_id !== undefined ? model.project_id : null,
        location: model.location !== undefined ? model.location : null,
        vertex_ai: model.vertex_ai !== undefined ? model.vertex_ai : null,
      };
    }).filter((model: AIModelConfig) => model.config_id); // Ensure config_id is populated
  }

  async addAIModel(modelConfigInput: AIModelConfigInput): Promise<AIModelConfig> {
    const response = await fetch(`${this.configUrl}/models`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(modelConfigInput),
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to add AI model' }));
      throw new Error(error.detail);
    }
    const newModelFromBackend = await response.json();
    // Assuming backend responds with an object where 'model_id' is the new unique ID
    return {
      ...newModelFromBackend,
      config_id: newModelFromBackend.model_id, // Map backend model_id to config_id
      model_id_on_provider: newModelFromBackend.model_id_on_provider || newModelFromBackend.model_id,
    };
  }

  async updateAIModel(configId: string, modelConfigInput: AIModelConfigInput): Promise<AIModelConfig> {
    const response = await fetch(`${this.configUrl}/models/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        config_id: configId,
        data: modelConfigInput,
      }),
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to update AI model' }));
      throw new Error(error.detail);
    }
    const updatedModelFromBackend = await response.json();
    return {
      ...updatedModelFromBackend,
      config_id: updatedModelFromBackend.model_id, 
      model_id_on_provider: updatedModelFromBackend.model_id_on_provider || updatedModelFromBackend.model_id,
    };
  }

  async deleteAIModel(configId: string): Promise<void> {
    const response = await fetch(`${this.configUrl}/models/delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ config_id: configId }),
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to delete AI model' }));
      throw new Error(error.detail);
    }
  }

  // --- MCP Server Configuration CRUD --- 
  async listMcpServers(): Promise<McpServerConfig[]> {
    const response = await fetch(`${this.configUrl}/mcp_servers`);
    if (!response.ok) throw new Error('Failed to fetch MCP server configurations');
    return response.json();
  }

  async addMcpServer(mcpConfigInput: McpServerConfigInput): Promise<McpServerConfig> {
    const response = await fetch(`${this.configUrl}/mcp_servers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(mcpConfigInput),
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to add MCP server' }));
      throw new Error(error.detail);
    }
    return response.json();
  }

  async updateMcpServer(mcpServerId: string, mcpConfigInput: McpServerConfigInput): Promise<McpServerConfig> {
    const response = await fetch(`${this.configUrl}/mcp_servers/${mcpServerId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(mcpConfigInput),
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to update MCP server' }));
      throw new Error(error.detail);
    }
    return response.json();
  }

  async deleteMcpServer(mcpServerId: string): Promise<void> {
    const response = await fetch(`${this.configUrl}/mcp_servers/${mcpServerId}`, { method: 'DELETE' });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to delete MCP server' }));
      throw new Error(error.detail);
    }
  }

  // --- Available Tools --- 
  async listAvailableTools(): Promise<DisplayableTool[]> {
    const response = await fetch(`${this.baseUrl}/tools/available`);
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to fetch available tools' }));
      throw new Error(error.detail);
    }
    return response.json();
  }

  // Send chat completion (non-streaming)
  async sendMessage(request: ChatRequest): Promise<ChatResponse> {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to send message');
    }

    return response.json();
  }

  // Send streaming chat completion
  async sendStreamingMessage(
    request: ChatRequest,
    onChunk: (chunk: StreamChunk) => void,
    onError?: (error: string) => void
  ): Promise<void> {
    try {
      const response = await fetch(`${this.baseUrl}/chat/completions/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...request, stream: true }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Failed to send streaming message');
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No response body');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              onChunk(data);
            } catch (e) {
              console.error('Error parsing SSE data:', e);
            }
          }
        }
      }
    } catch (error) {
      if (onError) {
        onError(error instanceof Error ? error.message : 'Unknown error');
      } else {
        throw error;
      }
    }
  }

  // Get conversation history
  async getConversationHistory(conversationId: string): Promise<ConversationHistory> {
    const response = await fetch(`${this.baseUrl}/chat/conversations/${conversationId}/history`);
    if (!response.ok) {
      throw new Error('Failed to fetch conversation history');
    }
    return response.json();
  }

  // List all conversations
  async listConversations(): Promise<ConversationHistory[]> {
    const response = await fetch(`${this.baseUrl}/chat/conversations`);
    if (!response.ok) {
      throw new Error('Failed to fetch conversations');
    }
    return response.json();
  }

  // Delete conversation
  async deleteConversation(conversationId: string): Promise<void> {
    const response = await fetch(`${this.baseUrl}/chat/conversations/${conversationId}`, {
      method: 'DELETE',
    });
    if (!response.ok) {
      throw new Error('Failed to delete conversation');
    }
  }
}

// Export singleton instance
export const apiService = new ApiService(); 