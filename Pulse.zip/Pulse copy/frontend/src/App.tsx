import { useState, useEffect, useRef, useCallback } from 'react';
import { ChatMessageDisplay } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { ScrollArea } from './components/ui/scroll-area';
import { Button } from './components/ui/button';
import { Moon, Sun } from 'lucide-react';
import { useTheme } from './hooks/useTheme';
import { useModels } from './hooks/useModels';
import { apiService } from './services/api';
import type { StreamChunk, ApiFile, McpServerConfig } from './services/api';
import AvailableToolsDialog from './components/AvailableToolsDialog';
import ModelManagementDialog from './components/ModelManagementDialog';

interface AttachedFile {
  id: string;
  file: File;
  type: 'image' | 'pdf' | 'text' | 'other';
}

export interface MessagePart {
  id: string;
  type: 'text' | 'tool_call_request' | 'tool_call_result' | 'image';
  text_content?: string;
  tool_name?: string;
  tool_arguments?: Record<string, any>;
  tool_result?: any;
  data?: string;
  mimeType?: string;
}

export interface Message {
  id: string;
  parts: MessagePart[];
  isUser: boolean;
  timestamp: Date;
  attachedFiles?: AttachedFile[];
  modelName?: string;
}

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasStartedChat, setHasStartedChat] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [streamingMessageId, setStreamingMessageId] = useState<string | null>(null);
  const { theme, setTheme } = useTheme();
  const { 
    models: availableModels,
    selectedModel: globalDefaultModelConfigId,
    getModelDisplayName,
    refetchModels 
  } = useModels();
  const [currentChatModelConfigId, setCurrentChatModelConfigId] = useState<string | null>(null);
  const [isChatSessionActive, setIsChatSessionActive] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollAreaRootRef = useRef<HTMLDivElement>(null);
  const [isUserScrolledUp, setIsUserScrolledUp] = useState(false);
  const [selectedMcpServerIdsForNextChat, setSelectedMcpServerIdsForNextChat] = useState<string[]>([]);
  const [availableToolsDialogOpen, setAvailableToolsDialogOpen] = useState(false);
  const [allConfiguredMcpServers, setAllConfiguredMcpServers] = useState<McpServerConfig[]>([]);
  const [isModelManagementDialogOpen, setIsModelManagementDialogOpen] = useState(false);

  const refetchMcpServers = useCallback(async () => {
    try {
      const servers = await apiService.listMcpServers();
      setAllConfiguredMcpServers(servers);
    } catch (error) {
      console.error("Failed to fetch MCP servers:", error);
      setAllConfiguredMcpServers([]); 
    }
  }, []);

  useEffect(() => {
    if (availableModels.length > 0 && !currentChatModelConfigId) {
      const modelConfigIdToSet = globalDefaultModelConfigId || availableModels[0].config_id;
      setCurrentChatModelConfigId(modelConfigIdToSet);
      console.log("Defaulting currentChatModelConfigId to:", modelConfigIdToSet);
    }
  }, [availableModels, globalDefaultModelConfigId, currentChatModelConfigId]);

  useEffect(() => {
    setIsChatSessionActive(messages.length > 0);
  }, [messages]);

  useEffect(() => {
    refetchMcpServers();
  }, [refetchMcpServers]);

  const handleScroll = useCallback(() => {
    const scrollViewport = scrollAreaRootRef.current?.querySelector('[data-radix-scroll-area-viewport]');
    if (scrollViewport) {
      const { scrollTop, scrollHeight, clientHeight } = scrollViewport;
      const atBottom = scrollHeight - scrollTop - clientHeight < 30;
      setIsUserScrolledUp(!atBottom);
    }
  }, []);

  useEffect(() => {
    const scrollViewport = scrollAreaRootRef.current?.querySelector('[data-radix-scroll-area-viewport]');
    if (scrollViewport) {
      scrollViewport.addEventListener('scroll', handleScroll);
      return () => scrollViewport.removeEventListener('scroll', handleScroll);
    }
  }, [handleScroll]);

  useEffect(() => {
    if (!isUserScrolledUp) {
      scrollToBottom();
    }
  }, [messages, isUserScrolledUp]);

  const scrollToBottom = (force: boolean = false) => {
    if (messagesEndRef.current && (!isUserScrolledUp || force)) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSendMessage = async (content: string, attachedFiles?: AttachedFile[]) => {
    if (!currentChatModelConfigId) {
      console.error('No model selected for the current chat (missing config_id)');
      return;
    }

    if (!hasStartedChat) {
      setIsAnimating(true);
      setTimeout(() => {
        setHasStartedChat(true);
        setIsAnimating(false);
      }, 800);
    }

    let apiFiles: ApiFile[] | undefined = undefined;
    if (attachedFiles && attachedFiles.length > 0) {
      apiFiles = await Promise.all(
        attachedFiles.map(async (af) => {
          const baseFile: Omit<ApiFile, 'data'> = {
            name: af.file.name,
            type: af.type,
            mime_type: af.file.type
          };
          if (af.type === 'image') {
            const base64Data = await new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve(reader.result as string);
              reader.onerror = (error) => reject(error);
              reader.readAsDataURL(af.file);
            });
            return { ...baseFile, data: base64Data };
          }
          return baseFile;
        })
      );
    }

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      parts: [{ id: `user-part-${Date.now()}`, type: 'text', text_content: content }],
      isUser: true,
      timestamp: new Date(),
      attachedFiles: attachedFiles,
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    const aiMessageId = `ai-${Date.now()}`;
    setStreamingMessageId(aiMessageId);
    
    const aiMessagePlaceholder: Message = {
      id: aiMessageId,
      parts: [],
      isUser: false,
      timestamp: new Date(),
      modelName: getModelDisplayName(currentChatModelConfigId),
    };
    
    setMessages(prev => [...prev, aiMessagePlaceholder]);

    try {
      await apiService.sendStreamingMessage(
        {
          message: content,
          conversation_id: conversationId || undefined,
          model_id: currentChatModelConfigId,
          files: apiFiles,
          stream: true,
          active_mcp_server_ids: selectedMcpServerIdsForNextChat.length > 0 ? selectedMcpServerIdsForNextChat : undefined,
        },
        (chunk: StreamChunk) => {
          if (!conversationId && chunk.conversation_id) {
            setConversationId(chunk.conversation_id);
          }

          if (chunk.message_id !== aiMessageId) {
            console.warn("Received chunk for a different message_id:", chunk.message_id, "expected:", aiMessageId);
          }
          
          setMessages(prev => prev.map(msg => {
            if (msg.id === aiMessageId) {
              const newParts = [...msg.parts];
              let partAdded = false;

              if (chunk.part_type === 'text' && chunk.text_content) {
                if (newParts.length > 0 && newParts[newParts.length - 1].type === 'text') {
                  const lastPartIndex = newParts.length - 1;
                  const existingLastPart = newParts[lastPartIndex];
                  newParts[lastPartIndex] = {
                    ...existingLastPart,
                    text_content: (existingLastPart.text_content || '') + chunk.text_content,
                  };
                } else {
                  newParts.push({
                    id: `part-${Date.now()}-${Math.random()}`,
                    type: 'text',
                    text_content: chunk.text_content,
                  });
                }
                partAdded = true;
              } else if (chunk.part_type === 'tool_call_request' && chunk.tool_call_request_data) {
                newParts.push({
                  id: `part-${Date.now()}-${Math.random()}`,
                  type: 'tool_call_request',
                  tool_name: chunk.tool_call_request_data.tool_name,
                  tool_arguments: chunk.tool_call_request_data.tool_arguments,
                });
                partAdded = true;
              } else if (chunk.part_type === 'tool_call_result' && chunk.tool_call_result_data) {
                newParts.push({
                  id: `part-${Date.now()}-${Math.random()}`,
                  type: 'tool_call_result',
                  tool_name: chunk.tool_call_result_data.tool_name,
                  tool_result: chunk.tool_call_result_data.tool_result,
                });
                partAdded = true;
              } else if (chunk.part_type === 'image' && chunk.image_data) {
                newParts.push({
                  id: `part-${Date.now()}-${Math.random()}`,
                  type: 'image',
                  data: chunk.image_data.data,
                  mimeType: chunk.image_data.mime_type,
                });
                partAdded = true;
              }
              
              if (partAdded) {
                return { ...msg, parts: newParts };
              }
            }
            return msg;
          }));

          if (chunk.done) {
            setStreamingMessageId(null);
            setIsLoading(false);
          }
        },
        (error: string) => {
          console.error('Streaming error:', error);
          setMessages(prev => prev.map(msg => 
            msg.id === aiMessageId 
              ? { ...msg, parts: [...msg.parts, { id: `error-part-${Date.now()}`, type: 'text', text_content: `Error: ${error}` }] }
              : msg
          ));
          setStreamingMessageId(null);
          setIsLoading(false);
        }
      );
    } catch (error) {
      console.error('Failed to send message:', error);
      const errorContent = error instanceof Error ? error.message : 'Failed to send message';
      setMessages(prev => prev.map(msg => 
        msg.id === aiMessageId 
          ? { ...msg, parts: [...msg.parts, { id: `catch-error-part-${Date.now()}`, type: 'text', text_content: `Error: ${errorContent}` }] }
          : msg
      ));
      setIsLoading(false);
      setStreamingMessageId(null);
    }
  };



  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-purple-900 transition-all duration-500">
      
      <div className="min-h-screen flex flex-col items-center">
        <div className="w-full max-w-4xl px-4 flex flex-col min-h-screen">
          
          {!hasStartedChat && !isAnimating ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="w-full max-w-2xl space-y-6 text-center">
                <div className="space-y-4">
                  <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Welcome to Pulse
                  </h2>
                  <p className="text-lg text-muted-foreground">
                    Your intelligent AI companion. Ask me anything!
                  </p>
                </div>
                <div className="w-full max-w-xl mx-auto">
                  <ChatInput
                    onSendMessage={handleSendMessage}
                    isLoading={isLoading}
                    availableModels={availableModels}
                    currentChatModelId={currentChatModelConfigId}
                    setCurrentChatModelId={setCurrentChatModelConfigId}
                    isChatSessionActive={isChatSessionActive}
                    getModelDisplayName={getModelDisplayName}
                    onOpenToolsDialog={() => setAvailableToolsDialogOpen(true)}
                    onOpenModelManagementDialog={() => setIsModelManagementDialogOpen(true)}
                  />
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex-1 py-0 overflow-hidden">
                {hasStartedChat && (
                  <ScrollArea 
                    ref={scrollAreaRootRef}
                    className="h-[calc(100vh-130px)] scroll-fade-out-bottom"
                  >
                    <div className="space-y-4 py-4 w-full max-w-3xl mx-auto">
                      {messages.map((message) => (
                        <ChatMessageDisplay
                          key={message.id}
                          message={message}
                        />
                      ))}
                      {isLoading && streamingMessageId && (
                        <div className="flex justify-start mb-4">
                          <div className="bg-gradient-to-r from-gray-100/80 to-gray-200/80 dark:from-gray-800/80 dark:to-gray-700/80 rounded-2xl px-4 py-3 backdrop-blur-sm shadow-sm">
                            <div className="flex space-x-1">
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div ref={messagesEndRef} />
                  </ScrollArea>
                )}
              </div>

              <div className={`pb-8 transition-all duration-800 ease-in-out ${
                isAnimating ? 'transform translate-y-0' : ''
              }`}>
                <div className="w-full max-w-3xl mx-auto">
                  <div className="sticky bottom-0 left-0 right-0 mt-auto p-0 bg-opacity-0">
                    <ChatInput
                      onSendMessage={handleSendMessage}
                      isLoading={isLoading}
                      className="pt-2"
                      availableModels={availableModels}
                      currentChatModelId={currentChatModelConfigId}
                      setCurrentChatModelId={setCurrentChatModelConfigId}
                      isChatSessionActive={isChatSessionActive}
                      getModelDisplayName={getModelDisplayName}
                      onOpenToolsDialog={() => setAvailableToolsDialogOpen(true)}
                      onOpenModelManagementDialog={() => setIsModelManagementDialogOpen(true)}
                    />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="fixed bottom-6 left-6 z-20">
        <Button
          onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
          variant="ghost"
          className="rounded-full p-3 bg-gray-200/50 dark:bg-gray-800/50 hover:bg-gray-300/50 dark:hover:bg-gray-700/50 backdrop-blur-sm border border-gray-300/30 dark:border-gray-600/30 shadow-sm transition-all duration-200"
          size="icon"
          title={theme === 'light' ? "Switch to Dark Mode" : "Switch to Light Mode"}
        >
          {theme === 'light' ? (
            <Moon className="h-5 w-5 text-gray-600 dark:text-gray-400" />
          ) : (
            <Sun className="h-5 w-5 text-gray-600 dark:text-gray-400" />
          )}
        </Button>
      </div>

      <AvailableToolsDialog 
        isOpen={availableToolsDialogOpen}
        onOpenChange={setAvailableToolsDialogOpen}
        allConfiguredMcpServers={allConfiguredMcpServers}
        selectedServerIds={selectedMcpServerIdsForNextChat}
        onSelectedServerIdsChange={setSelectedMcpServerIdsForNextChat}
        isChatSessionActive={isChatSessionActive}
        onMcpServersRefresh={refetchMcpServers}
      />

      <ModelManagementDialog 
        isOpen={isModelManagementDialogOpen}
        onOpenChange={setIsModelManagementDialogOpen}
        configuredModels={availableModels} 
        onModelsRefresh={async () => { 
          if (refetchModels) await refetchModels(); 
          // After potentially adding/deleting models, re-evaluate the currentChatModelConfigId
          // If the currently selected model was deleted, or if no model is selected, try to set a default.
          const currentModels = await apiService.listAIModels(); // get fresh list
          const stillExists = currentModels.find(m => m.config_id === currentChatModelConfigId);
          if (!stillExists || !currentChatModelConfigId) {
            if (currentModels.length > 0) {
              const newDefault = globalDefaultModelConfigId && currentModels.find(m => m.config_id === globalDefaultModelConfigId) 
                                ? globalDefaultModelConfigId 
                                : currentModels[0].config_id;
              setCurrentChatModelConfigId(newDefault);
              console.log("Model selection updated after ModelManagementDialog close. New currentChatModelConfigId:", newDefault);
            } else {
              setCurrentChatModelConfigId(null); // No models available
              console.log("No models available after ModelManagementDialog close.");
            }
          }
        }}
      />
    </div>
  );
}

export default App;
