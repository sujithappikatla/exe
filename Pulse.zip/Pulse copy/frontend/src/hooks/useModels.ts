import { useState, useEffect, useCallback } from 'react';
import { apiService } from '../services/api';
import type { AIModelConfig } from '../services/api';

const SELECTED_MODEL_CONFIG_KEY = 'pulse-selected-model-config-id';

export const useModels = () => {
  const [models, setModels] = useState<AIModelConfig[]>([]);
  const [selectedModelConfigId, setSelectedModelConfigId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchModels = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const fetchedModels = await apiService.listAIModels();
      // Filter out models that don't have a valid config_id, as they are unusable by the frontend
      const validModels = fetchedModels.filter(m => m.config_id && typeof m.config_id === 'string' && m.config_id.trim() !== '');
      setModels(validModels);
      
      const savedConfigId = localStorage.getItem(SELECTED_MODEL_CONFIG_KEY);
      
      let preferredModel: AIModelConfig | undefined = undefined;

      if (validModels.length > 0) {
        if (savedConfigId) {
          preferredModel = validModels.find(m => m.config_id === savedConfigId);
        }

        if (!preferredModel) {
          preferredModel =
            validModels.find(m => m.model_id_on_provider === 'gpt-4o') ||
            validModels.find(m => m.model_id_on_provider && m.model_id_on_provider.toLowerCase().includes('gpt-4')) ||
            validModels.find(m => m.model_provider === 'openai') ||
            validModels[0]; // Fallback to the first valid model
        }
      }
      
      if (preferredModel && preferredModel.config_id) {
        setSelectedModelConfigId(preferredModel.config_id);
        localStorage.setItem(SELECTED_MODEL_CONFIG_KEY, preferredModel.config_id);
        console.log('Default model config_id set to:', preferredModel.config_id);
      } else {
        setSelectedModelConfigId('');
        localStorage.removeItem(SELECTED_MODEL_CONFIG_KEY);
        if (validModels.length === 0) {
          console.warn('No valid AI models with config_id found after fetching.');
        } else {
          console.warn('Could not determine a preferred model or preferred model lacks config_id.');
        }
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch AI models';
      setError(errorMessage);
      console.error('Failed to fetch AI models:', err);
      setModels([]); // Clear models on error
      setSelectedModelConfigId(''); // Clear selection on error
      localStorage.removeItem(SELECTED_MODEL_CONFIG_KEY);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchModels();
  }, [fetchModels]);

  const setSelectedModelWithPersistence = (configId: string) => {
    const modelExists = models.some(m => m.config_id === configId); // models here are already filtered validModels
    if (modelExists) {
      setSelectedModelConfigId(configId);
      localStorage.setItem(SELECTED_MODEL_CONFIG_KEY, configId);
      console.log('Selected AI model config_id changed to:', configId);
    } else {
      console.warn(`Attempted to select non-existent model config_id: ${configId}. Clearing selection.`);
      setSelectedModelConfigId('');
      localStorage.removeItem(SELECTED_MODEL_CONFIG_KEY);
      if (models.length > 0) { // models here are already filtered validModels
        const fallbackModel = 
          models.find(m => m.model_id_on_provider === 'gpt-4o') || 
          models.find(m => m.model_id_on_provider && m.model_id_on_provider.toLowerCase().includes('gpt-4')) ||
          models.find(m => m.model_provider === 'openai') ||
          models[0];
        if (fallbackModel && fallbackModel.config_id) { // Ensure fallback has a config_id
            setSelectedModelConfigId(fallbackModel.config_id);
            localStorage.setItem(SELECTED_MODEL_CONFIG_KEY, fallbackModel.config_id);
        } else {
            console.warn("Fallback model selection failed or fallback model lacks config_id.")
        }
      }
    }
  };

  const getModelDisplayName = (configId: string | null): string => {
    if (!configId) return "Select Model";
    const model = models.find(m => m.config_id === configId); // models here are already filtered validModels
    return model?.display_name || configId;
  };
  
  const getSelectedModelConfig = (): AIModelConfig | undefined => {
    return models.find(m => m.config_id === selectedModelConfigId); // models here are already filtered validModels
  }

  return {
    models, // This list now only contains models with valid config_id
    selectedModel: selectedModelConfigId,
    setSelectedModel: setSelectedModelWithPersistence,
    loading,
    error,
    refetchModels: fetchModels,
    getModelDisplayName,
    getSelectedModelConfig,
  };
}; 