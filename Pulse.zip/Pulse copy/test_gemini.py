#!/usr/bin/env python3

import asyncio
from google import genai
from google.genai import types

async def test_gemini_direct():
    """Test Gemini directly with google-genai library"""
    
    print("🤖 Testing Gemini with google-genai library directly...")
    
    try:
        # Create client for Vertex AI (same config as our app)
        print("📡 Creating Vertex AI client...")
        client = genai.Client(
            vertexai=True,
            project="cloud-learning-443407",
            location="us-central1",
            http_options=types.HttpOptions(api_version="v1beta")
        )
        print("✅ Client created successfully!")
        
        # Test different model IDs
        model_ids_to_test = [
            "gemini-2.0-flash",
            "gemini-2.0-flash-001", 
            "gemini-1.5-flash",
            "gemini-1.5-flash-001",
            "gemini-1.5-pro",
            "gemini-1.5-pro-001"
        ]
        
        for model_id in model_ids_to_test:
            print(f"\n🧪 Testing model: {model_id}")
            
            try:
                # Simple test message
                contents = [types.Content(
                    role="user",
                    parts=[types.Part(text="Hello! Can you say hi back?")]
                )]
                
                # Test non-streaming first
                print(f"  📤 Testing non-streaming...")
                response = client.models.generate_content(
                    model=model_id,
                    contents=contents,
                    config=types.GenerateContentConfig(
                        temperature=0.7,
                        max_output_tokens=100
                    )
                )
                
                if response.candidates and response.candidates[0].content.parts:
                    text = response.candidates[0].content.parts[0].text
                    print(f"  ✅ Non-streaming SUCCESS: {text[:50]}...")
                    
                    # Test streaming
                    print(f"  📤 Testing streaming...")
                    stream = client.models.generate_content_stream(
                        model=model_id,
                        contents=contents,
                        config=types.GenerateContentConfig(
                            temperature=0.7,
                            max_output_tokens=100
                        )
                    )
                    
                    stream_text = ""
                    for chunk in stream:  # Regular for loop, not async for
                        if chunk.candidates and chunk.candidates[0].content.parts:
                            if chunk.candidates[0].content.parts[0].text:
                                stream_text += chunk.candidates[0].content.parts[0].text
                    
                    print(f"  ✅ Streaming SUCCESS: {stream_text[:50]}...")
                    
                    # If we get here, this model works!
                    print(f"🎉 MODEL {model_id} WORKS! Using this for testing...")
                    return model_id
                    
                else:
                    print(f"  ❌ Empty response from {model_id}")
                    
            except Exception as e:
                print(f"  ❌ ERROR with {model_id}: {e}")
                
        print("\n❌ No working models found!")
        return None
        
    except Exception as e:
        print(f"❌ Client creation failed: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    working_model = asyncio.run(test_gemini_direct())
    if working_model:
        print(f"\n🎯 RECOMMENDATION: Use model_id='{working_model}' in your config")
    else:
        print("\n🔍 Need to investigate Vertex AI setup or permissions") 