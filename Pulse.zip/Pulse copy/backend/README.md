# Pulse Chat Backend

FastAPI backend for the Pulse conversational chat application supporting OpenAI and Google Gemini models with flexible configuration via JSON.

## Features

- 🤖 **Multi-Provider Support**: OpenAI GPT models and Google Gemini models
- 💬 **Streaming & Non-Streaming**: Real-time streaming responses and traditional completions
- 🔄 **Conversation Management**: Automatic conversation history tracking
- 🌐 **CORS Enabled**: Ready for frontend integration
- 📝 **Interactive API Docs**: Swagger UI and ReDoc documentation
- 🔧 **JSON Configuration**: Flexible model configuration via `model_info.json`
- 🏢 **Vertex AI Support**: Support for both Google AI API and Vertex AI
- 🔑 **Per-Model Configuration**: Individual API keys and base URLs per model

## Quick Start

### 1. Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Models

Edit the `model_info.json` file to configure your models:

```json
[
    {
        "type": "openai",
        "display_name": "GPT-4o",
        "base_url": "https://api.openai.com/v1",
        "api_key": "your_openai_api_key_here",
        "model_id": "gpt-4o",
        "model_provider": "openai"
    },
    {
        "type": "google",
        "display_name": "Gemini 2.0 Flash",
        "model_id": "gemini-2.0-flash",
        "model_provider": "google",
        "project_id": "your_project_id",
        "vertex_ai": true,
        "location": "us-central1"
    }
]
```

### 3. Run the Server

```bash
# Development mode with auto-reload
python main.py

# Or using the startup script
python start.py

# Or using uvicorn directly
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

The API will be available at:
- **API Base**: http://localhost:8000
- **Interactive Docs**: http://localhost:8000/api/docs
- **ReDoc**: http://localhost:8000/api/redoc

## Model Configuration

### Configuration File Structure

The `model_info.json` file supports the following configuration options:

#### OpenAI Models
```json
{
    "type": "openai",
    "display_name": "GPT-4 Turbo",
    "base_url": "https://api.openai.com/v1",
    "api_key": "your_openai_api_key",
    "model_id": "gpt-4-turbo",
    "model_provider": "openai"
}
```

**Required fields:**
- `type`: "openai"
- `model_id`: OpenAI model identifier
- `api_key`: OpenAI API key
- `display_name`: Name shown in frontend

**Optional fields:**
- `base_url`: Custom API base URL (default: https://api.openai.com/v1)

#### Google Gemini Models (Regular API)
```json
{
    "type": "google",
    "display_name": "Gemini Pro",
    "model_id": "gemini-pro",
    "model_provider": "google",
    "api_key": "your_google_api_key"
}
```

#### Google Gemini Models (Vertex AI)
```json
{
    "type": "google",
    "display_name": "Gemini 2.0 Flash",
    "model_id": "gemini-2.0-flash",
    "model_provider": "google",
    "vertex_ai": true,
    "project_id": "your_gcp_project_id",
    "location": "us-central1"
}
```

**Required fields for Google:**
- `type`: "google"
- `model_id`: Google model identifier
- `display_name`: Name shown in frontend

**For regular Google AI API:**
- `api_key`: Google AI API key

**For Vertex AI:**
- `vertex_ai`: true
- `project_id`: GCP project ID
- `location`: GCP region (optional, default: us-central1)

## API Endpoints

### Health Check
- `GET /` - Basic health check
- `GET /api/health` - Detailed health status

### Models
- `GET /api/models/` - Get all available AI models
- `POST /api/models/reload` - Reload model configuration from JSON

### Chat
- `POST /api/chat/completions` - Create chat completion (non-streaming)
- `POST /api/chat/completions/stream` - Create streaming chat completion
- `GET /api/chat/conversations` - List all conversations
- `GET /api/chat/conversations/{conversation_id}/history` - Get conversation history
- `DELETE /api/chat/conversations/{conversation_id}` - Delete conversation

## Usage Examples

### Get Available Models

```bash
curl http://localhost:8000/api/models/
```

### Reload Model Configuration

```bash
curl -X POST http://localhost:8000/api/models/reload
```

### Chat Completion (Non-Streaming)

```bash
curl -X POST "http://localhost:8000/api/chat/completions" \
     -H "Content-Type: application/json" \
     -d '{
       "message": "Hello, how are you?",
       "model_id": "gpt-4o",
       "stream": false
     }'
```

### Streaming Chat Completion

```bash
curl -X POST "http://localhost:8000/api/chat/completions/stream" \
     -H "Content-Type: application/json" \
     -d '{
       "message": "Tell me a story",
       "model_id": "gemini-2.0-flash",
       "stream": true
     }'
```

## Project Structure

```
backend/
├── main.py                 # FastAPI application entry point
├── config.py              # Configuration management
├── models.py              # Pydantic models for requests/responses
├── memory_store.py        # In-memory conversation storage
├── model_info.json        # Model configuration file
├── requirements.txt       # Python dependencies
├── providers/             # AI provider implementations
│   ├── __init__.py
│   ├── base.py           # Base provider interface
│   ├── openai_provider.py # OpenAI implementation
│   └── google_provider.py # Google Gemini implementation
├── services/              # Business logic services
│   ├── __init__.py
│   └── model_service.py  # Model management service
└── routers/               # API route handlers
    ├── __init__.py
    ├── models.py         # Model endpoints
    └── chat.py           # Chat endpoints
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `HOST` | Server host | 0.0.0.0 |
| `PORT` | Server port | 8000 |
| `DEBUG` | Debug mode | True |
| `ALLOWED_ORIGINS` | CORS allowed origins | http://localhost:3000,http://localhost:5173 |
| `MODEL_CONFIG_FILE` | Path to model config JSON | model_info.json |

### Supported Models

Models are now configured via `model_info.json`. The backend supports:

#### OpenAI Models
- gpt-4o, gpt-4o-mini, gpt-4-turbo, gpt-4, gpt-3.5-turbo
- Custom base URLs for OpenAI-compatible APIs
- Individual API keys per model

#### Google Models
- gemini-pro, gemini-pro-vision, gemini-1.5-pro, gemini-1.5-flash, gemini-2.0-flash
- Support for both Google AI API and Vertex AI
- Configurable GCP projects and regions

## Development

### Adding a New Model

1. Add model configuration to `model_info.json`
2. Use POST `/api/models/reload` to reload without restarting
3. Model will be automatically available in the frontend

### Adding a New Provider

1. Create a new provider class in `providers/` inheriting from `BaseProvider`
2. Implement required methods: `get_model_info()`, `chat_completion()`, `stream_completion()`
3. Add provider initialization logic in `services/model_service.py`
4. Update `model_info.json` with the new provider type

### Testing

```bash
# Install test dependencies
pip install pytest httpx

# Run tests
pytest
```

## Production Deployment

1. Set `DEBUG=False` in environment
2. Use a production WSGI server like Gunicorn:
   ```bash
   pip install gunicorn
   gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker
   ```
3. Secure your `model_info.json` file (contains API keys)
4. Consider using environment variables or secret management for API keys
5. Set up proper authentication and rate limiting
6. Use a proper database instead of in-memory storage

## Security Notes

⚠️ **Important**: The `model_info.json` file contains sensitive API keys. Make sure to:
- Keep this file secure and not commit it to version control
- Use appropriate file permissions (600)
- Consider using environment variables or secret management systems for production

## Contributing

1. Follow PEP 8 style guidelines
2. Add type hints to all functions
3. Write docstrings for classes and methods
4. Add tests for new features
5. Update this README for significant changes 