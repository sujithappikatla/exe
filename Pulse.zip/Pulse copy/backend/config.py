import os
import json
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

from models import AppConfiguration

# Load environment variables from .env file
load_dotenv()

# Path to the configuration file
MODEL_INFO_FILE_PATH = os.getenv("MODEL_CONFIG_FILE", "model_info.json")

def load_app_config() -> AppConfiguration:
    """Load the entire application configuration from JSON file into AppConfiguration model."""
    try:
        with open(MODEL_INFO_FILE_PATH, 'r') as f:
            config_data = json.load(f)
            # Ensure top-level keys 'models' and 'mcp_servers' exist
            if 'models' not in config_data:
                config_data['models'] = []
            if 'mcp_servers' not in config_data:
                config_data['mcp_servers'] = []
            return AppConfiguration(**config_data)
    except FileNotFoundError:
        print(f"Warning: Config file '{MODEL_INFO_FILE_PATH}' not found. Returning default empty config.")
        return AppConfiguration(models=[], mcp_servers=[])
    except json.JSONDecodeError as e:
        print(f"Error parsing config file '{MODEL_INFO_FILE_PATH}': {e}. Returning default empty config.")
        return AppConfiguration(models=[], mcp_servers=[])
    except Exception as e:
        print(f"Unexpected error loading config file '{MODEL_INFO_FILE_PATH}': {e}. Returning default empty config.")
        return AppConfiguration(models=[], mcp_servers=[])

def save_app_config(app_config: AppConfiguration):
    """Save the AppConfiguration model to the JSON file."""
    try:
        with open(MODEL_INFO_FILE_PATH, 'w') as f:
            json.dump(app_config.model_dump(mode='json'), f, indent=4)
    except Exception as e:
        print(f"Error saving config file '{MODEL_INFO_FILE_PATH}': {e}")
        # Potentially raise the error or handle more gracefully
        raise

class Settings(BaseSettings):
    # Server Configuration
    host: str = os.getenv("HOST", "0.0.0.0")
    port: int = int(os.getenv("PORT", "8000"))
    debug: bool = os.getenv("DEBUG", "True").lower() == "true"
    
    # CORS Origins
    allowed_origins: List[str] = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000,http://localhost:5173").split(",")
    
    # Session Configuration
    session_secret_key: str = os.getenv("SESSION_SECRET_KEY", "pulse-secret-key-change-in-production")
    session_expire_minutes: int = int(os.getenv("SESSION_EXPIRE_MINUTES", "1440"))  # 24 hours
    
    # Application configuration (models, mcp_servers, etc.)
    # This will be loaded and can be updated.
    app_config: AppConfiguration = Field(default_factory=load_app_config)

    class Config:
        protected_namespaces = ('settings_',)

    # Method to reload app_config if needed, e.g., after an update via API
    def reload_app_config(self):
        self.app_config = load_app_config()

# Global settings instance
settings = Settings() 