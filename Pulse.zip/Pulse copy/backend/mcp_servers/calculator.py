# server_http.py

from mcp.server.fastmcp import FastMCP
import uvicorn
import os
import json
import uuid

# 1. Initialize the MCP server (stateless_http=True disables session persistence)
mcp = FastMCP("Calculator", stateless_http=True)


@mcp.tool()
def add(a: int, b: int) -> int:
    """
    Add two numbers.

    Args:
        a (int): The first number.
        b (int): The second number.

    Returns:
        int: The sum of the two numbers.
    """    
    return a + b

    
@mcp.tool()
def subtract(a: int, b: int) -> int:
    """
    Subtract two numbers.

    Args:
        a (int): The first number.
        b (int): The second number.

    Returns:
        int: The difference of the two numbers.
    """
    return a - b


@mcp.tool()
def multiply(a: int, b: int) -> int:
    """
    Multiply two numbers.

    Args:
        a (int): The first number.
        b (int): The second number.

    Returns:
        int: The product of the two numbers.
    """
    print(f"Multiplying {a} and {b}")
    print(f"Result: {a * b}")
    return a * b


@mcp.tool()
def divide(a: int, b: int) -> float:
    """
    Divide two numbers.

    Args:
        a (int): The first number.
        b (int): The second number.

    Returns:
        float: The quotient of the two numbers.
    """
    return a / b



# 3. Create an ASGI app for Streamable HTTP (default mount at /mcp)
http_app = mcp.streamable_http_app()

# 4. Run the server on port 8000
if __name__ == "__main__":
    uvicorn.run(http_app, host="0.0.0.0", port=8002)