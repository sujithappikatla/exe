# server_http.py

from mcp.server.fastmcp import FastMCP, Image
import uvicorn
import os
import json
import uuid
from io import StringIO
from contextlib import redirect_stdout
import base64

# 1. Initialize the MCP server (stateless_http=True disables session persistence)
mcp = FastMCP("Code Interpretor", stateless_http=True)

@mcp.tool()
async def interpret_code(code: str) -> str:
    """
    Interpret the python code.
    The code should be a valid python code.
    If there is some infromation that needs to be printed, use print() function.
    If there is some graph that needs to be plotted, use matplotlib function and dont show the plot, just save the plot as a png file with name "plot.png". The plot will be showed to user by Application, so dont show the plot in the output.
    Args:
        code (str): The python code to interpret.
    Returns:
        str: The result of the code interpretation.
    """
    if os.path.exists("plot.png"):
        os.remove("plot.png")
    

    print(f"Interpreting code: {code}")
    # Example with LangChain Sandbox

#     code = """import math
# factorial_of_9 = math.factorial(9)
# print(factorial_of_9)
# """

    f = StringIO()
    with redirect_stdout(f):
        exec(code)
    print(f)
    output = f.getvalue()
    print(output)
    # if os.path.exists("plot.png"):
    #     with open("plot.png", "rb") as f:
    #         png = base64.b64encode(f.read()).decode("utf-8")
    #         return [{"type": "text", "text": output}, Image(png)]
    
    if os.path.exists("plot.png"):
        return ["Plot Created Successfully", Image("plot.png")]
    


    return [output]






# 3. Create an ASGI app for Streamable HTTP (default mount at /mcp)
http_app = mcp.streamable_http_app()

# 4. Run the server on port 8000
if __name__ == "__main__":
    uvicorn.run(http_app, host="0.0.0.0", port=8003)