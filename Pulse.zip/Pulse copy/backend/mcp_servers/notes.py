# server_http.py

from mcp.server.fastmcp import FastMCP
import uvicorn
import os
import json
import uuid

# 1. Initialize the MCP server (stateless_http=True disables session persistence)
mcp = FastMCP("Notes App", stateless_http=True)

NOTEFILE_PATH = os.path.join(os.path.dirname(__file__), "notes.json")


def ensure_note_file():
    if not os.path.exists(NOTEFILE_PATH):
        with open(NOTEFILE_PATH, "w") as f:
            f.write("[]")


@mcp.tool()
def add_note(note: str, category: str) -> str:
    """
    Add a new note to the notes file.

    Args:
        note (str): The note to add.
        category (str): The category of the note.

    Returns:
        str: A message indicating that the note was added.
    """    
    ensure_note_file()

    note_id = uuid.uuid4().hex
    new_note = {
        "note_id": note_id,
        "note": note,
        "category": category,
    }
    with open(NOTEFILE_PATH, "r") as f:
        notes = json.load(f)
    notes.append(new_note)
    with open(NOTEFILE_PATH, "w") as f:
        json.dump(notes, f, indent=4)
    return f"Note added Succesfully with id: {note_id}"


@mcp.tool()
def list_notes() -> str:
    """
    List all notes in the notes file.

    Returns:
        str: A message listing all notes.
    """
    ensure_note_file()
    with open(NOTEFILE_PATH, "r") as f:
        notes = json.load(f)

    notes.sort(key=lambda note: note['note_id'])
    
    return "\n".join([f"Note ID: {note['note_id']} Category: {note['category']} Note : {note['note']} " for note in notes])


@mcp.tool()
def delete_note(note_id: str) -> str:
    """
    Delete a note from the notes file.

    Args:
        note_id (str): The note id to delete.

    Returns:
        str: A message indicating that the note was deleted.
    """
    ensure_note_file()
    with open(NOTEFILE_PATH, "r") as f:
        notes = json.load(f)
    notes = [note for note in notes if note['note_id'] != note_id]
    with open(NOTEFILE_PATH, "w") as f:
        json.dump(notes, f, indent=4)
    return f"Note deleted Succesfully"


# 3. Create an ASGI app for Streamable HTTP (default mount at /mcp)
http_app = mcp.streamable_http_app()

# 4. Run the server on port 8000
if __name__ == "__main__":
    uvicorn.run(http_app, host="0.0.0.0", port=8001)