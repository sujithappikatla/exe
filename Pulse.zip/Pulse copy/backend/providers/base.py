from abc import ABC, abstractmethod
from typing import List, Dict, Any, AsyncGenerator
from models import ChatMessage, ModelInfo

class BaseProvider(ABC):
    """Base class for AI model providers"""
    
    @abstractmethod
    async def get_model_info(self) -> ModelInfo:
        """Get model information"""
        pass
    
    @abstractmethod
    async def chat_completion(
        self, 
        messages: List[ChatMessage], 
        **kwargs
    ) -> str:
        """Get chat completion from the model"""
        pass
    
    @abstractmethod
    async def stream_completion(
        self, 
        messages: List[ChatMessage], 
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Get streaming chat completion from the model"""
        pass
    
    def format_messages_for_api(self, messages: List[ChatMessage]) -> List[Dict[str, Any]]:
        """Convert ChatMessage objects to API format"""
        formatted = []
        for message in messages:
            formatted.append({
                "role": message.role,
                "content": message.content
            })
        return formatted 