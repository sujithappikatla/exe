from google import genai
from google.genai import types
from google.protobuf.struct_pb2 import Value # For structuring arguments in FunctionResponse
import json
from typing import List, AsyncGenerator, Dict, Any, Optional
from models import ChatMessage, ModelInfo, ApiFile, McpToolDefinition, StreamChunk, ToolCallRequestDetails, ToolCallResultDetails
from providers.base import BaseProvider
import logging # Import logging
import traceback # Import traceback
import base64 # For decoding base64 images
from datetime import datetime

# Import mcp_service
from services.mcp_service import mcp_service

# Configure basic logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MCP_SEPARATOR = "__MCP__" # Define a separator for composite tool names

def _make_valid_function_name(server_id: str, tool_name: str) -> str:
    """Generate a valid function name for Gemini that starts with a letter or underscore.
    
    Gemini requires function names to:
    - Start with a letter or underscore
    - Be a-z, A-Z, 0-9, or contain underscores, dots and dashes
    - Maximum length of 64 characters
    """
    composite_name = f"{server_id}{MCP_SEPARATOR}{tool_name}"
    
    # If the name starts with a number, prefix with 'mcp_'
    if composite_name and composite_name[0].isdigit():
        composite_name = f"mcp_{composite_name}"
    
    # Ensure it doesn't exceed 64 characters
    if len(composite_name) > 64:
        # Truncate server_id if needed, keeping tool_name intact
        max_server_id_len = 64 - len(MCP_SEPARATOR) - len(tool_name) - 4  # 4 for 'mcp_' prefix
        if max_server_id_len > 0:
            truncated_server_id = server_id[:max_server_id_len]
            composite_name = f"mcp_{truncated_server_id}{MCP_SEPARATOR}{tool_name}"
        else:
            # If tool name itself is too long, truncate the entire thing
            composite_name = composite_name[:64]
    
    return composite_name

def _extract_server_tool_from_function_name(function_name: str) -> tuple[str, str]:
    """Extract server_id and tool_name from a potentially prefixed function name."""
    # Remove 'mcp_' prefix if present
    clean_name = function_name
    if function_name.startswith("mcp_"):
        clean_name = function_name[4:]  # Remove 'mcp_' prefix
    
    # Split by MCP_SEPARATOR
    parts = clean_name.split(MCP_SEPARATOR)
    if len(parts) == 2:
        return parts[0], parts[1]
    else:
        # Fallback - return original function name split
        original_parts = function_name.split(MCP_SEPARATOR)
        if len(original_parts) == 2:
            return original_parts[0], original_parts[1]
        else:
            # Unable to parse, return as-is
            return function_name, ""

class GoogleProvider(BaseProvider):
    """Google Gemini models provider using unified google-genai SDK"""
    
    def __init__(self, model_config: Dict[str, Any]):
        self.model_config = model_config
        self.model_id = model_config.get("model_id", "")
        self.display_name = model_config.get("display_name", self.model_id)
        self.use_vertex_ai = model_config.get("vertex_ai", False)
        
        logger.info(f"Initializing GoogleProvider for model: {self.model_id}, Vertex AI: {self.use_vertex_ai}")
        
        try:
            if self.use_vertex_ai:
                project_id = model_config.get("project_id")
                location = model_config.get("location", "us-central1")
                if not project_id:
                    logger.error("project_id is required for Vertex AI but not found in config.")
                    raise ValueError("project_id is required for Vertex AI")
                
                logger.info(f"Creating Google GenAI client for Vertex AI: project={project_id}, location={location}")
                # Use Vertex AI configuration
                self.client = genai.Client(
                    vertexai=True,
                    project=project_id,
                    location=location,
                    http_options=types.HttpOptions(api_version="v1")
                )
            else:
                api_key = model_config.get("api_key")
                if not api_key:
                    logger.error("api_key is required for Google AI API but not found in config.")
                    raise ValueError("api_key is required for Google AI API")
                logger.info(f"Creating Google GenAI client for Google AI API with API key.")
                # Use Google AI API configuration
                self.client = genai.Client(
                    api_key=api_key,
                    http_options=types.HttpOptions(api_version="v1beta")
                )
            
            logger.info(f"Google GenAI client created successfully for {self.model_id}.")
        except Exception as e:
            logger.error(f"Failed to create Google GenAI client for {self.model_id}: {e}")
            logger.error(traceback.format_exc())
            raise
    
    async def get_model_info(self) -> ModelInfo:
        """Get model information"""
        return ModelInfo(
            model_id=self.model_id,
            name=self.display_name,
            provider="google",
            description=f"Google {self.display_name} model (MCP Tool Enabled)"
        )
    
    def _format_messages_for_gemini(self, messages: List[ChatMessage]) -> List[types.Content]:
        contents_for_gemini = []
        for message in messages:
            gemini_role = "user"
            if message.role == "assistant":
                gemini_role = "model"
            elif message.role == "system":
                continue # System messages are handled via system_instruction
            elif message.role == "tool":
                try:
                    # For Gemini, the response content should be a dict.
                    # If mcp_service.call_mcp_tool returns a simple string, wrap it.
                    # If it returns a dict, use it directly.
                    tool_result_from_service = message.content
                    response_data_for_gemini = {}
                    if isinstance(tool_result_from_service, dict):
                        response_data_for_gemini = tool_result_from_service
                    elif isinstance(tool_result_from_service, str):
                        # Attempt to parse if it's a JSON string, otherwise wrap as text
                        try:
                            response_data_for_gemini = json.loads(tool_result_from_service)
                        except json.JSONDecodeError:
                            response_data_for_gemini = {"text_response": tool_result_from_service}
                    else:
                        # Fallback for other types, convert to string and wrap
                        response_data_for_gemini = {"response": str(tool_result_from_service)}

                    # model_name should hold the composite function name
                    function_name = message.name # Changed from message.model_name to message.name
                    if not function_name:
                        logger.warning("Tool response message missing original function name in 'name' field.")
                        continue

                    contents_for_gemini.append(types.Content(
                        role="user", # Tool responses are from user role for Gemini
                        parts=[types.Part(function_response=types.FunctionResponse(
                            name=function_name, 
                            response=response_data_for_gemini
                        ))]
                    ))
                    logger.debug(f"Formatted tool response for Gemini: name={function_name}, response={response_data_for_gemini}")
                except Exception as e:
                    logger.error(f"Error formatting tool response for Gemini: {e} - {traceback.format_exc()}")
                continue

            parts = []
            if message.content:
                parts.append(types.Part(text=message.content))

            if message.files and message.role == "user":
                for file_info in message.files:
                    if file_info.type == 'image' and file_info.data and file_info.mime_type:
                        try:
                            # Data is expected to be base64 string already for Gemini (if from frontend)
                            # Or raw bytes if handled internally
                            if file_info.data.startswith('data:'):
                                header, encoded_data = file_info.data.split(",", 1)
                                image_bytes = base64.b64decode(encoded_data)
                            else:
                                image_bytes = base64.b64decode(file_info.data) # Assume it's base64 if not a data URI
                            
                            image_blob = types.Blob(data=image_bytes, mime_type=file_info.mime_type)
                            parts.append(types.Part(inline_data=image_blob))
                            logger.debug(f"Added image part for Gemini: {file_info.name}, mime: {file_info.mime_type}")
                        except Exception as e:
                            logger.error(f"Error processing image for Gemini: {file_info.name} - {e} - {traceback.format_exc()}")
            
            if parts:
                contents_for_gemini.append(types.Content(role=gemini_role, parts=parts))
        
        return contents_for_gemini
    
    async def _build_system_prompt_with_mcp_tools(self, original_messages: List[ChatMessage], active_mcp_server_ids: Optional[List[str]] = None) -> str:
        """Generates a system prompt string including descriptions of dynamically discovered MCP tools for Gemini,
           filtered by active_mcp_server_ids if provided."""
        from config import settings # Delayed import
        
        # Ensure active_mcp_server_ids is a list for consistent processing; if None, no servers are active.
        effective_active_server_ids = active_mcp_server_ids if active_mcp_server_ids is not None else []

        mcp_tool_descriptions_str_list = []
        server_configs_map: Dict[str, Any] = {s.id: s for s in settings.app_config.mcp_servers}
        all_discovered_tools: Dict[str, List[McpToolDefinition]] = await mcp_service.get_all_discovered_tools()

        if not all_discovered_tools:
            return "" # No tools, no special prompt needed

        prompt_intro = "You have access to the following tools from external Model Context Protocol (MCP) servers. To use a tool, you MUST respond by calling the function with the specified composite name (server_id__MCP__tool_name) and provide arguments matching its schema using the FunctionCall feature.\\n"

        for server_id, tool_defs in all_discovered_tools.items():
            # Use effective_active_server_ids for the check
            if effective_active_server_ids and server_id not in effective_active_server_ids:
                continue # Skip this server if not in the active list (and the list is not empty)
            elif not effective_active_server_ids and active_mcp_server_ids is not None: # Case where active_mcp_server_ids was explicitly empty
                continue # No servers are active, so skip all
            elif active_mcp_server_ids is None: # if original active_mcp_server_ids was None, skip all tools from MCP servers
                continue

            server_config = server_configs_map.get(server_id)
            server_display_name = server_config.display_name if server_config else f"Server ID {server_id}"
            
            if tool_defs:
                server_desc = f"\\n--- MCP Server: '{server_display_name}' (ID: {server_id}) ---\\nTools available on this server:"
                tool_descs_for_server = []
                for tool in tool_defs:
                    composite_tool_name = _make_valid_function_name(server_id, tool.name)
                    param_schema_desc_parts = []
                    if tool.parameters_schema and tool.parameters_schema.get("properties"):
                        for p_name, p_info in tool.parameters_schema["properties"].items():
                            p_type = p_info.get("type", "any")
                            p_desc = p_info.get("description", "")
                            is_required = p_name in tool.parameters_schema.get("required", [])
                            req_str = " (required)" if is_required else ""
                            param_schema_desc_parts.append(f"    - Parameter '{p_name}': ({p_type}{req_str}) {p_desc}")
                    
                    param_summary = " (This tool takes no arguments)" if not param_schema_desc_parts else "\\n  Arguments expected by this tool (as a JSON object):\\n" + "\\n".join(param_schema_desc_parts)
                    tool_descs_for_server.append(f"  - Function Name: `{composite_tool_name}`\\n    Description: {tool.description}{param_summary}")
                
                if tool_descs_for_server:
                    mcp_tool_descriptions_str_list.append(server_desc + "\\n" + "\\n".join(tool_descs_for_server))
        
        if not mcp_tool_descriptions_str_list:
            return ""

        return prompt_intro + "\\n".join(mcp_tool_descriptions_str_list)

    def _get_system_instruction_from_messages(self, messages: List[ChatMessage]) -> Optional[types.Content]:
        system_texts = [msg.content for msg in messages if msg.role == "system" and msg.content]
        if system_texts:
            return types.Content(role="system", parts=[types.Part(text="\\n".join(system_texts))])
        return None

    async def _get_gemini_tool_config(self, active_mcp_server_ids: Optional[List[str]] = None) -> Optional[types.Tool]:
        """Generates Gemini-compatible Tool (list of FunctionDeclarations) for discovered MCP tools,
           filtered by active_mcp_server_ids if provided."""
        
        # Ensure active_mcp_server_ids is a list for consistent processing; if None, no servers are active.
        effective_active_server_ids = active_mcp_server_ids if active_mcp_server_ids is not None else []

        all_discovered_tools: Dict[str, List[McpToolDefinition]] = await mcp_service.get_all_discovered_tools()
        function_declarations = []

        if not all_discovered_tools: # if no tools discovered at all, return empty
            return None

        for server_id, tool_defs in all_discovered_tools.items():
            # Use effective_active_server_ids for the check
            if effective_active_server_ids and server_id not in effective_active_server_ids:
                continue # Skip this server if not in the active list (and the list is not empty)
            elif not effective_active_server_ids and active_mcp_server_ids is not None: # Case where active_mcp_server_ids was explicitly empty
                continue # No servers are active, so skip all
            elif active_mcp_server_ids is None: # if original active_mcp_server_ids was None, skip all tools from MCP servers
                continue

            for tool_def in tool_defs:
                composite_tool_name = _make_valid_function_name(server_id, tool_def.name)
                
                # Convert our parameters_schema (JSON schema dict) to Gemini's types.Schema
                gemini_params = None
                if tool_def.parameters_schema and tool_def.parameters_schema.get("type") == "object":
                    properties = {}
                    required_list = tool_def.parameters_schema.get("required", [])
                    if tool_def.parameters_schema.get("properties"):
                        for p_name, p_schema in tool_def.parameters_schema["properties"].items():
                            # Basic type mapping, can be expanded
                            p_type_str = p_schema.get("type", "string").upper()
                            gemini_type = getattr(types.Type, p_type_str, types.Type.STRING) # Default to STRING
                            properties[p_name] = types.Schema(type=gemini_type, description=p_schema.get("description"))
                    
                    gemini_params = types.Schema(
                        type=types.Type.OBJECT,
                        properties=properties if properties else None, # Ensure properties is not empty dict
                        required=required_list if required_list else None
                    )
                elif not tool_def.parameters_schema or not tool_def.parameters_schema.get("properties"): # No params
                     gemini_params = types.Schema(type=types.Type.OBJECT) # Tool with no params still needs an Object schema

                if gemini_params: # Only add tool if schema conversion was successful
                    function_declarations.append(
                        types.FunctionDeclaration(
                            name=composite_tool_name,
                            description=tool_def.description,
                            parameters=gemini_params
                        )
                    )
                else:
                    logger.warning(f"Could not generate Gemini schema for tool {composite_tool_name}, skipping.")
        
        if function_declarations:
            # For now, forcing function calling mode if tools are present.
            # Consider making this configurable or based on model capabilities.
            # The Tool object directly takes function_declarations.
            # The ToolConfig is applied at the generate_content call level.
            return types.Tool(function_declarations=function_declarations)
        return None

    async def _get_gemini_tools_list(self, active_mcp_server_ids: Optional[List[str]] = None) -> Optional[List[types.Tool]]:
        """ Generates a list of Gemini Tool objects for discovered MCP tools,
            filtered by active_mcp_server_ids if provided."""
        all_discovered_tools: Dict[str, List[McpToolDefinition]] = await mcp_service.get_all_discovered_tools()
        function_declarations = []
        for server_id, tool_defs in all_discovered_tools.items():
            if active_mcp_server_ids is not None and server_id not in active_mcp_server_ids:
                continue

            for tool_def in tool_defs:
                composite_tool_name = _make_valid_function_name(server_id, tool_def.name)
                gemini_params = None
                if tool_def.parameters_schema and tool_def.parameters_schema.get("type") == "object":
                    properties = {}
                    required_list = tool_def.parameters_schema.get("required", [])
                    if tool_def.parameters_schema.get("properties"):
                        for p_name, p_schema in tool_def.parameters_schema["properties"].items():
                            p_type_str = p_schema.get("type", "string").upper()
                            gemini_type_val = getattr(types.Type, p_type_str, types.Type.STRING)
                            properties[p_name] = types.Schema(type=gemini_type_val, description=p_schema.get("description"))
                    gemini_params = types.Schema(type=types.Type.OBJECT, properties=properties if properties else None, required=required_list if required_list else None)
                elif not tool_def.parameters_schema or not tool_def.parameters_schema.get("properties"):
                    gemini_params = types.Schema(type=types.Type.OBJECT) # Empty object for no-args tools
                
                if gemini_params:
                    function_declarations.append(types.FunctionDeclaration(name=composite_tool_name, description=tool_def.description, parameters=gemini_params))
                else:
                    logger.warning(f"Skipping tool {composite_tool_name} for Gemini due to schema conversion issue.")

        if function_declarations:
            return [types.Tool(function_declarations=function_declarations)]
        return None
    
    async def chat_completion(
        self, 
        messages: List[ChatMessage], 
        **kwargs
    ) -> str:
        logger.info(f"GoogleProvider: chat_completion for model: {self.model_id}")
        
        active_mcp_server_ids = kwargs.get("active_mcp_server_ids")

        # System instruction from original messages
        system_instruction_parts = [msg.content for msg in messages if msg.role == "system" and msg.content]
        
        # MCP tool descriptions (only if active servers and tools exist)
        mcp_tools_system_prompt_str = await self._build_system_prompt_with_mcp_tools(messages, active_mcp_server_ids)
        if mcp_tools_system_prompt_str: # Add MCP tool prompt only if it's non-empty
            system_instruction_parts.append(mcp_tools_system_prompt_str)
        
        final_system_instruction = None
        if system_instruction_parts:
            final_system_instruction = "\n\n".join(system_instruction_parts)

        gemini_messages = self._format_messages_for_gemini(messages)
        gemini_tools = await self._get_gemini_tool_config(active_mcp_server_ids) # Returns types.Tool or None

        # ToolConfig is separate for controlling mode
        gemini_tool_config = None
        if gemini_tools:
            gemini_tool_config = types.ToolConfig(
                function_calling_config=types.FunctionCallingConfig(
                    mode="AUTO"
                )
            )

        max_tool_iterations = 5
        current_iteration = 0

        while current_iteration < max_tool_iterations:
            current_iteration += 1
            logger.info(f"Google API call (iteration {current_iteration}): model={self.model_id}")

            generation_config = types.GenerateContentConfig(
                temperature=kwargs.get("temperature", 0.7),
                max_output_tokens=kwargs.get("max_tokens", 8096),
                system_instruction=final_system_instruction if final_system_instruction else None,
                tools=[gemini_tools] if gemini_tools else None,
                tool_config=gemini_tool_config if gemini_tool_config else None,
            )

            try:
                logger.debug(f"Sending to Gemini: contents={gemini_messages}, config={generation_config}")
                
                response = self.client.models.generate_content(
                    model=self.model_id,
                    contents=gemini_messages,
                    config=generation_config
                )
            except Exception as e:
                logger.error(f"Google API error during generate_content for {self.model_id}: {e}")
                logger.error(traceback.format_exc())
                raise Exception(f"Google API error: {e}")
    
            if not response.candidates or not response.candidates[0].content.parts:
                logger.warning(f"Google API response had no candidates or parts for {self.model_id}")
                return "Sorry, I could not process that request."

            response_part = response.candidates[0].content.parts[0]

            if response_part.function_call:
                fc = response_part.function_call
                logger.info(f"Google model requested function call: {fc.name} with args: {fc.args}")
                
                # Append assistant's function call request to history
                gemini_messages.append(types.Content(
                    role="model", 
                    parts=[types.Part(function_call=fc)]
                ))
                
                # Extract server_id and tool_name from potentially prefixed function name
                server_id, tool_name = _extract_server_tool_from_function_name(fc.name)
                if server_id and tool_name:
                    tool_args_dict = dict(fc.args) if fc.args else {}
                    try:
                        logger.info(f"Executing MCP tool: server='{server_id}', tool='{tool_name}', args={tool_args_dict}")
                        tool_result_content = await mcp_service.call_mcp_tool(
                            server_id=server_id,
                            tool_name=tool_name,
                            arguments=tool_args_dict
                        )
                        logger.info(f"MCP tool result (first 200 chars): {str(tool_result_content)[:200]}")
                        
                        # Process parts for LLM content, but send original full result for history/FunctionResponse wrapper
                        llm_response_content_str = ""
                        if isinstance(tool_result_content, list):
                            logger.info(f"GoogleProvider: MCP response is a list in chat_completion. Iterating {len(tool_result_content)} parts for {fc.name}.")
                            for idx, mcp_part in enumerate(tool_result_content):
                                part_type_attr = getattr(mcp_part, 'type', None)
                                # part_data_attr = getattr(mcp_part, 'data', None) # Not needed for LLM string
                                # part_mime_type_attr = getattr(mcp_part, 'mimeType', getattr(mcp_part, 'mime_type', None)) # Not needed for LLM string

                                if part_type_attr == 'image':
                                    logger.info(f"GoogleProvider: Found IMAGE part for {fc.name} in chat_completion (idx {idx}). Skipping for LLM content.")
                                    # Skip image parts for LLM
                                elif part_type_attr == 'text' and hasattr(mcp_part, 'text'):
                                    logger.info(f"GoogleProvider: Found TEXT part for {fc.name} in chat_completion (idx {idx}).")
                                    llm_response_content_str += (getattr(mcp_part, 'text', None) or "") + "\n"
                                else:
                                    logger.warning(f"GoogleProvider: Found UNKNOWN/other MCP part for {fc.name} in chat_completion (idx {idx}): {mcp_part}. Adding JSON to LLM string.")
                                    try:
                                        llm_response_content_str += json.dumps(mcp_part) + "\n"
                                    except TypeError:
                                        llm_response_content_str += str(mcp_part) + "\n"
                            llm_response_content_str = llm_response_content_str.strip()
                        elif isinstance(tool_result_content, str):
                            llm_response_content_str = tool_result_content
                        elif isinstance(tool_result_content, dict):
                             # If it's a dict (e.g. error, or simple response), send its string form or a summary
                            llm_response_content_str = json.dumps(tool_result_content) 
                        else:
                            llm_response_content_str = str(tool_result_content)

                        if not llm_response_content_str:
                             llm_response_content_str = "[Tool executed, textual parts processed]"

                        # For Gemini, the FunctionResponse.response field expects a dict.
                        # We use the llm_response_content_str (which now only contains text or JSON of other parts)
                        # to form this dictionary for the LLM.
                        structured_tool_result_for_llm = {"summary_of_execution": llm_response_content_str}
                        
                        # Append tool execution result to history
                        gemini_messages.append(types.Content(
                            role="user", # Tool response from 'user' role
                            parts=[types.Part(function_response=types.FunctionResponse(
                                name=fc.name, # Original composite name
                                response=structured_tool_result_for_llm # Send the text-only summary dict to LLM
                            ))]
                        ))
                    except Exception as e:
                        logger.error(f"Error processing MCP tool call for {fc.name} or executing tool: {e}")
                        logger.error(traceback.format_exc())
                        gemini_messages.append(types.Content(
                            role="user",
                            parts=[types.Part(function_response=types.FunctionResponse(
                                name=fc.name,
                                response={"error": f"Error executing tool {fc.name}: {str(e)}"}
                            ))]
                        ))
                else:
                    logger.warning(f"Unsupported function call format or non-MCP tool requested: {fc.name}")
                    gemini_messages.append(types.Content(
                        role="user",
                        parts=[types.Part(function_response=types.FunctionResponse(
                            name=fc.name,
                            response={"error": f"Tool '{fc.name}' is not a recognized MCP tool."}
                        ))]
                    ))
                # Loop back to call Google API again with the tool results included
            elif response_part.text:
                logger.info(f"Final response from Google (non-streaming): {response_part.text[:200]}")
                return response_part.text
            else:
                logger.warning("Google API response part had no function_call and no text.")
                return "Sorry, I received an empty response."
        
        logger.warning(f"GoogleProvider: Exceeded max tool iterations ({max_tool_iterations}) for model {self.model_id}")
        # Fallback: return the last model message content if any, or empty string
        last_model_message_part = next((p for c in reversed(gemini_messages) if c.role == "model" for p in c.parts if p.text), None)
        return last_model_message_part.text if last_model_message_part else ""

    
    async def stream_completion(
        self, 
        messages: List[ChatMessage], 
        **kwargs
    ) -> AsyncGenerator[StreamChunk, None]:
        logger.info(f"GoogleProvider: stream_completion for model: {self.model_id}")

        active_mcp_server_ids = kwargs.get("active_mcp_server_ids")
        conversation_id = kwargs.get("conversation_id")
        # Use "message_id" from kwargs, falling back if not present.
        # This aligns with what the frontend sends via model_service.
        message_id = kwargs.get("message_id", f"google_fallback_msg_{datetime.utcnow().timestamp()}") 

        # System instruction from original messages
        system_instruction_parts = [msg.content for msg in messages if msg.role == "system" and msg.content]

        # MCP tool descriptions (only if active servers and tools exist)
        mcp_tools_system_prompt_str = await self._build_system_prompt_with_mcp_tools(messages, active_mcp_server_ids)
        if mcp_tools_system_prompt_str: # Add MCP tool prompt only if it's non-empty
            system_instruction_parts.append(mcp_tools_system_prompt_str)

        final_system_instruction = None
        if system_instruction_parts:
            final_system_instruction = "\n\n".join(system_instruction_parts)

        gemini_messages = self._format_messages_for_gemini(messages)
        gemini_tools = await self._get_gemini_tool_config(active_mcp_server_ids) # Returns types.Tool or None
        
        # ToolConfig is separate for controlling mode
        gemini_tool_config = None
        if gemini_tools:
            gemini_tool_config = types.ToolConfig(
                function_calling_config=types.FunctionCallingConfig(
                    mode="AUTO"
                )
            )

        max_tool_iterations = 5
        current_iteration = 0

        while current_iteration < max_tool_iterations:
            current_iteration += 1
            logger.info(f"Google API stream call (iteration {current_iteration}): model={self.model_id}")

            generation_config = types.GenerateContentConfig(
                temperature=kwargs.get("temperature", 0.7),
                max_output_tokens=kwargs.get("max_tokens", 8096),
                system_instruction=final_system_instruction if final_system_instruction else None,
                tools=[gemini_tools] if gemini_tools else None,
                tool_config=gemini_tool_config if gemini_tool_config else None,
            )
            
            try:
                logger.debug(f"Sending to Gemini (stream): contents={gemini_messages}, config={generation_config}")
                
                stream = self.client.models.generate_content_stream(
                    model=self.model_id,
                    contents=gemini_messages,
                    config=generation_config
                )
            except Exception as e:
                logger.error(f"Google API error during stream generate_content for {self.model_id}: {e}")
                logger.error(traceback.format_exc())
                yield StreamChunk(
                    conversation_id=conversation_id or "unknown_conv",
                    message_id=message_id, # Use standardized message_id
                    part_type="text",
                    text_content=f"Error: Google API error: {e}",
                    done=True
                )
                return

            accumulated_function_call: Optional[types.FunctionCall] = None
            # To store the parts of the current assistant textual response before a tool call
            current_text_response_parts: List[str] = [] 

            for chunk in stream:
                # Add proper null safety checks for all levels
                if not chunk.candidates:
                    # logger.debug("Stream chunk had no candidates.")
                    continue
                
                candidate = chunk.candidates[0]
                if not candidate.content:
                    # logger.debug("Stream chunk candidate had no content.")
                    continue
                    
                if not candidate.content.parts:
                    # logger.debug("Stream chunk candidate content had no parts.")
                    continue
                
                part = candidate.content.parts[0]

                if part.text:
                    # logger.debug(f"Stream chunk text: {part.text}")
                    current_text_response_parts.append(part.text)
                    yield StreamChunk(
                        conversation_id=conversation_id or "unknown_conv",
                        message_id=message_id, # Use standardized message_id
                        part_type="text",
                        text_content=part.text
                    )
                
                if part.function_call:
                    # logger.debug(f"Stream chunk function_call: {part.function_call}")
                    # Function calls from Gemini stream are usually sent in full, not chunked for name/args.
                    # However, if they were chunked, we might need to accumulate here.
                    # For now, assume one chunk gives the full FunctionCall part.
                    accumulated_function_call = part.function_call # Overwrite if multiple, take the last one
            
            # After processing all chunks for this stream response:
            if accumulated_function_call:
                fc = accumulated_function_call
                logger.info(f"Google model requested function call (from stream): {fc.name} with args: {dict(fc.args)}")

                # Append assistant's response (text + function call) to history
                # If there was text before the function call, add it.
                assistant_parts_for_history = []
                if current_text_response_parts:
                    assistant_parts_for_history.append(types.Part(text="".join(current_text_response_parts)))
                assistant_parts_for_history.append(types.Part(function_call=fc))
                
                gemini_messages.append(types.Content(role="model", parts=assistant_parts_for_history))
                current_text_response_parts.clear() # Reset for next iteration
                accumulated_function_call = None # Reset for next iteration
                
                # Extract server_id and tool_name from potentially prefixed function name
                server_id, tool_name = _extract_server_tool_from_function_name(fc.name)
                if server_id and tool_name:
                    tool_args_dict = dict(fc.args) if fc.args else {}
                    try:
                        logger.info(f"Executing MCP tool (from stream): server='{server_id}', tool='{tool_name}', args={tool_args_dict}")
                        
                        # Yield tool_call_request chunk
                        yield StreamChunk(
                            conversation_id=conversation_id or "unknown_conv",
                            message_id=message_id, # Use standardized message_id
                            part_type="tool_call_request",
                            tool_call_request_data=ToolCallRequestDetails(
                                tool_name=fc.name, # Composite name
                                tool_arguments=tool_args_dict
                            )
                        )
                        
                        # mcp_service.call_mcp_tool returns a list of content parts or a string/dict for older/simpler tools
                        tool_result_content_from_mcp = await mcp_service.call_mcp_tool(
                            server_id=server_id,
                            tool_name=tool_name,
                            arguments=tool_args_dict
                        )
                        logger.info(f"MCP tool result (from stream, type: {type(tool_result_content_from_mcp)}): {str(tool_result_content_from_mcp)[:200]}")
                        
                        # Yield the full MCP response as ToolCallResultDetails first, this is what the UI will display in the collapsible section
                        yield StreamChunk(
                            conversation_id=conversation_id or "unknown_conv",
                            message_id=message_id,
                            part_type="tool_call_result",
                            tool_call_result_data=ToolCallResultDetails(
                                tool_name=fc.name, # Composite name
                                tool_result=tool_result_content_from_mcp # Send the raw, complete result for display
                            )
                        )

                        # Now, process parts for LLM and potential separate image chunks
                        llm_response_content_str = ""
                        # This is the content that will be sent back to the LLM
                        structured_tool_result_for_llm = {}

                        if isinstance(tool_result_content_from_mcp, list):
                            for part_idx, mcp_part in enumerate(tool_result_content_from_mcp):
                                part_type_attr = getattr(mcp_part, 'type', None)
                                part_data_attr = getattr(mcp_part, 'data', None)
                                part_mime_type_attr = getattr(mcp_part, 'mimeType', getattr(mcp_part, 'mime_type', None))

                                logger.info(f"GoogleProvider: Processing MCP part {part_idx} for {fc.name}: Type: {part_type_attr}, HasData: {part_data_attr is not None}, HasMimeType: {part_mime_type_attr is not None}")

                                if part_type_attr == 'image' and part_data_attr is not None and part_mime_type_attr is not None:
                                    logger.info(f"GoogleProvider: Found IMAGE part for {fc.name}. MimeType: {part_mime_type_attr}. Yielding separate image chunk. Skipping for LLM content.")
                                    # Yield separate image chunk for direct display in UI
                                    yield StreamChunk(
                                        conversation_id=conversation_id or "unknown_conv",
                                        message_id=message_id,
                                        part_type='image',
                                        image_data={'data': part_data_attr, 'mime_type': part_mime_type_attr},
                                        done=False
                                    )
                                    # Skip adding image placeholders to the LLM response string
                                elif part_type_attr == 'text' and hasattr(mcp_part, 'text'):
                                    logger.info(f"GoogleProvider: Found TEXT part for {fc.name}.")
                                    llm_response_content_str += (getattr(mcp_part, 'text', None) or "") + "\n"
                                else:
                                    logger.warning(f"GoogleProvider: Found UNKNOWN/other MCP part for {fc.name} (idx {part_idx}): {mcp_part}. Adding its JSON to LLM string.")
                                    try:
                                        llm_response_content_str += json.dumps(mcp_part) + "\n"
                                    except TypeError:
                                        llm_response_content_str += str(mcp_part) + "\n"
                            llm_response_content_str = llm_response_content_str.strip()
                            # For Gemini, the FunctionResponse.response needs to be a dict.
                            # We send the textual summary (now only containing actual text or JSON of other parts) to the LLM.
                            structured_tool_result_for_llm = {"summary_of_execution": llm_response_content_str if llm_response_content_str else "[Tool executed, textual parts processed]"}
                        elif isinstance(tool_result_content_from_mcp, dict):
                            # If it's already a dict, use it (could be an error or simple dict response)
                            structured_tool_result_for_llm = tool_result_content_from_mcp
                            llm_response_content_str = json.dumps(tool_result_content_from_mcp)
                        elif isinstance(tool_result_content_from_mcp, str):
                            # If it's a string, wrap it for the LLM and use as summary
                            structured_tool_result_for_llm = {"text_response": tool_result_content_from_mcp}
                            llm_response_content_str = tool_result_content_from_mcp
                        else:
                            # Fallback for other types
                            str_fallback = str(tool_result_content_from_mcp)
                            structured_tool_result_for_llm = {"response": str_fallback}
                            llm_response_content_str = str_fallback
                        
                        if not llm_response_content_str: # Ensure there's some content for the LLM
                            llm_response_content_str = "[Tool executed successfully but returned no textual content for LLM summary]"
                            if not structured_tool_result_for_llm: # Ensure dict for LLM is not empty
                                structured_tool_result_for_llm = {"status": "empty textual response"}

                        # Append tool execution result to history for LLM
                        # Gemini expects the `response` field in FunctionResponse to be a dict.
                        gemini_messages.append(types.Content(
                            role="user", 
                            parts=[types.Part(function_response=types.FunctionResponse(
                                name=fc.name, 
                                response=structured_tool_result_for_llm # Send the structured dict (summary) to LLM
                            ))]
                        ))
                    except Exception as e:
                        logger.error(f"Error processing MCP tool call (from stream) for {fc.name}: {e}")
                        logger.error(traceback.format_exc())
                        gemini_messages.append(types.Content(
                            role="user",
                            parts=[types.Part(function_response=types.FunctionResponse(
                                name=fc.name,
                                response={"error": f"Error executing tool {fc.name}: {str(e)}"}
                            ))]
                        ))
                        # Yield an error result for this tool call
                        yield StreamChunk(
                            conversation_id=conversation_id or "unknown_conv",
                            message_id=message_id, # Use standardized message_id
                            part_type="tool_call_result",
                            tool_call_result_data=ToolCallResultDetails(
                                tool_name=fc.name,
                                tool_result={"error": f"Error executing tool {fc.name}: {str(e)}"} 
                            )
                        )
                else:
                    logger.warning(f"Unsupported function call format or non-MCP tool (from stream): {fc.name}")
                    # Yield a text chunk indicating the error/warning
                    yield StreamChunk(
                        conversation_id=conversation_id or "unknown_conv",
                        message_id=message_id, # Use standardized message_id
                        part_type="text", 
                        text_content=f"Tool '{fc.name}' is not a recognized MCP tool."
                    )
                    gemini_messages.append(types.Content(
                        role="user",
                        parts=[types.Part(function_response=types.FunctionResponse(
                            name=fc.name,
                            response={"error": f"Tool '{fc.name}' is not recognized."}
                        ))]
                    ))
                continue # Loop back to call Google API again
            else:
                # No function call in this response, so the stream is complete for this turn.
                # All text content should have been yielded already.
                if not current_text_response_parts and current_iteration == 1:
                    # This case can happen if the model returns an empty first response (no text, no tool call)
                    logger.warning("Gemini stream yielded no text and no tool calls in the first iteration.")
                    # yield "" # Ensure a yield if nothing else was sent, to signify completion of an empty turn.
                yield StreamChunk(conversation_id=conversation_id or "unknown_conv", message_id=message_id, done=True) # Use standardized message_id
                return # End of generation

        logger.warning(f"GoogleProvider: Exceeded max tool iterations ({max_tool_iterations}) in stream for model {self.model_id}")
        # If loop finishes, it implies max iterations were hit.
        # Content should have been yielded. If any text parts were accumulated for a final non-tool response,
        # ensure they are yielded (though standard flow should yield them within the loop).
        if current_text_response_parts:
            final_text = "".join(current_text_response_parts)
            if final_text:
                # logger.debug(f"Yielding remaining text after max iterations: {final_text[:100]}")
                # This text should have already been yielded as StreamChunks
                pass # yield final_text # This might be redundant if all text already yielded.
        yield StreamChunk(conversation_id=conversation_id or "unknown_conv", message_id=message_id, done=True) # Use standardized message_id
        return # End of generator 