import openai
import json # For parsing arguments if they come as a string
from typing import List, AsyncGenerator, Dict, Any, Optional
from models import ChatMessage, ModelInfo, ApiFile, McpToolDefinition, StreamChunk, ToolCallRequestDetails, ToolCallResultDetails
from providers.base import BaseProvider
import logging
import traceback
import uuid # Import uuid for generating fallback IDs

# Import mcp_service
from services.mcp_service import mcp_service

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MCP_SEPARATOR = "__MCP__" # Define a separator for composite tool names

class OpenAIProvider(BaseProvider):
    """OpenAI GPT models provider"""
    
    def __init__(self, model_config: Dict[str, Any]):
        self.model_config = model_config
        self.api_key = model_config.get("api_key", "")
        self.base_url = model_config.get("base_url", "https://api.openai.com/v1")
        self.model_id = model_config.get("model_id", "")
        self.display_name = model_config.get("display_name", self.model_id)
        
        if not self.api_key:
            logger.error(f"api_key is required for OpenAI model {self.model_id} but not found.")
            raise ValueError(f"api_key is required for OpenAI model {self.model_id}")

        logger.info(f"Initializing OpenAIProvider for model: {self.model_id}")
        try:
            self.client = openai.AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
            logger.info(f"OpenAI AsyncClient initialized for {self.model_id}.")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI AsyncClient for {self.model_id}: {e}")
            logger.error(traceback.format_exc())
            raise
    
    async def get_model_info(self) -> ModelInfo:
        return ModelInfo(
            model_id=self.model_id,
            name=self.display_name,
            provider="openai",
            description=f"OpenAI {self.display_name} model (MCP Tool Enabled)"
        )
    
    def _format_messages_for_openai(self, messages: List[ChatMessage]) -> List[Dict[str, Any]]:
        formatted_messages = []
        for msg in messages:
            if msg.role == "tool":
                # For OpenAI, tool_call_id is associated with the tool result message
                formatted_messages.append({
                    "role": "tool",
                    "tool_call_id": msg.model_name, # Using model_name as a temporary store for tool_call_id
                    "name": msg.name, # This should be the composite tool name
                    "content": msg.content # Result from the tool call
                })
                continue

            role = msg.role
            if role == "assistant": role = "assistant" # Ensure role is one of 'system', 'user', 'assistant', 'tool'
            elif role == "system": role = "system"
            else: role = "user" # Default to 'user' if not assistant or system (covers 'human', etc.)


            content_parts = []
            if msg.content: # Text content
                 content_parts.append({"type": "text", "text": msg.content})

            if msg.files and role == "user": # Image files for user messages
                for file_info in msg.files:
                    if file_info.type == 'image' and file_info.data: # Assuming data is base64 string
                        content_parts.append({
                            "type": "image_url",
                            "image_url": {"url": file_info.data} # Format: "data:image/jpeg;base64,{base64_image}"
                        })
            
            # Only append if there is textual or image content
            # Assistant messages with only tool_calls are handled separately when constructing the API request
            if content_parts:
                formatted_messages.append({"role": role, "content": content_parts})
            # If it's an assistant message that made tool calls but had no text content,
            # it will be represented by the `tool_calls` attribute in the API request,
            # and its history entry is also handled by the `tool_calls` field when added.

        return formatted_messages

    async def _build_system_prompt_with_mcp_tools(self, original_messages: List[ChatMessage], active_mcp_server_ids: Optional[List[str]] = None) -> List[ChatMessage]:
        """Modifies the message list to include descriptions of dynamically discovered MCP tools in the system prompt,
           filtered by active_mcp_server_ids if provided."""
        from config import settings # Delayed import
        
        # Ensure active_mcp_server_ids is a list for consistent processing; if None, no servers are active.
        effective_active_server_ids = active_mcp_server_ids if active_mcp_server_ids is not None else []

        mcp_tool_descriptions = []
        
        server_configs_map: Dict[str, Any] = {
            s.id: s for s in settings.app_config.mcp_servers
        }
        
        all_discovered_tools: Dict[str, List[McpToolDefinition]] = await mcp_service.get_all_discovered_tools()

        if not all_discovered_tools:
            return original_messages

        prompt_intro = "You have access to the following tools . To use a tool, you MUST call the function with the specified composite name and provide arguments matching its schema.\\\\n"
        
        for server_id, tool_defs in all_discovered_tools.items():
            # Use effective_active_server_ids for the check
            if effective_active_server_ids and server_id not in effective_active_server_ids:
                continue # Skip this server if not in the active list (and the list is not empty)
            elif not effective_active_server_ids and active_mcp_server_ids is not None: # Case where active_mcp_server_ids was explicitly empty
                continue # No servers are active, so skip all
            elif active_mcp_server_ids is None: # if original active_mcp_server_ids was None, skip all tools from MCP servers
                continue

            server_config = server_configs_map.get(server_id)
            server_display_name = server_config.display_name if server_config else f"Server ID {server_id}"
            
            if tool_defs:
                server_desc = f"\\\\n--- MCP Server: '{server_display_name}' (ID: {server_id}) ---\\\\nTools available on this server:"
                tool_descs_for_server = []
                for tool in tool_defs:
                    composite_tool_name = f"{server_id}{MCP_SEPARATOR}{tool.name}"
                    param_str = json.dumps(tool.parameters_schema) if tool.parameters_schema else "No arguments."
                    tool_descs_for_server.append(f"  - Function Name: `{composite_tool_name}`\\\\n    Description: {tool.description}\\\\n    Arguments Schema (JSON): {param_str}")
                if tool_descs_for_server: # only add server section if it has tool descriptions
                    mcp_tool_descriptions.append(server_desc + "\\\\n" + "\\\\n".join(tool_descs_for_server))
        
        if not mcp_tool_descriptions:
            return original_messages

        tool_system_prompt = prompt_intro + "\\\\n".join(mcp_tool_descriptions)

        modified_messages = list(original_messages)
        system_message_exists = False
        for i, msg in enumerate(modified_messages):
            if msg.role == "system":
                modified_messages[i] = ChatMessage(
                    role="system", 
                    content=msg.content + "\\\\n\\\\n" + tool_system_prompt,
                    id=msg.id,
                    timestamp=msg.timestamp
                )
                system_message_exists = True
                break
        
        if not system_message_exists:
            modified_messages.insert(0, ChatMessage(role="system", content=tool_system_prompt))
            
        return modified_messages

    async def _get_openai_tool_schemas(self, active_mcp_server_ids: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Generates OpenAI-compatible tool schemas for discovered MCP tools,
           filtered by active_mcp_server_ids if provided."""
        
        # Ensure active_mcp_server_ids is a list for consistent processing; if None, no servers are active.
        effective_active_server_ids = active_mcp_server_ids if active_mcp_server_ids is not None else []
        
        all_discovered_tools: Dict[str, List[McpToolDefinition]] = await mcp_service.get_all_discovered_tools()
        openai_tools = []

        if not all_discovered_tools: # if no tools discovered at all, return empty
            return openai_tools

        for server_id, tool_defs in all_discovered_tools.items():
            # Use effective_active_server_ids for the check
            if effective_active_server_ids and server_id not in effective_active_server_ids:
                continue # Skip this server if not in the active list (and the list is not empty)
            elif not effective_active_server_ids and active_mcp_server_ids is not None: # Case where active_mcp_server_ids was explicitly empty
                continue # No servers are active, so skip all
            elif active_mcp_server_ids is None: # if original active_mcp_server_ids was None, skip all tools from MCP servers
                continue

            for tool_def in tool_defs:
                composite_tool_name = f"{server_id}{MCP_SEPARATOR}{tool_def.name}"
                openai_tools.append({
                    "type": "function",
                    "function": {
                        "name": composite_tool_name,
                        "description": tool_def.description,
                        "parameters": tool_def.parameters_schema if tool_def.parameters_schema else {"type": "object", "properties": {}},
                    }
                })
        return openai_tools

    async def chat_completion(self, messages: List[ChatMessage], **kwargs) -> str:
        logger.info(f"OpenAIProvider: chat_completion for model: {self.model_id}")
        
        active_mcp_server_ids = kwargs.get("active_mcp_server_ids") # This might be None

        # Process messages and tools based on effective_active_server_ids
        # If active_mcp_server_ids is None, _build_system_prompt_with_mcp_tools and _get_openai_tool_schemas 
        # should now correctly return no MCP tools.
        messages_with_tools_prompt = await self._build_system_prompt_with_mcp_tools(messages, active_mcp_server_ids)
        openai_messages = self._format_messages_for_openai(messages_with_tools_prompt)
        openai_tool_schemas = await self._get_openai_tool_schemas(active_mcp_server_ids)
        
        max_tool_iterations = 5
        current_iteration = 0

        while current_iteration < max_tool_iterations:
            current_iteration += 1
            logger.info(f"OpenAI API call (iteration {current_iteration}): model={self.model_id}")
            
            request_params = {
                "model": self.model_id,
                "messages": openai_messages,
                "temperature": kwargs.get("temperature", 0.7),
                "max_tokens": kwargs.get("max_tokens", 2048),
            }
            # Only add tools and tool_choice if there are any schemas generated
            if openai_tool_schemas: 
                request_params["tools"] = openai_tool_schemas
                request_params["tool_choice"] = "auto"
            else:
                # Ensure tool_choice is not present if tools are not present
                # Some OpenAI versions/models might error if tool_choice is present without tools.
                if "tool_choice" in request_params: # Should not be necessary due to above logic, but as a safeguard
                    del request_params["tool_choice"]
            
            try:
                completion = await self.client.chat.completions.create(**request_params) # type: ignore
            except Exception as e:
                logger.error(f"OpenAI API error during completions.create for {self.model_id}: {e}")
                logger.error(traceback.format_exc())
                raise Exception(f"OpenAI API error: {e}")
    
            response_message = completion.choices[0].message

            if response_message.tool_calls:
                logger.info(f"OpenAI model requested tool call(s) for {self.model_id}: {response_message.tool_calls}")
                
                # Append the assistant's message (that includes the tool call request) to history
                # The content field might be None or empty string, ensure it's handled.
                assistant_message_for_history = {"role": "assistant", "content": response_message.content or ""}
                if response_message.tool_calls:
                    assistant_message_for_history["tool_calls"] = [
                        {
                            "id": tc.id, 
                            "type": tc.type, 
                            "function": {"name": tc.function.name, "arguments": tc.function.arguments}
                        } for tc in response_message.tool_calls
                    ]
                openai_messages.append(assistant_message_for_history)

                for tool_call in response_message.tool_calls:
                    function_name = tool_call.function.name
                    try:
                        arguments = json.loads(tool_call.function.arguments)
                    except json.JSONDecodeError:
                        arguments = {"error": "Invalid JSON arguments provided by model"}
                        logger.warning(f"Invalid JSON arguments from model for tool {function_name}: {tool_call.function.arguments}")
                    
                    logger.info(f"Calling MCP tool: {function_name} with arguments: {arguments}")
                    
                    # Ensure function_name is a string
                    if not isinstance(function_name, str):
                        logger.error(f"Tool name {function_name} is not a string, skipping call.")
                        # Potentially append an error message to openai_messages for the LLM
                        openai_messages.append({
                            "tool_call_id": tool_call.id,
                            "role": "tool",
                            "name": str(function_name), # Convert to string for safety
                            "content": "Error: Tool name was not a string.",
                        })
                        continue

                    server_id, _, tool_name_on_server = function_name.partition(MCP_SEPARATOR)

                    if not tool_name_on_server: # Not an MCP tool, or malformed
                        logger.warning(f"Tool {function_name} is not a valid MCP tool name. Skipping.")
                        # Consider how to handle non-MCP tools or if this path should even be reached
                        # For now, append an error or placeholder back to the LLM
                        openai_messages.append({
                            "tool_call_id": tool_call.id,
                            "role": "tool",
                            "name": function_name,
                            "content": f"Error: Tool '{function_name}' is not a recognized MCP tool or is malformed.",
                        })
                        continue

                    try:
                        # This should now return a list of content parts from mcp_service
                        mcp_tool_response_parts = await mcp_service.call_mcp_tool(server_id, tool_name_on_server, arguments)
                        # logger.info(f"Raw response from MCP tool {function_name}: {mcp_tool_response_parts}")

                        llm_response_content_str = ""
                        if isinstance(mcp_tool_response_parts, list):
                            logger.info(f"MCP response is a list. Iterating {len(mcp_tool_response_parts)} parts for {function_name} (in chat_completion).")
                            for idx, part in enumerate(mcp_tool_response_parts):
                                part_type_attr = getattr(part, 'type', None)
                                part_data_attr = getattr(part, 'data', None)
                                part_mime_type_attr = getattr(part, 'mimeType', getattr(part, 'mime_type', None))

                                logger.info(f"Processing part {idx} for {function_name} (in chat_completion): Type: {part_type_attr}, HasData: {part_data_attr is not None}, HasMimeType: {part_mime_type_attr is not None}")
                                
                                if part_type_attr == 'image' and part_data_attr is not None and part_mime_type_attr is not None:
                                    logger.info(f"Found IMAGE part for {function_name} in chat_completion. MimeType: {part_mime_type_attr}. Skipping for LLM content.")
                                    # Skip adding image placeholders to the LLM response string
                                elif part_type_attr == 'text' and hasattr(part, 'text'):
                                    logger.info(f"Found TEXT part for {function_name} in chat_completion.")
                                    llm_response_content_str += (getattr(part, 'text', None) or "") + "\n"
                                else:
                                    # For any other complex parts, we might still want to send their string representation to the LLM
                                    # or decide to omit them as well. For now, let's try sending their JSON form if not text/image.
                                    logger.warning(f"Found UNKNOWN/other part type in chat_completion for {function_name} (idx {idx}): {part}. Adding its JSON to LLM string.")
                                    try:
                                        llm_response_content_str += json.dumps(part) + "\n"
                                    except TypeError:
                                        llm_response_content_str += str(part) + "\n"
                            llm_response_content_str = llm_response_content_str.strip() # Clean trailing newline
                        elif isinstance(mcp_tool_response_parts, str): # if it's a simple string
                            llm_response_content_str = mcp_tool_response_parts
                        else: # Fallback for other types
                            try:
                                llm_response_content_str = json.dumps(mcp_tool_response_parts)
                            except TypeError:
                                llm_response_content_str = str(mcp_tool_response_parts)
                        
                        if not llm_response_content_str: # Ensure there's some content
                            llm_response_content_str = "[Tool executed successfully but returned no textual content]"


                        logger.info(f"Content prepared for LLM (for tool {function_name}): {llm_response_content_str[:200]}...")
                        
                        openai_messages.append({
                            "tool_call_id": tool_call.id,
                            "role": "tool",
                            "name": function_name,
                            "content": llm_response_content_str, # Send the processed string content to LLM
                        })
                    except Exception as e:
                        logger.error(f"Error during MCP tool call or processing for {function_name}: {e}")
                        logger.error(traceback.format_exc())
                        openai_messages.append({
                            "tool_call_id": tool_call.id,
                            "role": "tool",
                            "name": function_name,
                            "content": f"Error executing tool {function_name}: {str(e)}",
                        })
                
                # Continue the loop to let the model process tool results
                continue 

            # If no tool calls, then it's the final text response from the model
            final_response_content = response_message.content or "" # Ensure content is not None
            
            # Check for text-based tool calls in Ollama models that don't support proper function calling
            if final_response_content:
                text_based_tool_calls = _parse_text_tool_calls(final_response_content)
                
                if text_based_tool_calls:
                    logger.info(f"Detected {len(text_based_tool_calls)} text-based tool calls from Ollama model in chat_completion.")
                    
                    # Add assistant message with original content including tool calls to history
                    openai_messages.append({
                        "role": "assistant",
                        "content": final_response_content
                    })
                    
                    # Process each text-based tool call
                    for tool_call_data in text_based_tool_calls:
                        function_name = tool_call_data.get("name", "")
                        arguments = tool_call_data.get("arguments", {})
                        tool_call_id = f"ollama_text_call_{uuid.uuid4().hex[:8]}"
                        
                        server_id, _, tool_name_on_server = function_name.partition(MCP_SEPARATOR)
                        
                        if not tool_name_on_server:
                            logger.warning(f"Text-based tool {function_name} is not a valid MCP tool name. Skipping.")
                            llm_response_content_str = f"Error: Tool '{function_name}' is not a recognized MCP tool."
                        else:
                            try:
                                logger.info(f"Executing text-based MCP tool: {function_name} with arguments: {arguments}")
                                mcp_tool_response_parts = await mcp_service.call_mcp_tool(server_id, tool_name_on_server, arguments)
                                
                                # Process response for LLM (similar to regular tool call processing)
                                llm_response_content_str = ""
                                if isinstance(mcp_tool_response_parts, list):
                                    for part in mcp_tool_response_parts:
                                        if getattr(part, 'type', None) == 'text' and hasattr(part, 'text'):
                                            llm_response_content_str += (getattr(part, 'text', None) or "") + "\n"
                                    llm_response_content_str = llm_response_content_str.strip()
                                elif isinstance(mcp_tool_response_parts, str):
                                    llm_response_content_str = mcp_tool_response_parts
                                else:
                                    try:
                                        llm_response_content_str = json.dumps(mcp_tool_response_parts)
                                    except TypeError:
                                        llm_response_content_str = str(mcp_tool_response_parts)
                                
                                if not llm_response_content_str:
                                    llm_response_content_str = "[Tool executed successfully]"
                                    
                            except Exception as e:
                                logger.error(f"Error executing text-based tool {function_name}: {e}")
                                llm_response_content_str = f"Error executing tool {function_name}: {str(e)}"
                        
                        # Add tool result to conversation history
                        openai_messages.append({
                            "tool_call_id": tool_call_id,
                            "role": "tool",
                            "name": function_name,
                            "content": llm_response_content_str
                        })
                    
                    # Continue loop to let model process tool results
                    continue
            
            logger.info(f"OpenAI model final response for {self.model_id}: {final_response_content[:200]}...")
            return final_response_content
        
        # If loop finishes (e.g., max_tool_iterations reached)
        logger.warning(f"Max tool iterations reached for model {self.model_id}. Returning last known content or empty.")
        # Attempt to return the last assistant message content if available, otherwise empty
        last_assistant_content = ""
        for msg in reversed(openai_messages):
            if msg["role"] == "assistant" and msg.get("content"):
                last_assistant_content = msg["content"]
                break
        return last_assistant_content


    async def stream_completion(self, messages: List[ChatMessage], **kwargs) -> AsyncGenerator[StreamChunk, None]:
        logger.info(f"OpenAIProvider: stream_completion for model: {self.model_id}")
        message_id = kwargs.get("message_id", str(uuid.uuid4())) # Get or generate a message_id
        conversation_id = kwargs.get("conversation_id", str(uuid.uuid4()))

        active_mcp_server_ids = kwargs.get("active_mcp_server_ids")

        messages_with_tools_prompt = await self._build_system_prompt_with_mcp_tools(messages, active_mcp_server_ids)
        openai_messages = self._format_messages_for_openai(messages_with_tools_prompt)
        openai_tool_schemas = await self._get_openai_tool_schemas(active_mcp_server_ids)
        
        max_tool_iterations = 5
        current_iteration = 0
        
        current_tool_call_id_map: Dict[str, str] = {} # Maps OpenAI's tool_call.id to our internal message part ID for tool_calls

        accumulated_tool_calls: Dict[int, Dict[str, Any]] = {} # {index: {id, function_name, function_args_buffer}}
        # For streaming, we need to aggregate tool call arguments
        # An assistant message can have multiple tool_calls in response_message.tool_calls
        # Each tool_call can have its arguments streamed in parts.
        
        # For Ollama compatibility - accumulate text content to detect text-based tool calls
        accumulated_text_content = ""

        while current_iteration < max_tool_iterations:
            current_iteration += 1
            logger.info(f"OpenAI Stream API call (iteration {current_iteration}): model={self.model_id}")

            request_params = {
                "model": self.model_id,
                "messages": openai_messages,
                "stream": True,
                "temperature": kwargs.get("temperature", 0.7),
                "max_tokens": kwargs.get("max_tokens", 2048),
            }
            if openai_tool_schemas:
                request_params["tools"] = openai_tool_schemas
                request_params["tool_choice"] = "auto" # Can also be {"type": "function", "function": {"name": "my_function"}} or "required"
            else:
                 if "tool_choice" in request_params:
                    del request_params["tool_choice"]
            
            try:
                stream = await self.client.chat.completions.create(**request_params) # type: ignore
            except Exception as e:
                logger.error(f"OpenAI API error during stream completions.create for {self.model_id}: {e}")
                logger.error(traceback.format_exc())
                yield StreamChunk(
                    conversation_id=conversation_id, message_id=message_id, 
                    part_type='text', text_content=f"Error: OpenAI API connection failed. {e}", done=True
                )
                return

            async for chunk in stream:
                if not chunk.choices:
                    continue
                
                delta = chunk.choices[0].delta
                finish_reason = chunk.choices[0].finish_reason

                # Handle textual content from the LLM (not tool related)
                if delta and delta.content:
                    accumulated_text_content += delta.content
                    yield StreamChunk(
                        conversation_id=conversation_id, message_id=message_id,
                        part_type='text', text_content=delta.content, done=False
                    )
                
                # Handle tool call requests from the LLM
                if delta and delta.tool_calls:
                    for tool_call_chunk in delta.tool_calls:
                        index = tool_call_chunk.index # OpenAI provides an index for each tool_call

                        if index not in accumulated_tool_calls:
                             # This is the first chunk for this tool_call_chunk.index
                            if tool_call_chunk.id and tool_call_chunk.function and tool_call_chunk.function.name:
                                accumulated_tool_calls[index] = {
                                    "id": tool_call_chunk.id, # OpenAI's tool_call_id
                                    "function_name": tool_call_chunk.function.name,
                                    "function_args_buffer": tool_call_chunk.function.arguments or ""
                                }
                            else: # Missing essential fields, buffer arguments if they exist
                                if tool_call_chunk.id: # If ID exists, try to append to it
                                     if index not in accumulated_tool_calls: # Should not happen if ID exists, but safety
                                        accumulated_tool_calls[index] = {"id": tool_call_chunk.id, "function_name": "", "function_args_buffer": ""}
                                     accumulated_tool_calls[index]["function_args_buffer"] += tool_call_chunk.function.arguments or ""
                                else: # No ID, can't reliably map. Log and skip this problematic chunk.
                                     logger.warning(f"Tool call chunk missing ID or function name: {tool_call_chunk}. Arguments: {tool_call_chunk.function.arguments}")


                        else: # Subsequent chunk for an existing tool_call_chunk.index
                            accumulated_tool_calls[index]["function_args_buffer"] += tool_call_chunk.function.arguments or ""
                        
                        # If we have full info for this tool call, yield it (or wait for finish_reason='tool_calls')
                        # We yield ToolCallRequestDetails when we have the full argument string for a tool
                        # This might happen before finish_reason='tool_calls' if only one tool is called and its args are fully streamed.
                        # However, for multiple tool calls, it's safer to wait for finish_reason
                        # Let's accumulate and process when finish_reason == 'tool_calls'

                if finish_reason == "tool_calls":
                    logger.info(f"OpenAI model requested tool_calls (finish_reason) for {self.model_id}.")
                    
                    # Prepare the assistant message for history (once, after all tool call chunks are processed)
                    assistant_message_content = chunk.choices[0].delta.content or "" # Content before tool calls
                    
                    # The 'tool_calls' that go into history are the fully formed ones
                    history_tool_calls = []
                    for _idx, tc_data in accumulated_tool_calls.items():
                        if tc_data.get("id") and tc_data.get("function_name"): # Ensure essential fields are present
                            history_tool_calls.append({
                                "id": tc_data["id"],
                                "type": "function", # OpenAI specific
                                "function": {"name": tc_data["function_name"], "arguments": tc_data["function_args_buffer"]}
                            })
                        else:
                            logger.warning(f"Skipping tool call in history due to missing id/name: {tc_data}")
                    
                    if history_tool_calls: # Only append if there are valid tool calls
                        assistant_message_for_history = {"role": "assistant", "content": assistant_message_content}
                        assistant_message_for_history["tool_calls"] = history_tool_calls
                        openai_messages.append(assistant_message_for_history)


                    # Now, process each accumulated tool call
                    for _idx, tool_call_data in accumulated_tool_calls.items():
                        tool_call_id_openai = tool_call_data["id"]
                        function_name = tool_call_data["function_name"]
                        function_arguments_str = tool_call_data["function_args_buffer"]
                        
                        try:
                            arguments = json.loads(function_arguments_str)
                        except json.JSONDecodeError:
                            arguments = {"error": "Invalid JSON arguments provided by model"}
                            logger.warning(f"Invalid JSON arguments from model for tool {function_name}: {function_arguments_str}")

                        # Yield ToolCallRequestDetails immediately
                        yield StreamChunk(
                            conversation_id=conversation_id, message_id=message_id,
                            part_type='tool_call_request',
                            tool_call_request_data=ToolCallRequestDetails(tool_name=function_name, tool_arguments=arguments),
                            done=False
                        )
                        
                        # Ensure function_name is a string
                        if not isinstance(function_name, str):
                            logger.error(f"Tool name {function_name} is not a string, skipping call.")
                            tool_call_result_content = f"Error: Tool name was not a string."
                            llm_response_content_str = tool_call_result_content
                        else:
                            server_id, _, tool_name_on_server = function_name.partition(MCP_SEPARATOR)

                            if not tool_name_on_server:
                                logger.warning(f"Tool {function_name} is not a valid MCP tool name. Skipping.")
                                tool_call_result_content = f"Error: Tool '{function_name}' is not a recognized MCP tool or is malformed."
                                llm_response_content_str = tool_call_result_content
                            else:
                                try:
                                    logger.info(f"Streaming: Calling MCP tool: {function_name} with arguments: {arguments}")
                                    # This should now return a list of content parts from mcp_service
                                    mcp_tool_response_parts = await mcp_service.call_mcp_tool(server_id, tool_name_on_server, arguments)
                                    logger.info(f"Streaming: Raw response from MCP tool {function_name}: {mcp_tool_response_parts}")

                                    # Yield the full MCP response as ToolCallResultDetails first
                                    yield StreamChunk(
                                        conversation_id=conversation_id, message_id=message_id,
                                        part_type='tool_call_result',
                                        tool_call_result_data=ToolCallResultDetails(tool_name=function_name, tool_result=mcp_tool_response_parts),
                                        done=False
                                    )

                                    # Process parts for LLM and potential separate image chunks
                                    llm_response_content_str = ""
                                    if isinstance(mcp_tool_response_parts, list):
                                        logger.info(f"MCP response is a list. Iterating {len(mcp_tool_response_parts)} parts for {function_name} (in stream_completion).")
                                        for idx, part in enumerate(mcp_tool_response_parts):
                                            part_type_attr = getattr(part, 'type', None)
                                            part_data_attr = getattr(part, 'data', None)
                                            # Check for both mimeType (direct from JSON) and mime_type (Pydantic potentially)
                                            part_mime_type_attr = getattr(part, 'mimeType', getattr(part, 'mime_type', None))

                                            logger.info(f"Processing part {idx} for {function_name} (in stream_completion): Type: {part_type_attr}, HasData: {part_data_attr is not None}, HasMimeType: {part_mime_type_attr is not None}")
                                            
                                            if part_type_attr == 'image' and part_data_attr is not None and part_mime_type_attr is not None:
                                                logger.info(f"Found IMAGE part for {function_name} in stream_completion. MimeType: {part_mime_type_attr}. Yielding separate image chunk. Skipping for LLM content.")
                                                # Yield separate image chunk for UI
                                                yield StreamChunk(
                                                    conversation_id=conversation_id, message_id=message_id,
                                                    part_type='image',
                                                    image_data={'data': part_data_attr, 'mime_type': part_mime_type_attr},
                                                    done=False
                                                )
                                                # Skip adding image placeholders to the LLM response string
                                            elif part_type_attr == 'text' and hasattr(part, 'text'): # text content is usually in a 'text' attribute
                                                logger.info(f"Found TEXT part for {function_name} in stream_completion.")
                                                llm_response_content_str += (getattr(part, 'text', None) or "") + "\n"
                                            else:
                                                # For any other complex parts, we might still want to send their string representation to the LLM
                                                # or decide to omit them as well. For now, let's try sending their JSON form if not text/image.
                                                logger.warning(f"Found UNKNOWN/other part type in stream_completion for {function_name} (idx {idx}): {part}. Adding its JSON to LLM string.")
                                                try:
                                                    llm_response_content_str += json.dumps(part) + "\n"
                                                except TypeError:
                                                    llm_response_content_str += str(part) + "\n"
                                        llm_response_content_str = llm_response_content_str.strip()
                                    elif isinstance(mcp_tool_response_parts, str):
                                        llm_response_content_str = mcp_tool_response_parts
                                    else:
                                        try:
                                            llm_response_content_str = json.dumps(mcp_tool_response_parts)
                                        except TypeError:
                                            llm_response_content_str = str(mcp_tool_response_parts)
                                    
                                    if not llm_response_content_str:
                                        llm_response_content_str = "[Tool executed successfully but returned no textual content]"

                                    tool_call_result_content = mcp_tool_response_parts # Retain original for history/display

                                except Exception as e:
                                    logger.error(f"Error during MCP tool call or processing for {function_name} in stream: {e}")
                                    logger.error(traceback.format_exc())
                                    tool_call_result_content = f"Error executing tool {function_name}: {str(e)}"
                                    llm_response_content_str = tool_call_result_content # LLM sees the error

                        # Append the 'tool' role message with results for LLM history
                        openai_messages.append({
                            "tool_call_id": tool_call_id_openai,
                            "role": "tool",
                            "name": function_name,
                            "content": llm_response_content_str, # Send the processed string content to LLM
                        })
                    # Clear accumulated calls for this stream response, as we'll make a new LLM call
                    accumulated_tool_calls.clear() 
                    break # Break from inner stream loop to re-enter while loop for next LLM call

                elif finish_reason == "stop":
                    logger.info(f"OpenAI model finished responding (stop reason) for {self.model_id}.")
                    
                    # Check for text-based tool calls in Ollama models that don't support proper function calling
                    if not accumulated_tool_calls and accumulated_text_content:
                        text_based_tool_calls = _parse_text_tool_calls(accumulated_text_content)
                        
                        if text_based_tool_calls:
                            logger.info(f"Detected {len(text_based_tool_calls)} text-based tool calls from Ollama model.")
                            
                            # Process each text-based tool call
                            for idx, tool_call_data in enumerate(text_based_tool_calls):
                                function_name = tool_call_data.get("name", "")
                                arguments = tool_call_data.get("arguments", {})
                                tool_call_id = f"ollama_text_call_{idx}_{uuid.uuid4().hex[:8]}"
                                
                                # Yield ToolCallRequestDetails
                                yield StreamChunk(
                                    conversation_id=conversation_id, message_id=message_id,
                                    part_type='tool_call_request',
                                    tool_call_request_data=ToolCallRequestDetails(tool_name=function_name, tool_arguments=arguments),
                                    done=False
                                )
                                
                                # Execute the tool call
                                server_id, _, tool_name_on_server = function_name.partition(MCP_SEPARATOR)
                                
                                if not tool_name_on_server:
                                    logger.warning(f"Text-based tool {function_name} is not a valid MCP tool name. Skipping.")
                                    llm_response_content_str = f"Error: Tool '{function_name}' is not a recognized MCP tool."
                                else:
                                    try:
                                        logger.info(f"Executing text-based MCP tool: {function_name} with arguments: {arguments}")
                                        mcp_tool_response_parts = await mcp_service.call_mcp_tool(server_id, tool_name_on_server, arguments)
                                        
                                        # Yield the tool result
                                        yield StreamChunk(
                                            conversation_id=conversation_id, message_id=message_id,
                                            part_type='tool_call_result',
                                            tool_call_result_data=ToolCallResultDetails(tool_name=function_name, tool_result=mcp_tool_response_parts),
                                            done=False
                                        )
                                        
                                        # Process response for LLM
                                        llm_response_content_str = ""
                                        if isinstance(mcp_tool_response_parts, list):
                                            for part in mcp_tool_response_parts:
                                                if getattr(part, 'type', None) == 'text' and hasattr(part, 'text'):
                                                    llm_response_content_str += (getattr(part, 'text', None) or "") + "\n"
                                                elif getattr(part, 'type', None) == 'image':
                                                    # Yield image chunks separately
                                                    part_data = getattr(part, 'data', None)
                                                    part_mime = getattr(part, 'mimeType', getattr(part, 'mime_type', None))
                                                    if part_data and part_mime:
                                                        yield StreamChunk(
                                                            conversation_id=conversation_id, message_id=message_id,
                                                            part_type='image',
                                                            image_data={'data': part_data, 'mime_type': part_mime},
                                                            done=False
                                                        )
                                            llm_response_content_str = llm_response_content_str.strip()
                                        elif isinstance(mcp_tool_response_parts, str):
                                            llm_response_content_str = mcp_tool_response_parts
                                        else:
                                            try:
                                                llm_response_content_str = json.dumps(mcp_tool_response_parts)
                                            except TypeError:
                                                llm_response_content_str = str(mcp_tool_response_parts)
                                        
                                        if not llm_response_content_str:
                                            llm_response_content_str = "[Tool executed successfully]"
                                            
                                    except Exception as e:
                                        logger.error(f"Error executing text-based tool {function_name}: {e}")
                                        llm_response_content_str = f"Error executing tool {function_name}: {str(e)}"
                                
                                # Add tool result to conversation history
                                openai_messages.append({
                                    "tool_call_id": tool_call_id,
                                    "role": "tool", 
                                    "name": function_name,
                                    "content": llm_response_content_str
                                })
                            
                            # Add assistant message with text-based tool calls to history
                            # Remove the tool call XML from the content
                            clean_content = accumulated_text_content
                            for tool_call in text_based_tool_calls:
                                # Remove the <tools>...</tools> blocks from content
                                import re
                                pattern = r'<tools>\s*' + re.escape(json.dumps(tool_call)).replace(r'\ ', r'\s*') + r'\s*</tools>'
                                clean_content = re.sub(pattern, '', clean_content, flags=re.IGNORECASE | re.DOTALL)
                            
                            # Convert text-based calls to OpenAI format for history
                            history_tool_calls = []
                            for idx, tool_call in enumerate(text_based_tool_calls):
                                history_tool_calls.append({
                                    "id": f"ollama_text_call_{idx}_{uuid.uuid4().hex[:8]}",
                                    "type": "function",
                                    "function": {
                                        "name": tool_call["name"],
                                        "arguments": json.dumps(tool_call["arguments"])
                                    }
                                })
                            
                            assistant_message_for_history = {
                                "role": "assistant", 
                                "content": clean_content.strip(),
                                "tool_calls": history_tool_calls
                            }
                            openai_messages.append(assistant_message_for_history)
                            
                            # Reset for next iteration
                            accumulated_text_content = ""
                            break  # Break to make next LLM call with tool results
                    
                    # If no tool calls detected, end normally
                    yield StreamChunk(
                        conversation_id=conversation_id, message_id=message_id,
                        part_type='text', text_content="", done=True # Signal completion
                    )
                    return # End of streaming
                elif finish_reason: # Other finish reasons like length, content_filter
                    logger.warning(f"OpenAI stream finished due to: {finish_reason} for {self.model_id}.")
                    yield StreamChunk(
                        conversation_id=conversation_id, message_id=message_id,
                        part_type='text', text_content=f"[Stream terminated: {finish_reason}]", done=True
                    )
                    return # End of streaming
            
            if finish_reason == "tool_calls": # If we broke from stream to make tool calls, continue while loop
                continue
            else: # If stream ended for other reasons or loop naturally finishes
                break 
        
        # If loop finishes (e.g., max_tool_iterations reached or unexpected break)
        logger.warning(f"Max tool iterations reached or stream unexpectedly ended for model {self.model_id}.")
        yield StreamChunk(
            conversation_id=conversation_id, message_id=message_id,
            part_type='text', text_content="[Streaming ended due to iteration limit or unexpected issue]", done=True
        ) 

def _parse_text_tool_calls(text_content: str) -> list[dict]:
    """Parse text-based tool calls from models that output XML-like tool call format.
    
    Example input: '<tools> { "name": "server_id__MCP__tool_name", "arguments": {} } </tools>'
    Returns: [{"name": "server_id__MCP__tool_name", "arguments": {}}]
    """
    import re
    
    tool_calls = []
    
    # Pattern to match <tools>...</tools> blocks
    tools_pattern = r'<tools>\s*(.*?)\s*</tools>'
    matches = re.findall(tools_pattern, text_content, re.DOTALL | re.IGNORECASE)
    
    for match in matches:
        try:
            # Try to parse as JSON
            tool_call_data = json.loads(match.strip())
            if isinstance(tool_call_data, dict) and "name" in tool_call_data:
                # Ensure arguments field exists
                if "arguments" not in tool_call_data:
                    tool_call_data["arguments"] = {}
                tool_calls.append(tool_call_data)
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse tool call JSON: {match}")
            continue
    
    return tool_calls 