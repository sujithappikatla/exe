from typing import Dict, List, Optional
from datetime import datetime
from uuid import uuid4
from models import ConversationHistory, ChatMessage

class MemoryStore:
    """Simple in-memory store for conversation histories"""
    
    def __init__(self):
        self.conversations: Dict[str, ConversationHistory] = {}
    
    def create_conversation(self, conversation_id: Optional[str] = None) -> str:
        """Create a new conversation and return its ID"""
        if conversation_id is None:
            conversation_id = str(uuid4())
        
        if conversation_id not in self.conversations:
            self.conversations[conversation_id] = ConversationHistory(
                conversation_id=conversation_id,
                messages=[]
            )
        
        return conversation_id
    
    def get_conversation(self, conversation_id: str) -> Optional[ConversationHistory]:
        """Get conversation by ID"""
        return self.conversations.get(conversation_id)
    
    def add_message(self, conversation_id: str, message: ChatMessage) -> None:
        """Add a message to a conversation"""
        if conversation_id not in self.conversations:
            self.create_conversation(conversation_id)
        
        self.conversations[conversation_id].messages.append(message)
        self.conversations[conversation_id].updated_at = datetime.now()
        
        # Auto-generate title from first user message if not set
        if (self.conversations[conversation_id].title is None and 
            message.role == "user" and 
            len(self.conversations[conversation_id].messages) == 1):
            # Use first 50 characters of the message as title
            title = message.content[:50]
            if len(message.content) > 50:
                title += "..."
            self.conversations[conversation_id].title = title
    
    def get_conversation_history(self, conversation_id: str) -> List[ChatMessage]:
        """Get message history for a conversation"""
        conversation = self.get_conversation(conversation_id)
        if conversation:
            return conversation.messages
        return []
    
    def list_conversations(self) -> List[ConversationHistory]:
        """List all conversations"""
        return list(self.conversations.values())
    
    def delete_conversation(self, conversation_id: str) -> bool:
        """Delete a conversation"""
        if conversation_id in self.conversations:
            del self.conversations[conversation_id]
            return True
        return False

# Global memory store instance
memory_store = MemoryStore() 