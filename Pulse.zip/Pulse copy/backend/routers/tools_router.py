from fastapi import APIRouter, Depends
from typing import List, Dict, Any

from models import DisplayableTool, McpServerConfig, McpToolDefinition # Added McpToolDefinition
from config import settings # To access app_config
# Removed: from providers.openai_provider import MCP_TOOL_SCHEMA as OPENAI_MCP_TOOL_SCHEMA
from services.mcp_service import mcp_service # Import the service instance

router = APIRouter(
    prefix="/tools",
    tags=["Tools"],
)

@router.get("/available", response_model=List[DisplayableTool])
async def get_available_tools() -> List[DisplayableTool]:
    """
    Returns a list of all tools dynamically discovered from configured MCP servers.
    """
    available_tools_list: List[DisplayableTool] = []

    # Add specific tools dynamically discovered from configured MCP servers
    # Get all configured MCP servers to map IDs to display names
    server_configs_map: Dict[str, McpServerConfig] = { 
        s.id: s for s in settings.app_config.mcp_servers
    }
    
    discovered_tools_by_server: Dict[str, List[McpToolDefinition]] = await mcp_service.get_all_discovered_tools()

    for server_id, tool_defs in discovered_tools_by_server.items():
        server_config = server_configs_map.get(server_id)
        server_display_name = server_config.display_name if server_config else "Unknown Server"
        for tool_def in tool_defs:
            available_tools_list.append(
                DisplayableTool(
                    name=tool_def.name,
                    description=tool_def.description,
                    parameters_schema=tool_def.parameters_schema,
                    source=f"MCP Server: {server_display_name} (ID: {server_id})"
                )
            )
    
    return available_tools_list 