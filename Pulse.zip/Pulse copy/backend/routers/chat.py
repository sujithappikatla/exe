from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from typing import List
from uuid import uuid4
import json
import asyncio
from models import ChatRequest, ChatResponse, ChatMessage, StreamChunk
from services.model_service import model_service
from memory_store import memory_store
import logging

router = APIRouter(prefix="/chat", tags=["chat"])
logger = logging.getLogger(__name__)

@router.post("/completions", response_model=ChatResponse)
async def create_chat_completion(request: ChatRequest):
    """Create a chat completion (non-streaming)"""
    try:
        # Create or get conversation
        conversation_id = request.conversation_id or str(uuid4())
        memory_store.create_conversation(conversation_id)
        
        # Add user message to history
        user_message = ChatMessage(
            role="user",
            content=request.message,
            files=request.files
        )
        # Log the files in user_message immediately after creation
        if user_message.files:
            logger.info(f"[ROUTER] User message created with {len(user_message.files)} files.")
            for i, f_info in enumerate(user_message.files):
                logger.info(f"[ROUTER] File {i}: name='{f_info.name}', type='{f_info.type}', mime_type='{f_info.mime_type}', has_data={f_info.data is not None}")
                if f_info.data:
                    logger.info(f"[ROUTER] File {i} data preview: {f_info.data[:100]}...") # Preview first 100 chars of data URL
        else:
            logger.info("[ROUTER] User message created with no files.")
            
        memory_store.add_message(conversation_id, user_message)
        
        # Get conversation history
        history = memory_store.get_conversation_history(conversation_id)
        
        # Get AI response
        response_content = await model_service.chat_completion(
            messages=history,
            model_id=request.model_id,
            active_mcp_server_ids=request.active_mcp_server_ids
        )
        
        # Create assistant message
        assistant_message = ChatMessage(
            role="assistant",
            content=response_content,
            model_name=model_service.get_model_display_name(request.model_id)
        )
        
        # Add assistant message to history
        memory_store.add_message(conversation_id, assistant_message)
        
        return ChatResponse(
            message=assistant_message,
            conversation_id=conversation_id
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating completion: {str(e)}")

@router.post("/completions/stream")
async def create_streaming_chat_completion(request: ChatRequest):
    """Create a streaming chat completion"""
    try:
        # Create or get conversation
        conversation_id = request.conversation_id or str(uuid4())
        memory_store.create_conversation(conversation_id)
        
        # Add user message to history
        user_message = ChatMessage(
            role="user",
            content=request.message,
            files=request.files
        )
        # Log the files in user_message immediately after creation
        if user_message.files:
            logger.info(f"[ROUTER] User message created with {len(user_message.files)} files.")
            for i, f_info in enumerate(user_message.files):
                logger.info(f"[ROUTER] File {i}: name='{f_info.name}', type='{f_info.type}', mime_type='{f_info.mime_type}', has_data={f_info.data is not None}")
                if f_info.data:
                    logger.info(f"[ROUTER] File {i} data preview: {f_info.data[:100]}...") # Preview first 100 chars of data URL
        else:
            logger.info("[ROUTER] User message created with no files.")
            
        memory_store.add_message(conversation_id, user_message)
        
        # Get conversation history
        history = memory_store.get_conversation_history(conversation_id)
        
        # Create assistant message ID
        ai_message_id = str(uuid4())
        
        async def generate_stream():
            collected_text_content = "" # To store text parts for history
            try:
                # Stream the response, passing conversation_id and ai_message_id
                async for chunk_model in model_service.stream_completion(
                    messages=history,
                    model_id=request.model_id,
                    # Pass the crucial IDs to the provider via kwargs
                    conversation_id=conversation_id, 
                    ai_message_id=ai_message_id,
                    active_mcp_server_ids=request.active_mcp_server_ids
                ):
                    # The provider now yields full StreamChunk Pydantic models.
                    # We just need to serialize and send.
                    
                    # Accumulate text content for history
                    if chunk_model.part_type == 'text' and chunk_model.text_content:
                        collected_text_content += chunk_model.text_content
                    
                    # Send chunk to client in SSE format
                    yield f"data: {chunk_model.model_dump_json()}\n\n"
                    await asyncio.sleep(0.001) # Small sleep to allow other tasks, if necessary
                
                # The provider's stream_completion should send the done=True chunk.
                # So, no need to send a separate final_chunk here explicitly unless the provider fails to do so.
                
                # Add complete assistant message to history (only text parts for now)
                assistant_message = ChatMessage(
                    id=ai_message_id, # Use the same ID for the message in history
                    role="assistant",
                    content=collected_text_content, # Store only the concatenated text parts
                    model_name=model_service.get_model_display_name(request.model_id)
                    # If ChatMessage model is updated to store parts, this would change.
                )
                memory_store.add_message(conversation_id, assistant_message)
                
            except Exception as e:
                logger.error(f"Error during stream generation for conv {conversation_id}, msg {ai_message_id}: {e}", exc_info=True)
                # Ensure a final error chunk is sent to the client so it knows the stream ended due to an error.
                error_stream_chunk = StreamChunk(
                    conversation_id=conversation_id,
                    message_id=ai_message_id,
                    part_type="text", # Send error as a text part
                    text_content=f"Error: {str(e)}",
                    done=True
                )
                yield f"data: {error_stream_chunk.model_dump_json()}\n\n"
        
        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Content-Type": "text/event-stream"
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating streaming completion: {str(e)}")

@router.get("/conversations/{conversation_id}/history")
async def get_conversation_history(conversation_id: str):
    """Get conversation history"""
    try:
        conversation = memory_store.get_conversation(conversation_id)
        if not conversation:
            raise HTTPException(status_code=404, detail="Conversation not found")
        
        return conversation
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching conversation: {str(e)}")

@router.get("/conversations")
async def list_conversations():
    """List all conversations"""
    try:
        conversations = memory_store.list_conversations()
        return conversations
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing conversations: {str(e)}")

@router.delete("/conversations/{conversation_id}")
async def delete_conversation(conversation_id: str):
    """Delete a conversation"""
    try:
        success = memory_store.delete_conversation(conversation_id)
        if not success:
            raise HTTPException(status_code=404, detail="Conversation not found")
        
        return {"message": "Conversation deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting conversation: {str(e)}") 