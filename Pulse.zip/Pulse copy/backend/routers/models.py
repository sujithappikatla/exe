from fastapi import APIRouter, HTTPException
from typing import List
from models import ModelInfo
from services.model_service import model_service

router = APIRouter(prefix="/models", tags=["models"])

@router.get("/", response_model=List[ModelInfo])
async def get_available_models():
    """Get list of all available AI models"""
    try:
        models = await model_service.get_available_models()
        return models
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching models: {str(e)}")

@router.post("/reload")
async def reload_models():
    """Reload model configuration from model_info.json"""
    try:
        model_service.reload_models()
        models = await model_service.get_available_models()
        return {
            "message": "Models reloaded successfully",
            "models_count": len(models),
            "models": models
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reloading models: {str(e)}") 