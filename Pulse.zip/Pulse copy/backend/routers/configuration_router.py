from fastapi import APIRouter, HTTPException, Depends, Body, status, Request
from typing import List, Dict, Any
from uuid import uuid4

from models import AIModelConfig, McpServerConfig, McpServerConfigInput, AppConfiguration, AIModelUpdateRequest, AIModelDeleteRequest
from config import settings, save_app_config

# Import actual service instances
from services.model_service import model_service
from services.mcp_service import mcp_service

router = APIRouter(
    prefix="/config",
    tags=["Configuration"],
)

# Dependency to get current app configuration from settings
def get_current_app_config() -> AppConfiguration:
    return settings.app_config

# --- AI Model Configuration Endpoints ---

@router.get("/models", response_model=List[AIModelConfig])
async def list_ai_models(current_config: AppConfiguration = Depends(get_current_app_config)):
    """List all configured AI models."""
    return current_config.models

@router.post("/models", response_model=AIModelConfig, status_code=status.HTTP_201_CREATED)
async def add_ai_model(model_config: AIModelConfig, current_config: AppConfiguration = Depends(get_current_app_config)):
    """Add a new AI model configuration."""
    current_config.models.append(model_config)
    try:
        save_app_config(current_config)
        settings.reload_app_config() # Reload global settings
        model_service.reload_config() # Notify model_service
        print("AI Model added, config saved and reloaded. ModelService would be notified.")
    except Exception as e:
        current_config.models.pop()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to save AI model configuration: {str(e)}")
    return model_config

@router.post("/models/update", response_model=AIModelConfig)
async def update_ai_model_post(
    request_data: AIModelUpdateRequest, 
    current_config: AppConfiguration = Depends(get_current_app_config)
):
    """Update an existing AI model configuration using config_id from request body."""
    model_id_to_update = request_data.config_id # This is the *current* model_id (the one to find)
    update_payload = request_data.data # This is AIModelConfigInputBE, containing the new data

    original_model_state = None
    model_index = -1

    # Find the model to update based on its current model_id (config_id from request)
    for i, model in enumerate(current_config.models):
        if model.model_id == model_id_to_update:
            original_model_state = model.model_copy(deep=True) # Save its current state for rollback
            model_index = i
            break
    
    if model_index == -1:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"AI Model with current id '{model_id_to_update}' not found.")

    # The new model_id will be what's provided in model_id_on_provider from the payload
    new_model_id = update_payload.model_id_on_provider.strip()
    if not new_model_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Model ID (model_id_on_provider) cannot be empty.")


    # If the model_id is being changed (i.e., new_model_id is different from model_id_to_update),
    # check if the new_model_id conflicts with any *other* existing model.
    if new_model_id != model_id_to_update:
        for i_check, model_check in enumerate(current_config.models):
            if i_check == model_index: # Skip comparing the model with its old self
                continue
            if model_check.model_id == new_model_id:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Another AI Model with id '{new_model_id}' already exists. Model IDs must be unique."
                )

    # Construct the fully updated AIModelConfig object from the payload
    # The 'type' field in AIModelConfig must be derived from 'model_provider'
    # Ensure vertex_ai defaults to False if None/null from frontend, as per AIModelConfig's potential defaults.
    updated_model_data = AIModelConfig(
        model_id=new_model_id, # This is the new (or existing if unchanged) model_id
        display_name=update_payload.display_name.strip(),
        type=update_payload.model_provider, # AIModelConfig uses 'type', frontend sends 'model_provider'
        model_provider=update_payload.model_provider,
        api_key=update_payload.api_key.strip() if update_payload.api_key else None,
        base_url=update_payload.base_url.strip() if update_payload.base_url else None,
        project_id=update_payload.project_id.strip() if update_payload.project_id else None,
        location=update_payload.location.strip() if update_payload.location else None,
        vertex_ai=update_payload.vertex_ai if update_payload.vertex_ai is not None else False
    )
            
    current_config.models[model_index] = updated_model_data # Replace the old model data with the new
        
    try:
        save_app_config(current_config)
        settings.reload_app_config()
        model_service.reload_config()
        print("AI Model updated (POST), config saved and reloaded. ModelService notified.")
    except Exception as e:
        if original_model_state and model_index != -1:
            current_config.models[model_index] = original_model_state # Rollback to the original state
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to update AI model configuration: {str(e)}")
    return current_config.models[model_index] # Return the updated model data

@router.post("/models/delete", status_code=status.HTTP_204_NO_CONTENT)
async def delete_ai_model_post(
    request_data: AIModelDeleteRequest,
    current_config: AppConfiguration = Depends(get_current_app_config)
):
    """Delete an AI model configuration using config_id from request body."""
    model_id_to_delete = request_data.config_id
    model_to_delete = None
    model_index = -1

    for i, model in enumerate(current_config.models):
        if model.model_id == model_id_to_delete:
            model_to_delete = model
            model_index = i
            break
            
    if not model_to_delete:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"AI Model with id '{model_id_to_delete}' not found.")
    
    current_config.models.pop(model_index) # Use pop with index for efficient removal and correct rollback
    try:
        save_app_config(current_config)
        settings.reload_app_config()
        model_service.reload_config()
        print("AI Model deleted (POST), config saved and reloaded. ModelService notified.")
    except Exception as e:
        if model_to_delete and model_index != -1:
            current_config.models.insert(model_index, model_to_delete) # Rollback by inserting back at original index
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to delete AI model configuration: {str(e)}")
    return # FastAPI handles 204 for None return with 204 status


# --- MCP Server Configuration Endpoints ---

@router.get("/mcp_servers", response_model=List[McpServerConfig])
async def list_mcp_servers(current_config: AppConfiguration = Depends(get_current_app_config)):
    """List all configured MCP servers."""
    return current_config.mcp_servers

@router.post("/mcp_servers", response_model=McpServerConfig, status_code=status.HTTP_201_CREATED)
async def add_mcp_server(mcp_config_input: McpServerConfigInput, current_config: AppConfiguration = Depends(get_current_app_config)):
    """Add a new MCP server configuration. ID will be generated."""
    new_id = str(uuid4())
    while any(s.id == new_id for s in current_config.mcp_servers):
        new_id = str(uuid4())
        
    mcp_server = McpServerConfig(id=new_id, **mcp_config_input.model_dump())
    
    if mcp_server.transport == "stdio" and not mcp_server.command:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Field 'command' is required for stdio transport.")
    if mcp_server.transport == "http" and not mcp_server.base_url:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Field 'base_url' is required for http transport.")

    current_config.mcp_servers.append(mcp_server)
    try:
        save_app_config(current_config)
        settings.reload_app_config()
        mcp_service.reload_config()
        print("MCP Server added, config saved and reloaded. McpService would be notified.")
    except Exception as e:
        current_config.mcp_servers.pop() 
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to save MCP server configuration: {str(e)}")
    return mcp_server

@router.put("/mcp_servers/{mcp_server_id}", response_model=McpServerConfig)
async def update_mcp_server(mcp_server_id: str, mcp_update_input: McpServerConfigInput, current_config: AppConfiguration = Depends(get_current_app_config)):
    """Update an existing MCP server configuration by its ID."""
    original_server_state = None
    server_index = -1
    for i, server in enumerate(current_config.mcp_servers):
        if server.id == mcp_server_id:
            updated_server = McpServerConfig(id=mcp_server_id, **mcp_update_input.model_dump())
            if updated_server.transport == "stdio" and not updated_server.command:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Field 'command' is required for stdio transport.")
            if updated_server.transport == "http" and not updated_server.base_url:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Field 'base_url' is required for http transport.")
            
            original_server_state = current_config.mcp_servers[i].model_copy(deep=True)
            server_index = i
            current_config.mcp_servers[i] = updated_server
            break
            
    if server_index == -1:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"MCP Server with id '{mcp_server_id}' not found.")

    try:
        save_app_config(current_config)
        settings.reload_app_config()
        mcp_service.reload_config()
        print("MCP Server updated, config saved and reloaded. McpService would be notified.")
    except Exception as e:
        if original_server_state and server_index != -1:
            current_config.mcp_servers[server_index] = original_server_state 
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to update MCP server configuration: {str(e)}")
    return current_config.mcp_servers[server_index]

@router.delete("/mcp_servers/{mcp_server_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_mcp_server(mcp_server_id: str, current_config: AppConfiguration = Depends(get_current_app_config)):
    """Delete an MCP server configuration by its ID."""
    server_to_delete = None
    server_index = -1
    for i, server in enumerate(current_config.mcp_servers):
        if server.id == mcp_server_id:
            server_to_delete = server
            server_index = i # get index for efficient pop and rollback
            break
            
    if not server_to_delete:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"MCP Server with id '{mcp_server_id}' not found.")

    current_config.mcp_servers.pop(server_index)
    try:
        save_app_config(current_config)
        settings.reload_app_config()
        mcp_service.reload_config()
        print("MCP Server deleted, config saved and reloaded. McpService would be notified.")
    except Exception as e:
        if server_to_delete and server_index != -1:
            current_config.mcp_servers.insert(server_index, server_to_delete) # Rollback
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to delete MCP server configuration: {str(e)}")
    return

# TODO: Implement a proper notification mechanism for services (model_service, mcp_service)
# This might involve a pub/sub system, callbacks, or direct method calls if services are singletons.
# For now, print statements are used as placeholders. 