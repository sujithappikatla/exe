from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import uvicorn
from config import settings
from routers import models, chat
from routers import configuration_router
from routers import tools_router

# Import services to make them available if needed (e.g., for app.state or direct use)
from services.model_service import model_service
from services.mcp_service import mcp_service

# Create FastAPI app
app = FastAPI(
    title="Pulse Chat API",
    description="Backend API for Pulse conversational chat application",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Make services available via app.state if needed by other parts of the app
# This is one way to ensure they are globally accessible singletons if desired.
app.state.model_service = model_service
app.state.mcp_service = mcp_service

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Include routers
app.include_router(models.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(configuration_router.router, prefix="/api")
app.include_router(tools_router.router, prefix="/api")

@app.on_event("startup")
async def startup_event():
    # Ensure services load their initial config from settings
    # This is important if settings.app_config is loaded lazily or might not be fully populated at import time.
    print("Application startup: Initializing services with current configuration...")
    if hasattr(settings, 'app_config') and settings.app_config:
        model_service.reload_config() 
        mcp_service.reload_config()
        print("Services initialized.")
    else:
        print("Warning: app_config not found in settings at startup. Services may not be fully initialized.")

@app.get("/")
async def root():
    """Health check endpoint"""
    return {"message": "Pulse Chat API is running", "version": "1.0.0"}

@app.get("/api/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "api_version": "1.0.0",
        "available_providers": list(getattr(app.state, 'model_service', {}).providers.keys()) if hasattr(app.state, 'model_service') else []
    }

@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"detail": "Endpoint not found"}
    )

@app.exception_handler(500)
async def internal_server_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )


# Serve React/Vue build files
# app.mount("/assets", StaticFiles(directory="../frontend/dist/assets"), name="assets")

# # Catch-all route for frontend routing
# @app.get("/{catchall:path}")
# async def serve_frontend(catchall: str):
#     return FileResponse("../frontend/dist/index.html")


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        access_log=settings.debug
    ) 