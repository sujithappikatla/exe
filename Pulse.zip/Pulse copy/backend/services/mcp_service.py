from typing import List, Optional, Dict, Any
from fastapi import HTTPException
import logging # Added for logging
import base64 # For decoding image data
import os # For file operations
import time # For unique filenames

from config import settings # To access settings.app_config.mcp_servers
from models import McpServerConfig, AppConfiguration, McpToolDefinition # Added McpToolDefinition
from fastmcp import Client as MCPClient # MCP Client from fastmcp
from mcp import types as mcp_types # Changed from fastmcp to mcp for MCP type hints
# Corrected imports based on fastmcp documentation/structure
from fastmcp.client.transports import PythonStdioTransport, StreamableHttpTransport, SSETransport
# from fastmcp.client.client import Client # MCP Client from fastmcp
# from fastmcp.client.transport import StdioTransport, HTTPTransport # For specific transport classes if needed

logger = logging.getLogger(__name__) # Added logger

class McpService:
    """Service to manage MCP server configurations and interactions."""

    def __init__(self):
        self.mcp_server_configs: Dict[str, McpServerConfig] = {}
        self.discovered_tools_cache: Dict[str, List[McpToolDefinition]] = {}
        self._initialize_configs()

    def _initialize_configs(self):
        """Initialize MCP server configurations from settings.app_config."""
        self.mcp_server_configs.clear()
        self.discovered_tools_cache.clear() # Clear tool cache
        mcp_configs_list: List[McpServerConfig] = settings.app_config.mcp_servers
        for config in mcp_configs_list:
            self.mcp_server_configs[config.id] = config
        logger.info(f"McpService: Initialized with {len(self.mcp_server_configs)} MCP server configurations. Tool cache cleared.")

    def reload_config(self):
        """Reload MCP server configurations from global settings."""
        logger.info("McpService: Reloading configuration...")
        # settings.app_config should have been updated by the router
        self._initialize_configs()
        logger.info(f"McpService: Re-initialization complete. Current MCP configs: {list(self.mcp_server_configs.keys())}")

    def get_mcp_server_config(self, server_id: str) -> Optional[McpServerConfig]:
        """Get a specific MCP server configuration by its ID."""
        return self.mcp_server_configs.get(server_id)

    async def get_or_discover_tools_for_server(self, server_id: str) -> List[McpToolDefinition]:
        """
        Retrieves tool definitions for a given MCP server, using cache if available,
        otherwise discovers them from the server.
        """
        if server_id in self.discovered_tools_cache:
            logger.debug(f"Returning cached tools for MCP server ID: {server_id}")
            return self.discovered_tools_cache[server_id]

        mcp_config = self.get_mcp_server_config(server_id)
        if not mcp_config:
            logger.error(f"MCP Server configuration with ID '{server_id}' not found for tool discovery.")
            return [] # Return empty list if server config not found

        logger.info(f"Discovering tools for MCP server: {mcp_config.display_name} (ID: {server_id})")
        discovered_tools: List[McpToolDefinition] = []

        try:
            client_params: Any = None
            if mcp_config.transport == "stdio":
                if not mcp_config.command:
                    raise ValueError("Stdio transport selected but no command specified.")
                client_params = mcp_config.command
            elif mcp_config.transport == "http":
                if not mcp_config.base_url:
                    raise ValueError("HTTP transport selected but no base_url specified.")
                client_params = mcp_config.base_url
            else:
                raise ValueError(f"Unsupported MCP transport type: {mcp_config.transport}")

            async with MCPClient(client_params) as client:
                raw_tools: List[mcp_types.Tool] = await client.list_tools()
                logger.debug(f"Raw tools from server {server_id}: {raw_tools}")
                for tool in raw_tools:
                    # The mcp_types.Tool has 'name', 'description',
                    # and 'inputSchema' (which is a dict representing the JSON schema).
                    params_schema = tool.inputSchema if tool.inputSchema is not None else {"type": "object", "properties": {}}

                    discovered_tools.append(
                        McpToolDefinition(
                            name=tool.name,
                            description=tool.description or "",
                            parameters_schema=params_schema
                        )
                    )
            self.discovered_tools_cache[server_id] = discovered_tools
            logger.info(f"Successfully discovered {len(discovered_tools)} tools for MCP server {server_id}.")
            return discovered_tools
        except Exception as e:
            logger.error(f"Error discovering tools for MCP server {server_id} ({mcp_config.display_name}): {e}", exc_info=True)
            self.discovered_tools_cache[server_id] = [] # Cache empty list on error to prevent retries for a bit
            return []

    async def get_all_discovered_tools(self) -> Dict[str, List[McpToolDefinition]]:
        """
        Retrieves all dynamically discovered tools from all configured MCP servers.
        Returns a dictionary mapping server_id to its list of McpToolDefinition.
        """
        all_tools: Dict[str, List[McpToolDefinition]] = {}
        if settings.app_config and settings.app_config.mcp_servers:
            for server_config in settings.app_config.mcp_servers:
                tools_for_server = await self.get_or_discover_tools_for_server(server_config.id)
                all_tools[server_config.id] = tools_for_server
        return all_tools

    async def call_mcp_tool(
        self,
        server_id: str,
        tool_name: str,
        arguments: Dict[str, Any]
    ) -> Any:
        """Call a tool on a configured MCP server."""
        mcp_config = self.get_mcp_server_config(server_id)
        if not mcp_config:
            print(f"Error: MCP Server configuration with ID '{server_id}' not found.")
            raise HTTPException(status_code=404, detail=f"MCP Server configuration with ID '{server_id}' not found.")

        print(f"McpService: Calling tool '{tool_name}' on MCP server '{server_id}' ({mcp_config.display_name}) with args: {arguments}")

        try:
            client_params: Any = None
            if mcp_config.transport == "stdio":
                if not mcp_config.command:
                    raise ValueError("Stdio transport selected but no command specified in MCP server config.")
                # The fastmcp.Client can take a command string directly for stdio if it's simple.
                # For more complex StdioServerParameters (like setting cwd, env), we'd construct that.
                # Example: client_params = StdioServerParameters(command=mcp_config.command.split()[0], args=mcp_config.command.split()[1:])
                # For now, assume command is a simple string executable path + args
                client_params = mcp_config.command 

            elif mcp_config.transport == "http":
                if not mcp_config.base_url:
                    raise ValueError("HTTP transport selected but no base_url specified in MCP server config.")
                # The fastmcp.Client can take a URL string directly for HTTP/SSE.
                client_params = mcp_config.base_url
            else:
                raise ValueError(f"Unsupported MCP transport type: {mcp_config.transport}")

            async with MCPClient(client_params) as client:
                # Ensure client is initialized (some transports might do this on connect)
                # await client.initialize() # Often not needed if client handles it in __aenter__
                
                tool_result = await client.call_tool(tool_name, arguments)
                
                logger.debug(f"McpService: Tool '{tool_name}' on server '{server_id}' executed. Raw result type: {type(tool_result)}, result: {tool_result}")

                # --- Debug: Save image if present in tool_result.content ---
                if isinstance(tool_result, mcp_types.CallToolResult) and tool_result.content:
                    for i, part in enumerate(tool_result.content):
                        if isinstance(part, mcp_types.ImageContent) and part.data and part.mime_type:
                            try:
                                logger.info(f"ImageContent part found: mime_type='{part.mime_type}', data preview='{part.data[:50]}...'")
                                # Ensure data is plain base64, remove prefix if present (e.g., "data:image/png;base64,")
                                base64_data = part.data
                                if ';base64,' in base64_data:
                                    base64_data = base64_data.split(';base64,', 1)[1]
                                
                                image_bytes = base64.b64decode(base64_data)
                                
                                temp_dir = "backend/temp_mcp_images"
                                os.makedirs(temp_dir, exist_ok=True)
                                
                                # Determine file extension
                                extension = ".png" # default
                                if part.mime_type == "image/jpeg":
                                    extension = ".jpg"
                                elif part.mime_type == "image/gif":
                                    extension = ".gif"
                                elif part.mime_type == "image/webp":
                                    extension = ".webp"
                                
                                timestamp = int(time.time() * 1000)
                                filename = f"mcp_image_{server_id}_{tool_name}_{timestamp}_{i}{extension}"
                                filepath = os.path.join(temp_dir, filename)
                                
                                with open(filepath, "wb") as f:
                                    f.write(image_bytes)
                                logger.info(f"MCP tool image part saved for debugging: {filepath}")
                            except Exception as img_save_e:
                                logger.error(f"Error saving image from MCP tool result: {img_save_e}", exc_info=True)
                # --- End Debug ---

                # The result from fastmcp call_tool is mcp_types.CallToolResult
                # Its 'content' attribute is a list of content parts (e.g., TextContent, ImageContent).
                # The frontend expects this list of parts directly.
                if isinstance(tool_result, mcp_types.CallToolResult):
                    return tool_result.content 
                
                # Fallback for unexpected result types, though fastmcp should return CallToolResult
                logger.warning(f"Unexpected tool result type from MCP server {server_id}: {type(tool_result)}. Returning raw.")
                return tool_result

        except ValueError as ve:
            print(f"Configuration error for MCP server '{server_id}': {ve}")
            raise HTTPException(status_code=500, detail=f"Configuration error for MCP server '{server_id}': {str(ve)}")
        except ConnectionRefusedError:
            print(f"Connection refused when connecting to MCP server '{server_id}' at {mcp_config.base_url or mcp_config.command}")
            raise HTTPException(status_code=503, detail=f"Connection refused by MCP server '{mcp_config.display_name}'. Ensure it is running and accessible.")
        except Exception as e:
            print(f"Error calling MCP tool '{tool_name}' on server '{server_id}': {e}")
            # Consider if more specific error handling from fastmcp is needed
            raise HTTPException(status_code=500, detail=f"Error calling MCP tool '{tool_name}' on server '{mcp_config.display_name}': {str(e)}")

# Global MCP service instance
mcp_service = McpService() 