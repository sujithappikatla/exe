from typing import List, Optional, Dict, Any
from uuid import uuid4
from config import settings # settings now holds AppConfiguration
from models import ModelInfo, ChatMessage, AIModelConfig # AIModelConfig for type hinting
from providers.openai_provider import OpenAIProvider
from providers.google_provider import GoogleProvider
from providers.base import BaseProvider

class ModelService:
    """Service to manage AI models and providers"""
    
    def __init__(self):
        self.providers: Dict[str, BaseProvider] = {}
        self.model_pydantic_configs: Dict[str, AIModelConfig] = {} # Store Pydantic models
        self._initialize_providers()
    
    def _initialize_providers(self):
        """Initialize AI providers based on model configuration from settings.app_config."""
        # Clear existing providers and configs before re-initializing
        self.providers.clear()
        self.model_pydantic_configs.clear()

        model_configs_list: List[AIModelConfig] = settings.app_config.models
        
        for model_config in model_configs_list:
            model_id = model_config.model_id
            if not model_id:
                print(f"Warning: Model config missing model_id: {model_config.model_dump_json()}")
                continue
            
            self.model_pydantic_configs[model_id] = model_config
            
            try:
                # Convert AIModelConfig Pydantic model to dict for provider initialization if needed
                # Or update providers to accept AIModelConfig directly
                config_dict = model_config.model_dump()

                if model_config.type == "openai":
                    provider = OpenAIProvider(config_dict) # Assuming providers take dicts for now
                elif model_config.type == "google":
                    provider = GoogleProvider(config_dict) # Assuming providers take dicts for now
                else:
                    print(f"Warning: Unknown model type for {model_id}: {model_config.type}")
                    continue
                
                self.providers[model_id] = provider
                print(f"Initialized provider for model: {model_id}")
                
            except Exception as e:
                print(f"Error initializing provider for {model_id}: {e}")
    
    async def get_available_models(self) -> List[ModelInfo]:
        """Get all available models from all providers."""
        all_models_info = []
        for model_id, provider in self.providers.items():
            try:
                # Construct ModelInfo from AIModelConfig if provider.get_model_info() is removed
                # or ensure provider.get_model_info() still works / is updated.
                pydantic_config = self.model_pydantic_configs.get(model_id)
                if pydantic_config:
                    all_models_info.append(ModelInfo(
                        model_id=pydantic_config.model_id,
                        name=pydantic_config.display_name,
                        provider=pydantic_config.type, # or model_config.model_provider
                        description=None # Add description to AIModelConfig if needed
                    ))
                else:
                     print(f"Warning: No Pydantic config found for model_id {model_id} during get_available_models")

            except Exception as e:
                print(f"Error getting model info for {model_id}: {e}")
        return all_models_info
    
    def get_provider_for_model(self, model_id: str) -> Optional[BaseProvider]:
        """Get the appropriate provider for a given model ID."""
        if not self.providers:
            print("Warning: get_provider_for_model called but no providers initialized. Attempting re-init.")
            self.reload_config() # Attempt to reload if called when empty
        return self.providers.get(model_id)
    
    async def chat_completion(
        self, 
        messages: List[ChatMessage], 
        model_id: str,
        **kwargs
    ) -> str:
        """Get chat completion from the appropriate provider."""
        provider = self.get_provider_for_model(model_id)
        if not provider:
            raise ValueError(f"No provider found for model: {model_id}. Available providers: {list(self.providers.keys())}")
        
        return await provider.chat_completion(messages, **kwargs)
    
    async def stream_completion(
        self, 
        messages: List[ChatMessage], 
        model_id: str,
        **kwargs
    ):
        """Get streaming chat completion from the appropriate provider."""
        provider = self.get_provider_for_model(model_id)
        if not provider:
            raise ValueError(f"No provider found for model: {model_id}. Available providers: {list(self.providers.keys())}")
        
        async for chunk in provider.stream_completion(messages, **kwargs):
            yield chunk
    
    def get_model_display_name(self, model_id: str) -> str:
        """Get the display name for a model from Pydantic config."""
        pydantic_config = self.model_pydantic_configs.get(model_id)
        return pydantic_config.display_name if pydantic_config else model_id
    
    def reload_config(self):
        """Reload model configuration from global settings and reinitialize providers."""
        print("ModelService: Reloading configuration and re-initializing providers...")
        # Settings should have been reloaded by the router already by calling settings.reload_app_config()
        self._initialize_providers()
        print(f"ModelService: Re-initialization complete. Current providers: {list(self.providers.keys())}")

# Global model service instance
model_service = ModelService() 