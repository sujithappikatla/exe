#!/usr/bin/env python3
"""
Pulse Chat Backend Server Starter
"""

import os
import sys
import uvicorn
from config import settings

def check_environment():
    """Check if environment is properly configured"""
    warnings = []
    
    # Access model configurations from settings.app_config
    model_configs = settings.app_config.models
    
    if not model_configs:
        warnings.append("⚠️  No models configured in model_info.json")
        # If no models, no further checks needed on them.
        # Check for MCP servers if necessary or other global configs.
        if not settings.app_config.mcp_servers:
            warnings.append("⚠️  No MCP servers configured in model_info.json")
        return warnings
    
    openai_models = [m for m in model_configs if m.type == "openai"]
    google_models = [m for m in model_configs if m.type == "google"]
    
    if not openai_models and not google_models:
        warnings.append("⚠️  No OpenAI or Google models configured")
    
    # Check OpenAI models
    if openai_models:
        openai_with_keys = [m for m in openai_models if m.api_key]
        if len(openai_with_keys) != len(openai_models):
            warnings.append(f"⚠️  {len(openai_models) - len(openai_with_keys)} OpenAI model(s) missing API keys")
    # else: # Removed redundant warning if no models at all
        # warnings.append("⚠️  No OpenAI models configured") 
    
    # Check Google models
    if google_models:
        google_api_models = [m for m in google_models if not m.vertex_ai and m.api_key]
        # For Vertex AI, we check project_id and location as per our model
        google_vertex_models = [m for m in google_models if m.vertex_ai and m.project_id and m.location]
        
        # Correctly calculate incomplete Google models
        total_google_configured_correctly = len(google_api_models) + len(google_vertex_models)
        google_incomplete = len(google_models) - total_google_configured_correctly
        
        if google_incomplete > 0:
            warnings.append(f"⚠️  {google_incomplete} Google model(s) missing required configuration (API key or Project ID/Location for Vertex)")
    # else: # Removed redundant warning
        # warnings.append("⚠️  No Google models configured")
    
    # Check MCP Servers
    if not settings.app_config.mcp_servers:
        warnings.append("⚠️  No MCP servers configured in model_info.json")
    else:
        # Basic check if MCP servers list is not empty. More detailed checks can be added.
        pass


    return warnings

def main():
    """Main server startup function"""
    print("🤖 Starting Pulse Chat Backend...")
    print(f"📍 Server will run on: http://{settings.host}:{settings.port}")
    print(f"📖 API Documentation: http://{settings.host}:{settings.port}/api/docs")
    print(f"🔧 Debug mode: {settings.debug}")
    print()
    
    # At this point, settings.app_config should be loaded by Pydantic
    # No need to check for MODEL_INFO_FILE_PATH existence explicitly here,
    # as load_app_config in config.py handles FileNotFoundError.
    # The "Unexpected error loading config file..." message earlier indicates an issue there.

    warnings = check_environment() # Uses settings.app_config
    if warnings:
        print("Configuration status:")
        for warning in warnings:
            print(f"  {warning}")
        print()

    if settings.app_config and settings.app_config.models:
        print(f"✅ Loaded {len(settings.app_config.models)} model configuration(s):")
        for config in settings.app_config.models:
            print(f"   - {config.display_name} ({config.type}, ID: {config.model_id})")
    else:
        # This case is covered by check_environment warnings
        pass 
    
    if settings.app_config and settings.app_config.mcp_servers:
        print(f"✅ Loaded {len(settings.app_config.mcp_servers)} MCP server configuration(s):")
        for server in settings.app_config.mcp_servers:
            print(f"   - {server.display_name} (Transport: {server.transport}, ID: {server.id})")
    else:
        # This case is covered by check_environment warnings
        pass
    print()

    try:
        uvicorn.run(
            "main:app",
            host=settings.host,
            port=settings.port,
            reload=settings.debug,
            access_log=settings.debug,
            log_level="info" if settings.debug else "warning"
        )
    except KeyboardInterrupt:
        print("\n👋 Server stopped by user")
    except Exception as e:
        print(f"\n❌ Server failed to start: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 