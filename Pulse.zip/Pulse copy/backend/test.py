import asyncio
from google import genai
from google.genai import types

PROJECT_ID = "cloud-learning-443407"  # Replace with your project ID
LOCATION = "us-central1"      # Replace with your location if different
MODEL_ID = "gemini-2.0-flash" # Or your specific Vertex model

async def run_test():
    print(f"Attempting to initialize client for project: {PROJECT_ID}, location: {LOCATION}")
    try:
        client = genai.Client(
            vertexai=True,
            project=PROJECT_ID,
            location=LOCATION
        )
        print(f"Client initialized: {client}")
        print(f"Attempting to generate content with model: {MODEL_ID}")

        # Test with a simple prompt
        response = await client.aio.models.generate_content(
            model=MODEL_ID,
            contents=[types.Content(role="user", parts=[types.Part(text="Tell me a short joke.")])]
        )
        print("Response received:")
        print(response.text)

    except Exception as e:
        print(f"An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(run_test())
