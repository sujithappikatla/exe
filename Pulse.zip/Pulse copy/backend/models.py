from datetime import datetime
from typing import List, Optional, Dict, Any, Literal
from pydantic import BaseModel, Field
from uuid import uuid4

class ModelInfo(BaseModel):
    """Model information for API response"""
    model_id: str
    name: str
    provider: Literal["openai", "google"]
    description: Optional[str] = None

# Definition for file data, matching frontend's ApiFile
class ApiFile(BaseModel):
    name: str
    type: Literal['image', 'pdf', 'text', 'other'] # Matches simplified frontend type
    mime_type: str  # Actual MIME type from File object
    data: Optional[str] = None # Base64 data URL for images

class ChatMessage(BaseModel):
    """Individual chat message"""
    id: str = Field(default_factory=lambda: str(uuid4()))
    role: Literal["user", "assistant", "system"] = "user"
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)
    model_name: Optional[str] = None
    files: Optional[List[ApiFile]] = None # Updated to use ApiFile

class ChatRequest(BaseModel):
    """Request for chat completion"""
    message: str
    conversation_id: Optional[str] = None
    model_id: str
    files: Optional[List[ApiFile]] = None # Updated to use ApiFile
    stream: bool = False
    active_mcp_server_ids: Optional[List[str]] = None # For specifying active MCP servers for the session

class ChatResponse(BaseModel):
    """Response for chat completion"""
    message: ChatMessage
    conversation_id: str

class ConversationHistory(BaseModel):
    """Conversation history structure"""
    conversation_id: str
    messages: List[ChatMessage]
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    title: Optional[str] = None

# --- Streaming Part Models for Tool Calls ---
class ToolCallRequestDetails(BaseModel):
    tool_name: str
    tool_arguments: Dict[str, Any]
    # We can add a tool_call_id if needed for more precise correlation, 
    # but for sequential display, tool_name might be enough if only one call of a given name happens at a time per LLM turn.
    # For now, keeping it simple.

class ToolCallResultDetails(BaseModel):
    tool_name: str # To correlate with the request
    tool_result: Any
    # Optional: error: Optional[str] = None, if the tool call failed

class ImageData(BaseModel):
    """Represents image data for streaming."""
    data: str # Base64 encoded image data
    mime_type: str

class StreamChunk(BaseModel):
    """Streaming response chunk, augmented for tool calls and images."""
    conversation_id: str
    message_id: str # ID of the AI message this chunk belongs to
    part_type: Literal["text", "tool_call_request", "tool_call_result", "image"] = "text"
    text_content: Optional[str] = None # Content for 'text' part_type
    tool_call_request_data: Optional[ToolCallRequestDetails] = None # Data for 'tool_call_request'
    tool_call_result_data: Optional[ToolCallResultDetails] = None # Data for 'tool_call_result'
    image_data: Optional[ImageData] = None # Data for 'image' part_type
    done: bool = False

# --- New Configuration Models ---

class AIModelConfig(BaseModel):
    """Configuration for a single AI model, matching model_info.json structure"""
    type: Literal["openai", "google"]
    display_name: str
    model_id: str
    model_provider: Literal["openai", "google"] # Redundant with type, but often in user files
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    # Google specific
    project_id: Optional[str] = None
    location: Optional[str] = None
    vertex_ai: Optional[bool] = False
    # Could add more fields like temperature, max_tokens defaults, etc.

class McpServerConfigInput(BaseModel):
    """Input for creating/updating an MCP server configuration"""
    display_name: str
    transport: Literal["stdio", "http"]
    command: Optional[str] = None # For stdio transport
    base_url: Optional[str] = None # For http transport (e.g., http://localhost:8000/mcp)
    # We might add other fields like description, specific http paths if not part of base_url

class McpToolDefinition(BaseModel):
    name: str
    description: str
    parameters_schema: Optional[Dict[str, Any]] = None # E.g., {"type": "object", "properties": {"param_name": {"type": "string"}}, "required": ["param_name"]}

class McpServerConfig(McpServerConfigInput):
    """Full MCP server configuration including a unique ID"""
    id: str # User-defined, must be unique, or backend-generated

class AppConfiguration(BaseModel):
    """Top-level application configuration, representing model_info.json structure"""
    models: List[AIModelConfig] = Field(default_factory=list)
    mcp_servers: List[McpServerConfig] = Field(default_factory=list)

# --- New Request Models for AI Model CRUD ---

# Represents the structure of the 'data' payload sent by the frontend for model updates
class AIModelConfigInputBE(BaseModel):
    display_name: str
    model_id_on_provider: str # This is what the frontend form sends as the model's ID
    model_provider: Literal['openai', 'google']
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    vertex_ai: Optional[bool] = None # Frontend might send null, backend AIModelConfig defaults to False
    project_id: Optional[str] = None
    location: Optional[str] = None

class AIModelUpdateRequest(BaseModel):
    """Request body for updating an AI model configuration"""
    config_id: str  # The current model_id of the model to update
    data: AIModelConfigInputBE # Changed from AIModelConfig

class AIModelDeleteRequest(BaseModel):
    """Request body for deleting an AI model configuration"""
    config_id: str  # The model_id of the model to delete

# --- Tool Display Model ---
class DisplayableTool(BaseModel):
    name: str
    description: str
    parameters_schema: Optional[Dict[str, Any]] = None
    source: str # e.g., "Built-in LLM Function" or "MCP Server: <server_display_name>" 