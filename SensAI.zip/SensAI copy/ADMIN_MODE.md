# Admin Mode Documentation

## Overview

Admin Mode is a comprehensive role-based access control system that provides user management and approval workflows for SensAI. The first user to sign up automatically becomes an admin, and all subsequent users require admin approval before they can access the system.

## Features

### 1. Automatic First Admin
- The very first user to create an account automatically gets:
  - `role: "admin"`
  - `account_status: "active"`
- This user has immediate access to all features

### 2. User Approval Workflow
- All subsequent users who sign up get:
  - `role: "user"`
  - `account_status: "pending"`
- Pending users cannot log in until approved by an admin
- When a pending user tries to log in, they see:
  - A clear message explaining their account is pending
  - List of admin email addresses to contact

### 3. Admin Panel
- Accessible only to users with `role: "admin"`
- Located in the user profile dropdown menu (top item)
- Opens as a side panel from the right

#### Admin Panel Features:
- **User Statistics**: View total users and pending approvals
- **User List**: See all users with their details:
  - Username
  - Email
  - Role (Admin/User)
  - Account Status (Active/Pending)
  - Join date
- **Search**: Filter users by username or email
- **User Management Actions**:
  - Approve/Deactivate accounts
  - Change user roles (User ↔ Admin)
  - Safeguard: Admins cannot change their own role

## Database Schema

### User Model Changes
Two new fields added to the `users` table:

```python
role = Column(String(20), default="user", nullable=False)  # "admin" or "user"
account_status = Column(String(20), default="pending", nullable=False)  # "active" or "pending"
```

## API Endpoints

### Admin Endpoints (Requires Admin Role)

#### 1. List All Users
```
GET /api/admin/users?limit=50&offset=0
```
Returns paginated list of all users with their details.

#### 2. Update User Status
```
PATCH /api/admin/users/{user_id}/status
Body: { "account_status": "active" | "pending" }
```
Approve or deactivate a user account.

#### 3. Update User Role
```
PATCH /api/admin/users/{user_id}/role
Body: { "role": "admin" | "user" }
```
Change a user's role. Cannot change own role.

### Authentication Changes

#### Login Endpoint
```
POST /api/auth/login
```
Now returns `403 Forbidden` for pending accounts with:
```json
{
  "detail": {
    "message": "Your account is pending approval. Please contact an admin to activate your account.",
    "admin_emails": ["admin1@example.com", "admin2@example.com"]
  }
}
```

#### Signup Endpoint
```
POST /api/auth/signup
```
Automatically determines role and status based on user count.

## Migration Guide

### For New Installations
No migration needed - the schema is included by default.

### For Existing Installations

1. **Run the migration script**:
   ```bash
   cd backend
   python migrate_admin_mode.py
   ```

2. **What the migration does**:
   - Adds `role` and `account_status` columns if they don't exist
   - Sets the first user (by ID) as admin with active status
   - Sets all other existing users as regular users with active status
   - All existing users remain active (they were already using the system)

3. **Verify migration**:
   ```bash
   # Check the database
   sqlite3 sensai.db "SELECT id, username, email, role, account_status FROM users;"
   ```

## Usage Guide

### For Admins

#### Accessing Admin Panel
1. Log in to SensAI
2. Click on your profile icon (bottom left sidebar)
3. Select "Admin Panel" from the dropdown menu
4. The panel will slide in from the right

#### Approving New Users
1. Open Admin Panel
2. Look for users with "Pending" status badge
3. Click the "Approve" button next to the user
4. User can now log in immediately

#### Managing User Roles
1. Open Admin Panel
2. Find the user you want to promote/demote
3. Click "Change Role" button
4. Select "Set as Admin" or "Set as User"
5. Confirm the action

#### Deactivating Users
1. Open Admin Panel
2. Find an active user
3. Click "Deactivate" button
4. User will no longer be able to log in

### For Regular Users

#### When Account is Pending
1. After signup, you'll be redirected to login
2. Attempting to log in will show:
   - "Your account is pending approval" message
   - List of admin email addresses
3. Contact any admin to request account activation
4. Once approved, you can log in normally

## Frontend Components

### New Components
- `AdminPanel.jsx` - Main admin panel sheet component
- `UserListItem.jsx` - Individual user card with actions
- `useAdmin.js` - Custom hook for admin operations

### Modified Components
- `AppSidebar.jsx` - Added "Admin Panel" menu item
- `LoginPage.jsx` - Added pending account error handling
- `AuthContext.jsx` - Updated to handle role in user data

## Security Considerations

1. **Admin Verification**: All admin endpoints verify user role via JWT token
2. **Role Protection**: Users cannot change their own role
3. **First User Security**: Only the absolute first user gets automatic admin access
4. **Token Updates**: JWT tokens include role information
5. **Frontend Guards**: Admin panel only visible to admins

## Testing Checklist

- [ ] First user signup creates admin account
- [ ] Second user signup creates pending account
- [ ] Pending user cannot log in
- [ ] Login shows admin emails for pending users
- [ ] Admin can see Admin Panel menu item
- [ ] Regular users cannot see Admin Panel menu item
- [ ] Admin can view all users
- [ ] Admin can approve pending accounts
- [ ] Admin can change user roles
- [ ] Admin cannot change own role
- [ ] Non-admin cannot access admin API endpoints
- [ ] Approved users can log in successfully

## Troubleshooting

### Problem: Admin Panel Not Showing
- **Check**: User role in localStorage
- **Solution**: Clear browser cache and log in again
- **Verify**: Check JWT token includes `"role": "admin"`

### Problem: All Users Pending After Migration
- **Check**: Migration script output
- **Solution**: Manually set first user as admin:
  ```sql
  UPDATE users SET role='admin', account_status='active' WHERE id=(SELECT MIN(id) FROM users);
  ```

### Problem: 403 Error When Accessing Admin Endpoints
- **Check**: User role in database
- **Solution**: Ensure user has `role='admin'` in database

## Future Enhancements

Potential features for future versions:
- User deletion by admins
- Bulk user operations
- Audit log for admin actions
- Email notifications for approvals
- Custom roles beyond admin/user
- User profile editing by admins
- Account suspension (temporary deactivation)

