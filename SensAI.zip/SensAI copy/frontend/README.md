# Frontend - React + Vite + Tailwind CSS v4 + Shadcn UI

A modern authentication system with dark/light theme support built with the latest frontend technologies.

## Tech Stack

- **React** - UI library
- **Vite** - Build tool and dev server
- **Tailwind CSS v4** - Utility-first CSS framework
- **Shadcn UI** - Re-usable component library built with Radix UI and Tailwind
- **JavaScript** - Programming language
- **Lucide React** - Icon library

## Features

- ✅ Dark/Light theme toggle with persistence
- ✅ Login page with email/password authentication
- ✅ Sign up page with full registration form (email, username, password, confirm password)
- ✅ Form validation and error handling
- ✅ Clean, modular code architecture
- ✅ API service layer ready for backend integration
- ✅ Responsive design

## Getting Started

### Prerequisites

- Node.js (v18 or higher recommended)
- npm or yarn

### Installation

1. Install dependencies:
```bash
npm install
```

### Development

Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5173/`

### Build

Build for production:
```bash
npm run build
```

Preview the production build:
```bash
npm run preview
```

## Project Structure

```
frontend/
├── src/
│   ├── components/        # React components
│   │   ├── ui/           # Shadcn UI components
│   │   └── ThemeToggle.jsx
│   ├── pages/            # Page components
│   │   ├── LoginPage.jsx
│   │   └── SignUpPage.jsx
│   ├── hooks/            # Custom React hooks
│   │   └── useTheme.js
│   ├── services/         # API and network operations
│   │   └── api.js
│   ├── lib/              # Utility functions
│   ├── App.jsx           # Main app component with routing
│   ├── main.jsx          # Entry point
│   └── index.css         # Global styles and Tailwind config
├── public/               # Public assets
├── components.json       # Shadcn UI configuration
├── jsconfig.json         # JavaScript path aliases
├── vite.config.js        # Vite configuration
├── PROJECT_STRUCTURE.md  # Detailed structure documentation
└── package.json          # Dependencies and scripts
```

For detailed information about the project organization, see [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md).

## Adding Shadcn Components

To add new Shadcn UI components:

```bash
npx shadcn@latest add [component-name]
```

For example:
```bash
npx shadcn@latest add card
npx shadcn@latest add dialog
npx shadcn@latest add input
```

Browse available components at [ui.shadcn.com](https://ui.shadcn.com)

## Path Aliases

The project uses `@` as an alias for the `src` directory:

```javascript
import { Button } from '@/components/ui/button'
import { utils } from '@/lib/utils'
```

## Tailwind CSS v4

This project uses Tailwind CSS v4 with the Vite plugin. The configuration is in `vite.config.js` and styles are imported in `src/index.css`.

Color scheme and theme variables are defined using CSS custom properties in `index.css`.

## Development Features

- ✅ Hot Module Replacement (HMR)
- ✅ Fast refresh with React
- ✅ Optimized production builds
- ✅ Path aliases for clean imports (`@/`)
- ✅ Modern CSS with Tailwind v4
- ✅ Beautiful UI components with Shadcn
- ✅ Form validation and error handling
- ✅ Code organized by feature/responsibility

## Environment Variables

Create a `.env` file in the project root:

```env
VITE_API_BASE_URL=http://localhost:8000
```

This will be used for API calls once the backend is integrated.

## Learn More

- [React Documentation](https://react.dev)
- [Vite Documentation](https://vite.dev)
- [Tailwind CSS v4](https://tailwindcss.com)
- [Shadcn UI](https://ui.shadcn.com)
