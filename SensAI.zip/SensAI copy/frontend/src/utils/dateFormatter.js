/**
 * Date Formatting Utilities
 * Helper functions for formatting dates in conversation UI
 */

/**
 * Format conversation date for display
 * @param {Date|string} date - Date to format
 * @returns {string} Formatted date string with full date and time
 */
export function formatConversationDate(date) {
  const messageDate = new Date(date);
  
  // Return full date and time in a readable format
  return messageDate.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}

/**
 * Generate conversation title based on current date
 * @returns {string} Generated title
 */
export function generateConversationTitle() {
  // Always use date-based title
  return formatConversationDate(new Date());
}

/**
 * Format timestamp for message display
 * @param {Date|string} date - Date to format
 * @returns {string} Formatted time string
 */
export function formatMessageTime(date) {
  const messageDate = new Date(date);
  return messageDate.toLocaleTimeString('en-US', { 
    hour: 'numeric', 
    minute: '2-digit',
    hour12: true 
  });
}

/**
 * Format date for general display (e.g., user join dates)
 * @param {Date|string} date - Date to format
 * @returns {string} Formatted date string
 */
export function formatDate(date) {
  const targetDate = new Date(date);
  
  return targetDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}

