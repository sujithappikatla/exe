/**
 * Date Formatting Utilities
 * Helper functions for formatting dates in conversation UI
 */

/**
 * Format conversation date for display
 * @param {Date|string} date - Date to format
 * @returns {string} Formatted date string
 */
export function formatConversationDate(date) {
  const now = new Date();
  const messageDate = new Date(date);
  const diffMs = now - messageDate;
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) {
    return messageDate.toLocaleDateString('en-US', { weekday: 'long' });
  }
  if (diffDays < 365) {
    return messageDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }
  return messageDate.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

/**
 * Generate conversation title based on current date
 * @returns {string} Generated title
 */
export function generateConversationTitle() {
  // Always use date-based title
  return formatConversationDate(new Date());
}

/**
 * Format timestamp for message display
 * @param {Date|string} date - Date to format
 * @returns {string} Formatted time string
 */
export function formatMessageTime(date) {
  const messageDate = new Date(date);
  return messageDate.toLocaleTimeString('en-US', { 
    hour: 'numeric', 
    minute: '2-digit',
    hour12: true 
  });
}

