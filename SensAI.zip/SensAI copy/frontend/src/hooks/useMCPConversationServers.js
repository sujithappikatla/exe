/**
 * useMCPConversationServers Hook
 * Custom hook for managing MCP servers for a specific conversation
 * Handles fetching servers with toggle state and toggling servers on/off
 */

import { useState, useEffect, useCallback } from 'react';
import { mcpAPI } from '@/services/api';

export function useMCPConversationServers(conversationId) {
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  /**
   * Fetch MCP servers for this conversation with toggle state
   * If no conversationId, fetch all available servers (for preview)
   */
  const fetchConversationServers = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      if (!conversationId) {
        // No conversation yet - show all available servers with is_enabled: true (default)
        const allServers = await mcpAPI.listServers();
        const serversWithState = (allServers || []).map(server => ({
          ...server,
          is_enabled: true, // Default all enabled for new conversations
        }));
        setServers(serversWithState);
      } else {
        // Fetch conversation-specific toggle states
        const data = await mcpAPI.getConversationServers(conversationId);
        setServers(data || []);
      }
    } catch (err) {
      console.error('Error fetching conversation MCP servers:', err);
      setError(err.message || 'Failed to load MCP servers');
    } finally {
      setLoading(false);
    }
  }, [conversationId]);

  /**
   * Toggle a server on/off for this conversation
   * @param {string} serverName - Name of the server to toggle
   * @param {boolean} isEnabled - Enable or disable
   * @returns {Promise<void>}
   */
  const toggleServer = useCallback(
    async (serverName, isEnabled) => {
      if (!conversationId) {
        throw new Error('No conversation selected');
      }

      // Optimistic update
      setServers((prev) =>
        prev.map((server) =>
          server.name === serverName
            ? { ...server, is_enabled: isEnabled }
            : server
        )
      );

      try {
        await mcpAPI.toggleServer(conversationId, serverName, isEnabled);
      } catch (err) {
        console.error('Error toggling MCP server:', err);
        // Revert optimistic update on error
        setServers((prev) =>
          prev.map((server) =>
            server.name === serverName
              ? { ...server, is_enabled: !isEnabled }
              : server
          )
        );
        throw err;
      }
    },
    [conversationId]
  );

  /**
   * Refresh the conversation servers list
   */
  const refreshServers = useCallback(() => {
    fetchConversationServers();
  }, [fetchConversationServers]);

  // Fetch servers when conversation changes
  useEffect(() => {
    fetchConversationServers();
  }, [fetchConversationServers]);

  return {
    servers,
    loading,
    error,
    toggleServer,
    refreshServers,
  };
}

