/**
 * useAutoScroll Hook
 * Smart auto-scroll logic that disables when user scrolls up
 */

import { useState, useEffect, useRef, useCallback } from 'react';

export function useAutoScroll(isStreaming, messages, streamingContent) {
  const scrollRef = useRef(null);
  const [autoScrollEnabled, setAutoScrollEnabled] = useState(true);
  const lastScrollTop = useRef(0);
  const userScrolled = useRef(false);

  /**
   * Check if scroll is at bottom
   */
  const isAtBottom = useCallback(() => {
    const element = scrollRef.current;
    if (!element) return false;

    const { scrollTop, scrollHeight, clientHeight } = element;
    const threshold = 50; // 50px threshold
    return scrollHeight - scrollTop - clientHeight < threshold;
  }, []);

  /**
   * Handle scroll event - detect user scroll
   */
  const handleScroll = useCallback(() => {
    const element = scrollRef.current;
    if (!element) return;

    const { scrollTop, scrollHeight, clientHeight } = element;
    const atBottom = scrollHeight - scrollTop - clientHeight < 50;

    // If user scrolled up (away from bottom), disable auto-scroll
    if (scrollTop < lastScrollTop.current && !atBottom) {
      setAutoScrollEnabled(false);
      userScrolled.current = true;
    }

    // If user scrolled to bottom, enable auto-scroll
    if (atBottom && userScrolled.current) {
      setAutoScrollEnabled(true);
      userScrolled.current = false;
    }

    lastScrollTop.current = scrollTop;
  }, []);

  /**
   * Scroll to bottom smoothly
   */
  const scrollToBottom = useCallback((behavior = 'smooth') => {
    const element = scrollRef.current;
    if (!element) return;

    element.scrollTo({
      top: element.scrollHeight,
      behavior,
    });
  }, []);

  /**
   * Auto-scroll when new content arrives
   */
  useEffect(() => {
    if (autoScrollEnabled && scrollRef.current) {
      scrollToBottom('smooth');
    }
  }, [messages, streamingContent, autoScrollEnabled, scrollToBottom]);

  /**
   * Enable auto-scroll when streaming starts
   */
  useEffect(() => {
    if (isStreaming) {
      setAutoScrollEnabled(true);
      userScrolled.current = false;
    }
  }, [isStreaming]);

  return {
    scrollRef,
    handleScroll,
    autoScrollEnabled,
    scrollToBottom,
  };
}

