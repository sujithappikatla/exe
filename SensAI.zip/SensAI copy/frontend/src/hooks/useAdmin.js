/**
 * useAdmin Hook
 * Custom hook for managing admin panel state and operations
 */

import { useState, useCallback } from 'react';
import { adminAPI } from '@/services/api';

export function useAdmin() {
  const [users, setUsers] = useState([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  /**
   * Fetch all users
   */
  const fetchUsers = useCallback(async (limit = 50, offset = 0) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await adminAPI.listUsers(limit, offset);
      setUsers(response.users || []);
      setTotal(response.total || 0);
    } catch (err) {
      setError(err.message || 'Failed to fetch users');
      console.error('Error fetching users:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Update user account status
   */
  const updateStatus = useCallback(async (userId, status) => {
    setError(null);
    
    try {
      const updatedUser = await adminAPI.updateUserStatus(userId, status);
      
      // Update local state
      setUsers(prevUsers =>
        prevUsers.map(user =>
          user.id === userId ? updatedUser : user
        )
      );
      
      return updatedUser;
    } catch (err) {
      setError(err.message || 'Failed to update user status');
      console.error('Error updating user status:', err);
      throw err;
    }
  }, []);

  /**
   * Update user role
   */
  const updateRole = useCallback(async (userId, role) => {
    setError(null);
    
    try {
      const updatedUser = await adminAPI.updateUserRole(userId, role);
      
      // Update local state
      setUsers(prevUsers =>
        prevUsers.map(user =>
          user.id === userId ? updatedUser : user
        )
      );
      
      return updatedUser;
    } catch (err) {
      setError(err.message || 'Failed to update user role');
      console.error('Error updating user role:', err);
      throw err;
    }
  }, []);

  return {
    users,
    total,
    isLoading,
    error,
    fetchUsers,
    updateStatus,
    updateRole,
  };
}

