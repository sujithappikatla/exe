/**
 * useChat Hook
 * Main chat logic with SSE streaming and page reload recovery
 */

import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { chatAPI } from '@/services/api';
import { tokenManager } from '@/services/api';

export function useChat(conversationId) {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isRecovering, setIsRecovering] = useState(false);
  const [currentStreamContent, setCurrentStreamContent] = useState('');
  const [currentStatus, setCurrentStatus] = useState(null);
  const [error, setError] = useState(null);
  const eventSourceRef = useRef(null);
  const streamingMessageIdRef = useRef(null);

  /**
   * Load conversation from API
   */
  const loadConversation = async (convId = conversationId) => {
    if (!convId) return;

    try {
      const data = await chatAPI.getConversation(convId);
      setMessages(data.messages || []);

      // Check if there might be an active streaming session
      const lastUserMessage = data.messages?.filter((m) => m.role === 'user').pop();
      const lastAssistantMessage = data.messages?.filter((m) => m.role === 'assistant').pop();

      // If last user message exists and (no assistant message OR user message is newer)
      const mightHaveActiveSession =
        lastUserMessage &&
        (!lastAssistantMessage ||
          new Date(lastUserMessage.created_at) > new Date(lastAssistantMessage.created_at));

      if (mightHaveActiveSession) {
        // Try to reconnect to SSE
        setIsRecovering(true);
        connectSSE(convId);
      }
    } catch (err) {
      console.error('Failed to load conversation:', err);
      setError(err.message);
    }
  };

  /**
   * Connect to SSE stream
   */
  const connectSSE = (convId) => {
    const token = tokenManager.getToken();
    if (!token) {
      setError('No authentication token');
      return;
    }

    try {
      const eventSource = chatAPI.connectToStream(convId, token, {
        onContent: (data) => {
          // Stream is active! Continue showing it
          setIsStreaming(true);
          setIsRecovering(false);
          setCurrentStreamContent((prev) => prev + data.delta);
          streamingMessageIdRef.current = data.message_id;
        },
        onStatus: (data) => {
          setCurrentStatus(data.message);
        },
        onComplete: (data) => {
          // Stream completed - refresh conversation to get saved message
          setIsStreaming(false);
          setIsRecovering(false);
          setCurrentStreamContent('');
          setCurrentStatus(null);
          streamingMessageIdRef.current = null;
          
          // Close SSE connection
          if (eventSourceRef.current) {
            eventSourceRef.current.close();
            eventSourceRef.current = null;
          }

          // Reload conversation to get the saved assistant message
          // Use the convId from the closure to ensure we load the right conversation
          loadConversation(convId);
        },
        onError: (data) => {
          if (data.message && data.message.includes('No active session')) {
            // This is expected - no streaming in progress
            setIsRecovering(false);
            setIsStreaming(false);
          } else {
            // Real error
            setError(data.message || 'Connection error');
            setIsStreaming(false);
            setIsRecovering(false);
          }
          
          // Close connection on error
          if (eventSourceRef.current) {
            eventSourceRef.current.close();
            eventSourceRef.current = null;
          }
        },
        onToolConfirmation: (data) => {
          console.log('Tool confirmation requested:', data);
          // TODO: Show confirmation dialog
        },
        onActionComplete: (data) => {
          console.log('Action completed:', data);
        },
      });

      eventSourceRef.current = eventSource;
    } catch (err) {
      console.error('Failed to connect to SSE:', err);
      setError(err.message);
      setIsRecovering(false);
      setIsStreaming(false);
    }
  };

  /**
   * Send a message
   */
  const sendMessage = async (content) => {
    try {
      let targetConversationId = conversationId;

      // If no conversation exists, create one first
      if (!targetConversationId) {
        const { generateConversationTitle } = await import('@/utils/dateFormatter');
        const title = generateConversationTitle();
        const newConversation = await chatAPI.createConversation(title);
        targetConversationId = newConversation.id;

        // Navigate to the new conversation WITHOUT page reload
        navigate(`/chat/${targetConversationId}`, { replace: true });
      }

      // Add user message to UI immediately with temporary ID
      const tempId = `temp-${Date.now()}`;
      const userMsg = { 
        role: 'user', 
        content, 
        id: tempId,
        created_at: new Date().toISOString()
      };
      setMessages((prev) => [...prev, userMsg]);

      // Send to backend
      const response = await chatAPI.sendMessage(targetConversationId, content);

      // Update with real message ID
      setMessages((prev) =>
        prev.map((m) => (m.id === tempId ? { ...m, id: response.message_id } : m))
      );

      // Start streaming
      setIsStreaming(true);
      setCurrentStreamContent('');
      setCurrentStatus(null);
      setError(null);
      connectSSE(targetConversationId);
    } catch (err) {
      console.error('Failed to send message:', err);
      setError(err.message);
      // Remove the temporary message on error
      setMessages((prev) => prev.filter((m) => !m.id.toString().startsWith('temp-')));
    }
  };

  /**
   * Stop ongoing streaming
   */
  const stopStreaming = async () => {
    if (!conversationId) return;

    try {
      await chatAPI.stopGeneration(conversationId);
    } catch (err) {
      console.error('Failed to stop generation:', err);
    } finally {
      // Always close SSE and reset state
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
      setIsStreaming(false);
      setCurrentStreamContent('');
      setCurrentStatus(null);
      
      // Reload to get any partial message that was saved
      loadConversation(conversationId);
    }
  };

  /**
   * Add feedback to a message
   */
  const addMessageFeedback = async (messageId, feedbackType, reason = null) => {
    try {
      const feedback = await chatAPI.addFeedback(messageId, feedbackType, reason);
      
      // Update message in state
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId ? { ...m, feedback } : m
        )
      );
    } catch (err) {
      console.error('Failed to add feedback:', err);
      throw err;
    }
  };

  /**
   * Remove feedback from a message
   */
  const removeFeedback = async (messageId) => {
    try {
      await chatAPI.deleteFeedback(messageId);
      
      // Update message in state
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId ? { ...m, feedback: null } : m
        )
      );
    } catch (err) {
      console.error('Failed to remove feedback:', err);
      throw err;
    }
  };

  // Load conversation on mount or when conversationId changes
  useEffect(() => {
    if (conversationId) {
      loadConversation();
    } else {
      setMessages([]);
    }

    // Cleanup on unmount or conversation change
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
      setIsStreaming(false);
      setIsRecovering(false);
      setCurrentStreamContent('');
      setCurrentStatus(null);
    };
  }, [conversationId]);

  return {
    messages,
    isStreaming,
    isRecovering,
    currentStreamContent,
    currentStatus,
    error,
    sendMessage,
    stopStreaming,
    addMessageFeedback,
    removeFeedback,
  };
}

