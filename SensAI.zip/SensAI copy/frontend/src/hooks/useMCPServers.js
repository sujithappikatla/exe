/**
 * useMCPServers Hook
 * Custom hook for managing MCP servers (CRUD operations)
 */

import { useState, useEffect, useCallback } from 'react';
import { mcpAPI } from '@/services/api';

export function useMCPServers() {
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  /**
   * Fetch all MCP servers (system + user)
   */
  const fetchServers = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await mcpAPI.listServers();
      setServers(data || []);
    } catch (err) {
      console.error('Error fetching MCP servers:', err);
      setError(err.message || 'Failed to load MCP servers');
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Create a new user MCP server
   * @param {object} serverData - Server configuration
   * @returns {Promise<object>} Created server
   */
  const createServer = useCallback(async (serverData) => {
    try {
      const createdServer = await mcpAPI.createServer(serverData);
      setServers((prev) => [...prev, createdServer]);
      return createdServer;
    } catch (err) {
      console.error('Error creating MCP server:', err);
      throw err;
    }
  }, []);

  /**
   * Update an existing user MCP server
   * @param {number} serverId - Server ID
   * @param {object} serverData - Updated server configuration
   * @returns {Promise<object>} Updated server
   */
  const updateServer = useCallback(async (serverId, serverData) => {
    try {
      const updatedServer = await mcpAPI.updateServer(serverId, serverData);
      setServers((prev) =>
        prev.map((server) =>
          server.id === serverId ? updatedServer : server
        )
      );
      return updatedServer;
    } catch (err) {
      console.error('Error updating MCP server:', err);
      throw err;
    }
  }, []);

  /**
   * Delete a user MCP server
   * @param {number} serverId - Server ID
   * @returns {Promise<void>}
   */
  const deleteServer = useCallback(async (serverId) => {
    try {
      await mcpAPI.deleteServer(serverId);
      setServers((prev) => prev.filter((server) => server.id !== serverId));
    } catch (err) {
      console.error('Error deleting MCP server:', err);
      throw err;
    }
  }, []);

  /**
   * Refresh the servers list
   */
  const refreshServers = useCallback(() => {
    fetchServers();
  }, [fetchServers]);

  // Fetch servers on mount
  useEffect(() => {
    fetchServers();
  }, [fetchServers]);

  return {
    servers,
    loading,
    error,
    createServer,
    updateServer,
    deleteServer,
    refreshServers,
  };
}

