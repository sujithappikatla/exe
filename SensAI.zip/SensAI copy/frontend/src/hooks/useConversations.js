/**
 * useConversations Hook
 * Manages conversation list state and operations
 */

import { useState, useEffect, useCallback } from 'react';
import { chatAPI } from '@/services/api';

export function useConversations() {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  /**
   * Load conversations from API
   */
  const loadConversations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await chatAPI.listConversations();
      setConversations(data);
    } catch (err) {
      console.error('Failed to load conversations:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Create a new conversation
   * @param {string} title - Optional conversation title
   * @returns {Promise<object>} Created conversation
   */
  const createConversation = async (title = null) => {
    try {
      const conversation = await chatAPI.createConversation(title);
      setConversations((prev) => [conversation, ...prev]);
      return conversation;
    } catch (err) {
      console.error('Failed to create conversation:', err);
      throw err;
    }
  };

  /**
   * Delete a conversation
   * @param {number} id - Conversation ID
   */
  const deleteConversation = async (id) => {
    try {
      await chatAPI.deleteConversation(id);
      setConversations((prev) => prev.filter((conv) => conv.id !== id));
    } catch (err) {
      console.error('Failed to delete conversation:', err);
      throw err;
    }
  };

  // Load conversations on mount
  useEffect(() => {
    loadConversations();
  }, []);

  return {
    conversations,
    loading,
    error,
    loadConversations,
    createConversation,
    deleteConversation,
  };
}

