/**
 * Home Page / Dashboard
 * Main landing page after login
 */

import { useAuth } from '@/contexts/AuthContext';

export function HomePage() {
  const { user } = useAuth();

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-4xl font-bold text-foreground">
          Welcome back, {user?.username}!
        </h1>
        <p className="mt-2 text-lg text-muted-foreground">
          This is your dashboard. More features coming soon!
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Placeholder cards */}
        <div className="rounded-lg border bg-card p-6">
          <h3 className="text-lg font-semibold">Quick Stats</h3>
          <p className="mt-2 text-muted-foreground">
            Your activity summary will appear here.
          </p>
        </div>

        <div className="rounded-lg border bg-card p-6">
          <h3 className="text-lg font-semibold">Recent Activity</h3>
          <p className="mt-2 text-muted-foreground">
            Recent actions will be displayed here.
          </p>
        </div>

        <div className="rounded-lg border bg-card p-6">
          <h3 className="text-lg font-semibold">Notifications</h3>
          <p className="mt-2 text-muted-foreground">
            You have no new notifications.
          </p>
        </div>
      </div>
    </div>
  );
}

