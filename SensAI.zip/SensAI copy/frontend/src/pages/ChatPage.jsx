/**
 * ChatPage Component
 * Main chat interface with streaming support
 */

import { useParams } from 'react-router-dom';
import { Loader2, AlertCircle } from 'lucide-react';
import { useChat } from '@/hooks/useChat';
import { useAutoScroll } from '@/hooks/useAutoScroll';
import { MessageList } from '@/components/chat/MessageList';
import { MessageInput } from '@/components/chat/MessageInput';
import { EmptyState } from '@/components/chat/EmptyState';

export function ChatPage() {
  const { conversationId } = useParams();

  const {
    messages,
    isStreaming,
    isRecovering,
    currentStreamContent,
    currentStatus,
    error,
    sendMessage,
    stopStreaming,
    addMessageFeedback,
    removeFeedback,
  } = useChat(conversationId);

  const { scrollRef, handleScroll, autoScrollEnabled, scrollToBottom } = useAutoScroll(
    isStreaming,
    messages,
    currentStreamContent
  );

  const handleFeedback = async (messageId, feedbackType) => {
    if (feedbackType === null) {
      await removeFeedback(messageId);
    } else {
      await addMessageFeedback(messageId, feedbackType);
    }
  };

  const handleSuggestionClick = (prompt) => {
    sendMessage(prompt);
  };

  // If no conversation selected, show empty state (new chat)
  // User can still send messages - conversation will be created then
  const showEmptyState = messages.length === 0 && !isStreaming;

  return (
    <div className="flex flex-col h-full">
      {/* Recovery indicator */}
      {isRecovering && (
        <div className="flex items-center gap-2 p-3 bg-muted flex-shrink-0">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm">Checking for active session...</span>
        </div>
      )}

      {/* Error banner */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-destructive/10 text-destructive flex-shrink-0">
          <AlertCircle className="h-4 w-4" />
          <span className="text-sm">{error}</span>
        </div>
      )}

      {/* Messages or empty state - scrollable area */}
      <div className="flex-1 min-h-0">
        {showEmptyState ? (
          <div className="h-full overflow-y-auto">
            <EmptyState onSuggestionClick={handleSuggestionClick} />
          </div>
        ) : (
          <MessageList
            messages={messages}
            streamingContent={isStreaming ? currentStreamContent : null}
            scrollRef={scrollRef}
            onScroll={handleScroll}
            autoScrollEnabled={autoScrollEnabled}
            scrollToBottom={scrollToBottom}
            onFeedback={handleFeedback}
            currentStatus={currentStatus}
          />
        )}
      </div>

      {/* Input box - fixed at bottom */}
      <div className="flex-shrink-0">
        <MessageInput
          onSend={sendMessage}
          onStop={stopStreaming}
          isStreaming={isStreaming}
          disabled={isRecovering}
        />
      </div>
    </div>
  );
}

