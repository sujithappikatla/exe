/**
 * API Constants
 * All API endpoint URLs and base configuration
 */

// Base API URL - from environment variable or default
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080';

// Authentication Endpoints
export const AUTH_ENDPOINTS = {
  SIGNUP: '/api/auth/signup',
  LOGIN: '/api/auth/login',
  LOGOUT: '/api/auth/logout',
  ME: '/api/auth/me',
  CHANGE_PASSWORD: '/api/auth/change-password',
};

// Chat Endpoints
export const CHAT_ENDPOINTS = {
  CONVERSATIONS: '/api/chat/conversations',
  CONVERSATION_DETAIL: (id) => `/api/chat/conversations/${id}`,
  MESSAGES: (id) => `/api/chat/conversations/${id}/messages`,
  STOP: (id) => `/api/chat/conversations/${id}/stop`,
  STREAM: (id) => `/api/chat/conversations/${id}/stream`,
  FEEDBACK: (messageId) => `/api/chat/messages/${messageId}/feedback`,
};

// MCP Endpoints
export const MCP_ENDPOINTS = {
  SERVERS: '/api/mcp/servers',
  SERVER_DETAIL: (id) => `/api/mcp/servers/${id}`,
  CONVERSATION_SERVERS: (conversationId) => `/api/mcp/conversations/${conversationId}/servers`,
  TOGGLE_SERVER: (conversationId) => `/api/mcp/conversations/${conversationId}/servers/toggle`,
};

// Admin Endpoints
export const ADMIN_ENDPOINTS = {
  USERS: '/api/admin/users',
  USER_STATUS: (userId) => `/api/admin/users/${userId}/status`,
  USER_ROLE: (userId) => `/api/admin/users/${userId}/role`,
};

// Full API URLs
export const API_URLS = {
  // Authentication
  SIGNUP: `${API_BASE_URL}${AUTH_ENDPOINTS.SIGNUP}`,
  LOGIN: `${API_BASE_URL}${AUTH_ENDPOINTS.LOGIN}`,
  LOGOUT: `${API_BASE_URL}${AUTH_ENDPOINTS.LOGOUT}`,
  ME: `${API_BASE_URL}${AUTH_ENDPOINTS.ME}`,
  CHANGE_PASSWORD: `${API_BASE_URL}${AUTH_ENDPOINTS.CHANGE_PASSWORD}`,
  
  // Chat
  CONVERSATIONS: `${API_BASE_URL}${CHAT_ENDPOINTS.CONVERSATIONS}`,
  CONVERSATION_DETAIL: (id) => `${API_BASE_URL}${CHAT_ENDPOINTS.CONVERSATION_DETAIL(id)}`,
  MESSAGES: (id) => `${API_BASE_URL}${CHAT_ENDPOINTS.MESSAGES(id)}`,
  STOP: (id) => `${API_BASE_URL}${CHAT_ENDPOINTS.STOP(id)}`,
  STREAM: (id) => `${API_BASE_URL}${CHAT_ENDPOINTS.STREAM(id)}`,
  FEEDBACK: (messageId) => `${API_BASE_URL}${CHAT_ENDPOINTS.FEEDBACK(messageId)}`,
  
  // MCP
  MCP_SERVERS: `${API_BASE_URL}${MCP_ENDPOINTS.SERVERS}`,
  MCP_SERVER_DETAIL: (id) => `${API_BASE_URL}${MCP_ENDPOINTS.SERVER_DETAIL(id)}`,
  MCP_CONVERSATION_SERVERS: (conversationId) => `${API_BASE_URL}${MCP_ENDPOINTS.CONVERSATION_SERVERS(conversationId)}`,
  MCP_TOGGLE_SERVER: (conversationId) => `${API_BASE_URL}${MCP_ENDPOINTS.TOGGLE_SERVER(conversationId)}`,
  
  // Admin
  ADMIN_USERS: `${API_BASE_URL}${ADMIN_ENDPOINTS.USERS}`,
  ADMIN_USER_STATUS: (userId) => `${API_BASE_URL}${ADMIN_ENDPOINTS.USER_STATUS(userId)}`,
  ADMIN_USER_ROLE: (userId) => `${API_BASE_URL}${ADMIN_ENDPOINTS.USER_ROLE(userId)}`,
  
  // Health check
  HEALTH: `${API_BASE_URL}/health`,
  ROOT: `${API_BASE_URL}/`,
};

// Storage keys
export const STORAGE_KEYS = {
  ACCESS_TOKEN: 'access_token',
  USER_DATA: 'user_data',
};

// API Configuration
export const API_CONFIG = {
  TIMEOUT: 10000, // 10 seconds
  HEADERS: {
    'Content-Type': 'application/json',
  },
};

