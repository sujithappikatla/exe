/**
 * API Service
 * All network operations and API calls should be defined here
 * This keeps the API logic separate from UI components
 */

import { API_URLS, STORAGE_KEYS, API_CONFIG } from './constants';

/**
 * Token Management
 */
export const tokenManager = {
  /**
   * Get access token from localStorage
   * @returns {string|null} Access token or null
   */
  getToken: () => {
    return localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
  },

  /**
   * Set access token in localStorage
   * @param {string} token - JWT token
   */
  setToken: (token) => {
    localStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, token);
  },

  /**
   * Remove access token from localStorage
   */
  removeToken: () => {
    localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
  },

  /**
   * Get user data from localStorage
   * @returns {object|null} User data or null
   */
  getUserData: () => {
    const data = localStorage.getItem(STORAGE_KEYS.USER_DATA);
    return data ? JSON.parse(data) : null;
  },

  /**
   * Set user data in localStorage
   * @param {object} userData - User data object
   */
  setUserData: (userData) => {
    localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(userData));
  },

  /**
   * Remove user data from localStorage
   */
  removeUserData: () => {
    localStorage.removeItem(STORAGE_KEYS.USER_DATA);
  },

  /**
   * Clear all auth data
   */
  clearAuth: () => {
    tokenManager.removeToken();
    tokenManager.removeUserData();
  },
};

// Global callback for handling unauthorized access
let unauthorizedCallback = null;

/**
 * Set callback for handling 401 unauthorized errors
 * This allows the API service to trigger logout from AuthContext
 * @param {Function} callback - Function to call on 401 error
 */
export function setUnauthorizedCallback(callback) {
  unauthorizedCallback = callback;
}

/**
 * Generic API request handler
 * @param {string} url - Full API URL
 * @param {object} options - Fetch options
 * @param {boolean} requiresAuth - Whether the request requires authentication
 * @returns {Promise} Response data
 */
async function apiRequest(url, options = {}, requiresAuth = false) {
  const headers = {
    ...API_CONFIG.HEADERS,
    ...options.headers,
  };

  // Add authorization header if required
  if (requiresAuth) {
    const token = tokenManager.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  const config = {
    ...options,
    headers,
  };

  try {
    const response = await fetch(url, config);

    // Handle 204 No Content - no body to parse
    if (response.status === 204) {
      return null;
    }

    // Handle non-JSON responses
    const contentType = response.headers.get('content-type');
    let data;
    
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      data = await response.text();
    }

    // Check for 401 Unauthorized
    if (response.status === 401) {
      console.warn('Unauthorized access detected (401). Initiating logout...');
      tokenManager.clearAuth();
      
      // Trigger logout callback if set
      if (unauthorizedCallback) {
        unauthorizedCallback();
      }
      
      const errorMessage = data?.detail || data?.message || 'Unauthorized';
      const error = new Error(errorMessage);
      error.status = 401;
      throw error;
    }

    if (!response.ok) {
      // Handle error response
      const errorMessage = data?.detail || data?.message || data || 'API request failed';
      const error = new Error(typeof errorMessage === 'string' ? errorMessage : JSON.stringify(errorMessage));
      error.status = response.status;
      error.detail = data?.detail;
      throw error;
    }

    return data;
  } catch (error) {
    // If error already has status 401, just re-throw
    if (error.status === 401) {
      throw error;
    }
    
    console.error('API Error:', error);
    throw error;
  }
}

/**
 * Authentication API calls
 */
export const authAPI = {
  /**
   * Login user
   * @param {object} credentials - User credentials (email, password)
   * @returns {Promise} User data and token
   */
  login: async (credentials) => {
    const response = await apiRequest(
      API_URLS.LOGIN,
      {
        method: 'POST',
        body: JSON.stringify(credentials),
      },
      false
    );

    // Store token and user data
    if (response.token && response.user) {
      tokenManager.setToken(response.token.access_token);
      tokenManager.setUserData(response.user);
    }

    return response;
  },

  /**
   * Sign up new user
   * @param {object} userData - User data (email, username, password)
   * @returns {Promise} User data and token
   */
  signUp: async (userData) => {
    const response = await apiRequest(
      API_URLS.SIGNUP,
      {
        method: 'POST',
        body: JSON.stringify(userData),
      },
      false
    );

    // Don't store token and user data (user must manually login)
    // Token is provided by API but not automatically stored
    
    return response;
  },

  /**
   * Logout user
   * @returns {Promise} Success message
   */
  logout: async () => {
    try {
      const response = await apiRequest(
        API_URLS.LOGOUT,
        {
          method: 'POST',
        },
        true // Requires authentication
      );

      return response;
    } finally {
      // Always clear local auth data, even if API call fails
      tokenManager.clearAuth();
    }
  },

  /**
   * Get current user info
   * @returns {Promise} User data
   */
  me: async () => {
    const response = await apiRequest(
      API_URLS.ME,
      {
        method: 'GET',
      },
      true // Requires authentication
    );

    // Update stored user data
    if (response.user) {
      tokenManager.setUserData(response.user);
    }

    return response;
  },

  /**
   * Check if user is authenticated
   * @returns {boolean} True if user has a token
   */
  isAuthenticated: () => {
    return !!tokenManager.getToken();
  },

  /**
   * Change user password
   * @param {object} passwordData - Current and new password
   * @returns {Promise} Success message
   */
  changePassword: async (passwordData) => {
    const response = await apiRequest(
      API_URLS.CHANGE_PASSWORD,
      {
        method: 'POST',
        body: JSON.stringify(passwordData),
      },
      true // Requires authentication
    );

    return response;
  },
};

/**
 * Chat API calls
 */
export const chatAPI = {
  /**
   * Create a new conversation
   * @param {string} title - Optional conversation title
   * @returns {Promise} Created conversation
   */
  createConversation: async (title = null) => {
    const response = await apiRequest(
      API_URLS.CONVERSATIONS,
      {
        method: 'POST',
        body: JSON.stringify({ title }),
      },
      true // Requires authentication
    );
    return response;
  },

  /**
   * List user's conversations
   * @param {number} limit - Max conversations to return
   * @param {number} offset - Number to skip
   * @returns {Promise} List of conversations
   */
  listConversations: async (limit = 50, offset = 0) => {
    const url = `${API_URLS.CONVERSATIONS}?limit=${limit}&offset=${offset}`;
    const response = await apiRequest(url, { method: 'GET' }, true);
    return response;
  },

  /**
   * Get conversation details with all messages
   * @param {number} conversationId - Conversation ID
   * @returns {Promise} Conversation with messages
   */
  getConversation: async (conversationId) => {
    const response = await apiRequest(
      API_URLS.CONVERSATION_DETAIL(conversationId),
      { method: 'GET' },
      true
    );
    return response;
  },

  /**
   * Delete a conversation
   * @param {number} conversationId - Conversation ID
   * @returns {Promise} Success
   */
  deleteConversation: async (conversationId) => {
    const response = await apiRequest(
      API_URLS.CONVERSATION_DETAIL(conversationId),
      { method: 'DELETE' },
      true
    );
    return response;
  },

  /**
   * Send a message in a conversation
   * @param {number} conversationId - Conversation ID
   * @param {string} content - Message content
   * @returns {Promise} Message ID and conversation ID
   */
  sendMessage: async (conversationId, content) => {
    const response = await apiRequest(
      API_URLS.MESSAGES(conversationId),
      {
        method: 'POST',
        body: JSON.stringify({ content }),
      },
      true
    );
    return response;
  },

  /**
   * Stop ongoing message generation
   * @param {number} conversationId - Conversation ID
   * @returns {Promise} Stop status
   */
  stopGeneration: async (conversationId) => {
    const response = await apiRequest(
      API_URLS.STOP(conversationId),
      { method: 'POST' },
      true
    );
    return response;
  },

  /**
   * Add or update message feedback
   * @param {number} messageId - Message ID
   * @param {string} feedbackType - 'like' or 'dislike'
   * @param {string} reason - Optional reason
   * @returns {Promise} Feedback data
   */
  addFeedback: async (messageId, feedbackType, reason = null) => {
    const response = await apiRequest(
      API_URLS.FEEDBACK(messageId),
      {
        method: 'POST',
        body: JSON.stringify({ feedback_type: feedbackType, reason }),
      },
      true
    );
    return response;
  },

  /**
   * Delete message feedback
   * @param {number} messageId - Message ID
   * @returns {Promise} Success
   */
  deleteFeedback: async (messageId) => {
    const response = await apiRequest(
      API_URLS.FEEDBACK(messageId),
      { method: 'DELETE' },
      true
    );
    return response;
  },

  /**
   * Connect to SSE stream for conversation
   * @param {number} conversationId - Conversation ID
   * @param {string} token - JWT token
   * @param {object} callbacks - Event callbacks
   * @returns {EventSource} EventSource instance
   */
  connectToStream: (conversationId, token, callbacks) => {
    const url = `${API_URLS.STREAM(conversationId)}?token=${encodeURIComponent(token)}`;
    const eventSource = new EventSource(url);

    // Handle different event types
    eventSource.addEventListener('content', (e) => {
      try {
        const data = JSON.parse(e.data);
        callbacks.onContent?.(data);
      } catch (error) {
        console.error('Error parsing content event:', error);
      }
    });

    eventSource.addEventListener('status', (e) => {
      try {
        const data = JSON.parse(e.data);
        callbacks.onStatus?.(data);
      } catch (error) {
        console.error('Error parsing status event:', error);
      }
    });

    eventSource.addEventListener('message_complete', (e) => {
      try {
        const data = JSON.parse(e.data);
        callbacks.onComplete?.(data);
      } catch (error) {
        console.error('Error parsing complete event:', error);
      }
    });

    eventSource.addEventListener('tool_confirmation', (e) => {
      try {
        const data = JSON.parse(e.data);
        callbacks.onToolConfirmation?.(data);
      } catch (error) {
        console.error('Error parsing tool confirmation event:', error);
      }
    });

    eventSource.addEventListener('action_complete', (e) => {
      try {
        const data = JSON.parse(e.data);
        callbacks.onActionComplete?.(data);
      } catch (error) {
        console.error('Error parsing action complete event:', error);
      }
    });

    eventSource.addEventListener('error', (e) => {
      try {
        const data = e.data ? JSON.parse(e.data) : { message: 'Connection error' };
        callbacks.onError?.(data);
      } catch (error) {
        callbacks.onError?.({ message: 'Connection error' });
      }
    });

    eventSource.onerror = (error) => {
      console.error('SSE connection error:', error);
      callbacks.onError?.({ message: 'No active session' });
    };

    return eventSource;
  },
};

/**
 * Admin API calls
 */
export const adminAPI = {
  /**
   * List all users (admin only)
   * @param {number} limit - Max users to return
   * @param {number} offset - Number to skip
   * @returns {Promise} List of users
   */
  listUsers: async (limit = 50, offset = 0) => {
    const url = `${API_URLS.ADMIN_USERS}?limit=${limit}&offset=${offset}`;
    const response = await apiRequest(url, { method: 'GET' }, true);
    return response;
  },

  /**
   * Update user account status (admin only)
   * @param {number} userId - User ID
   * @param {string} status - "active" or "pending"
   * @returns {Promise} Updated user
   */
  updateUserStatus: async (userId, status) => {
    const response = await apiRequest(
      API_URLS.ADMIN_USER_STATUS(userId),
      {
        method: 'PATCH',
        body: JSON.stringify({ account_status: status }),
      },
      true
    );
    return response;
  },

  /**
   * Update user role (admin only)
   * @param {number} userId - User ID
   * @param {string} role - "admin" or "user"
   * @returns {Promise} Updated user
   */
  updateUserRole: async (userId, role) => {
    const response = await apiRequest(
      API_URLS.ADMIN_USER_ROLE(userId),
      {
        method: 'PATCH',
        body: JSON.stringify({ role }),
      },
      true
    );
    return response;
  },
};

/**
 * MCP API calls
 */
export const mcpAPI = {
  /**
   * List all MCP servers (system + user)
   * @returns {Promise} List of MCP servers
   */
  listServers: async () => {
    const response = await apiRequest(
      API_URLS.MCP_SERVERS,
      { method: 'GET' },
      true
    );
    return response;
  },

  /**
   * Create a new user MCP server
   * @param {object} serverData - Server configuration
   * @returns {Promise} Created server
   */
  createServer: async (serverData) => {
    const response = await apiRequest(
      API_URLS.MCP_SERVERS,
      {
        method: 'POST',
        body: JSON.stringify(serverData),
      },
      true
    );
    return response;
  },

  /**
   * Update a user MCP server
   * @param {number} serverId - Server ID
   * @param {object} serverData - Updated server configuration
   * @returns {Promise} Updated server
   */
  updateServer: async (serverId, serverData) => {
    const response = await apiRequest(
      API_URLS.MCP_SERVER_DETAIL(serverId),
      {
        method: 'PUT',
        body: JSON.stringify(serverData),
      },
      true
    );
    return response;
  },

  /**
   * Delete a user MCP server
   * @param {number} serverId - Server ID
   * @returns {Promise} Success
   */
  deleteServer: async (serverId) => {
    const response = await apiRequest(
      API_URLS.MCP_SERVER_DETAIL(serverId),
      { method: 'DELETE' },
      true
    );
    return response;
  },

  /**
   * Get MCP servers for a conversation with toggle state
   * @param {number} conversationId - Conversation ID
   * @returns {Promise} List of servers with is_enabled state
   */
  getConversationServers: async (conversationId) => {
    const response = await apiRequest(
      API_URLS.MCP_CONVERSATION_SERVERS(conversationId),
      { method: 'GET' },
      true
    );
    return response;
  },

  /**
   * Toggle MCP server on/off for a conversation
   * @param {number} conversationId - Conversation ID
   * @param {string} serverName - Name of the server
   * @param {boolean} isEnabled - Enable or disable
   * @returns {Promise} Toggle status
   */
  toggleServer: async (conversationId, serverName, isEnabled) => {
    const response = await apiRequest(
      API_URLS.MCP_TOGGLE_SERVER(conversationId),
      {
        method: 'POST',
        body: JSON.stringify({
          server_name: serverName,
          is_enabled: isEnabled,
        }),
      },
      true
    );
    return response;
  },
};

export default apiRequest;

