/**
 * Authentication Context
 * Manages user authentication state across the application
 */

import { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI, tokenManager, setUnauthorizedCallback } from '@/services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  // Handle 401 unauthorized errors globally
  useEffect(() => {
    const handleUnauthorized = () => {
      console.log('Session expired or unauthorized. Redirecting to login...');
      setUser(null);
      setIsAuthenticated(false);
      navigate('/login', { replace: true });
    };

    // Register the unauthorized callback with the API service
    setUnauthorizedCallback(handleUnauthorized);

    return () => {
      // Cleanup on unmount
      setUnauthorizedCallback(null);
    };
  }, [navigate]);

  // Check if user is already authenticated on mount
  useEffect(() => {
    const checkAuth = () => {
      const token = tokenManager.getToken();
      const userData = tokenManager.getUserData();
      
      if (token && userData) {
        setUser(userData);
        setIsAuthenticated(true);
      }
      
      setIsLoading(false);
    };

    checkAuth();
  }, []);

  const login = (userData, token) => {
    setUser(userData);
    setIsAuthenticated(true);
    tokenManager.setToken(token);
    tokenManager.setUserData(userData);
  };

  const logout = async () => {
    try {
      // Call backend logout endpoint
      await authAPI.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Always clear local state
      setUser(null);
      setIsAuthenticated(false);
      tokenManager.clearAuth();
    }
  };

  const updateUser = (updatedUserData) => {
    setUser(updatedUserData);
    tokenManager.setUserData(updatedUserData);
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        isAuthenticated, 
        isLoading, 
        login, 
        logout, 
        updateUser 
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

