import { Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';

/**
 * Theme toggle button component
 * Switches between light and dark mode
 */
export function ThemeToggle({ theme, onToggle }) {
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={onToggle}
      aria-label="Toggle theme"
    >
      {theme === 'light' ? (
        <Moon className="h-5 w-5" />
      ) : (
        <Sun className="h-5 w-5" />
      )}
    </Button>
  );
}

