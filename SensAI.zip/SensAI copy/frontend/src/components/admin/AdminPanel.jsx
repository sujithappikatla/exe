/**
 * Admin Panel Component
 * Sheet component for managing users (admin only)
 */

import { useEffect, useState, useMemo } from 'react';
import { Search, RefreshCw, Shield, User as UserIcon, CheckCircle, Clock } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAdmin } from '@/hooks/useAdmin';
import { formatDate } from '@/utils/dateFormatter';

export function AdminPanel({ open, onOpenChange }) {
  const { users, total, isLoading, error, fetchUsers, updateStatus, updateRole } = useAdmin();
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch users when panel opens
  useEffect(() => {
    if (open) {
      fetchUsers();
    }
  }, [open, fetchUsers]);

  // Count active admins
  const activeAdminCount = useMemo(() => {
    return users.filter(u => u.role === 'admin' && u.account_status === 'active').length;
  }, [users]);

  // Filter users based on search query
  const filteredUsers = users.filter(user => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      user.username.toLowerCase().includes(query) ||
      user.email.toLowerCase().includes(query)
    );
  });

  const handleRefresh = () => {
    fetchUsers();
  };

  const handleStatusChange = async (user, newStatus) => {
    // Don't allow deactivating the only admin
    if (activeAdminCount === 1 && user.role === 'admin' && newStatus === 'pending') {
      alert('Cannot deactivate the only admin user');
      return;
    }

    if (window.confirm(`Are you sure you want to ${newStatus === 'active' ? 'activate' : 'deactivate'} this user?`)) {
      try {
        await updateStatus(user.id, newStatus);
      } catch (error) {
        alert('Failed to update user status. Please try again.');
      }
    }
  };

  const handleRoleChange = async (user, newRole) => {
    // Don't allow changing role of the only admin
    if (activeAdminCount === 1 && user.role === 'admin') {
      alert('Cannot change the role of the only admin user');
      return;
    }

    if (window.confirm(`Are you sure you want to change this user's role to ${newRole}?`)) {
      try {
        await updateRole(user.id, newRole);
      } catch (error) {
        alert(error.message || 'Failed to update user role. Please try again.');
      }
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-3xl p-0 flex flex-col">
        <SheetHeader className="px-6 py-4 border-b">
          <SheetTitle>Admin Panel</SheetTitle>
          <SheetDescription>
            Manage users, roles, and account approvals
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          <div className="space-y-4">
            {/* Stats */}
            <div className="grid grid-cols-2 gap-3">
              <Card>
                <CardContent className="p-3">
                  <div className="text-xl font-bold">{total}</div>
                  <div className="text-xs text-muted-foreground">Total Users</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-3">
                  <div className="text-xl font-bold">
                    {users.filter(u => u.account_status === 'pending').length}
                  </div>
                  <div className="text-xs text-muted-foreground">Pending Approval</div>
                </CardContent>
              </Card>
            </div>

            {/* Search and Refresh */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by username or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={isLoading}
                className="px-3"
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>

            {/* Error Message */}
            {error && (
              <div className="rounded-md bg-destructive/10 p-2">
                <p className="text-xs text-destructive">{error}</p>
              </div>
            )}

            {/* User Table */}
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[200px]">User</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead className="w-[100px]">Role</TableHead>
                    <TableHead className="w-[100px]">Status</TableHead>
                    <TableHead className="w-[100px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading && users.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        Loading users...
                      </TableCell>
                    </TableRow>
                  ) : filteredUsers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        {searchQuery ? 'No users found matching your search.' : 'No users yet.'}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredUsers.map((user) => {
                      const isOnlyAdmin = activeAdminCount === 1 && user.role === 'admin' && user.account_status === 'active';
                      
                      return (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">
                            <div className="flex flex-col">
                              <span className="text-sm">{user.username}</span>
                              <span className="text-xs text-muted-foreground">{formatDate(user.created_at)}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">{user.email}</TableCell>
                          <TableCell>
                            <Badge variant={user.role === 'admin' ? 'default' : 'secondary'} className="text-xs">
                              {user.role === 'admin' ? (
                                <>
                                  <Shield className="mr-1 h-3 w-3" />
                                  Admin
                                </>
                              ) : (
                                <>
                                  <UserIcon className="mr-1 h-3 w-3" />
                                  User
                                </>
                              )}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={user.account_status === 'active' ? 'outline' : 'destructive'} className="text-xs">
                              {user.account_status === 'active' ? (
                                <>
                                  <CheckCircle className="mr-1 h-3 w-3" />
                                  Active
                                </>
                              ) : (
                                <>
                                  <Clock className="mr-1 h-3 w-3" />
                                  Pending
                                </>
                              )}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              {/* Status Toggle */}
                              {user.account_status === 'pending' ? (
                                <Button
                                  size="sm"
                                  variant="default"
                                  onClick={() => handleStatusChange(user, 'active')}
                                  className="h-7 text-xs px-2"
                                >
                                  Approve
                                </Button>
                              ) : (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleStatusChange(user, 'pending')}
                                  disabled={isOnlyAdmin}
                                  className="h-7 text-xs px-2"
                                >
                                  Deactivate
                                </Button>
                              )}

                              {/* Role Dropdown */}
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button 
                                    size="sm" 
                                    variant="ghost" 
                                    disabled={isOnlyAdmin}
                                    className="h-7 text-xs px-2"
                                  >
                                    Role
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem
                                    onClick={() => handleRoleChange(user, 'user')}
                                    disabled={user.role === 'user'}
                                  >
                                    <UserIcon className="mr-2 h-4 w-4" />
                                    Set as User
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => handleRoleChange(user, 'admin')}
                                    disabled={user.role === 'admin'}
                                  >
                                    <Shield className="mr-2 h-4 w-4" />
                                    Set as Admin
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

