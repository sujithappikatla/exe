/**
 * User List Item Component
 * Individual user card for admin panel
 */

import { useState } from 'react';
import { Shield, User, Mail, Calendar, CheckCircle, Clock } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { formatDate } from '@/utils/dateFormatter';

export function UserListItem({ user, onStatusChange, onRoleChange }) {
  const [isUpdating, setIsUpdating] = useState(false);

  const handleStatusChange = async (newStatus) => {
    if (window.confirm(`Are you sure you want to ${newStatus === 'active' ? 'activate' : 'deactivate'} this user?`)) {
      setIsUpdating(true);
      try {
        await onStatusChange(user.id, newStatus);
      } catch (error) {
        alert('Failed to update user status. Please try again.');
      } finally {
        setIsUpdating(false);
      }
    }
  };

  const handleRoleChange = async (newRole) => {
    if (window.confirm(`Are you sure you want to change this user's role to ${newRole}?`)) {
      setIsUpdating(true);
      try {
        await onRoleChange(user.id, newRole);
      } catch (error) {
        alert(error.message || 'Failed to update user role. Please try again.');
      } finally {
        setIsUpdating(false);
      }
    }
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          {/* User Info */}
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-2">
              <h4 className="font-semibold">{user.username}</h4>
              <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                {user.role === 'admin' ? (
                  <>
                    <Shield className="mr-1 h-3 w-3" />
                    Admin
                  </>
                ) : (
                  <>
                    <User className="mr-1 h-3 w-3" />
                    User
                  </>
                )}
              </Badge>
              <Badge variant={user.account_status === 'active' ? 'outline' : 'destructive'}>
                {user.account_status === 'active' ? (
                  <>
                    <CheckCircle className="mr-1 h-3 w-3" />
                    Active
                  </>
                ) : (
                  <>
                    <Clock className="mr-1 h-3 w-3" />
                    Pending
                  </>
                )}
              </Badge>
            </div>
            
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Mail className="h-3 w-3" />
              <span>{user.email}</span>
            </div>
            
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              <span>Joined {formatDate(user.created_at)}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            {/* Status Toggle */}
            {user.account_status === 'pending' ? (
              <Button
                size="sm"
                onClick={() => handleStatusChange('active')}
                disabled={isUpdating}
              >
                Approve
              </Button>
            ) : (
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleStatusChange('pending')}
                disabled={isUpdating}
              >
                Deactivate
              </Button>
            )}

            {/* Role Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline" disabled={isUpdating}>
                  Change Role
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  onClick={() => handleRoleChange('user')}
                  disabled={user.role === 'user'}
                >
                  <User className="mr-2 h-4 w-4" />
                  Set as User
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => handleRoleChange('admin')}
                  disabled={user.role === 'admin'}
                >
                  <Shield className="mr-2 h-4 w-4" />
                  Set as Admin
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

