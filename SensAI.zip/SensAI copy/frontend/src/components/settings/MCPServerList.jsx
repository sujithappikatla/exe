/**
 * MCPServerList Component
 * List container for all MCP servers with add/edit/delete functionality
 */

import { useState } from 'react';
import { Plus, Server } from 'lucide-react';
import { useMCPServers } from '@/hooks/useMCPServers';
import { MCPServerCard } from './MCPServerCard';
import { MCPServerDialog } from './MCPServerDialog';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';

export function MCPServerList() {
  const { servers, loading, error, createServer, updateServer, deleteServer } = useMCPServers();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingServer, setEditingServer] = useState(null);

  const handleAdd = () => {
    setEditingServer(null);
    setDialogOpen(true);
  };

  const handleEdit = (server) => {
    setEditingServer(server);
    setDialogOpen(true);
  };

  const handleSave = async (serverData) => {
    if (editingServer) {
      // Update existing server
      await updateServer(editingServer.id, serverData);
    } else {
      // Create new server
      await createServer(serverData);
    }
  };

  const handleDelete = async (serverId) => {
    await deleteServer(serverId);
  };

  // Separate system and user servers
  const systemServers = servers.filter((s) => s.is_system);
  const userServers = servers.filter((s) => !s.is_system);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Add Button */}
      <div className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">
          {servers.length === 0 ? 'No servers configured' : `${servers.length} server${servers.length !== 1 ? 's' : ''} configured`}
        </p>
        <Button onClick={handleAdd} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Server
        </Button>
      </div>

      {servers.length === 0 ? (
        /* Empty State */
        <div className="flex flex-col items-center justify-center py-12 border-2 border-dashed rounded-lg">
          <Server className="h-12 w-12 text-muted-foreground mb-3" />
          <h3 className="font-semibold text-lg mb-1">No MCP Servers</h3>
          <p className="text-sm text-muted-foreground mb-4 text-center max-w-md">
            Add MCP servers to enable tool integration for your conversations
          </p>
          <Button onClick={handleAdd}>
            <Plus className="h-4 w-4 mr-2" />
            Add Your First Server
          </Button>
        </div>
      ) : (
        /* Server Lists */
        <div className="space-y-6">
          {/* System Servers */}
          {systemServers.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-muted-foreground">
                System Servers ({systemServers.length})
              </h3>
              <div className="grid gap-4 md:grid-cols-2">
                {systemServers.map((server) => (
                  <MCPServerCard
                    key={server.id}
                    server={server}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            </div>
          )}

          {/* User Servers */}
          {userServers.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-muted-foreground">
                Custom Servers ({userServers.length})
              </h3>
              <div className="grid gap-4 md:grid-cols-2">
                {userServers.map((server) => (
                  <MCPServerCard
                    key={server.id}
                    server={server}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <MCPServerDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        server={editingServer}
        onSave={handleSave}
      />
    </div>
  );
}

