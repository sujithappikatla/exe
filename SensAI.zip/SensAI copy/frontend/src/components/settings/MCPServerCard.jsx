/**
 * MCPServerCard Component
 * Card displaying a single MCP server with details and actions
 */

import { useState } from 'react';
import { Edit, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';

export function MCPServerCard({ server, onEdit, onDelete }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [error, setError] = useState(null);

  const handleDelete = async () => {
    if (!window.confirm(`Are you sure you want to delete "${server.name}"?`)) {
      return;
    }

    setIsDeleting(true);
    setError(null);
    try {
      await onDelete(server.id);
    } catch (err) {
      setError(err.message || 'Failed to delete server');
      setIsDeleting(false);
    }
  };

  const canEdit = !server.is_system && server.id > 0;
  const canDelete = !server.is_system && server.id > 0;

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-base flex items-center gap-2 flex-wrap">
              <span className="truncate">{server.name}</span>
              <Badge variant={server.is_system ? 'secondary' : 'outline'} className="text-xs">
                {server.is_system ? 'System' : 'Custom'}
              </Badge>
              {server.is_active && (
                <Badge variant="default" className="text-xs">
                  Active
                </Badge>
              )}
            </CardTitle>
          </div>
          {canEdit && (
            <div className="flex gap-1 ml-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => onEdit(server)}
                title="Edit server"
              >
                <Edit className="h-4 w-4" />
              </Button>
              {canDelete && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive hover:text-destructive"
                  onClick={handleDelete}
                  disabled={isDeleting}
                  title="Delete server"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-3">
        {/* Basic Info */}
        <div className="space-y-2 text-sm">
          <div>
            <span className="text-muted-foreground">Transport:</span>{' '}
            <span className="font-medium">{server.transport}</span>
          </div>
          
          {server.transport === 'streamable_http' && server.url && (
            <div>
              <span className="text-muted-foreground">URL:</span>{' '}
              <span className="font-mono text-xs">{server.url}</span>
            </div>
          )}
          
          {server.transport === 'stdio' && server.command && (
            <div>
              <span className="text-muted-foreground">Command:</span>{' '}
              <span className="font-mono text-xs">{server.command}</span>
            </div>
          )}
        </div>

        {/* Expandable Details */}
        {((server.args && server.args.length > 0) || server.headers) && (
          <>
            <Button
              variant="ghost"
              size="sm"
              className="w-full justify-between text-xs"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              <span>{isExpanded ? 'Hide' : 'Show'} Details</span>
              {isExpanded ? (
                <ChevronUp className="h-3 w-3" />
              ) : (
                <ChevronDown className="h-3 w-3" />
              )}
            </Button>

            {isExpanded && (
              <div className="space-y-2 text-sm pt-2 border-t">
                {server.args && server.args.length > 0 && (
                  <div>
                    <span className="text-muted-foreground text-xs">Arguments:</span>
                    <pre className="mt-1 p-2 bg-muted rounded text-xs overflow-x-auto">
                      {JSON.stringify(server.args, null, 2)}
                    </pre>
                  </div>
                )}
                {server.headers && Object.keys(server.headers).length > 0 && (
                  <div>
                    <span className="text-muted-foreground text-xs">Headers:</span>
                    <pre className="mt-1 p-2 bg-muted rounded text-xs overflow-x-auto">
                      {JSON.stringify(server.headers, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* Error Display */}
        {error && (
          <Alert variant="destructive" className="mt-3">
            <AlertDescription className="text-xs">{error}</AlertDescription>
          </Alert>
        )}

        {/* System Server Notice */}
        {server.is_system && (
          <p className="text-xs text-muted-foreground pt-2 border-t">
            System servers are configured in backend settings and cannot be modified here.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

