/**
 * MCPServerDialog Component
 * Dialog for adding or editing MCP servers
 */

import { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';

export function MCPServerDialog({ open, onOpenChange, server, onSave }) {
  const isEdit = !!server;
  
  const [formData, setFormData] = useState({
    name: '',
    transport: 'stdio',
    url: '',
    command: '',
    args: '',
    headers: '',
    is_active: true,
  });
  
  const [errors, setErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);

  // Initialize form with server data when editing
  useEffect(() => {
    if (server) {
      setFormData({
        name: server.name || '',
        transport: server.transport || 'stdio',
        url: server.url || '',
        command: server.command || '',
        args: server.args ? JSON.stringify(server.args, null, 2) : '',
        headers: server.headers ? JSON.stringify(server.headers, null, 2) : '',
        is_active: server.is_active !== undefined ? server.is_active : true,
      });
    } else {
      setFormData({
        name: '',
        transport: 'stdio',
        url: '',
        command: '',
        args: '',
        headers: '',
        is_active: true,
      });
    }
    setErrors({});
    setSaveError(null);
  }, [server, open]);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (formData.transport === 'streamable_http') {
      if (!formData.url.trim()) {
        newErrors.url = 'URL is required for HTTP transport';
      }
      // Validate headers JSON if provided
      if (formData.headers.trim()) {
        try {
          JSON.parse(formData.headers);
        } catch (e) {
          newErrors.headers = 'Invalid JSON format';
        }
      }
    } else if (formData.transport === 'stdio') {
      if (!formData.command.trim()) {
        newErrors.command = 'Command is required for stdio transport';
      }
      // Validate args JSON if provided
      if (formData.args.trim()) {
        try {
          const parsed = JSON.parse(formData.args);
          if (!Array.isArray(parsed)) {
            newErrors.args = 'Args must be a JSON array';
          }
        } catch (e) {
          newErrors.args = 'Invalid JSON format';
        }
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    setIsSaving(true);
    setSaveError(null);

    try {
      // Prepare data
      const serverData = {
        name: formData.name.trim(),
        transport: formData.transport,
        is_active: formData.is_active,
      };

      if (formData.transport === 'streamable_http') {
        serverData.url = formData.url.trim();
        serverData.headers = formData.headers.trim()
          ? JSON.parse(formData.headers)
          : {};
      } else if (formData.transport === 'stdio') {
        serverData.command = formData.command.trim();
        serverData.args = formData.args.trim()
          ? JSON.parse(formData.args)
          : [];
      }

      await onSave(serverData);
      onOpenChange(false);
    } catch (err) {
      setSaveError(err.message || 'Failed to save server');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[525px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Edit' : 'Add'} MCP Server</DialogTitle>
          <DialogDescription>
            Configure a Model Context Protocol server for tool integration
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              placeholder="my-server"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className={errors.name ? 'border-destructive' : ''}
            />
            {errors.name && (
              <p className="text-xs text-destructive">{errors.name}</p>
            )}
          </div>

          {/* Transport */}
          <div className="space-y-2">
            <Label htmlFor="transport">Transport *</Label>
            <select
              id="transport"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              value={formData.transport}
              onChange={(e) => handleChange('transport', e.target.value)}
            >
              <option value="stdio">stdio (Local Process)</option>
              <option value="streamable_http">streamable_http (HTTP Server)</option>
            </select>
          </div>

          {/* Transport-specific fields */}
          {formData.transport === 'streamable_http' ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="url">URL *</Label>
                <Input
                  id="url"
                  placeholder="http://localhost:8000/mcp"
                  value={formData.url}
                  onChange={(e) => handleChange('url', e.target.value)}
                  className={errors.url ? 'border-destructive' : ''}
                />
                {errors.url && (
                  <p className="text-xs text-destructive">{errors.url}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="headers">Headers (JSON Object)</Label>
                <textarea
                  id="headers"
                  className={`flex min-h-[80px] w-full rounded-md border ${
                    errors.headers ? 'border-destructive' : 'border-input'
                  } bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 font-mono`}
                  placeholder='{"Authorization": "Bearer token"}'
                  value={formData.headers}
                  onChange={(e) => handleChange('headers', e.target.value)}
                />
                {errors.headers && (
                  <p className="text-xs text-destructive">{errors.headers}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  Optional. Must be valid JSON object format.
                </p>
              </div>
            </>
          ) : (
            <>
              <div className="space-y-2">
                <Label htmlFor="command">Command *</Label>
                <Input
                  id="command"
                  placeholder="python"
                  value={formData.command}
                  onChange={(e) => handleChange('command', e.target.value)}
                  className={errors.command ? 'border-destructive' : ''}
                />
                {errors.command && (
                  <p className="text-xs text-destructive">{errors.command}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="args">Arguments (JSON Array)</Label>
                <textarea
                  id="args"
                  className={`flex min-h-[80px] w-full rounded-md border ${
                    errors.args ? 'border-destructive' : 'border-input'
                  } bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 font-mono`}
                  placeholder='["/path/to/server.py"]'
                  value={formData.args}
                  onChange={(e) => handleChange('args', e.target.value)}
                />
                {errors.args && (
                  <p className="text-xs text-destructive">{errors.args}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  Optional. Must be valid JSON array format.
                </p>
              </div>
            </>
          )}

          {/* Active Toggle */}
          <div className="flex items-center space-x-2">
            <Switch
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => handleChange('is_active', checked)}
            />
            <Label htmlFor="is_active" className="cursor-pointer">
              Active
            </Label>
          </div>

          {/* Save Error */}
          {saveError && (
            <Alert variant="destructive">
              <AlertDescription>{saveError}</AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSaving}
          >
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEdit ? 'Update' : 'Create'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

