/**
 * App Sidebar Component
 * Main application sidebar using Shadcn Sidebar
 */

import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { MessageSquarePlus, MessageSquare, Settings, LogOut, User, ChevronUp, Trash2, ShieldAlert } from 'lucide-react';
import { useConversations } from '@/hooks/useConversations';
import { generateConversationTitle } from '@/utils/dateFormatter';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuAction,
  useSidebar,
} from '@/components/ui/sidebar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { AdminPanel } from '@/components/admin/AdminPanel';

export function AppSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { conversationId } = useParams();
  const { user, logout } = useAuth();
  const { conversations, deleteConversation, loadConversations } = useConversations();
  const { state } = useSidebar();
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);

  // Refresh conversation list when URL changes (new conversation created)
  useEffect(() => {
    // Refresh whenever we're on a chat route
    if (location.pathname.startsWith('/chat')) {
      loadConversations();
    }
  }, [location.pathname, loadConversations]);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const handleNewChat = () => {
    // Just navigate to /chat without conversationId
    // Conversation will be created when user sends first message
    navigate('/chat');
  };

  const handleDeleteConversation = async (e, convId) => {
    e.stopPropagation(); // Prevent navigation when clicking delete
    
    if (confirm('Are you sure you want to delete this conversation?')) {
      try {
        await deleteConversation(convId);
        
        // If we're currently viewing the deleted conversation, redirect to /chat
        if (conversationId === convId.toString()) {
          navigate('/chat');
        }
      } catch (error) {
        console.error('Failed to delete conversation:', error);
        alert('Failed to delete conversation. Please try again.');
      }
    }
  };

  return (
    <Sidebar collapsible="icon">
      {/* Header */}
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild>
              <div className="flex items-center gap-2">
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <span className="text-xl font-bold">S</span>
                </div>
                <div className="flex flex-col gap-0.5 leading-none">
                  <span className="font-semibold">SensAI</span>
                  <span className="text-xs text-muted-foreground">AI Assistant</span>
                </div>
              </div>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      {/* Main Content */}
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {/* New Chat Button */}
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={handleNewChat}
                  className="cursor-pointer"
                  tooltip={state === "collapsed" ? "New Chat" : undefined}
                >
                  <MessageSquarePlus className="h-4 w-4" />
                  <span>New Chat</span>
                </SidebarMenuButton>
              </SidebarMenuItem>

              {/* Conversation List - Hidden when collapsed */}
              {state === "expanded" && conversations.length > 0 && (
                <div className="mt-4 space-y-1">
                  {conversations.map((conv) => (
                    <SidebarMenuItem key={conv.id}>
                      <SidebarMenuButton
                        onClick={() => navigate(`/chat/${conv.id}`)}
                        isActive={conversationId === conv.id.toString()}
                        className="w-full cursor-pointer"
                      >
                        <MessageSquare className="h-4 w-4 flex-shrink-0" />
                        <span className="truncate">{conv.title || 'New Chat'}</span>
                      </SidebarMenuButton>
                      <SidebarMenuAction 
                        onClick={(e) => handleDeleteConversation(e, conv.id)}
                        showOnHover
                        className="cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete conversation</span>
                      </SidebarMenuAction>
                    </SidebarMenuItem>
                  ))}
                </div>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* Footer with User Menu */}
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton
                  size="lg"
                  className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                >
                  <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                    <User className="h-4 w-4" />
                  </div>
                  <div className="grid flex-1 text-left text-sm leading-tight">
                    <span className="truncate font-semibold">{user?.username}</span>
                    <span className="truncate text-xs text-muted-foreground">{user?.email}</span>
                  </div>
                  <ChevronUp className="ml-auto size-4" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
                side="top"
                align="end"
                sideOffset={4}
              >
                {user?.role === 'admin' && (
                  <DropdownMenuItem onClick={() => setIsAdminPanelOpen(true)} className="cursor-pointer">
                    <ShieldAlert className="mr-2 h-4 w-4" />
                    <span>Admin Panel</span>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => navigate('/settings')} className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout} className="text-destructive cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      
      {/* Admin Panel Sheet */}
      <AdminPanel open={isAdminPanelOpen} onOpenChange={setIsAdminPanelOpen} />
    </Sidebar>
  );
}

