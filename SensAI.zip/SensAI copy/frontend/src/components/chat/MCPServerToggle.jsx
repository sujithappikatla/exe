/**
 * MCPServerToggle Component
 * Sheet/popover for toggling MCP servers on/off for a conversation
 */

import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Loader2, Server } from 'lucide-react';
import { useMCPConversationServers } from '@/hooks/useMCPConversationServers';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';

export function MCPServerToggle({ children, open, onOpenChange }) {
  const { conversationId } = useParams();
  const { servers, loading, error, toggleServer } = useMCPConversationServers(conversationId);

  const handleToggle = async (serverName, currentState) => {
    try {
      await toggleServer(serverName, !currentState);
    } catch (err) {
      console.error('Failed to toggle server:', err);
    }
  };

  const systemServers = servers.filter((s) => s.is_system);
  const userServers = servers.filter((s) => !s.is_system);
  const disabledCount = servers.filter((s) => !s.is_enabled).length;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetTrigger asChild>
        {children}
      </SheetTrigger>
      <SheetContent 
        side="bottom" 
        className="sm:max-w-2xl sm:mx-auto max-h-[85vh] overflow-hidden flex flex-col rounded-t-3xl border-t-2"
      >
        <SheetHeader className="px-6 pt-6 pb-4 border-b flex-shrink-0">
          <SheetTitle className="text-2xl font-semibold">MCP Servers</SheetTitle>
          <SheetDescription className="text-base">
            {conversationId 
              ? 'Enable or disable tools for this conversation'
              : 'Available MCP servers - start a conversation to configure'
            }
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          {!conversationId && servers.length > 0 && (
            <Alert className="mb-6 rounded-xl border-2 bg-blue-50/50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
              <AlertDescription className="text-sm text-blue-900 dark:text-blue-100">
                💡 Server toggles will be available once you start a conversation
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-6">
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-muted/30 rounded-xl">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-6 w-12 rounded-full" />
                </div>
              ))}
            </div>
          ) : error ? (
            <Alert variant="destructive" className="rounded-xl">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : servers.length === 0 ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted/50 mb-4">
                <Server className="h-8 w-8 text-muted-foreground" />
              </div>
              <p className="text-base font-medium text-foreground mb-1">
                No MCP servers configured
              </p>
              <p className="text-sm text-muted-foreground">
                Add servers in Settings to enable tools
              </p>
            </div>
          ) : (
            <>
              {/* System Servers */}
              {systemServers.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">
                    System Servers
                  </h3>
                  <div className="space-y-2">
                    {systemServers.map((server) => (
                      <ServerToggleItem
                        key={server.id}
                        server={server}
                        onToggle={handleToggle}
                        disabled={!conversationId}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* User Servers */}
              {userServers.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">
                    Custom Servers
                  </h3>
                  <div className="space-y-2">
                    {userServers.map((server) => (
                      <ServerToggleItem
                        key={server.id}
                        server={server}
                        onToggle={handleToggle}
                        disabled={!conversationId}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Status summary */}
              {conversationId && disabledCount > 0 && (
                <div className="mt-6 pt-4 border-t">
                  <p className="text-xs text-center text-muted-foreground">
                    🔕 {disabledCount} server{disabledCount > 1 ? 's' : ''} disabled for this conversation
                  </p>
                </div>
              )}
            </>
          )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

/**
 * ServerToggleItem Component
 * Individual server item with toggle switch
 */
function ServerToggleItem({ server, onToggle, disabled }) {
  const [isToggling, setIsToggling] = useState(false);

  const handleToggle = async () => {
    if (disabled) return;
    
    setIsToggling(true);
    try {
      await onToggle(server.name, server.is_enabled);
    } finally {
      setIsToggling(false);
    }
  };

  return (
    <div className={`
      flex items-center justify-between p-4 rounded-xl border-2 transition-all
      ${server.is_enabled 
        ? 'bg-primary/5 border-primary/20 hover:bg-primary/10' 
        : 'bg-muted/30 border-border hover:bg-muted/50'
      }
      ${disabled ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}
    `}>
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className={`
          w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0
          ${server.is_enabled 
            ? 'bg-primary/10 text-primary' 
            : 'bg-muted text-muted-foreground'
          }
        `}>
          <Server className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <Label
            htmlFor={`server-${server.id}`}
            className="text-sm font-semibold cursor-pointer truncate block"
          >
            {server.name}
          </Label>
          <div className="flex items-center gap-2 mt-0.5">
            <Badge
              variant={server.is_system ? 'secondary' : 'outline'}
              className="text-xs px-2 py-0.5 rounded-md"
            >
              {server.is_system ? '🔒 System' : '👤 Custom'}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {server.transport}
            </span>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2 ml-3">
        {isToggling ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : (
          <Switch
            id={`server-${server.id}`}
            checked={server.is_enabled}
            onCheckedChange={handleToggle}
            disabled={disabled || !server.is_active}
          />
        )}
      </div>
    </div>
  );
}

