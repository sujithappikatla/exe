/**
 * Markdown Component
 * Renders markdown text with proper formatting using react-markdown
 */

import { memo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export const Markdown = memo(({ content }) => {
  return (
    <div className="prose prose-sm dark:prose-invert max-w-none">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // Code blocks
          pre: ({ node, ...props }) => (
            <pre className="bg-muted p-3 rounded-lg my-2 overflow-x-auto" {...props} />
          ),
          code: ({ node, inline, ...props }) => 
            inline ? (
              <code className="bg-muted px-1.5 py-0.5 rounded text-sm" {...props} />
            ) : (
              <code className="text-sm" {...props} />
            ),
          // Headers
          h1: ({ node, ...props }) => <h1 className="text-2xl font-bold mt-4 mb-2" {...props} />,
          h2: ({ node, ...props }) => <h2 className="text-xl font-bold mt-3 mb-2" {...props} />,
          h3: ({ node, ...props }) => <h3 className="text-lg font-bold mt-2 mb-1" {...props} />,
          h4: ({ node, ...props }) => <h4 className="text-base font-bold mt-2 mb-1" {...props} />,
          // Lists
          ul: ({ node, ...props }) => <ul className="list-disc list-inside my-2 space-y-1" {...props} />,
          ol: ({ node, ...props }) => <ol className="list-decimal list-inside my-2 space-y-1" {...props} />,
          li: ({ node, ...props }) => <li className="ml-2" {...props} />,
          // Paragraphs
          p: ({ node, ...props }) => <p className="my-2" {...props} />,
          // Links
          a: ({ node, ...props }) => (
            <a 
              className="text-primary hover:underline" 
              target="_blank" 
              rel="noopener noreferrer" 
              {...props} 
            />
          ),
          // Blockquotes
          blockquote: ({ node, ...props }) => (
            <blockquote className="border-l-4 border-muted-foreground/30 pl-4 italic my-2" {...props} />
          ),
          // Tables
          table: ({ node, ...props }) => (
            <div className="overflow-x-auto my-2">
              <table className="min-w-full border-collapse border border-muted" {...props} />
            </div>
          ),
          th: ({ node, ...props }) => (
            <th className="border border-muted px-3 py-2 bg-muted font-semibold" {...props} />
          ),
          td: ({ node, ...props }) => (
            <td className="border border-muted px-3 py-2" {...props} />
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
});

Markdown.displayName = 'Markdown';

