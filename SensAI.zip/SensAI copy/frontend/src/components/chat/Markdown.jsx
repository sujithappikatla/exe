/**
 * Markdown Component
 * Renders markdown text with proper formatting
 * For now, uses simple text formatting. To enable full markdown:
 * Run: npm install react-markdown remark-gfm
 */

import { memo } from 'react';

export const Markdown = memo(({ content }) => {
  // Simple markdown-like rendering for common patterns
  const renderContent = () => {
    // Split by code blocks
    const parts = content.split(/(```[\s\S]*?```|`[^`]+`)/g);
    
    return parts.map((part, index) => {
      // Code block
      if (part.startsWith('```') && part.endsWith('```')) {
        const code = part.slice(3, -3).trim();
        return (
          <pre key={index} className="bg-muted p-3 rounded-lg my-2 overflow-x-auto">
            <code className="text-sm">{code}</code>
          </pre>
        );
      }
      
      // Inline code
      if (part.startsWith('`') && part.endsWith('`')) {
        const code = part.slice(1, -1);
        return (
          <code key={index} className="bg-muted px-1.5 py-0.5 rounded text-sm">
            {code}
          </code>
        );
      }
      
      // Regular text with line breaks
      return (
        <span key={index} className="whitespace-pre-wrap break-words">
          {part}
        </span>
      );
    });
  };

  return (
    <div className="prose prose-sm dark:prose-invert max-w-none">
      {renderContent()}
    </div>
  );
});

Markdown.displayName = 'Markdown';

