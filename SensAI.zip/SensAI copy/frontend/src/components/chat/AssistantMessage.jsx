/**
 * AssistantMessage Component
 * Displays assistant message with like/dislike/copy actions
 */

import { useState } from 'react';
import { ThumbsUp, ThumbsDown, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { copyToClipboard } from '@/utils/copyToClipboard';
import { Markdown } from './Markdown';

export function AssistantMessage({ message, onFeedback }) {
  const [copied, setCopied] = useState(false);

  const handleLike = async () => {
    try {
      if (message.feedback?.feedback_type === 'like') {
        // Remove feedback if already liked
        await onFeedback(message.id, null);
      } else {
        await onFeedback(message.id, 'like');
      }
    } catch (err) {
      console.error('Failed to update feedback:', err);
    }
  };

  const handleDislike = async () => {
    try {
      if (message.feedback?.feedback_type === 'dislike') {
        // Remove feedback if already disliked
        await onFeedback(message.id, null);
      } else {
        await onFeedback(message.id, 'dislike');
      }
    } catch (err) {
      console.error('Failed to update feedback:', err);
    }
  };

  const handleCopy = async () => {
    const success = await copyToClipboard(message.content);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex justify-start mb-4">
      <div className="max-w-[70%]">
        <div className="rounded-lg bg-muted px-4 py-3">
          <Markdown content={message.content} />
        </div>

        {/* Action buttons - always visible */}
        <div className="flex items-center gap-1 mt-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLike}
            className={
              message.feedback?.feedback_type === 'like'
                ? 'text-green-600'
                : 'text-muted-foreground hover:text-foreground'
            }
            title="Like this response"
          >
            <ThumbsUp className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDislike}
            className={
              message.feedback?.feedback_type === 'dislike'
                ? 'text-red-600'
                : 'text-muted-foreground hover:text-foreground'
            }
            title="Dislike this response"
          >
            <ThumbsDown className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopy}
            className="text-muted-foreground hover:text-foreground"
            title={copied ? 'Copied!' : 'Copy to clipboard'}
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
}

