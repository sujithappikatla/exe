/**
 * EmptyState Component
 * Initial state when no messages in conversation
 */

import { MessageSquare, Code, Lightbulb, PenTool } from 'lucide-react';
import { Card } from '@/components/ui/card';

export function EmptyState({ onSuggestionClick }) {
  const suggestions = [
    {
      icon: Code,
      text: 'Write code for...',
      prompt: 'Write a Python function to sort a list of dictionaries by a specific key.',
    },
    {
      icon: Lightbulb,
      text: 'Explain a concept',
      prompt: 'Explain how async/await works in JavaScript with examples.',
    },
    {
      icon: PenTool,
      text: 'Help me write',
      prompt: 'Help me write a professional email to request a meeting.',
    },
    {
      icon: MessageSquare,
      text: 'Have a conversation',
      prompt: 'Let\'s have a conversation about artificial intelligence.',
    },
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">How can I help you today?</h2>
        <p className="text-muted-foreground">
          Start a conversation or choose a suggestion below
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl w-full">
        {suggestions.map((suggestion, index) => {
          const Icon = suggestion.icon;
          return (
            <Card
              key={index}
              className="p-4 cursor-pointer hover:bg-accent transition-colors"
              onClick={() => onSuggestionClick?.(suggestion.prompt)}
            >
              <div className="flex items-start gap-3">
                <Icon className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium mb-1">{suggestion.text}</h3>
                  <p className="text-sm text-muted-foreground">
                    {suggestion.prompt}
                  </p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

