/**
 * MessageList Component
 * Scrollable container for messages with auto-scroll indicator
 */

import { ArrowDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { UserMessage } from './UserMessage';
import { AssistantMessage } from './AssistantMessage';
import { Markdown } from './Markdown';

export function MessageList({
  messages,
  streamingContent,
  scrollRef,
  onScroll,
  autoScrollEnabled,
  scrollToBottom,
  onFeedback,
  currentStatus,
}) {
  return (
    <div className="relative h-full flex flex-col">
      <div
        ref={scrollRef}
        onScroll={onScroll}
        className="flex-1 overflow-y-auto px-4 py-6"
      >
        <div className="max-w-4xl mx-auto">
          {messages.map((message) =>
            message.role === 'user' ? (
              <UserMessage key={message.id} message={message} />
            ) : (
              <AssistantMessage
                key={message.id}
                message={message}
                onFeedback={onFeedback}
              />
            )
          )}

          {/* Streaming message */}
          {streamingContent && (
            <div className="flex justify-start mb-4">
              <div className="max-w-[70%]">
                <div className="rounded-lg bg-muted px-4 py-3">
                  <Markdown content={streamingContent} />
                </div>
                {currentStatus && (
                  <p className="text-xs text-muted-foreground mt-2 italic">
                    {currentStatus}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Scroll to bottom button */}
      {!autoScrollEnabled && (
        <div className="absolute bottom-4 right-4">
          <Button
            onClick={() => scrollToBottom('smooth')}
            size="icon"
            variant="secondary"
            className="rounded-full shadow-lg"
            title="Scroll to bottom"
          >
            <ArrowDown className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
}

