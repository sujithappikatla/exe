/**
 * MessageInput Component
 * Input box with send/stop button and MCP server toggle
 */

import { useState, useRef, useEffect } from 'react';
import { Send, Square, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { MCPServerToggle } from './MCPServerToggle';

export function MessageInput({ onSend, onStop, isStreaming, disabled }) {
  const [input, setInput] = useState('');
  const [mcpSheetOpen, setMcpSheetOpen] = useState(false);
  const textareaRef = useRef(null);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isStreaming && input.trim()) {
        onSend(input.trim());
        setInput('');
      }
    }
  };

  const handleSubmit = () => {
    if (!isStreaming && input.trim()) {
      onSend(input.trim());
      setInput('');
    } else if (isStreaming) {
      onStop();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`;
    }
  }, [input]);

  // Focus textarea on mount
  useEffect(() => {
    if (textareaRef.current && !disabled) {
      textareaRef.current.focus();
    }
  }, [disabled]);

  return (
    <div className="bg-gradient-to-t from-background via-background to-background/50 backdrop-blur-md border-t border-border/50 p-4 sm:p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-card/50 backdrop-blur-sm rounded-3xl shadow-lg border-2 border-border/50 transition-all hover:shadow-xl hover:border-border">
          <div className="flex items-center gap-2">
            {/* MCP Server Toggle Button */}
            <MCPServerToggle open={mcpSheetOpen} onOpenChange={setMcpSheetOpen}>
              <Button
                variant="ghost"
                size="icon"
                className="ml-2 h-10 w-10 rounded-xl flex-shrink-0 hover:bg-primary/10 transition-all group"
                disabled={disabled && !isStreaming}
                title="Toggle MCP servers"
              >
                <Plus className="h-5 w-5 group-hover:scale-110 transition-transform" />
              </Button>
            </MCPServerToggle>

            {/* Message Input Container */}
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type your message..."
                className="w-full resize-none rounded-xl bg-transparent px-4 py-3 pr-14 text-sm focus:outline-none transition-all disabled:cursor-not-allowed disabled:opacity-50 min-h-[44px] max-h-[200px] placeholder:text-muted-foreground/50"
                rows={1}
                disabled={disabled && !isStreaming}
              />
              <Button
                onClick={handleSubmit}
                disabled={(disabled || !input.trim()) && !isStreaming}
                size="icon"
                className={`absolute mr-2 right-1 top-1/2 -translate-y-1/2 h-9 w-9 rounded-lg transition-all shadow-md hover:shadow-lg ${
                  isStreaming
                    ? 'bg-destructive hover:bg-destructive/90 text-destructive-foreground'
                    : 'bg-primary hover:bg-primary/90 text-primary-foreground disabled:bg-muted disabled:text-muted-foreground disabled:opacity-50 disabled:shadow-none'
                }`}
                title={isStreaming ? 'Stop generation' : 'Send message'}
              >
                {isStreaming ? (
                  <Square className="h-4 w-4 fill-current" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </div>
        
        {/* Helper text */}
        {/* <p className="text-xs text-center text-muted-foreground/60 mt-3">
          Press <kbd className="px-1.5 py-0.5 bg-muted rounded text-xs font-mono">Enter</kbd> to send, <kbd className="px-1.5 py-0.5 bg-muted rounded text-xs font-mono">Shift + Enter</kbd> for new line
        </p> */}
      </div>
    </div>
  );
}

