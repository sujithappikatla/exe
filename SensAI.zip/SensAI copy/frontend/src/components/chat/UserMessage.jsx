/**
 * UserMessage Component
 * Displays a user message bubble
 */

import { Markdown } from './Markdown';

export function UserMessage({ message }) {
  return (
    <div className="flex justify-end mb-4">
      <div className="max-w-[70%] rounded-lg bg-primary text-primary-foreground px-4 py-3">
        <div className="text-primary-foreground [&_.prose]:text-primary-foreground [&_code]:bg-primary-foreground/20">
          <Markdown content={message.content} />
        </div>
      </div>
    </div>
  );
}

