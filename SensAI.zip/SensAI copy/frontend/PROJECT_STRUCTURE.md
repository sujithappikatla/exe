# Project Structure

This document outlines the organization of the frontend codebase.

## Directory Structure

```
frontend/
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── ui/             # Shadcn UI components (auto-generated)
│   │   │   ├── button.jsx
│   │   │   ├── card.jsx
│   │   │   ├── input.jsx
│   │   │   ├── label.jsx
│   │   │   └── switch.jsx
│   │   └── ThemeToggle.jsx # Theme switcher component
│   │
│   ├── pages/              # Page components
│   │   ├── LoginPage.jsx   # Login page with email/password
│   │   └── SignUpPage.jsx  # Sign up page with full registration form
│   │
│   ├── hooks/              # Custom React hooks
│   │   └── useTheme.js     # Theme management hook
│   │
│   ├── services/           # API and external services
│   │   └── api.js          # All API calls and network operations
│   │
│   ├── lib/                # Utility functions
│   │   └── utils.js        # Helper functions (cn, etc.)
│   │
│   ├── App.jsx             # Main app component with routing
│   ├── main.jsx            # App entry point
│   └── index.css           # Global styles and Tailwind config
│
├── public/                 # Static assets
├── components.json         # Shadcn UI configuration
├── jsconfig.json           # JavaScript config with path aliases
└── vite.config.js          # Vite configuration
```

## Component Organization

### Pages (`src/pages/`)
Full page components that represent different views in the application.

- **LoginPage.jsx**: User authentication page
  - Email and password fields
  - Form validation
  - Error handling
  - Link to sign up page

- **SignUpPage.jsx**: User registration page
  - Email, username, password, and confirm password fields
  - Comprehensive form validation
  - Error handling
  - Link to login page

### Components (`src/components/`)
Reusable UI components used across multiple pages.

- **ThemeToggle.jsx**: Toggle between light and dark themes
  - Fixed position button
  - Uses Moon/Sun icons from Lucide

### UI Components (`src/components/ui/`)
Auto-generated Shadcn UI components. These are customizable and styled with Tailwind.

### Hooks (`src/hooks/`)
Custom React hooks for shared logic.

- **useTheme.js**: Manages theme state
  - Persists theme preference in localStorage
  - Applies theme to document root
  - Provides toggle function

### Services (`src/services/`)
All network operations and API integrations.

- **api.js**: Centralized API service
  - Generic API request handler
  - Authentication endpoints (login, signup, logout)
  - Error handling
  - Ready for backend integration

## Code Organization Principles

1. **Separation of Concerns**: UI, logic, and data are separated
2. **Reusability**: Components are modular and reusable
3. **Maintainability**: Clear file naming and organization
4. **Scalability**: Easy to add new pages, components, and services

## Path Aliases

The project uses `@` as an alias for the `src` directory:

```javascript
import { Button } from '@/components/ui/button'
import { useTheme } from '@/hooks/useTheme'
import { authAPI } from '@/services/api'
```

## Adding New Features

### New Page
1. Create file in `src/pages/`
2. Import and add to routing in `App.jsx`

### New Component
1. Create file in `src/components/`
2. Export component as named or default export
3. Import where needed

### New API Endpoint
1. Add function to appropriate service in `src/services/`
2. Follow the existing pattern for error handling

### New Shadcn Component
```bash
npx shadcn@latest add [component-name]
```

## Environment Variables

Create a `.env` file in the root directory:

```env
VITE_API_BASE_URL=http://localhost:8000
```

Access in code:
```javascript
const apiUrl = import.meta.env.VITE_API_BASE_URL
```

