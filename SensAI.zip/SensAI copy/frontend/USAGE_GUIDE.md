# Usage Guide

## Overview

This application provides a complete authentication UI with Login and Sign Up pages, along with theme switching capabilities.

## Features

### 🌓 Theme Toggle

- **Location**: Top-right corner of the screen (fixed position)
- **Icon**: Moon icon for light mode, Sun icon for dark mode
- **Persistence**: Your theme preference is saved in localStorage
- **Auto-detection**: Defaults to system preference if no saved preference exists

### 🔐 Login Page

The login page includes:

- **Email field**: Must be a valid email format
- **Password field**: Required for authentication
- **Validation**: Real-time error messages for invalid inputs
- **Submit button**: Disabled during loading state
- **Sign up link**: Click to switch to the sign up page

**Current Behavior**: Shows a success alert (backend integration pending)

### ✍️ Sign Up Page

The sign up page includes:

- **Email field**: Must be a valid email format
- **Username field**: 
  - Minimum 3 characters
  - Only letters, numbers, and underscores allowed
- **Password field**: Minimum 8 characters
- **Confirm Password field**: Must match the password
- **Validation**: Comprehensive real-time validation
- **Submit button**: Disabled during loading state
- **Sign in link**: Click to switch to the login page

**Current Behavior**: Shows a success alert (backend integration pending)

## Navigation

- Start on **Login Page** by default
- Click "Sign up" link to go to Sign Up page
- Click "Sign in" link to return to Login page

## Form Validation

### Email Validation
- ❌ Empty email: "Email is required"
- ❌ Invalid format: "Please enter a valid email"
- ✅ Valid: `user@example.com`

### Username Validation (Sign Up)
- ❌ Empty: "Username is required"
- ❌ Too short: "Username must be at least 3 characters"
- ❌ Invalid characters: "Username can only contain letters, numbers, and underscores"
- ✅ Valid: `john_doe123`

### Password Validation
- ❌ Empty: "Password is required"
- ❌ Too short (Sign Up): "Password must be at least 8 characters"
- ✅ Valid: Any password (8+ chars for sign up)

### Confirm Password Validation (Sign Up)
- ❌ Empty: "Please confirm your password"
- ❌ Mismatch: "Passwords do not match"
- ✅ Valid: Matches password field

## Error Handling

- **Field-level errors**: Shown below each input field in red
- **Form-level errors**: Shown in a red banner above the submit button
- **Auto-clear**: Errors clear when you start typing in the field

## Responsive Design

The application is fully responsive:
- **Mobile**: Full-width card with proper spacing
- **Tablet**: Centered card with max-width
- **Desktop**: Centered card with optimal width

## Theme Colors

The application uses semantic color tokens that adapt to the theme:

- `background`: Page background
- `foreground`: Text color
- `card`: Card background
- `muted`: Secondary text
- `destructive`: Error states
- `primary`: Primary buttons and links
- `border`: Input borders

All colors are defined in `src/index.css` and can be customized.

## Keyboard Accessibility

- **Tab**: Navigate between fields
- **Enter**: Submit form
- **Escape**: Clear field (browser default)

## Future Backend Integration

The application is ready for backend integration:

1. API calls are centralized in `src/services/api.js`
2. Environment variables configured for API URL
3. Form data is properly structured for API requests
4. Error handling is in place for API responses

### Next Steps for Integration

1. Set up backend API endpoints for:
   - `POST /api/auth/login`
   - `POST /api/auth/signup`
   - `POST /api/auth/logout`

2. Update the API functions in `src/services/api.js`

3. Add authentication state management (context or state management library)

4. Implement protected routes and session management

5. Add JWT token storage and refresh logic

## Development Tips

### Test Different States

1. **Empty form submission**: Triggers all validation errors
2. **Partial completion**: Shows specific field errors
3. **Theme switching**: Works on both pages
4. **Page switching**: State is reset between pages

### Common Use Cases

**New User Flow**:
1. Land on Login page
2. Click "Sign up"
3. Fill in registration form
4. Submit (shows success alert)
5. (When backend is ready) Auto-login and redirect

**Returning User Flow**:
1. Land on Login page
2. Enter credentials
3. Submit (shows success alert)
4. (When backend is ready) Redirect to dashboard

### Customization

**Change theme colors**: Edit CSS variables in `src/index.css`

**Add new fields**: Update form state and validation in page components

**Add new pages**: Create in `src/pages/` and update routing in `App.jsx`

**Add new API endpoints**: Add to `src/services/api.js`

## Troubleshooting

### Theme not persisting
- Check browser localStorage
- Clear cache and reload

### Form not submitting
- Check browser console for errors
- Ensure all validation passes

### Styles not applying
- Ensure Tailwind classes are correct
- Check if dev server is running
- Hard refresh the page (Cmd/Ctrl + Shift + R)

## Support

For issues or questions, check:
- [React Documentation](https://react.dev)
- [Shadcn UI Components](https://ui.shadcn.com)
- [Tailwind CSS](https://tailwindcss.com)

