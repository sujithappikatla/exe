"""
Database Initialization Script
Run this to create/update database tables for the chat feature
"""

from database import init_db

if __name__ == "__main__":
    print("Initializing database...")
    print("This will create/update all tables including:")
    print("  - users")
    print("  - conversations")
    print("  - messages")
    print("  - agent_actions")
    print("  - message_feedback")
    print()
    
    try:
        init_db()
        print("✅ Database initialized successfully!")
        print()
        print("Next steps:")
        print("1. Make sure your .env file is configured (see ENV_TEMPLATE.txt)")
        print("2. Start the server: python app.py")
        print("3. Check API docs: http://localhost:8080/docs")
    except Exception as e:
        print(f"❌ Error initializing database: {e}")
        import traceback
        traceback.print_exc()

