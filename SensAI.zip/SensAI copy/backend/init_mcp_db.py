"""
Database Migration Script for MCP Tables
Initializes the MCP server tables only (user servers)

Note: Default/system MCP servers are NOT stored in the database.
They are loaded directly from DEFAULT_MCP_SERVERS in settings at runtime.
This migration only creates tables for user-specific MCP servers.
"""

from database import Base, engine
from config.settings import settings


def init_mcp_tables():
    """
    Create MCP-related tables in the database
    """
    print("Creating MCP tables...")
    Base.metadata.create_all(bind=engine)
    print("✓ MCP tables created successfully")


def display_default_servers_info():
    """
    Display information about default MCP servers configured in settings
    """
    default_servers = settings.default_mcp_servers_list
    
    if not default_servers:
        print("\n📋 No default MCP servers configured in settings")
        print("   You can add them in your .env file using DEFAULT_MCP_SERVERS")
        print("   Or add user-specific servers via the API")
    else:
        print(f"\n📋 Found {len(default_servers)} default MCP server(s) in settings:")
        for server_config in default_servers:
            name = server_config.get("name", "unknown")
            transport = server_config.get("transport", "unknown")
            print(f"   • {name} ({transport})")
        print("\n   Note: These servers are loaded from settings (not in database)")
        print("   To modify them, update DEFAULT_MCP_SERVERS in your .env file")


def main():
    """
    Main migration function
    """
    print("=" * 60)
    print("MCP Database Migration")
    print("=" * 60)
    print()
    
    try:
        # Create tables
        init_mcp_tables()
        print()
        
        # Display default servers info (not added to database)
        display_default_servers_info()
        print()
        
        print("=" * 60)
        print("Migration completed successfully!")
        print("=" * 60)
        print()
        print("Next steps:")
        print("  • Default servers: Configure in .env via DEFAULT_MCP_SERVERS")
        print("  • User servers: Add via POST /api/mcp/servers API")
        
    except Exception as e:
        print()
        print("=" * 60)
        print(f"Migration failed: {e}")
        print("=" * 60)
        raise


if __name__ == "__main__":
    main()

