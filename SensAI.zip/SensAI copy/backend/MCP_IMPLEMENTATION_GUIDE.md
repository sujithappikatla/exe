# MCP Client + LangGraph Implementation Guide

## Overview

This implementation adds MCP (Model Context Protocol) client support with LangGraph StateGraph nodes for intelligent tool-calling workflows. The system now supports dynamic tool loading from MCP servers and integrates them seamlessly into the chat agent.

## What Was Implemented

### 1. Dependencies
- Added `langchain-mcp-adapters>=0.1.0` to `requirements.txt`

### 2. Database Schema

Two new models were added:

#### MCPServer Model
Stores MCP server configurations (both system and user-specific):
- `id`, `user_id` (nullable for system servers)
- `name`, `transport` (stdio/streamable_http)
- `url` (for HTTP), `command`, `args` (for stdio)
- `headers` (for HTTP authentication)
- `is_system` (true for default servers), `is_active`

#### ConversationMCPState Model
Tracks runtime toggle state of MCP servers per conversation:
- `conversation_id`, `server_name`, `is_enabled`
- Default: all servers enabled
- Resets on conversation reload

### 3. Configuration (config/settings.py)

Added `DEFAULT_MCP_SERVERS` setting:

```python
# In .env file or environment:
DEFAULT_MCP_SERVERS='[{"name":"calculator","transport":"stdio","command":"python","args":["/path/to/calc_server.py"]},{"name":"weather","transport":"streamable_http","url":"http://localhost:8000/mcp","headers":{}}]'
```

**Transport Types Supported:**

**stdio (local process):**
```json
{
  "name": "calculator",
  "transport": "stdio",
  "command": "python",
  "args": ["/absolute/path/to/server.py"]
}
```

**streamable_http (HTTP server):**
```json
{
  "name": "weather",
  "transport": "streamable_http",
  "url": "http://localhost:8000/mcp",
  "headers": {"Authorization": "Bearer token"}
}
```

### 4. MCP Manager Service (services/mcp_manager.py)

Central service for MCP client lifecycle management:
- `create_client()` - Creates and caches MCP client per conversation
- `load_mcp_config()` - Loads enabled servers for user/conversation
- `build_client_config()` - Converts DB models to client config
- `get_tools()` - Retrieves tools from MCP client
- `cleanup_client()` - Cleans up client resources
- `reload_client()` - Reloads after configuration changes

### 5. LangGraph Agent (agents/chat_agent.py)

Complete refactor from simple streaming to LangGraph StateGraph:

**Architecture:**
```
START → call_model → [tools_condition] → tools → call_model → END
                   ↘ [no tools] → END
```

**Nodes:**
- `call_model`: Invokes LLM with tools bound, streams tokens
- `tools`: ToolNode that executes tool calls

**Features:**
- Streaming via `astream_events()`
- Tool binding when MCP tools available
- Graceful fallback when no tools configured
- Maintains compatibility with Ollama and OpenAI

### 6. API Endpoints (routes/mcp.py)

#### MCP Server Management:
- `GET /api/mcp/servers` - List user's + system servers
- `POST /api/mcp/servers` - Add new user server
- `PUT /api/mcp/servers/{server_id}` - Update user server
- `DELETE /api/mcp/servers/{server_id}` - Delete user server (system protected)

#### Conversation-Specific:
- `GET /api/mcp/conversations/{conversation_id}/servers` - List servers with toggle state
- `POST /api/mcp/conversations/{conversation_id}/servers/toggle` - Toggle server on/off

**Security:**
- System servers cannot be modified or deleted
- Users can only manage their own servers
- Conversation access verified before toggle operations

### 7. Chat Flow Integration (routes/chat.py)

Updated `process_agent_response()`:
1. Creates MCP client for conversation
2. Loads tools from enabled MCP servers
3. Passes tools to LangGraph agent
4. Agent uses tools when needed
5. Streams response with tool calls

**Graceful Handling:**
- Works without tools if no servers configured
- Continues on MCP errors (logs and proceeds)
- Maintains existing SSE streaming

### 8. Migration Script (init_mcp_db.py)

Run to initialize MCP tables and populate default servers:

```bash
cd backend
source .venv/bin/activate
python init_mcp_db.py
```

Creates tables and adds servers from `DEFAULT_MCP_SERVERS` setting.

## How to Use

### 1. Install Dependencies

```bash
cd backend
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Configure Default MCP Servers

In your `.env` file:

```env
# Example: Add a calculator MCP server
DEFAULT_MCP_SERVERS='[{"name":"calculator","transport":"stdio","command":"python","args":["/absolute/path/to/calc_server.py"]}]'
```

Or start with empty array and add via API:

```env
DEFAULT_MCP_SERVERS='[]'
```

### 3. Run Database Migration

```bash
python init_mcp_db.py
```

### 4. Start the Server

```bash
python app.py
```

Or with uvicorn:

```bash
uvicorn app:app --host 0.0.0.0 --port 8080 --reload
```

### 5. Add User MCP Servers via API

```bash
# Add a new MCP server
curl -X POST http://localhost:8080/api/mcp/servers \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-weather-server",
    "transport": "streamable_http",
    "url": "http://localhost:8000/mcp",
    "headers": {},
    "is_active": true
  }'
```

### 6. Toggle Servers for Conversation

```bash
# Disable a server for specific conversation
curl -X POST http://localhost:8080/api/mcp/conversations/1/servers/toggle \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "server_name": "calculator",
    "is_enabled": false
  }'
```

## Tool Calling Flow

1. User sends message to conversation
2. Backend loads enabled MCP servers for that conversation
3. MCP Manager creates client and retrieves tools
4. LangGraph agent receives tools
5. If user query requires tool:
   - Agent calls tool via ToolNode
   - Tool executes and returns result
   - Agent processes result and generates response
6. Response streamed to user via SSE

## Frontend Integration (To Do)

Frontend needs to add:

1. **Settings Page - MCP Servers Section:**
   - List all servers (system + user's)
   - Add new server form (name, transport, url/command/args)
   - Edit/Delete user servers (system servers show as read-only)
   - Active/Inactive toggle

2. **Chat Interface - MCP Toggle (Optional):**
   - Dropdown or sidebar showing available servers
   - Toggle switches to enable/disable per conversation
   - Real-time update (reload client on toggle)

3. **API Calls:**
   ```javascript
   // List servers
   GET /api/mcp/servers
   
   // Add server
   POST /api/mcp/servers
   
   // Get conversation servers with state
   GET /api/mcp/conversations/{id}/servers
   
   // Toggle server
   POST /api/mcp/conversations/{id}/servers/toggle
   ```

## Testing Scenarios

### 1. No MCP Servers
- Agent works normally without tools
- Regular chat conversation

### 2. With MCP Servers (stdio)
- Configure a local MCP server
- Agent can call tools when needed
- Example: Calculator tool for math queries

### 3. With MCP Servers (HTTP)
- Configure remote MCP server
- Agent can call HTTP-based tools
- Example: Weather API tool

### 4. Multiple Servers
- Configure multiple MCP servers
- Agent has access to all enabled tools
- Can use different tools in same conversation

### 5. Toggle On/Off
- Disable specific server for conversation
- Agent loses access to those tools
- Re-enable to restore access

### 6. System vs User Servers
- System servers available to all users
- Users cannot delete system servers
- Users can add/remove their own servers

## Debugging

### Enable Verbose Logging

In your code, add:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Check MCP Client Status

```python
from services.mcp_manager import mcp_manager

# Check cached clients
print(mcp_manager._clients_cache)
```

### Verify Tools Loaded

Check console output for:
```
Loaded X tools from MCP servers
```

### Test MCP Server Directly

Test your MCP server independently before integrating:

```bash
# For stdio servers
python your_server.py

# For HTTP servers
curl http://localhost:8000/mcp
```

## Common Issues

### 1. "No tools loaded"
- Check `DEFAULT_MCP_SERVERS` configuration
- Verify MCP server is running (for HTTP)
- Check file paths (for stdio)
- Run migration script

### 2. "Cannot import langchain_mcp_adapters"
- Install dependencies: `pip install -r requirements.txt`
- Activate virtual environment

### 3. "Server already exists"
- Server name must be unique per user
- Use different name or delete existing

### 4. "Cannot modify system servers"
- System servers are read-only
- Create user server instead

### 5. Tools not working in conversation
- Check server is enabled for conversation
- Verify toggle state: `GET /api/mcp/conversations/{id}/servers`
- Check conversation ownership

## Architecture Benefits

1. **Modular**: MCP logic separated from core chat
2. **Scalable**: Cache clients per conversation
3. **Flexible**: Support multiple transport types
4. **Secure**: User isolation, system server protection
5. **Graceful**: Works with or without tools
6. **Streaming**: Maintains SSE streaming with tools
7. **LangGraph**: Clean node-based architecture for complex workflows

## Next Steps

1. **Frontend Implementation**: Add MCP management UI
2. **Tool Confirmation**: Implement user approval for sensitive tools
3. **Tool Logging**: Track tool usage in AgentAction table
4. **MCP Discovery**: Auto-discover MCP servers
5. **Health Checks**: Verify MCP servers are accessible
6. **Tool Categories**: Group tools by category
7. **Usage Analytics**: Track which tools are most used

## References

- [LangChain MCP Adapters Documentation](https://github.com/langchain-ai/langchain-mcp-adapters)
- [MCP Protocol Specification](https://modelcontextprotocol.io/)
- [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)

