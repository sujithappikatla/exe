# Setup Checklist for Chat Feature

## Pre-Installation

- [ ] Python 3.9+ installed
- [ ] Virtual environment created and activated (`.venv`)
- [ ] LLM endpoint available (OpenAI API or Ollama installed locally)

## Installation Steps

### 1. Install Dependencies

```bash
cd backend
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

**Expected**: All packages install without errors

### 2. Configure Environment

```bash
# Create .env from template
cp ENV_TEMPLATE.txt .env

# Edit .env and set:
# - SECRET_KEY (generate a random string, e.g., openssl rand -hex 32)
# - LLM_API_KEY (your API key or "not-needed" for Ollama)
# - LLM_MODEL (e.g., "gpt-3.5-turbo" or "llama2")
# - LLM_BASE_URL (optional, for Ollama: http://localhost:11434/v1)
```

**Required Variables:**
- [ ] `SECRET_KEY` set
- [ ] `LLM_MODEL` set
- [ ] `LLM_API_KEY` set (or "not-needed")

**Optional Variables:**
- [ ] `LLM_BASE_URL` (if using Ollama or custom endpoint)
- [ ] `DATABASE_URL` (if not using SQLite)
- [ ] `CORS_ORIGINS` (if frontend on different port)

### 3. Initialize Database

```bash
python init_chat_db.py
```

**Expected Output:**
```
Initializing database...
This will create/update all tables including:
  - users
  - conversations
  - messages
  - agent_actions
  - message_feedback

✅ Database initialized successfully!
```

### 4. Verify Setup

```bash
python verify_setup.py
```

**Expected**: All checks pass with ✅

### 5. Start Server

```bash
python app.py
```

**Expected Output:**
```
✅ Database tables created successfully
🚀 SensAI API is ready!
INFO:     Uvicorn running on http://0.0.0.0:8080
```

### 6. Test API

Open browser: `http://localhost:8080/docs`

**Expected**: FastAPI interactive documentation loads

## Verification Tests

### Test 1: Health Check

```bash
curl http://localhost:8080/health
```

**Expected**: `{"status": "healthy"}`

### Test 2: Register User

```bash
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "username": "testuser",
    "password": "Test123!@#"
  }'
```

**Expected**: Returns user object and JWT token

### Test 3: Create Conversation

```bash
export TOKEN="your-jwt-token-from-step-2"

curl -X POST http://localhost:8080/api/chat/conversations \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title": "Test Chat"}'
```

**Expected**: Returns conversation object with id

### Test 4: Send Message

```bash
curl -X POST http://localhost:8080/api/chat/conversations/1/messages \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content": "Hello!"}'
```

**Expected**: Returns message_id and conversation_id

### Test 5: Stream Response

```bash
curl -N "http://localhost:8080/api/chat/conversations/1/stream?token=$TOKEN"
```

**Expected**: SSE events stream (status, content, message_complete)

## Troubleshooting

### Issue: Packages won't install

**Solution:**
```bash
# Update pip
pip install --upgrade pip

# Install one by one to identify problem
pip install fastapi uvicorn sqlalchemy langchain
```

### Issue: "pydantic.errors.PydanticSchemaGenerationError"

**Solution:**
```bash
# Update pydantic
pip install --upgrade pydantic pydantic-settings
```

### Issue: "Could not validate credentials"

**Solution:**
- Check SECRET_KEY is set in .env
- Verify token is not expired (default: 30 minutes)
- Re-login to get fresh token

### Issue: LLM connection fails

**For Ollama:**
```bash
# Check Ollama is running
ollama serve

# Pull model if not exists
ollama pull llama2

# Verify endpoint
curl http://localhost:11434/api/tags
```

**For OpenAI:**
- Verify API key is correct
- Check API key has credits
- Test with: `curl https://api.openai.com/v1/models -H "Authorization: Bearer $API_KEY"`

### Issue: Database errors

**Solution:**
```bash
# Delete old database
rm sensai.db

# Re-initialize
python init_chat_db.py

# Verify tables
sqlite3 sensai.db ".tables"
# Should show: users conversations messages agent_actions message_feedback
```

### Issue: SSE not streaming

**Solution:**
- Make sure to send message FIRST, then open SSE stream
- Check browser console for connection errors
- Verify CORS settings if frontend is on different origin
- Try curl first to test backend only

### Issue: Import errors in verify_setup.py

**Solution:**
```bash
# Make sure you're in backend directory
cd backend

# Activate virtual environment
source .venv/bin/activate

# Re-install requirements
pip install -r requirements.txt
```

## Post-Installation

Once all tests pass:

- [ ] Server starts without errors
- [ ] Health check returns healthy
- [ ] Can register and login users
- [ ] Can create conversations
- [ ] Can send messages
- [ ] SSE streaming works
- [ ] API documentation loads at `/docs`

## Next Steps

1. **Frontend Integration**
   - Use EventSource for SSE connection
   - Implement chat UI components
   - Add message feedback buttons
   - Handle page reload recovery

2. **Customize Agent**
   - Modify `agents/chat_agent.py`
   - Add custom tools
   - Implement RAG retrieval
   - Add web search capability

3. **Production Deployment**
   - Switch to PostgreSQL
   - Set up Redis for sessions
   - Configure proper CORS
   - Enable SSL/TLS
   - Set up monitoring

## Quick Reference

**Documentation Files:**
- `QUICK_START_CHAT.md` - Getting started guide
- `CHAT_FEATURE.md` - Complete API reference
- `IMPLEMENTATION_SUMMARY.md` - Technical details
- `ENV_TEMPLATE.txt` - Environment variables

**Utility Scripts:**
- `init_chat_db.py` - Initialize database tables
- `verify_setup.py` - Verify installation
- `app.py` - Start the server

**Key Directories:**
- `routes/` - API endpoints
- `agents/` - LLM agent implementation
- `services/` - Business logic (session management)
- `utils/` - Helper functions (SSE, auth)
- `database/` - Models and database config
- `schemas/` - Pydantic validation schemas

## Support

If you encounter issues not covered here:
1. Check error messages carefully
2. Review relevant documentation file
3. Verify all checklist items are complete
4. Check logs for detailed error information
5. Test individual components in isolation

## Success Indicators

You're ready to move forward when:
- ✅ `verify_setup.py` passes all checks
- ✅ Server starts and responds to health checks
- ✅ Can complete all 5 verification tests
- ✅ SSE events stream to client
- ✅ No errors in server logs
- ✅ API documentation is accessible

**Congratulations! Your chat feature is ready to use! 🎉**

