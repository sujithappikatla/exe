# Chat Feature Documentation

## Overview

The SensAI backend now includes a comprehensive streaming chat system with support for:
- Real-time SSE (Server-Sent Events) streaming
- LangChain/LangGraph agent integration
- OpenAI-compatible API format (works with OpenAI, Ollama, and other providers)
- Full conversation persistence
- Tool confirmation support
- Message feedback (like/dislike)
- Stop generation mid-stream
- Page reload recovery

## Architecture

### Protocol Design
- **SSE (Server-Sent Events)**: Unidirectional streaming from server to client for LLM responses
- **REST Endpoints**: Handle user actions (send message, stop, confirm tools)
- **JWT Authentication**: Secure all endpoints including SSE streams
- **Stateless Backend**: Full database persistence with message history replay

### Database Schema

**New Tables:**
1. `conversations` - User conversations
2. `messages` - Individual messages (user, assistant, system)
3. `agent_actions` - All agent activities (thinking, tool calls, RAG, web search)
4. `message_feedback` - User feedback on messages (like/dislike)

## API Endpoints

### Conversation Management

#### Create Conversation
```http
POST /api/chat/conversations
Authorization: Bearer {token}
Content-Type: application/json

{
  "title": "Optional conversation title"
}
```

#### List Conversations
```http
GET /api/chat/conversations?limit=50&offset=0
Authorization: Bearer {token}
```

#### Get Conversation Details
```http
GET /api/chat/conversations/{conversation_id}
Authorization: Bearer {token}
```

#### Delete Conversation
```http
DELETE /api/chat/conversations/{conversation_id}
Authorization: Bearer {token}
```

### Messaging

#### Send Message
```http
POST /api/chat/conversations/{conversation_id}/messages
Authorization: Bearer {token}
Content-Type: application/json

{
  "content": "User message here"
}
```

**Response:**
```json
{
  "message_id": 123,
  "conversation_id": 456
}
```

### Streaming

#### SSE Stream Endpoint
```http
GET /api/chat/conversations/{conversation_id}/stream?token={jwt_token}
```

**Event Types:**

1. **Status Update**
```json
event: status
data: {"type": "thinking", "message": "AI is thinking..."}
```

2. **Content Streaming**
```json
event: content
data: {"delta": "token", "message_id": 123}
```

3. **Tool Confirmation Request**
```json
event: tool_confirmation
data: {
  "action_id": 456,
  "tool_name": "execute_code",
  "tool_args": {...},
  "description": "Agent wants to run code"
}
```

4. **Action Complete**
```json
event: action_complete
data: {"action_id": 456, "action_type": "web_search", "result": "..."}
```

5. **Message Complete**
```json
event: message_complete
data: {"message_id": 123}
```

6. **Error**
```json
event: error
data: {"message": "Error description"}
```

### Control

#### Stop Generation
```http
POST /api/chat/conversations/{conversation_id}/stop
Authorization: Bearer {token}
```

#### Confirm Tool Execution
```http
POST /api/chat/actions/{action_id}/confirm
Authorization: Bearer {token}
Content-Type: application/json

{
  "approved": true,
  "user_note": "Optional note"
}
```

### Feedback

#### Add/Update Message Feedback
```http
POST /api/chat/messages/{message_id}/feedback
Authorization: Bearer {token}
Content-Type: application/json

{
  "feedback_type": "like",
  "reason": "Optional reason"
}
```

#### Delete Message Feedback
```http
DELETE /api/chat/messages/{message_id}/feedback
Authorization: Bearer {token}
```

## Configuration

### Environment Variables

Add these to your `.env` file:

```bash
# LLM Configuration

# For OpenAI
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=your-openai-api-key
LLM_MODEL=gpt-3.5-turbo
LLM_TEMPERATURE=0.7

# For Ollama (local)
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=not-needed
LLM_MODEL=llama2
LLM_TEMPERATURE=0.7
```

## Installation

1. **Install dependencies:**
```bash
cd backend
source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
```

2. **Set up environment variables:**
```bash
cp .env.example .env
# Edit .env with your configuration
```

3. **Initialize database:**
```bash
python -c "from database import init_db; init_db()"
```

4. **Run the server:**
```bash
python app.py
# or
uvicorn app:app --reload --host 0.0.0.0 --port 8080
```

## Frontend Integration

### Basic Flow

1. **User sends message:**
```javascript
const response = await fetch('/api/chat/conversations/1/messages', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ content: 'Hello!' })
});
const { message_id } = await response.json();
```

2. **Open SSE connection:**
```javascript
const eventSource = new EventSource(
  `/api/chat/conversations/1/stream?token=${token}`
);

eventSource.addEventListener('content', (e) => {
  const { delta, message_id } = JSON.parse(e.data);
  // Append delta to UI
});

eventSource.addEventListener('status', (e) => {
  const { type, message } = JSON.parse(e.data);
  // Show status in UI (thinking, tool_execution, etc.)
});

eventSource.addEventListener('message_complete', (e) => {
  // Generation finished
  eventSource.close();
});

eventSource.addEventListener('error', (e) => {
  const { message } = JSON.parse(e.data);
  // Handle error
});
```

3. **Stop generation:**
```javascript
await fetch('/api/chat/conversations/1/stop', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}` }
});
```

4. **Page reload recovery:**
```javascript
const response = await fetch('/api/chat/conversations/1', {
  headers: { 'Authorization': `Bearer ${token}` }
});
const conversation = await response.json();
// Render all messages and actions
```

## LLM Provider Setup

### OpenAI
```bash
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=sk-...
LLM_MODEL=gpt-3.5-turbo
```

### Ollama (Local)
1. Install Ollama: https://ollama.ai
2. Pull a model: `ollama pull llama2`
3. Configure:
```bash
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=not-needed
LLM_MODEL=llama2
```

### Other OpenAI-Compatible Providers
Any provider with OpenAI-compatible API (Together AI, Anyscale, etc.) can be used:
```bash
LLM_BASE_URL=https://provider-url/v1
LLM_API_KEY=your-api-key
LLM_MODEL=model-name
```

## Future Enhancements

The system is designed to support:
- **MCP (Model Context Protocol)**: Future integration planned
- **Tool Calling**: Framework ready for custom tools
- **RAG Integration**: Can be added to agent workflow
- **Web Search**: Infrastructure in place
- **Multi-modal Support**: Can be extended for images/audio

## Testing

### Manual Testing

1. **Create conversation:**
```bash
curl -X POST http://localhost:8080/api/chat/conversations \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title": "Test Conversation"}'
```

2. **Send message:**
```bash
curl -X POST http://localhost:8080/api/chat/conversations/1/messages \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content": "Hello, how are you?"}'
```

3. **Watch SSE stream:**
```bash
curl -N http://localhost:8080/api/chat/conversations/1/stream?token=YOUR_TOKEN
```

## Troubleshooting

### Common Issues

1. **"Could not connect to LLM"**
   - Check LLM_BASE_URL is correct
   - Verify Ollama is running if using local model
   - Check API key if using cloud provider

2. **"No active session"**
   - Make sure to send a message before opening SSE stream
   - SSE connection should be opened immediately after sending message

3. **Messages not streaming**
   - Check that LLM supports streaming
   - Verify callback handler is properly configured
   - Check browser console for SSE connection errors

4. **Database errors**
   - Run `init_db()` to create tables
   - Check DATABASE_URL is correct
   - Ensure write permissions for SQLite file

## Performance Considerations

- **Concurrent Sessions**: In-memory session management works for single server
- **Scaling**: For multiple servers, use Redis for session management
- **Database**: SQLite is fine for development; use PostgreSQL for production
- **SSE Connections**: Each active stream holds a connection; monitor server resources

## Security

- All endpoints require JWT authentication
- SSE uses token in query param (EventSource limitation)
- CORS configured for allowed origins
- Database cascades ensure data consistency
- Stop signals prevent runaway generations

