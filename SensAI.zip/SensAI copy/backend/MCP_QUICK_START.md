# MCP Quick Start Guide

Get up and running with MCP (Model Context Protocol) integration in 5 minutes.

## Prerequisites

- Python 3.8+ with virtual environment activated
- Backend dependencies installed
- Database initialized

## Step 1: Install Dependencies

```bash
cd backend
source .venv/bin/activate  # or: .venv\Scripts\activate on Windows
pip install -r requirements.txt
```

## Step 2: Run Database Migration

```bash
python init_mcp_db.py
```

Expected output:
```
============================================================
MCP Database Migration
============================================================

Creating MCP tables...
✓ MCP tables created successfully

No default MCP servers configured in settings

============================================================
Migration completed successfully!
============================================================
```

## Step 3: Test with Example MCP Server (Optional)

### Option A: Use the included example calculator server

1. Get the absolute path to the example server:
```bash
pwd  # Note this path
# Example output: /Users/sujith/Tech/Work/SensAI/backend
```

2. Add to your `.env` file:
```env
DEFAULT_MCP_SERVERS='[{"name":"calculator","transport":"stdio","command":"python","args":["/Users/sujith/Tech/Work/SensAI/backend/example_mcp_server.py"]}]'
```

**Important**: Replace `/Users/sujith/Tech/Work/SensAI/backend` with your actual path!

3. Run migration again to load the default server:
```bash
python init_mcp_db.py
```

Expected output:
```
Found 1 default MCP server(s) in configuration
✓ Added system server: calculator (stdio)

✓ Successfully added 1 default MCP server(s)
```

### Option B: Skip MCP servers for now

Start with no MCP servers and add them later via API or frontend:

```env
DEFAULT_MCP_SERVERS='[]'
```

## Step 4: Start the Server

```bash
python app.py
```

Or:

```bash
uvicorn app:app --host 0.0.0.0 --port 8080 --reload
```

## Step 5: Verify MCP Integration

### Test 1: Check Server Status

```bash
curl http://localhost:8080/health
```

### Test 2: Login and Get Token

```bash
# Register a user
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "username": "testuser",
    "password": "password123"
  }'

# Login to get token
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }'

# Save the token from response
```

### Test 3: List MCP Servers

```bash
curl http://localhost:8080/api/mcp/servers \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

Expected response (if you configured the calculator):
```json
[
  {
    "id": 1,
    "user_id": null,
    "name": "calculator",
    "transport": "stdio",
    "command": "python",
    "args": ["/path/to/example_mcp_server.py"],
    "is_system": true,
    "is_active": true,
    "created_at": "2025-01-01T00:00:00",
    "updated_at": "2025-01-01T00:00:00"
  }
]
```

### Test 4: Create Conversation and Test Calculator

```bash
# Create a conversation
CONV_RESPONSE=$(curl -X POST http://localhost:8080/api/chat/conversations \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test MCP"}')

# Extract conversation_id (you'll need jq or manually parse)
CONV_ID=$(echo $CONV_RESPONSE | jq -r '.id')

# Send a message that requires calculation
curl -X POST http://localhost:8080/api/chat/conversations/$CONV_ID/messages \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{"content":"What is 25 multiplied by 4?"}'
```

Watch the logs - you should see:
```
Loaded 6 tools from MCP servers
```

The agent will use the calculator tool to answer!

## Common Setup Issues

### Issue: "Module 'mcp' not found"

**Solution**: The example server requires the `mcp` package:
```bash
pip install mcp
```

Or use FastMCP:
```bash
pip install fastmcp
```

### Issue: "Import 'langchain_mcp_adapters' could not be resolved"

**Solution**: Install the package:
```bash
pip install langchain-mcp-adapters
```

### Issue: "No tools loaded"

**Possible causes:**
1. MCP server path is incorrect (must be absolute path)
2. MCP server not configured in DEFAULT_MCP_SERVERS
3. Migration not run after adding configuration
4. Python command not in PATH

**Solution**: 
```bash
# Check path
ls /path/to/example_mcp_server.py

# Test server directly
python /path/to/example_mcp_server.py
# Should see: "Starting Calculator MCP Server..."

# Re-run migration
python init_mcp_db.py
```

### Issue: "langchain.chat_models" import error

**Solution**: Update imports - use `langchain_openai`:
```bash
pip install --upgrade langchain-openai
```

## Adding Your Own MCP Server

### Method 1: Via DEFAULT_MCP_SERVERS

1. Create your MCP server (see `example_mcp_server.py`)
2. Get absolute path to your server
3. Add to `.env`:
```env
DEFAULT_MCP_SERVERS='[{"name":"my-server","transport":"stdio","command":"python","args":["/absolute/path/to/server.py"]}]'
```
4. Run migration: `python init_mcp_db.py`

### Method 2: Via API

```bash
curl -X POST http://localhost:8080/api/mcp/servers \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-weather-server",
    "transport": "streamable_http",
    "url": "http://localhost:8000/mcp",
    "is_active": true
  }'
```

## Testing Tool Calls

Try these queries with the calculator server:

1. "What is 15 times 8?"
2. "Calculate the square root of 144"
3. "What is 100 divided by 5?"
4. "Calculate 2 to the power of 10"
5. "Add 123 and 456"

The agent should automatically detect when to use the calculator tools!

## Next Steps

1. **Frontend Integration**: Add MCP management UI in settings
2. **Custom Tools**: Create your own MCP servers with custom tools
3. **Multiple Servers**: Add multiple MCP servers for different capabilities
4. **Toggle Controls**: Implement per-conversation server toggles in UI

## Resources

- Full Implementation Guide: `MCP_IMPLEMENTATION_GUIDE.md`
- Example Server: `example_mcp_server.py`
- LangChain MCP Docs: https://github.com/langchain-ai/langchain-mcp-adapters
- MCP Protocol: https://modelcontextprotocol.io/

## Need Help?

Check the logs:
```bash
# Start server with verbose output
python app.py

# Watch for these log messages:
# - "Loaded X tools from MCP servers"
# - "Starting Calculator MCP Server..."
# - "Creating MCP tables..."
```

Verify database:
```bash
sqlite3 sensai.db
> SELECT * FROM mcp_servers;
> .quit
```

That's it! You now have MCP integration running with tool-calling capabilities. 🚀

