"""
Application Settings
Configuration management using Pydantic Settings
"""

from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List, Dict, Any
import json


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables
    """
    # Database
    DATABASE_URL: str = "sqlite:///./sensai.db"
    
    # JWT
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8080
    RELOAD: bool = True
    
    # CORS
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"
    
    # LLM Configuration
    LLM_BASE_URL: str = "http://localhost:11434/v1"  # Optional: For Ollama or custom endpoints (e.g., http://localhost:11434/v1)
    LLM_API_KEY: str = "not-needed"  # API key for LLM (not needed for Ollama)
    LLM_MODEL: str = "mistral-small:latest"  # Model name
    LLM_TEMPERATURE: float = 0.7  # Temperature for generation
    
    # MCP Configuration
    # Default MCP servers that are available to all users (system servers)
    # These servers cannot be deleted by users but can be toggled on/off per conversation
    # 
    # Example configuration:
    # DEFAULT_MCP_SERVERS='[{"name":"calculator","transport":"stdio","command":"python","args":["/path/to/calc_server.py"]},{"name":"weather","transport":"streamable_http","url":"http://localhost:8000/mcp","headers":{}}]'
    #
    # For stdio transport (local process):
    #   - name: Unique identifier for the server
    #   - transport: "stdio"
    #   - command: Command to run (e.g., "python", "node", "npx")
    #   - args: Array of arguments (e.g., ["/absolute/path/to/server.py"])
    #
    # For streamable_http transport (HTTP server):
    #   - name: Unique identifier for the server
    #   - transport: "streamable_http"
    #   - url: HTTP endpoint URL (e.g., "http://localhost:8000/mcp")
    #   - headers: Optional headers dict for authentication (e.g., {"Authorization": "Bearer token"})
    DEFAULT_MCP_SERVERS: List[Dict[str, Any]] = [
        {
            "name":"calculator",
            "transport":"stdio",
            "command":"/Users/sujith/Tech/Work/SensAI/backend/.venv/bin/python",
            "args":["/Users/sujith/Tech/Work/SensAI/backend/example_mcp_server.py"]
        }
    ]  # JSON array string
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True
    )
    
    @property
    def cors_origins_list(self) -> List[str]:
        """Convert CORS_ORIGINS string to list"""
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",")]
    
    @property
    def default_mcp_servers_list(self) -> List[Dict[str, Any]]:
        """Convert DEFAULT_MCP_SERVERS JSON string to list of dicts"""
        try:
            return self.DEFAULT_MCP_SERVERS
        except (json.JSONDecodeError, TypeError):
            return []


# Create settings instance
settings = Settings()

