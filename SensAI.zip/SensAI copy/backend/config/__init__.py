"""
Configuration package
Contains application settings and configuration
"""

from .settings import settings

__all__ = ["settings"]

