# Backend - FastAPI + SQLAlchemy + JWT Authentication

A modern, well-structured FastAPI backend with JWT authentication and SQLAlchemy ORM.

## Tech Stack

- **FastAPI** - Modern, fast web framework
- **SQLAlchemy** - SQL toolkit and ORM
- **SQLite3** - Database (easily switchable to PostgreSQL/MySQL)
- **Pydantic** - Data validation
- **JWT** - JSON Web Tokens for authentication
- **Bcrypt** - Password hashing
- **Uvicorn** - ASGI server

## Project Structure

```
backend/
├── config/              # Configuration and settings
│   ├── settings.py     # Environment-based configuration
│   └── __init__.py
├── database/           # Database models and configuration
│   ├── models.py      # SQLAlchemy models
│   ├── config.py      # Database connection setup
│   └── __init__.py
├── routes/            # API route handlers
│   ├── auth.py       # Authentication endpoints
│   └── __init__.py
├── schemas/          # Pydantic schemas
│   ├── user.py      # User schemas
│   ├── auth.py      # Auth schemas
│   └── __init__.py
├── utils/           # Utility functions
│   ├── auth.py     # JWT and password utilities
│   └── __init__.py
├── app.py          # Main FastAPI application
├── requirements.txt # Python dependencies
└── .env            # Environment variables
```

## Setup

### 1. Create Virtual Environment

```bash
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Environment Variables

Create a `.env` file (or use `.env.example` as template):

```env
# Database
DATABASE_URL=sqlite:///./sensai.db

# JWT
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Server
HOST=0.0.0.0
PORT=8000
RELOAD=True

# CORS
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
```

### 4. Run the Server

```bash
python app.py
```

Or with uvicorn directly:

```bash
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```

## API Endpoints

### Authentication

#### POST `/api/auth/signup`
Register a new user

**Request:**
```json
{
  "email": "user@example.com",
  "username": "johndoe",
  "password": "securepassword123"
}
```

**Response:**
```json
{
  "user": {
    "id": 1,
    "email": "user@example.com",
    "username": "johndoe",
    "is_active": true,
    "created_at": "2025-10-16T00:00:00",
    "updated_at": "2025-10-16T00:00:00"
  },
  "token": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "bearer"
  }
}
```

#### POST `/api/auth/login`
Login with email and password

**Request:**
```json
{
  "email": "user@example.com",
  "password": "securepassword123"
}
```

**Response:**
```json
{
  "user": {
    "id": 1,
    "email": "user@example.com",
    "username": "johndoe",
    "is_active": true,
    "created_at": "2025-10-16T00:00:00",
    "updated_at": "2025-10-16T00:00:00"
  },
  "token": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "bearer"
  }
}
```

#### POST `/api/auth/logout`
Logout (requires authentication)

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "message": "Successfully logged out"
}
```

#### GET `/api/auth/me`
Get current user info (requires authentication)

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "user": {
    "id": 1,
    "email": "user@example.com",
    "username": "johndoe",
    "is_active": true,
    "created_at": "2025-10-16T00:00:00",
    "updated_at": "2025-10-16T00:00:00"
  },
  "token": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "bearer"
  }
}
```

### General

#### GET `/`
Root endpoint with API info

#### GET `/health`
Health check endpoint

#### GET `/docs`
Interactive API documentation (Swagger UI)

#### GET `/redoc`
Alternative API documentation (ReDoc)

## Database

### Current: SQLite

The application uses SQLite for development. The database file is `sensai.db`.

### Switching to PostgreSQL

1. Install PostgreSQL driver:
   ```bash
   pip install psycopg2-binary
   ```

2. Update `.env`:
   ```env
   DATABASE_URL=postgresql://user:password@localhost/dbname
   ```

### Switching to MySQL

1. Install MySQL driver:
   ```bash
   pip install pymysql
   ```

2. Update `.env`:
   ```env
   DATABASE_URL=mysql+pymysql://user:password@localhost/dbname
   ```

**Note:** The code is database-agnostic. Just change the `DATABASE_URL` and it will work!

## Security Features

- ✅ Password hashing with bcrypt
- ✅ JWT token authentication
- ✅ Token expiration
- ✅ CORS protection
- ✅ Input validation with Pydantic
- ✅ SQL injection protection (SQLAlchemy)

## Development

### Auto-reload

The server runs with auto-reload enabled in development mode. Any code changes will automatically restart the server.

### Interactive Docs

Visit `http://localhost:8000/docs` for interactive API documentation where you can test endpoints directly.

### Database Migrations (Optional)

For production, you can use Alembic for database migrations:

```bash
# Initialize Alembic
alembic init migrations

# Create a migration
alembic revision --autogenerate -m "Initial migration"

# Apply migrations
alembic upgrade head
```

## Testing

You can test the API using:

1. **Swagger UI**: http://localhost:8000/docs
2. **cURL**:
   ```bash
   curl -X POST "http://localhost:8000/api/auth/signup" \
     -H "Content-Type: application/json" \
     -d '{"email":"test@example.com","username":"testuser","password":"password123"}'
   ```
3. **Postman**: Import the endpoints
4. **Frontend**: Use the React frontend

## Error Handling

The API returns appropriate HTTP status codes:

- `200` - Success
- `201` - Created
- `400` - Bad Request (validation errors)
- `401` - Unauthorized
- `404` - Not Found
- `500` - Internal Server Error

## Code Organization

### Clean Separation

- **Database**: All DB code in `database/`
- **Routes**: API endpoints in `routes/`
- **Schemas**: Pydantic models in `schemas/`
- **Utils**: Helper functions in `utils/`
- **Config**: Settings in `config/`
- **Main App**: Minimal setup in `app.py`

### Best Practices

- ✅ Type hints throughout
- ✅ Dependency injection
- ✅ Async/await where beneficial
- ✅ Comprehensive error handling
- ✅ Clean, readable code
- ✅ Proper comments and docstrings

## Production Deployment

For production:

1. Change `SECRET_KEY` to a strong random value
2. Set `RELOAD=False`
3. Use a production database (PostgreSQL/MySQL)
4. Set up proper CORS origins
5. Use a process manager (systemd, supervisor)
6. Set up HTTPS
7. Configure proper logging

## License

MIT

