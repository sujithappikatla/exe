# MCP Architecture - System vs User Servers

## Overview

The MCP implementation uses a **dual-source architecture** for server configurations:
- **System Servers**: Loaded from settings (never stored in database)
- **User Servers**: Stored in database (user-specific)

This design ensures settings changes take effect immediately without requiring database migrations.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    MCP Server Sources                        │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────┐      ┌──────────────────────┐    │
│  │   Settings (env)     │      │  Database (users)    │    │
│  │                      │      │                      │    │
│  │ DEFAULT_MCP_SERVERS  │      │   mcp_servers        │    │
│  │ - calculator         │      │   - user_id=1        │    │
│  │ - weather            │      │   - my-custom-tool   │    │
│  │ - ...                │      │   - ...              │    │
│  │                      │      │                      │    │
│  │ (System/Default)     │      │ (User-specific)      │    │
│  └──────────┬───────────┘      └──────────┬───────────┘    │
│             │                              │                 │
│             └──────────────┬───────────────┘                 │
│                            │                                 │
│                            ▼                                 │
│                  ┌─────────────────┐                        │
│                  │  MCP Manager    │                        │
│                  │  (Runtime Merge)│                        │
│                  └─────────────────┘                        │
│                            │                                 │
│                            ▼                                 │
│                  ┌─────────────────┐                        │
│                  │ All Available   │                        │
│                  │ Servers         │                        │
│                  │ (Settings + DB) │                        │
│                  └─────────────────┘                        │
└─────────────────────────────────────────────────────────────┘
```

## System Servers (Settings)

### Characteristics
- ✅ Defined in `DEFAULT_MCP_SERVERS` setting
- ✅ Available to ALL users
- ✅ Changes take effect immediately (no migration)
- ✅ Cannot be deleted/modified via API
- ✅ Never stored in database
- ✅ Can be toggled on/off per conversation

### Configuration

In `settings.py`:
```python
DEFAULT_MCP_SERVERS: List[Dict[str, Any]] = [
    {
        "name": "calculator",
        "transport": "stdio",
        "command": "/path/to/python",
        "args": ["/path/to/calc_server.py"]
    }
]
```

### API Representation
- **ID**: Negative numbers (e.g., -1, -2, -3)
- **is_system**: Always `true`
- **user_id**: Always `null`

Example:
```json
{
  "id": -1,
  "user_id": null,
  "name": "calculator",
  "transport": "stdio",
  "command": "/path/to/python",
  "args": ["/path/to/calc_server.py"],
  "is_system": true,
  "is_active": true
}
```

## User Servers (Database)

### Characteristics
- ✅ Stored in `mcp_servers` table
- ✅ User-specific (isolated by user_id)
- ✅ Can be created/updated/deleted via API
- ✅ Persisted across sessions
- ✅ Can be toggled on/off per conversation

### Database Schema
```sql
CREATE TABLE mcp_servers (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    name VARCHAR(255) NOT NULL,
    transport VARCHAR(50) NOT NULL,
    url VARCHAR(500),           -- for streamable_http
    command VARCHAR(500),        -- for stdio
    args JSON,                   -- for stdio
    headers JSON,                -- for streamable_http
    is_system BOOLEAN NOT NULL,  -- always false for user servers
    is_active BOOLEAN NOT NULL,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

### API Representation
- **ID**: Positive numbers (e.g., 1, 2, 3)
- **is_system**: Always `false`
- **user_id**: User's ID

Example:
```json
{
  "id": 1,
  "user_id": 123,
  "name": "my-weather-api",
  "transport": "streamable_http",
  "url": "http://localhost:8000/mcp",
  "headers": {},
  "is_system": false,
  "is_active": true
}
```

## Runtime Behavior

### Loading Servers

When loading MCP configuration for a conversation:

```python
# services/mcp_manager.py

async def load_mcp_config(user_id, conversation_id, db):
    # 1. Load system servers from settings
    system_servers = settings.default_mcp_servers_list
    
    # 2. Load user servers from database
    user_servers = db.query(MCPServer).filter(
        MCPServer.user_id == user_id,
        MCPServer.is_active == True
    ).all()
    
    # 3. Merge both sources
    all_servers = system_servers + user_servers
    
    # 4. Filter by conversation toggle state
    toggle_states = get_toggle_states(conversation_id, db)
    enabled_servers = filter_by_toggles(all_servers, toggle_states)
    
    return enabled_servers
```

### Server Priority

When servers have duplicate names:
1. **System servers** (from settings) loaded first
2. **User servers** (from database) loaded second
3. If duplicate names exist, user server takes precedence

To avoid conflicts:
- Use unique names for system servers
- Check system server names before creating user servers
- API validates name uniqueness per user

## API Behavior

### GET /api/mcp/servers

Returns merged list:
```json
[
  {
    "id": -1,
    "name": "calculator",
    "is_system": true,
    "user_id": null
  },
  {
    "id": 1,
    "name": "my-tool",
    "is_system": false,
    "user_id": 123
  }
]
```

### POST /api/mcp/servers

Creates **user server** in database:
- ✅ Only user servers can be created
- ✅ System servers are read-only (from settings)

### PUT /api/mcp/servers/{id}

Updates **user server**:
- ✅ Only positive IDs (user servers)
- ❌ Negative IDs rejected (system servers)

### DELETE /api/mcp/servers/{id}

Deletes **user server**:
- ✅ Only positive IDs (user servers)
- ❌ Negative IDs rejected (system servers)

### POST /api/mcp/conversations/{id}/servers/toggle

Toggles any server (system or user):
- ✅ Works for system servers (by name lookup in settings)
- ✅ Works for user servers (by name lookup in database)
- Creates/updates toggle state in `conversation_mcp_states` table

## Migration

### Initial Setup

```bash
python init_mcp_db.py
```

This creates tables **only**. No servers are added to database.

### Updating System Servers

**Old way** (❌ no longer needed):
```bash
# Edit settings
# Run migration to add to database
python init_mcp_db.py
```

**New way** (✅):
```python
# Edit settings.py or .env
DEFAULT_MCP_SERVERS = [...]

# Restart server - changes take effect immediately!
python app.py
```

### Adding User Servers

Via API:
```bash
curl -X POST /api/mcp/servers \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "my-tool",
    "transport": "stdio",
    "command": "python",
    "args": ["/path/to/server.py"]
  }'
```

## Benefits of This Architecture

### 1. **Immediate Updates**
- Change `DEFAULT_MCP_SERVERS` in settings
- Restart server
- Changes take effect immediately
- No database migration needed

### 2. **Clean Separation**
- System config in settings (infrastructure)
- User data in database (user preferences)
- Clear boundary between system and user

### 3. **No Stale Data**
- System servers always reflect current settings
- No "old default servers" stuck in database
- Settings are source of truth

### 4. **Simpler Migration**
- Migration only creates tables
- No complex "sync settings to database" logic
- Idempotent and fast

### 5. **Clear API Semantics**
- Negative IDs = system (read-only)
- Positive IDs = user (read-write)
- Easy to understand and enforce

## Example Scenarios

### Scenario 1: Admin Updates Default Tools

**Before:**
```python
# settings.py
DEFAULT_MCP_SERVERS = [
    {"name": "calculator", ...}
]
```

**After:**
```python
# settings.py  
DEFAULT_MCP_SERVERS = [
    {"name": "calculator", ...},
    {"name": "weather", ...}  # New!
]
```

**Result:**
- Restart server
- All users immediately see "weather" tool
- No database changes needed
- No migration script to run

### Scenario 2: User Adds Custom Tool

```bash
# User creates custom server via API
POST /api/mcp/servers
{
  "name": "my-research-tool",
  "transport": "streamable_http",
  "url": "http://localhost:9000/mcp"
}
```

**Result:**
- Stored in database with `user_id=123`
- Only this user sees the tool
- Other users unaffected
- Can be deleted/updated by this user

### Scenario 3: User Disables Default Tool

```bash
# User toggles off "calculator" for conversation
POST /api/mcp/conversations/5/servers/toggle
{
  "server_name": "calculator",
  "is_enabled": false
}
```

**Result:**
- Toggle state stored in `conversation_mcp_states`
- Calculator disabled for conversation 5 only
- System server unchanged
- Other conversations unaffected

## Code References

### Key Files
- `services/mcp_manager.py` - Merges system + user servers
- `routes/mcp.py` - API endpoints (respects system vs user)
- `config/settings.py` - System server configuration
- `database/models.py` - User server storage
- `init_mcp_db.py` - Migration (tables only)

### Key Functions
- `mcp_manager.load_mcp_config()` - Merges sources
- `list_mcp_servers()` - Returns both types with correct IDs
- `get_conversation_mcp_servers()` - Includes toggle state

## Testing

### Test System Server Loading
```python
# 1. Add to settings
DEFAULT_MCP_SERVERS = [{"name": "test", ...}]

# 2. Restart server

# 3. Call API
GET /api/mcp/servers
# Should see server with id=-1
```

### Test User Server CRUD
```python
# 1. Create
POST /api/mcp/servers {"name": "my-tool", ...}
# Returns id=1

# 2. Update
PUT /api/mcp/servers/1 {"is_active": false}
# Success

# 3. Delete
DELETE /api/mcp/servers/1
# Success

# 4. Try to delete system server
DELETE /api/mcp/servers/-1
# Error: Cannot delete system servers
```

### Test Toggle State
```python
# 1. Toggle system server off
POST /api/mcp/conversations/1/servers/toggle
{"server_name": "calculator", "is_enabled": false}

# 2. Load config
# Should not include calculator

# 3. Toggle back on
POST /api/mcp/conversations/1/servers/toggle
{"server_name": "calculator", "is_enabled": true}

# 4. Load config
# Should include calculator
```

## Summary

| Aspect | System Servers | User Servers |
|--------|---------------|--------------|
| **Source** | Settings | Database |
| **Storage** | `DEFAULT_MCP_SERVERS` | `mcp_servers` table |
| **Scope** | All users | Per user |
| **ID Range** | Negative (-1, -2, ...) | Positive (1, 2, ...) |
| **is_system** | `true` | `false` |
| **user_id** | `null` | User's ID |
| **Create** | Edit settings | POST /api/mcp/servers |
| **Update** | Edit settings | PUT /api/mcp/servers/{id} |
| **Delete** | Edit settings | DELETE /api/mcp/servers/{id} |
| **Toggle** | Per conversation | Per conversation |
| **Changes** | Restart server | API call |
| **Migration** | None | Stored in DB |

---

**This architecture provides the best of both worlds:**
- System defaults that admins control via settings
- User customization via database and API
- Clear separation and no data duplication
- Immediate updates for system changes

