"""
Chat Routes
API endpoints for chat functionality including conversations, messages, and SSE streaming
"""

import asyncio
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import desc, func

from database import get_db, User, Conversation, Message, AgentAction, MessageFeedback
from schemas import (
    MessageCreate,
    MessageResponse,
    ConversationCreate,
    ConversationListResponse,
    ConversationDetailResponse,
    SendMessageResponse,
    ToolConfirmation,
    StopGenerationResponse,
    MessageFeedbackCreate,
    MessageFeedbackResponse,
)
from utils.auth import get_current_user
from utils.sse import (
    format_sse_ping,
    verify_token_from_query,
    create_error_event,
    create_message_complete_event,
)
from services.chat_session import chat_session_manager
from services.mcp_manager import mcp_manager
from agents.chat_agent import LangGraphChatAgent
from config.settings import settings

router = APIRouter(prefix="/api/chat", tags=["Chat"])


# ============ Conversation Endpoints ============

@router.post("/conversations", response_model=ConversationListResponse, status_code=status.HTTP_201_CREATED)
async def create_conversation(
    conversation_data: ConversationCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Create a new conversation
    
    Args:
        conversation_data: Conversation creation data
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Created conversation
    """
    # Create new conversation
    new_conversation = Conversation(
        user_id=current_user.id,
        title=conversation_data.title,
    )
    
    db.add(new_conversation)
    db.commit()
    db.refresh(new_conversation)
    
    return ConversationListResponse(
        id=new_conversation.id,
        title=new_conversation.title,
        created_at=new_conversation.created_at,
        updated_at=new_conversation.updated_at,
        message_count=0,
        last_message=None,
        last_message_at=None,
    )


@router.get("/conversations", response_model=List[ConversationListResponse])
async def list_conversations(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    """
    List user's conversations with pagination
    
    Args:
        current_user: Current authenticated user
        db: Database session
        limit: Maximum number of conversations to return
        offset: Number of conversations to skip
        
    Returns:
        List of conversations with metadata
    """
    # Get conversations with message counts
    conversations = (
        db.query(Conversation)
        .filter(Conversation.user_id == current_user.id)
        .order_by(desc(Conversation.updated_at))
        .limit(limit)
        .offset(offset)
        .all()
    )
    
    result = []
    for conv in conversations:
        # Get message count
        message_count = db.query(func.count(Message.id)).filter(
            Message.conversation_id == conv.id
        ).scalar()
        
        # Get last message
        last_message_obj = (
            db.query(Message)
            .filter(Message.conversation_id == conv.id)
            .order_by(desc(Message.created_at))
            .first()
        )
        
        last_message = last_message_obj.content[:100] if last_message_obj else None
        last_message_at = last_message_obj.created_at if last_message_obj else None
        
        result.append(
            ConversationListResponse(
                id=conv.id,
                title=conv.title,
                created_at=conv.created_at,
                updated_at=conv.updated_at,
                message_count=message_count,
                last_message=last_message,
                last_message_at=last_message_at,
            )
        )
    
    return result


@router.get("/conversations/{conversation_id}", response_model=ConversationDetailResponse)
async def get_conversation(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get detailed conversation with all messages and actions
    Used for page reload recovery
    
    Args:
        conversation_id: ID of the conversation
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Detailed conversation with messages
    """
    # Get conversation
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found"
        )
    
    # Messages and related data are loaded via relationships
    return conversation


@router.delete("/conversations/{conversation_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_conversation(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Delete a conversation
    
    Args:
        conversation_id: ID of the conversation
        current_user: Current authenticated user
        db: Database session
    """
    # Get conversation
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found"
        )
    
    # Stop active session if any
    await chat_session_manager.stop_session(conversation_id)
    
    # Delete conversation (cascade will handle messages, actions, and mcp_states)
    db.delete(conversation)
    db.commit()
    
    return None


# ============ Message Endpoints ============

@router.post("/conversations/{conversation_id}/messages", response_model=SendMessageResponse)
async def send_message(
    conversation_id: int,
    message_data: MessageCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Send a user message and trigger agent processing
    
    Args:
        conversation_id: ID of the conversation
        message_data: Message content
        background_tasks: FastAPI background tasks
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Message ID and conversation ID
    """
    # Verify conversation exists and belongs to user
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found"
        )
    
    # Create user message
    user_message = Message(
        conversation_id=conversation_id,
        role="user",
        content=message_data.content,
    )
    
    db.add(user_message)
    db.commit()
    db.refresh(user_message)
    
    # Update conversation title if it's the first message
    if not conversation.title:
        # Generate title from first message (first 50 chars)
        conversation.title = message_data.content[:50]
        if len(message_data.content) > 50:
            conversation.title += "..."
        db.commit()
    
    # Update conversation timestamp
    conversation.updated_at = datetime.utcnow()
    db.commit()
    
    # Start agent processing in background
    background_tasks.add_task(
        process_agent_response,
        conversation_id,
        user_message.id,
    )
    
    return SendMessageResponse(
        message_id=user_message.id,
        conversation_id=conversation_id,
    )


async def process_agent_response(conversation_id: int, user_message_id: int):
    """
    Background task to process agent response with MCP tool support
    
    Args:
        conversation_id: ID of the conversation
        user_message_id: ID of the user message
    """
    # Get new database session for background task
    from database import SessionLocal
    db = SessionLocal()
    
    try:
        # Create session for streaming
        session = await chat_session_manager.create_session(conversation_id)
        
        # Get conversation and user info
        conversation = db.query(Conversation).filter(Conversation.id == conversation_id).first()
        if not conversation:
            return
        
        user_id = conversation.user_id
        
        # Get conversation history
        messages = (
            db.query(Message)
            .filter(Message.conversation_id == conversation_id)
            .order_by(Message.created_at)
            .all()
        )
        
        # Get the user message
        user_message = db.query(Message).filter(Message.id == user_message_id).first()
        if not user_message:
            return
        
        # Get conversation history (excluding the new message)
        conversation_history = [m for m in messages if m.id != user_message_id]
        
        # Load MCP tools if configured
        tools = []
        mcp_client = None
        try:
            # Create MCP client for this conversation
            mcp_client = await mcp_manager.create_client(user_id, conversation_id, db)
            
            if mcp_client:
                # Get tools from MCP client
                tools = await mcp_manager.get_tools(mcp_client)
                if tools:
                    print(f"Loaded {len(tools)} tools from MCP servers")
        except Exception as e:
            print(f"Error loading MCP tools: {e}")
            # Continue without tools
        
        # Initialize agent with settings
        agent = LangGraphChatAgent(
            llm_base_url=settings.LLM_BASE_URL,
            llm_api_key=settings.LLM_API_KEY,
            llm_model=settings.LLM_MODEL,
            temperature=settings.LLM_TEMPERATURE,
        )
        
        # Process message with streaming and optional tools
        assistant_content = await agent.process_message(
            conversation_history=conversation_history,
            new_message=user_message,
            sse_queue=session.sse_queue,
            stop_event=session.stop_event,
            db=db,
            confirmation_waiters=session.confirmation_waiters,
            tools=tools if tools else None,
        )
        
        # Save assistant response to database
        assistant_message = Message(
            conversation_id=conversation_id,
            role="assistant",
            content=assistant_content,
        )
        
        db.add(assistant_message)
        db.commit()
        
        # Update conversation timestamp
        if conversation:
            conversation.updated_at = datetime.utcnow()
            db.commit()
        
    except Exception as e:
        print(f"Error processing agent response: {e}")
        import traceback
        traceback.print_exc()
        # Send error event if session is still active
        session = await chat_session_manager.get_session(conversation_id)
        if session:
            await session.sse_queue.put(create_error_event(str(e)))
    
    finally:
        db.close()
        # Don't cleanup session here - let SSE endpoint handle it


# ============ SSE Streaming Endpoint ============

@router.get("/conversations/{conversation_id}/stream")
async def stream_conversation(
    conversation_id: int,
    token: str = Query(..., description="JWT token for authentication"),
    db: Session = Depends(get_db),
):
    """
    SSE endpoint for streaming agent responses
    
    Args:
        conversation_id: ID of the conversation
        token: JWT token (query param since EventSource doesn't support headers)
        db: Database session
        
    Returns:
        StreamingResponse with SSE events
    """
    # Verify token
    try:
        payload = verify_token_from_query(token)
        user_id = payload.get("user_id")
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials"
        )
    
    # Verify conversation belongs to user
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == user_id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found"
        )
    
    # Stream events
    async def event_generator():
        """Generate SSE events from the queue"""
        session = await chat_session_manager.get_session(conversation_id)
        
        if not session:
            # No active session - send error and close
            yield create_error_event("No active session")
            return
        
        try:
            # Send keepalive pings every 30 seconds
            last_ping = asyncio.get_event_loop().time()
            ping_interval = 30
            
            while session.is_active:
                try:
                    # Wait for event with timeout for ping
                    event = await asyncio.wait_for(
                        session.sse_queue.get(),
                        timeout=ping_interval
                    )
                    yield event
                    
                except asyncio.TimeoutError:
                    # Send ping for keepalive
                    current_time = asyncio.get_event_loop().time()
                    if current_time - last_ping >= ping_interval:
                        yield format_sse_ping()
                        last_ping = current_time
                
                except Exception as e:
                    yield create_error_event(f"Stream error: {str(e)}")
                    break
        
        finally:
            # Cleanup session when client disconnects
            await chat_session_manager.cleanup_session(conversation_id)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable buffering in nginx
        },
    )


# ============ Control Endpoints ============

@router.post("/conversations/{conversation_id}/stop", response_model=StopGenerationResponse)
async def stop_generation(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Stop active generation for a conversation
    
    Args:
        conversation_id: ID of the conversation
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Stop status
    """
    # Verify conversation belongs to user
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found"
        )
    
    # Stop the session
    stopped = await chat_session_manager.stop_session(conversation_id)
    
    return StopGenerationResponse(
        message="Generation stopped" if stopped else "No active generation",
        stopped=stopped,
    )


@router.post("/actions/{action_id}/confirm")
async def confirm_action(
    action_id: int,
    confirmation: ToolConfirmation,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Confirm or reject a tool execution request
    
    Args:
        action_id: ID of the agent action
        confirmation: User's confirmation decision
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Success message
    """
    # Get the action
    action = db.query(AgentAction).filter(AgentAction.id == action_id).first()
    
    if not action:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Action not found"
        )
    
    # Verify action belongs to user's conversation
    message = db.query(Message).filter(Message.id == action.message_id).first()
    if not message:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Message not found")
    
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == message.conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    
    # Update action status
    action.status = "approved" if confirmation.approved else "rejected"
    action.user_response = confirmation.user_note
    db.commit()
    
    # Resolve the confirmation waiter
    await chat_session_manager.resolve_confirmation(
        conversation.id,
        action_id,
        confirmation.approved,
        confirmation.user_note,
    )
    
    return {"message": "Action confirmed"}


# ============ Feedback Endpoints ============

@router.post("/messages/{message_id}/feedback", response_model=MessageFeedbackResponse)
async def add_message_feedback(
    message_id: int,
    feedback_data: MessageFeedbackCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Add or update feedback (like/dislike) for a message
    
    Args:
        message_id: ID of the message
        feedback_data: Feedback data
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Created or updated feedback
    """
    # Verify message belongs to user's conversation
    message = db.query(Message).filter(Message.id == message_id).first()
    
    if not message:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Message not found"
        )
    
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == message.conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    
    # Check if feedback already exists
    existing_feedback = (
        db.query(MessageFeedback)
        .filter(MessageFeedback.message_id == message_id)
        .first()
    )
    
    if existing_feedback:
        # Update existing feedback
        existing_feedback.feedback_type = feedback_data.feedback_type
        existing_feedback.reason = feedback_data.reason
        existing_feedback.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(existing_feedback)
        return existing_feedback
    else:
        # Create new feedback
        new_feedback = MessageFeedback(
            message_id=message_id,
            feedback_type=feedback_data.feedback_type,
            reason=feedback_data.reason,
        )
        db.add(new_feedback)
        db.commit()
        db.refresh(new_feedback)
        return new_feedback


@router.delete("/messages/{message_id}/feedback", status_code=status.HTTP_204_NO_CONTENT)
async def delete_message_feedback(
    message_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Delete feedback for a message
    
    Args:
        message_id: ID of the message
        current_user: Current authenticated user
        db: Database session
    """
    # Verify message belongs to user's conversation
    message = db.query(Message).filter(Message.id == message_id).first()
    
    if not message:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Message not found"
        )
    
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == message.conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    
    # Delete feedback if it exists
    feedback = (
        db.query(MessageFeedback)
        .filter(MessageFeedback.message_id == message_id)
        .first()
    )
    
    if feedback:
        db.delete(feedback)
        db.commit()

