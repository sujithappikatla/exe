"""
Routes package
Contains all API route handlers
"""

from .auth import router as auth_router
from .chat import router as chat_router
from .mcp import router as mcp_router

__all__ = ["auth_router", "chat_router", "mcp_router"]

