"""
Admin Routes
API endpoints for admin user management
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from database import get_db, User
from schemas.admin import UpdateUserStatus, UpdateUserRole, UserListResponse
from schemas.user import UserResponse
from schemas.auth import MessageResponse
from utils.auth import get_current_admin

router = APIRouter(prefix="/api/admin", tags=["Admin"])


@router.get("/users", response_model=UserListResponse)
async def list_users(
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """
    List all users (admin only)
    
    Args:
        limit: Maximum number of users to return
        offset: Number of users to skip
        current_admin: Current authenticated admin user
        db: Database session
        
    Returns:
        List of all users with pagination
    """
    # Get total count
    total = db.query(User).count()
    
    # Get users with pagination
    users = db.query(User).offset(offset).limit(limit).all()
    
    return UserListResponse(users=users, total=total)


@router.patch("/users/{user_id}/status", response_model=UserResponse)
async def update_user_status(
    user_id: int,
    status_update: UpdateUserStatus,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """
    Update user account status (admin only)
    
    Args:
        user_id: ID of user to update
        status_update: New account status
        current_admin: Current authenticated admin user
        db: Database session
        
    Returns:
        Updated user information
        
    Raises:
        HTTPException: If user not found
    """
    user = db.query(User).filter(User.id == user_id).first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    user.account_status = status_update.account_status
    db.commit()
    db.refresh(user)
    
    return user


@router.patch("/users/{user_id}/role", response_model=UserResponse)
async def update_user_role(
    user_id: int,
    role_update: UpdateUserRole,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """
    Update user role (admin only)
    
    Args:
        user_id: ID of user to update
        role_update: New role
        current_admin: Current authenticated admin user
        db: Database session
        
    Returns:
        Updated user information
        
    Raises:
        HTTPException: If user not found or trying to change own role
    """
    user = db.query(User).filter(User.id == user_id).first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Prevent admin from changing their own role
    if user.id == current_admin.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot change your own role"
        )
    
    user.role = role_update.role
    db.commit()
    db.refresh(user)
    
    return user

