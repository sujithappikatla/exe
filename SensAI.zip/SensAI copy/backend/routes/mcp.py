"""
MCP Routes
API endpoints for managing MCP (Model Context Protocol) servers
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import datetime

from database import get_db, User, MCPServer, Conversation, ConversationMCPState
from schemas import (
    MCPServerCreate,
    MCPServerUpdate,
    MCPServerResponse,
    ConversationMCPServerResponse,
    MCPServerToggle,
    MCPServerToggleResponse,
)
from utils.auth import get_current_user
from services.mcp_manager import mcp_manager

router = APIRouter(prefix="/api/mcp", tags=["MCP"])


# ============ MCP Server Management Endpoints ============

@router.get("/servers", response_model=List[MCPServerResponse])
async def list_mcp_servers(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    List all MCP servers available to the user
    Includes system servers (from settings) and user's personal servers (from database)
    
    Args:
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        List of MCP servers
    """
    from config.settings import settings
    from datetime import datetime
    
    result = []
    
    # Get system servers from settings (not in database)
    default_servers = settings.default_mcp_servers_list
    for idx, server_config in enumerate(default_servers):
        # Create response object for system server
        server_response = MCPServerResponse(
            id=-(idx + 1),  # Negative IDs for system servers (not in DB)
            user_id=None,
            name=server_config.get("name", "unknown"),
            transport=server_config.get("transport", "stdio"),
            url=server_config.get("url"),
            command=server_config.get("command"),
            args=server_config.get("args"),
            headers=server_config.get("headers", {}),
            is_system=True,
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        result.append(server_response)
    
    # Get user's custom servers from database
    user_servers = (
        db.query(MCPServer)
        .filter(MCPServer.user_id == current_user.id)
        .order_by(MCPServer.created_at.desc())
        .all()
    )
    
    result.extend(user_servers)
    
    return result


@router.post("/servers", response_model=MCPServerResponse, status_code=status.HTTP_201_CREATED)
async def create_mcp_server(
    server_data: MCPServerCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Create a new user MCP server
    
    Args:
        server_data: MCP server configuration
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Created MCP server
    """
    # Validate transport-specific fields
    if server_data.transport == "streamable_http":
        if not server_data.url:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="URL is required for streamable_http transport"
            )
    elif server_data.transport == "stdio":
        if not server_data.command:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Command is required for stdio transport"
            )
    
    # Check if server name already exists for this user
    existing = (
        db.query(MCPServer)
        .filter(
            MCPServer.user_id == current_user.id,
            MCPServer.name == server_data.name
        )
        .first()
    )
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Server with name '{server_data.name}' already exists"
        )
    
    # Create new server
    new_server = MCPServer(
        user_id=current_user.id,
        name=server_data.name,
        transport=server_data.transport,
        url=server_data.url,
        command=server_data.command,
        args=server_data.args,
        headers=server_data.headers or {},
        is_system=False,
        is_active=server_data.is_active,
    )
    
    db.add(new_server)
    db.commit()
    db.refresh(new_server)
    
    return new_server


@router.put("/servers/{server_id}", response_model=MCPServerResponse)
async def update_mcp_server(
    server_id: int,
    server_data: MCPServerUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Update a user MCP server
    System servers (from settings) cannot be updated
    Only user servers (from database) can be updated
    
    Args:
        server_id: ID of the server
        server_data: Updated server configuration
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Updated MCP server
    """
    # System servers have negative IDs and aren't in database
    if server_id < 0:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot modify system servers (configured in settings)"
        )
    
    # Get the server from database
    server = db.query(MCPServer).filter(MCPServer.id == server_id).first()
    
    if not server:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Server not found"
        )
    
    # Check ownership
    if server.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot modify servers owned by other users"
        )
    
    # Update fields
    update_data = server_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(server, field, value)
    
    server.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(server)
    
    return server


@router.delete("/servers/{server_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_mcp_server(
    server_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Delete a user MCP server
    System servers (from settings) cannot be deleted
    Only user servers (from database) can be deleted
    
    Args:
        server_id: ID of the server
        current_user: Current authenticated user
        db: Database session
    """
    # System servers have negative IDs and aren't in database
    if server_id < 0:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot delete system servers (configured in settings)"
        )
    
    # Get the server from database
    server = db.query(MCPServer).filter(MCPServer.id == server_id).first()
    
    if not server:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Server not found"
        )
    
    # Check ownership
    if server.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot delete servers owned by other users"
        )
    
    # Delete the server
    db.delete(server)
    db.commit()


# ============ Conversation MCP State Endpoints ============

@router.get("/conversations/{conversation_id}/servers", response_model=List[ConversationMCPServerResponse])
async def get_conversation_mcp_servers(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Get MCP servers with toggle state for a specific conversation
    Includes system servers (from settings) and user servers (from database)
    
    Args:
        conversation_id: ID of the conversation
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        List of MCP servers with is_enabled state
    """
    from config.settings import settings
    
    # Verify conversation belongs to user
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found"
        )
    
    # Get toggle states
    toggle_states = (
        db.query(ConversationMCPState)
        .filter(ConversationMCPState.conversation_id == conversation_id)
        .all()
    )
    
    toggle_map = {state.server_name: state.is_enabled for state in toggle_states}
    
    result = []
    
    # Add system servers from settings
    default_servers = settings.default_mcp_servers_list
    for idx, server_config in enumerate(default_servers):
        server_name = server_config.get("name", "unknown")
        server_dict = {
            "id": -(idx + 1),  # Negative IDs for system servers
            "user_id": None,
            "name": server_name,
            "transport": server_config.get("transport", "stdio"),
            "url": server_config.get("url"),
            "command": server_config.get("command"),
            "args": server_config.get("args"),
            "headers": server_config.get("headers", {}),
            "is_system": True,
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "is_enabled": toggle_map.get(server_name, True)  # Default enabled
        }
        result.append(ConversationMCPServerResponse(**server_dict))
    
    # Add user's custom servers from database
    user_servers = (
        db.query(MCPServer)
        .filter(
            (MCPServer.user_id == current_user.id) &
            (MCPServer.is_active == True)
        )
        .all()
    )
    
    for server in user_servers:
        server_dict = {
            "id": server.id,
            "user_id": server.user_id,
            "name": server.name,
            "transport": server.transport,
            "url": server.url,
            "command": server.command,
            "args": server.args,
            "headers": server.headers,
            "is_system": False,  # User servers are not system
            "is_active": server.is_active,
            "created_at": server.created_at,
            "updated_at": server.updated_at,
            "is_enabled": toggle_map.get(server.name, True)  # Default enabled
        }
        result.append(ConversationMCPServerResponse(**server_dict))
    
    return result


@router.post("/conversations/{conversation_id}/servers/toggle", response_model=MCPServerToggleResponse)
async def toggle_conversation_mcp_server(
    conversation_id: int,
    toggle_data: MCPServerToggle,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Toggle MCP server on/off for a specific conversation (runtime only)
    Works for both system servers (from settings) and user servers (from database)
    
    Args:
        conversation_id: ID of the conversation
        toggle_data: Toggle configuration
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Toggle status
    """
    from config.settings import settings
    
    # Verify conversation belongs to user
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    
    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found"
        )
    
    # Check if server exists in settings (system) or database (user)
    server_exists = False
    
    # Check system servers from settings
    default_servers = settings.default_mcp_servers_list
    for server_config in default_servers:
        if server_config.get("name") == toggle_data.server_name:
            server_exists = True
            break
    
    # Check user servers from database
    if not server_exists:
        user_server = (
            db.query(MCPServer)
            .filter(
                MCPServer.name == toggle_data.server_name,
                MCPServer.user_id == current_user.id
            )
            .first()
        )
        if user_server:
            server_exists = True
    
    if not server_exists:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Server '{toggle_data.server_name}' not found"
        )
    
    # Check if toggle state exists
    existing_state = (
        db.query(ConversationMCPState)
        .filter(
            ConversationMCPState.conversation_id == conversation_id,
            ConversationMCPState.server_name == toggle_data.server_name
        )
        .first()
    )
    
    if existing_state:
        # Update existing state
        existing_state.is_enabled = toggle_data.is_enabled
        existing_state.updated_at = datetime.utcnow()
    else:
        # Create new state
        new_state = ConversationMCPState(
            conversation_id=conversation_id,
            server_name=toggle_data.server_name,
            is_enabled=toggle_data.is_enabled
        )
        db.add(new_state)
    
    db.commit()
    
    # Reload MCP client for this conversation
    await mcp_manager.reload_client(current_user.id, conversation_id, db)
    
    return MCPServerToggleResponse(
        server_name=toggle_data.server_name,
        is_enabled=toggle_data.is_enabled,
        message=f"Server '{toggle_data.server_name}' {'enabled' if toggle_data.is_enabled else 'disabled'} for this conversation"
    )

