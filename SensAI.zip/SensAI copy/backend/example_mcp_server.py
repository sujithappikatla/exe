"""
Example MCP Server
A simple calculator MCP server for testing MCP integration

This server provides basic arithmetic operations via MCP protocol.
Can be used with stdio transport for local testing.

Usage:
    python example_mcp_server.py

Then configure in DEFAULT_MCP_SERVERS:
    {
        "name": "calculator",
        "transport": "stdio",
        "command": "python",
        "args": ["/absolute/path/to/example_mcp_server.py"]
    }
"""

from typing import Any
from mcp.server.fastmcp import FastMCP

# Create FastMCP server
mcp = FastMCP("Calculator")


@mcp.tool()
def add(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b


@mcp.tool()
def subtract(a: float, b: float) -> float:
    """Subtract b from a."""
    return a - b


@mcp.tool()
def multiply(a: float, b: float) -> float:
    """Multiply two numbers."""
    return a * b


@mcp.tool()
def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


@mcp.tool()
def power(base: float, exponent: float) -> float:
    """Raise base to the power of exponent."""
    return base ** exponent


@mcp.tool()
def square_root(n: float) -> float:
    """Calculate square root of n."""
    if n < 0:
        raise ValueError("Cannot calculate square root of negative number")
    return n ** 0.5


@mcp.tool()
def tell_joke() -> str:
    """Tell a random programming or math joke."""
    import random
    
    jokes = [
        "Why do programmers prefer dark mode? Because light attracts bugs!",
        "Why was the math book sad? Because it had too many problems!",
        "How do you comfort a JavaScript bug? You console it!",
        "Why do mathematicians like parks? Because of all the natural logs!",
        "What's a programmer's favorite hangout place? Foo Bar!",
        "Why did the developer go broke? Because he used up all his cache!",
        "What do you call a programmer from Finland? Nerdic!",
        "Why don't programmers like nature? It has too many bugs!",
        "What's the object-oriented way to become wealthy? Inheritance!",
        "Why did the function break up with the variable? It wasn't returning her calls!"
    ]
    
    return random.choice(jokes)





if __name__ == "__main__":
    # Run with stdio transport (for local integration)
    print("Starting Calculator MCP Server...", flush=True)
    mcp.run(transport="streamable-http")

