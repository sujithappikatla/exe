"""
SSE Streaming Callbacks
LangChain callbacks for streaming LLM responses and agent status updates via SSE
"""

import asyncio
from typing import Any, Dict, List, Optional
from langchain_core.callbacks import AsyncCallbackHandler
from utils.sse import (
    create_content_event,
    create_status_event,
    create_action_complete_event,
)


class SSEStreamingCallback(AsyncCallbackHandler):
    """
    Async callback handler for streaming LLM responses via SSE
    Captures tokens and agent events, queuing them for SSE transmission
    """

    def __init__(self, sse_queue: asyncio.Queue, message_id: int):
        """
        Initialize callback handler
        
        Args:
            sse_queue: Queue for sending SSE events
            message_id: ID of the message being processed
        """
        self.sse_queue = sse_queue
        self.message_id = message_id
        self.current_action_type: Optional[str] = None

    async def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> None:
        """Called when LLM starts generating"""
        await self.sse_queue.put(
            create_status_event("thinking", "AI is thinking...")
        )

    async def on_llm_new_token(self, token: str, **kwargs: Any) -> None:
        """
        Called when LLM generates a new token
        Streams the token to the frontend
        """
        await self.sse_queue.put(
            create_content_event(token, self.message_id)
        )

    async def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        """Called when LLM finishes generating"""
        # We don't send a specific event here, as message_complete is sent separately
        pass

    async def on_llm_error(self, error: Exception, **kwargs: Any) -> None:
        """Called when LLM encounters an error"""
        from utils.sse import create_error_event
        await self.sse_queue.put(
            create_error_event(f"LLM error: {str(error)}")
        )

    async def on_tool_start(
        self, serialized: Dict[str, Any], input_str: str, **kwargs: Any
    ) -> None:
        """Called when a tool starts executing"""
        tool_name = serialized.get("name", "unknown")
        await self.sse_queue.put(
            create_status_event("tool_execution", f"Executing tool: {tool_name}")
        )

    async def on_tool_end(self, output: str, **kwargs: Any) -> None:
        """Called when a tool finishes executing"""
        # Tool completion will be tracked via AgentAction in database
        pass

    async def on_tool_error(self, error: Exception, **kwargs: Any) -> None:
        """Called when a tool encounters an error"""
        from utils.sse import create_error_event
        await self.sse_queue.put(
            create_error_event(f"Tool error: {str(error)}")
        )

    async def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        """Called when agent takes an action"""
        # This can be used to track agent reasoning steps
        pass

    async def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        """Called when agent finishes"""
        pass

    async def send_custom_status(self, status_type: str, message: str):
        """
        Send custom status update
        
        Args:
            status_type: Type of status update
            message: Status message
        """
        await self.sse_queue.put(
            create_status_event(status_type, message)
        )

    async def send_action_complete(self, action_id: int, action_type: str, result: Optional[str] = None):
        """
        Send action complete event
        
        Args:
            action_id: ID of the completed action
            action_type: Type of action
            result: Optional result summary
        """
        await self.sse_queue.put(
            create_action_complete_event(action_id, action_type, result)
        )

