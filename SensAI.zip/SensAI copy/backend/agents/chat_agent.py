"""
LangGraph Chat Agent
LangGraph-based agent with streaming support, tool calling, and MCP integration
"""

import asyncio
from typing import List, Optional, Dict, Any, Sequence
from sqlalchemy.orm import Session

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode, tools_condition

from database.models import Message, AgentAction
from .callbacks import SSEStreamingCallback
from utils.sse import create_message_complete_event


class LangGraphChatAgent:
    """
    LangGraph-based chat agent with streaming and MCP tool support
    Uses StateGraph with nodes for model calling and tool execution
    """

    def __init__(
        self,
        llm_base_url: Optional[str] = None,
        llm_api_key: str = "not-needed",
        llm_model: str = "gpt-3.5-turbo",
        temperature: float = 0.7,
    ):
        """
        Initialize the LangGraph chat agent
        
        Args:
            llm_base_url: Base URL for OpenAI-compatible API (e.g., http://localhost:11434/v1 for Ollama)
            llm_api_key: API key (not needed for local models like Ollama)
            llm_model: Model name (e.g., gpt-3.5-turbo, llama2, etc.)
            temperature: Temperature for generation
        """
        self.llm_base_url = llm_base_url
        self.llm_api_key = llm_api_key
        self.llm_model = llm_model
        self.temperature = temperature

    def _create_llm(self, callback: SSEStreamingCallback) -> ChatOpenAI:
        """
        Create LangChain LLM instance with streaming callback
        
        Args:
            callback: Streaming callback handler
            
        Returns:
            ChatOpenAI: Configured LLM instance
        """
        llm_kwargs = {
            "model": self.llm_model,
            "temperature": self.temperature,
            "streaming": True,
            "callbacks": [callback],
        }

        # Add base_url if using custom endpoint (like Ollama)
        if self.llm_base_url:
            llm_kwargs["base_url"] = self.llm_base_url
            llm_kwargs["api_key"] = self.llm_api_key
        else:
            # Use default OpenAI
            llm_kwargs["api_key"] = self.llm_api_key

        return ChatOpenAI(**llm_kwargs)

    def _convert_messages_to_langchain(self, messages: List[Message]) -> List[BaseMessage]:
        """
        Convert database messages to LangChain message format
        
        Args:
            messages: List of database Message objects
            
        Returns:
            List of LangChain message objects
        """
        langchain_messages = []
        for msg in messages:
            if msg.role == "user":
                langchain_messages.append(HumanMessage(content=msg.content))
            elif msg.role == "assistant":
                langchain_messages.append(AIMessage(content=msg.content))
            elif msg.role == "system":
                langchain_messages.append(SystemMessage(content=msg.content))
        return langchain_messages

    def _build_graph(
        self,
        llm: ChatOpenAI,
        tools: Optional[List[Any]] = None
    ):
        """
        Build LangGraph StateGraph with model and tool nodes
        
        Args:
            llm: LangChain LLM instance
            tools: List of tools available to the agent
            
        Returns:
            Compiled graph
        """
        # Bind tools to LLM if provided
        if tools:
            llm_with_tools = llm.bind_tools(tools)
        else:
            llm_with_tools = llm

        def call_model(state: MessagesState) -> Dict[str, Sequence[BaseMessage]]:
            """
            Node that calls the LLM
            """
            response = llm_with_tools.invoke(state["messages"])
            return {"messages": [response]}

        # Build the graph
        builder = StateGraph(MessagesState)
        
        # Add nodes
        builder.add_node("call_model", call_model)
        
        if tools:
            # Add tool node
            builder.add_node("tools", ToolNode(tools))
            
            # Add edges
            builder.add_edge(START, "call_model")
            
            # Conditional edge: if LLM wants to use tools, go to tools node, else end
            builder.add_conditional_edges(
                "call_model",
                tools_condition,
            )
            
            # After tool execution, go back to model
            builder.add_edge("tools", "call_model")
        else:
            # No tools, simple flow
            builder.add_edge(START, "call_model")
            builder.add_edge("call_model", END)
        
        # Compile graph
        graph = builder.compile()
        return graph

    async def process_message(
        self,
        conversation_history: List[Message],
        new_message: Message,
        sse_queue: asyncio.Queue,
        stop_event: asyncio.Event,
        db: Session,
        confirmation_waiters: Dict[int, asyncio.Future],
        tools: Optional[List[Any]] = None,
    ) -> str:
        """
        Process a user message and stream the response using LangGraph
        
        Args:
            conversation_history: List of previous messages in conversation
            new_message: The new user message to process
            sse_queue: Queue for sending SSE events
            stop_event: Event to signal stopping generation
            db: Database session
            confirmation_waiters: Dict of action_id -> Future for tool confirmations
            tools: Optional list of MCP tools
            
        Returns:
            str: The complete assistant response
        """
        # Create callback handler
        callback = SSEStreamingCallback(sse_queue, new_message.id)

        try:
            # Create LLM with streaming
            llm = self._create_llm(callback)

            # Convert conversation history to LangChain format
            all_messages = conversation_history + [new_message]
            langchain_messages = self._convert_messages_to_langchain(all_messages)

            # Add system message if not already present
            if not langchain_messages or not isinstance(langchain_messages[0], SystemMessage):
                system_message = SystemMessage(
                    content="You are a helpful AI assistant. Provide clear, accurate, and helpful responses."
                )
                langchain_messages.insert(0, system_message)

            # Build the graph
            graph = self._build_graph(llm, tools)

            # Stream the response
            response_content = ""
            
            # Check for stop signal before starting
            if stop_event.is_set():
                await sse_queue.put(
                    create_message_complete_event(new_message.id)
                )
                return response_content

            # Invoke graph with streaming
            # Note: For streaming with astream_events, we need to track tokens
            try:
                async for event in graph.astream_events(
                    {"messages": langchain_messages},
                    version="v2"
                ):
                    # Check stop signal
                    if stop_event.is_set():
                        break
                    
                    # Handle different event types
                    kind = event.get("event")
                    
                    # on_chat_model_stream events contain token chunks
                    if kind == "on_chat_model_stream":
                        chunk = event.get("data", {}).get("chunk")
                        if chunk and hasattr(chunk, "content"):
                            if chunk.content:
                                response_content += chunk.content
                    
                    # on_chat_model_end gives us the final output
                    elif kind == "on_chat_model_end":
                        output = event.get("data", {}).get("output")
                        if output and hasattr(output, "content"):
                            # This is the final content - already accumulated above
                            pass
            
            except Exception as stream_error:
                print(f"Streaming error: {stream_error}")
                # Fall back to non-streaming invoke
                result = await graph.ainvoke({"messages": langchain_messages})
                final_messages = result.get("messages", [])
                if final_messages:
                    last_message = final_messages[-1]
                    if hasattr(last_message, "content"):
                        response_content = last_message.content

            # Send message complete event
            await sse_queue.put(
                create_message_complete_event(new_message.id)
            )

            return response_content

        except asyncio.CancelledError:
            # Handle cancellation gracefully
            await sse_queue.put(
                create_message_complete_event(new_message.id)
            )
            raise

        except Exception as e:
            # Handle errors
            from utils.sse import create_error_event
            await sse_queue.put(
                create_error_event(f"Agent error: {str(e)}")
            )
            raise

    async def request_tool_confirmation(
        self,
        sse_queue: asyncio.Queue,
        action_id: int,
        tool_name: str,
        tool_args: Dict[str, Any],
        description: str,
        confirmation_future: asyncio.Future,
    ) -> Dict[str, Any]:
        """
        Request user confirmation for a tool execution
        
        Args:
            sse_queue: Queue for SSE events
            action_id: ID of the agent action
            tool_name: Name of the tool
            tool_args: Arguments for the tool
            description: Human-readable description
            confirmation_future: Future to wait for user response
            
        Returns:
            Dict with 'approved' (bool) and 'user_note' (Optional[str])
        """
        from utils.sse import create_tool_confirmation_event
        
        # Send tool confirmation request via SSE
        await sse_queue.put(
            create_tool_confirmation_event(action_id, tool_name, tool_args, description)
        )

        # Wait for user response
        try:
            result = await confirmation_future
            return result
        except asyncio.CancelledError:
            return {"approved": False, "user_note": "Cancelled"}


# Legacy class alias for backward compatibility
StreamingChatAgent = LangGraphChatAgent
