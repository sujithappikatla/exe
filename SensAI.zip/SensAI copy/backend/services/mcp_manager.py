"""
MCP Manager Service
Manages MCP (Model Context Protocol) client lifecycle and tool loading
"""

import asyncio
from typing import Dict, List, Optional, Any
from sqlalchemy.orm import Session

from database import MCPServer, ConversationMCPState
from config.settings import settings


class MCPManager:
    """
    Manager for MCP client lifecycle and configuration
    Handles loading MCP server configs, building client configs, and managing tool access
    """

    def __init__(self):
        """Initialize MCP Manager"""
        self._clients_cache: Dict[int, Any] = {}  # conversation_id -> MultiServerMCPClient
        self._lock = asyncio.Lock()

    async def load_mcp_config(
        self,
        user_id: int,
        conversation_id: int,
        db: Session
    ) -> List[Dict[str, Any]]:
        """
        Load MCP server configurations for a user and conversation
        Returns system servers from settings + user servers from database, filtered by conversation toggle state
        
        Args:
            user_id: ID of the user
            conversation_id: ID of the conversation
            db: Database session
            
        Returns:
            List of enabled server configs (as dicts)
        """
        # Get default servers from settings (these are NOT in database)
        default_servers = settings.default_mcp_servers_list
        
        # Get user's custom servers from database
        user_servers = (
            db.query(MCPServer)
            .filter(
                (MCPServer.user_id == user_id) &
                (MCPServer.is_active == True)
            )
            .all()
        )
        
        # Convert user DB servers to dict format
        user_server_dicts = []
        for server in user_servers:
            server_dict = {
                "name": server.name,
                "transport": server.transport,
            }
            if server.url:
                server_dict["url"] = server.url
            if server.command:
                server_dict["command"] = server.command
            if server.args:
                server_dict["args"] = server.args
            if server.headers:
                server_dict["headers"] = server.headers
            user_server_dicts.append(server_dict)
        
        # Merge default + user servers
        all_servers = default_servers + user_server_dicts

        if not all_servers:
            return []

        # Get conversation-specific toggle states
        toggle_states = (
            db.query(ConversationMCPState)
            .filter(ConversationMCPState.conversation_id == conversation_id)
            .all()
        )
        
        # Build toggle state map
        toggle_map = {state.server_name: state.is_enabled for state in toggle_states}

        # Filter servers by toggle state (default: enabled if no toggle state exists)
        enabled_servers = [
            server for server in all_servers
            if toggle_map.get(server["name"], True)  # Default to enabled
        ]

        return enabled_servers

    def build_client_config(self, servers: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """
        Build MultiServerMCPClient configuration from server configs
        
        Args:
            servers: List of server config dicts
            
        Returns:
            Dict suitable for MultiServerMCPClient initialization
            Format: {server_name: {transport: ..., url/command/args: ...}}
        """
        config = {}
        
        for server in servers:
            name = server.get("name")
            transport = server.get("transport")
            
            if not name or not transport:
                print(f"Warning: Server missing name or transport: {server}")
                continue
            
            server_config: Dict[str, Any] = {
                "transport": transport
            }
            
            if transport == "streamable_http":
                url = server.get("url")
                if not url:
                    print(f"Warning: Server '{name}' has streamable_http transport but no URL")
                    continue
                server_config["url"] = url
                if "headers" in server and server["headers"]:
                    server_config["headers"] = server["headers"]
                    
            elif transport == "stdio":
                command = server.get("command")
                if not command:
                    print(f"Warning: Server '{name}' has stdio transport but no command")
                    continue
                server_config["command"] = command
                if "args" in server and server["args"]:
                    server_config["args"] = server["args"]
            
            config[name] = server_config
        
        return config

    async def get_tools(self, client: Any) -> List[Any]:
        """
        Get tools from MCP client
        
        Args:
            client: MultiServerMCPClient instance
            
        Returns:
            List of LangChain tools
        """
        try:
            tools = await client.get_tools()
            return tools
        except Exception as e:
            print(f"Error loading tools from MCP client: {e}")
            return []

    async def create_client(
        self,
        user_id: int,
        conversation_id: int,
        db: Session
    ) -> Optional[Any]:
        """
        Create and cache MCP client for a conversation
        
        Args:
            user_id: ID of the user
            conversation_id: ID of the conversation
            db: Database session
            
        Returns:
            MultiServerMCPClient instance or None if no servers configured
        """
        async with self._lock:
            # Check cache first
            if conversation_id in self._clients_cache:
                return self._clients_cache[conversation_id]

            # Load server configurations
            servers = await self.load_mcp_config(user_id, conversation_id, db)
            
            if not servers:
                return None

            # Build client configuration
            client_config = self.build_client_config(servers)
            
            if not client_config:
                return None

            try:
                # Import here to avoid circular imports
                from langchain_mcp_adapters.client import MultiServerMCPClient
                
                # Create MCP client
                client = MultiServerMCPClient(client_config)
                
                # Cache the client
                self._clients_cache[conversation_id] = client
                
                return client
                
            except Exception as e:
                print(f"Error creating MCP client: {e}")
                return None

    async def cleanup_client(self, conversation_id: int):
        """
        Clean up cached MCP client for a conversation
        
        Args:
            conversation_id: ID of the conversation
        """
        async with self._lock:
            if conversation_id in self._clients_cache:
                try:
                    # Close the client if it has a close method
                    client = self._clients_cache[conversation_id]
                    if hasattr(client, 'close'):
                        await client.close()
                except Exception as e:
                    print(f"Error closing MCP client: {e}")
                finally:
                    del self._clients_cache[conversation_id]

    async def reload_client(
        self,
        user_id: int,
        conversation_id: int,
        db: Session
    ) -> Optional[Any]:
        """
        Reload MCP client (useful after server configuration changes)
        
        Args:
            user_id: ID of the user
            conversation_id: ID of the conversation
            db: Database session
            
        Returns:
            New MultiServerMCPClient instance or None
        """
        await self.cleanup_client(conversation_id)
        return await self.create_client(user_id, conversation_id, db)

    def get_cached_client(self, conversation_id: int) -> Optional[Any]:
        """
        Get cached MCP client without async operations
        
        Args:
            conversation_id: ID of the conversation
            
        Returns:
            Cached MultiServerMCPClient or None
        """
        return self._clients_cache.get(conversation_id)


# Global singleton instance
mcp_manager = MCPManager()

