"""
Chat Session Manager
Manages active streaming sessions, stop signals, and tool confirmation waiters
"""

import asyncio
from typing import Dict, Optional
from dataclasses import dataclass, field


@dataclass
class SessionState:
    """
    State for an active chat session
    Manages SSE queue, stop signals, and tool confirmation waiters
    """
    conversation_id: int
    sse_queue: asyncio.Queue
    stop_event: asyncio.Event
    confirmation_waiters: Dict[int, asyncio.Future] = field(default_factory=dict)
    is_active: bool = True


class ChatSessionManager:
    """
    Manages active chat sessions for streaming
    Thread-safe with asyncio.Lock for concurrent access
    """

    def __init__(self):
        self._active_sessions: Dict[int, SessionState] = {}
        self._lock = asyncio.Lock()

    async def create_session(self, conversation_id: int) -> SessionState:
        """
        Create a new session for a conversation
        
        Args:
            conversation_id: ID of the conversation
            
        Returns:
            SessionState: The created session state
        """
        async with self._lock:
            # If session already exists, clean it up first
            if conversation_id in self._active_sessions:
                await self._cleanup_session_internal(conversation_id)

            # Create new session
            session = SessionState(
                conversation_id=conversation_id,
                sse_queue=asyncio.Queue(),
                stop_event=asyncio.Event(),
                confirmation_waiters={},
                is_active=True
            )
            self._active_sessions[conversation_id] = session
            return session

    async def get_session(self, conversation_id: int) -> Optional[SessionState]:
        """
        Get an existing session
        
        Args:
            conversation_id: ID of the conversation
            
        Returns:
            Optional[SessionState]: The session state if it exists, None otherwise
        """
        async with self._lock:
            return self._active_sessions.get(conversation_id)

    async def stop_session(self, conversation_id: int) -> bool:
        """
        Stop an active session by setting the stop event
        
        Args:
            conversation_id: ID of the conversation
            
        Returns:
            bool: True if session was stopped, False if not found
        """
        async with self._lock:
            session = self._active_sessions.get(conversation_id)
            if session and session.is_active:
                session.stop_event.set()
                session.is_active = False
                return True
            return False

    async def cleanup_session(self, conversation_id: int):
        """
        Clean up a session and remove it from active sessions
        Also cleans up MCP client if any
        
        Args:
            conversation_id: ID of the conversation
        """
        # Cleanup MCP client first
        try:
            from services.mcp_manager import mcp_manager
            await mcp_manager.cleanup_client(conversation_id)
        except Exception as e:
            print(f"Error cleaning up MCP client: {e}")
        
        async with self._lock:
            await self._cleanup_session_internal(conversation_id)

    async def _cleanup_session_internal(self, conversation_id: int):
        """
        Internal cleanup method (assumes lock is already held)
        
        Args:
            conversation_id: ID of the conversation
        """
        session = self._active_sessions.get(conversation_id)
        if session:
            # Cancel any pending confirmation waiters
            for future in session.confirmation_waiters.values():
                if not future.done():
                    future.cancel()
            
            # Mark as inactive
            session.is_active = False
            
            # Remove from active sessions
            del self._active_sessions[conversation_id]

    async def add_confirmation_waiter(
        self, conversation_id: int, action_id: int
    ) -> Optional[asyncio.Future]:
        """
        Add a confirmation waiter for a tool execution
        
        Args:
            conversation_id: ID of the conversation
            action_id: ID of the agent action
            
        Returns:
            Optional[asyncio.Future]: Future that will be resolved when user confirms/rejects
        """
        async with self._lock:
            session = self._active_sessions.get(conversation_id)
            if session and session.is_active:
                future = asyncio.Future()
                session.confirmation_waiters[action_id] = future
                return future
            return None

    async def resolve_confirmation(
        self, conversation_id: int, action_id: int, approved: bool, user_note: Optional[str] = None
    ) -> bool:
        """
        Resolve a confirmation waiter with user's decision
        
        Args:
            conversation_id: ID of the conversation
            action_id: ID of the agent action
            approved: Whether the user approved the action
            user_note: Optional note from the user
            
        Returns:
            bool: True if waiter was resolved, False if not found
        """
        async with self._lock:
            session = self._active_sessions.get(conversation_id)
            if session:
                future = session.confirmation_waiters.get(action_id)
                if future and not future.done():
                    future.set_result({"approved": approved, "user_note": user_note})
                    del session.confirmation_waiters[action_id]
                    return True
            return False

    async def get_active_session_count(self) -> int:
        """
        Get the count of active sessions
        
        Returns:
            int: Number of active sessions
        """
        async with self._lock:
            return len(self._active_sessions)

    async def is_session_active(self, conversation_id: int) -> bool:
        """
        Check if a session is active
        
        Args:
            conversation_id: ID of the conversation
            
        Returns:
            bool: True if session is active, False otherwise
        """
        async with self._lock:
            session = self._active_sessions.get(conversation_id)
            return session is not None and session.is_active


# Global singleton instance
chat_session_manager = ChatSessionManager()

