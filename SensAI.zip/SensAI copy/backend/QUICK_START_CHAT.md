# Quick Start Guide - Chat Feature

## Prerequisites

- Python 3.9+ installed
- Virtual environment activated (`.venv`)
- An LLM endpoint (OpenAI API or local Ollama)

## Setup Steps

### 1. Install Dependencies

```bash
cd backend
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment

Copy the template and edit `.env`:

```bash
# Create .env from template
cat ENV_TEMPLATE.txt > .env

# Edit .env with your settings
# At minimum, set:
# - SECRET_KEY (generate a random string)
# - LLM configuration (OpenAI or Ollama)
```

**For OpenAI:**
```bash
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=sk-your-api-key
LLM_MODEL=gpt-3.5-turbo
```

**For Ollama (Local):**
```bash
# First install and run Ollama: https://ollama.ai
# Then pull a model: ollama pull llama2

LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=not-needed
LLM_MODEL=llama2
```

### 3. Initialize Database

```bash
python init_chat_db.py
```

This creates all necessary tables for the chat feature.

### 4. Start the Server

```bash
python app.py
```

The server will start on http://localhost:8080

### 5. Test the API

Open the interactive API docs:
```
http://localhost:8080/docs
```

## Basic Usage Example

### 1. Register/Login to get JWT token

```bash
# Register
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "username": "testuser",
    "password": "password123"
  }'

# Response includes token:
# {"user": {...}, "token": {"access_token": "eyJ...", "token_type": "bearer"}}
```

### 2. Create a conversation

```bash
export TOKEN="your-jwt-token-here"

curl -X POST http://localhost:8080/api/chat/conversations \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title": "My First Chat"}'

# Response: {"id": 1, "title": "My First Chat", ...}
```

### 3. Send a message

```bash
curl -X POST http://localhost:8080/api/chat/conversations/1/messages \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content": "Hello! Can you help me?"}'

# Response: {"message_id": 1, "conversation_id": 1}
```

### 4. Stream the AI response

```bash
# Open SSE connection to see streaming response
curl -N "http://localhost:8080/api/chat/conversations/1/stream?token=$TOKEN"

# You'll see events like:
# event: status
# data: {"type": "thinking", "message": "AI is thinking..."}
#
# event: content
# data: {"delta": "Hello", "message_id": 2}
#
# event: content
# data: {"delta": "! How", "message_id": 2}
# ...
```

### 5. Get conversation history

```bash
curl http://localhost:8080/api/chat/conversations/1 \
  -H "Authorization: Bearer $TOKEN"

# Returns full conversation with all messages and actions
```

## Frontend Integration

### Connect to SSE Stream

```javascript
const token = localStorage.getItem('token');
const conversationId = 1;

// Send message first
const response = await fetch(`/api/chat/conversations/${conversationId}/messages`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ content: 'Hello!' })
});

// Then open SSE stream
const eventSource = new EventSource(
  `/api/chat/conversations/${conversationId}/stream?token=${token}`
);

eventSource.addEventListener('content', (e) => {
  const { delta } = JSON.parse(e.data);
  // Append delta to message UI
  console.log('Token:', delta);
});

eventSource.addEventListener('status', (e) => {
  const { type, message } = JSON.parse(e.data);
  console.log('Status:', type, message);
});

eventSource.addEventListener('message_complete', (e) => {
  console.log('Message complete');
  eventSource.close();
});

eventSource.onerror = (e) => {
  console.error('SSE error:', e);
  eventSource.close();
};
```

### Add Message Feedback

```javascript
// Like a message
await fetch(`/api/chat/messages/${messageId}/feedback`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    feedback_type: 'like',
    reason: 'Very helpful!'
  })
});
```

### Stop Generation

```javascript
await fetch(`/api/chat/conversations/${conversationId}/stop`, {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}` }
});
```

## Troubleshooting

### "Could not validate credentials"
- Check that your JWT token is valid
- Token might be expired (default: 30 minutes)
- Re-login to get a new token

### "No active session"
- Send a message first before opening SSE stream
- Make sure the message was sent successfully

### LLM connection errors
- **OpenAI**: Verify API key is correct
- **Ollama**: Make sure Ollama is running (`ollama serve`)
- Check LLM_BASE_URL is correct
- Check network connectivity

### Database errors
- Run `python init_chat_db.py` to create/update tables
- Check file permissions for SQLite database
- For production, consider PostgreSQL

### SSE not streaming
- Check browser console for connection errors
- Verify CORS settings allow your frontend origin
- Some proxies/CDNs buffer SSE - disable buffering
- Check network tab to see if connection is established

## Next Steps

1. **Review Full Documentation**: See `CHAT_FEATURE.md` for complete API reference
2. **Customize Agent**: Modify `agents/chat_agent.py` to add tools and capabilities
3. **Add Tools**: Implement tool calling with confirmation support
4. **RAG Integration**: Add document retrieval to the agent workflow
5. **MCP Support**: Future enhancement for Model Context Protocol

## Production Checklist

- [ ] Use PostgreSQL instead of SQLite
- [ ] Set up Redis for distributed session management
- [ ] Configure proper CORS origins
- [ ] Use environment-specific settings
- [ ] Set up logging and monitoring
- [ ] Implement rate limiting
- [ ] Add proper error tracking
- [ ] Set up SSL/TLS
- [ ] Configure database backups
- [ ] Set up health checks

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review `CHAT_FEATURE.md` for detailed documentation
3. Check FastAPI docs at `/docs` endpoint
4. Review LangChain documentation for agent customization

