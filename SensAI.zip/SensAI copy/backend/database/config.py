"""
Database Configuration
Handles database connection and session management
Generic configuration that works with SQLite, PostgreSQL, MySQL, etc.
"""

from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from config.settings import settings

# Create database engine
# This will work with any database URL (SQLite, PostgreSQL, MySQL, etc.)
engine = create_engine(
    settings.DATABASE_URL,
    # SQLite-specific settings (ignored by other databases)
    connect_args={"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {},
    # Connection pool settings (useful for PostgreSQL/MySQL)
    pool_pre_ping=True,
)

# Enable foreign key constraints for SQLite
# This is required for cascade deletes to work properly
if settings.DATABASE_URL.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

# Create SessionLocal class for database sessions
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """
    Dependency function to get database session
    Yields a database session and ensures it's closed after use
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """
    Initialize database tables
    Creates all tables defined in models.py
    """
    from .models import Base
    Base.metadata.create_all(bind=engine)
    print("✅ Database tables created successfully")

