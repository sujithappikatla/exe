"""
Database Models
SQLAlchemy ORM models for database tables
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, ForeignKey, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class User(Base):
    """
    User model for storing user information
    This model is database-agnostic and will work with SQLite, PostgreSQL, MySQL, etc.
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    conversations = relationship("Conversation", back_populates="user", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<User(id={self.id}, username={self.username}, email={self.email})>"


class Conversation(Base):
    """
    Conversation model for storing chat conversations
    Each conversation belongs to a user and contains multiple messages
    """
    __tablename__ = "conversations"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(500), nullable=True)  # Auto-generated from first message
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    user = relationship("User", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan", order_by="Message.created_at")
    mcp_states = relationship("ConversationMCPState", back_populates="conversation", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Conversation(id={self.id}, user_id={self.user_id}, title={self.title})>"


class Message(Base):
    """
    Message model for storing individual messages in conversations
    Supports user, assistant, and system roles
    """
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False, index=True)
    role = Column(String(50), nullable=False)  # 'user', 'assistant', 'system'
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    conversation = relationship("Conversation", back_populates="messages")
    actions = relationship("AgentAction", back_populates="message", cascade="all, delete-orphan", order_by="AgentAction.created_at")
    feedback = relationship("MessageFeedback", back_populates="message", uselist=False, cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Message(id={self.id}, conversation_id={self.conversation_id}, role={self.role})>"


class AgentAction(Base):
    """
    AgentAction model for tracking all agent activities during message processing
    Stores tool calls, thinking steps, RAG retrievals, web searches, etc.
    """
    __tablename__ = "agent_actions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    message_id = Column(Integer, ForeignKey("messages.id"), nullable=False, index=True)
    action_type = Column(String(100), nullable=False)  # 'thinking', 'tool_call', 'rag_retrieval', 'web_search', 'tool_confirmation_request'
    action_data = Column(JSON, nullable=True)  # Stores tool details, search results, etc.
    status = Column(String(50), nullable=False, default="pending")  # 'pending', 'approved', 'rejected', 'completed', 'cancelled'
    user_response = Column(Text, nullable=True)  # For confirmations
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    message = relationship("Message", back_populates="actions")

    def __repr__(self):
        return f"<AgentAction(id={self.id}, message_id={self.message_id}, action_type={self.action_type}, status={self.status})>"


class MessageFeedback(Base):
    """
    MessageFeedback model for storing user feedback (like/dislike) on messages
    One feedback per message, can be updated
    """
    __tablename__ = "message_feedback"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    message_id = Column(Integer, ForeignKey("messages.id"), nullable=False, unique=True, index=True)
    feedback_type = Column(String(20), nullable=False)  # 'like', 'dislike'
    reason = Column(Text, nullable=True)  # Optional reason for feedback
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    message = relationship("Message", back_populates="feedback")

    def __repr__(self):
        return f"<MessageFeedback(id={self.id}, message_id={self.message_id}, feedback_type={self.feedback_type})>"


class MCPServer(Base):
    """
    MCPServer model for storing MCP (Model Context Protocol) server configurations
    Can be system-wide (user_id=NULL) or user-specific
    System servers are added from DEFAULT_MCP_SERVERS config and cannot be deleted by users
    """
    __tablename__ = "mcp_servers"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)  # NULL for system servers
    name = Column(String(255), nullable=False, index=True)  # Unique identifier for the server
    transport = Column(String(50), nullable=False)  # 'stdio' or 'streamable_http'
    
    # For streamable_http transport
    url = Column(String(500), nullable=True)  # HTTP endpoint URL
    
    # For stdio transport
    command = Column(String(500), nullable=True)  # Command to run (e.g., 'python', 'node')
    args = Column(JSON, nullable=True)  # Arguments as JSON array (e.g., ["/path/to/server.py"])
    
    # Optional headers for HTTP auth (streamable_http)
    headers = Column(JSON, nullable=True)  # Headers as JSON object
    
    # Status flags
    is_system = Column(Boolean, default=False, nullable=False)  # True if from DEFAULT_MCP_SERVERS
    is_active = Column(Boolean, default=True, nullable=False)  # Active/Inactive flag
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    user = relationship("User", backref="mcp_servers")

    def __repr__(self):
        return f"<MCPServer(id={self.id}, name={self.name}, transport={self.transport}, is_system={self.is_system})>"


class ConversationMCPState(Base):
    """
    ConversationMCPState model for tracking runtime MCP server toggle state per conversation
    Tracks which MCP servers are enabled/disabled for each conversation
    This is a runtime state and resets when conversation is reloaded (default: all enabled)
    """
    __tablename__ = "conversation_mcp_states"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False, index=True)
    server_name = Column(String(255), nullable=False)  # Name of the MCP server
    is_enabled = Column(Boolean, default=True, nullable=False)  # Enabled/Disabled for this conversation
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    conversation = relationship("Conversation", back_populates="mcp_states")

    def __repr__(self):
        return f"<ConversationMCPState(id={self.id}, conversation_id={self.conversation_id}, server_name={self.server_name}, is_enabled={self.is_enabled})>"

