"""
SSE (Server-Sent Events) Utilities
Helper functions for formatting and sending SSE events
"""

import json
from typing import Any, Dict, Optional
from jose import jwt, JWTError
from fastapi import HTTPException, status
from config.settings import settings


def format_sse_event(event: str, data: Dict[str, Any], event_id: Optional[str] = None) -> str:
    """
    Format data as an SSE event
    
    Args:
        event: Event type (e.g., 'status', 'content', 'error')
        data: Event data to be JSON-encoded
        event_id: Optional event ID
        
    Returns:
        str: Formatted SSE event string
    """
    message = f"event: {event}\n"
    if event_id:
        message += f"id: {event_id}\n"
    message += f"data: {json.dumps(data)}\n\n"
    return message


def format_sse_ping() -> str:
    """
    Format a ping event for keepalive
    
    Returns:
        str: Formatted ping event
    """
    return ": ping\n\n"


def verify_token_from_query(token: str) -> Dict[str, Any]:
    """
    Verify JWT token from query parameter
    Used for SSE authentication since EventSource doesn't support custom headers
    
    Args:
        token: JWT token from query parameter
        
    Returns:
        Dict[str, Any]: Decoded token payload
        
    Raises:
        HTTPException: If token is invalid
    """
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        return payload
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials"
        )


def create_status_event(status_type: str, message: str) -> str:
    """
    Create an SSE status event
    
    Args:
        status_type: Type of status (thinking, tool_execution, rag_retrieval, web_search)
        message: Status message
        
    Returns:
        str: Formatted SSE event
    """
    return format_sse_event("status", {"type": status_type, "message": message})


def create_content_event(delta: str, message_id: int) -> str:
    """
    Create an SSE content event for streaming LLM tokens
    
    Args:
        delta: Token/content chunk
        message_id: ID of the message being streamed
        
    Returns:
        str: Formatted SSE event
    """
    return format_sse_event("content", {"delta": delta, "message_id": message_id})


def create_tool_confirmation_event(
    action_id: int, tool_name: str, tool_args: Dict[str, Any], description: str
) -> str:
    """
    Create an SSE tool confirmation event
    
    Args:
        action_id: ID of the agent action
        tool_name: Name of the tool to be executed
        tool_args: Arguments for the tool
        description: Human-readable description
        
    Returns:
        str: Formatted SSE event
    """
    return format_sse_event(
        "tool_confirmation",
        {
            "action_id": action_id,
            "tool_name": tool_name,
            "tool_args": tool_args,
            "description": description,
        },
    )


def create_action_complete_event(
    action_id: int, action_type: str, result: Optional[str] = None
) -> str:
    """
    Create an SSE action complete event
    
    Args:
        action_id: ID of the agent action
        action_type: Type of action that completed
        result: Optional result summary
        
    Returns:
        str: Formatted SSE event
    """
    return format_sse_event(
        "action_complete",
        {"action_id": action_id, "action_type": action_type, "result": result},
    )


def create_message_complete_event(message_id: int) -> str:
    """
    Create an SSE message complete event
    
    Args:
        message_id: ID of the completed message
        
    Returns:
        str: Formatted SSE event
    """
    return format_sse_event("message_complete", {"message_id": message_id})


def create_error_event(message: str, code: Optional[str] = None) -> str:
    """
    Create an SSE error event
    
    Args:
        message: Error message
        code: Optional error code
        
    Returns:
        str: Formatted SSE event
    """
    data = {"message": message}
    if code:
        data["code"] = code
    return format_sse_event("error", data)

