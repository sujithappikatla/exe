"""
Schemas package
Contains all Pydantic schemas for request/response validation
"""

from .user import UserBase, UserCreate, UserLogin, UserResponse, UserInDB
from .auth import Token, TokenData, AuthResponse, MessageResponse
from .password import PasswordChange
from .chat import (
    MessageCreate,
    ChatMessageResponse,
    ConversationCreate,
    ConversationBase,
    ConversationListResponse,
    ConversationDetailResponse,
    SendMessageResponse,
    ToolConfirmation,
    StopGenerationResponse,
    MessageFeedbackCreate,
    MessageFeedbackResponse,
    AgentActionResponse,
    SSEStatusEvent,
    SSEContentEvent,
    SSEToolConfirmationEvent,
    SSEActionCompleteEvent,
    SSEMessageCompleteEvent,
    SSEErrorEvent,
)
from .mcp import (
    MCPTransportType,
    MCPServerBase,
    MCPServerCreate,
    MCPServerUpdate,
    MCPServerResponse,
    ConversationMCPServerResponse,
    MCPServerToggle,
    MCPServerToggleResponse,
    MCPToolInfo,
    MCPServerToolsResponse,
)

__all__ = [
    "UserBase",
    "UserCreate",
    "UserLogin",
    "UserResponse",
    "UserInDB",
    "Token",
    "TokenData",
    "AuthResponse",
    "MessageResponse",
    "PasswordChange",
    "MessageCreate",
    "ChatMessageResponse",
    "ConversationCreate",
    "ConversationBase",
    "ConversationListResponse",
    "ConversationDetailResponse",
    "SendMessageResponse",
    "ToolConfirmation",
    "StopGenerationResponse",
    "MessageFeedbackCreate",
    "MessageFeedbackResponse",
    "AgentActionResponse",
    "SSEStatusEvent",
    "SSEContentEvent",
    "SSEToolConfirmationEvent",
    "SSEActionCompleteEvent",
    "SSEMessageCompleteEvent",
    "SSEErrorEvent",
    "MCPTransportType",
    "MCPServerBase",
    "MCPServerCreate",
    "MCPServerUpdate",
    "MCPServerResponse",
    "ConversationMCPServerResponse",
    "MCPServerToggle",
    "MCPServerToggleResponse",
    "MCPToolInfo",
    "MCPServerToolsResponse",
]

