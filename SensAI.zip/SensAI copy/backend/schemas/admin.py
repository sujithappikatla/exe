"""
Admin Schemas
Pydantic models for admin-related requests/responses
"""

from typing import List
from pydantic import BaseModel, Field
from .user import UserResponse


class UpdateUserStatus(BaseModel):
    """Schema for updating user account status"""
    account_status: str = Field(..., pattern="^(active|pending)$")


class UpdateUserRole(BaseModel):
    """Schema for updating user role"""
    role: str = Field(..., pattern="^(admin|user)$")


class UserListResponse(BaseModel):
    """Schema for list of users"""
    users: List[UserResponse]
    total: int

