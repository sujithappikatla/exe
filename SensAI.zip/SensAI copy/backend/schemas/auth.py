"""
Authentication Schemas
Pydantic models for authentication-related requests/responses
"""

from pydantic import BaseModel
from .user import UserResponse


class Token(BaseModel):
    """Schema for JWT token response"""
    access_token: str
    token_type: str


class TokenData(BaseModel):
    """Schema for token payload data"""
    user_id: int
    email: str
    username: str


class AuthResponse(BaseModel):
    """Schema for authentication response (login/signup)"""
    user: UserResponse
    token: Token


class MessageResponse(BaseModel):
    """Generic message response"""
    message: str

