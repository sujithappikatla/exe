"""
Chat Schemas
Pydantic schemas for chat-related API requests and responses
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# ============ Agent Action Schemas ============

class AgentActionBase(BaseModel):
    """Base schema for agent actions"""
    action_type: str
    action_data: Optional[Dict[str, Any]] = None
    status: str = "pending"


class AgentActionCreate(AgentActionBase):
    """Schema for creating an agent action"""
    message_id: int


class AgentActionResponse(AgentActionBase):
    """Schema for agent action response"""
    id: int
    message_id: int
    user_response: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ============ Message Feedback Schemas ============

class MessageFeedbackCreate(BaseModel):
    """Schema for creating or updating message feedback"""
    feedback_type: str = Field(..., pattern="^(like|dislike)$")
    reason: Optional[str] = None


class MessageFeedbackResponse(BaseModel):
    """Schema for message feedback response"""
    id: int
    message_id: int
    feedback_type: str
    reason: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ============ Message Schemas ============

class MessageBase(BaseModel):
    """Base schema for messages"""
    role: str
    content: str


class MessageCreate(BaseModel):
    """Schema for creating a message (user sending message)"""
    content: str


class ChatMessageResponse(MessageBase):
    """Schema for chat message response"""
    id: int
    conversation_id: int
    created_at: datetime
    actions: List[AgentActionResponse] = []
    feedback: Optional[MessageFeedbackResponse] = None

    class Config:
        from_attributes = True


# ============ Conversation Schemas ============

class ConversationCreate(BaseModel):
    """Schema for creating a conversation"""
    title: Optional[str] = None


class ConversationBase(BaseModel):
    """Base schema for conversations"""
    id: int
    title: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ConversationListResponse(ConversationBase):
    """Schema for conversation list item (without messages)"""
    message_count: int = 0
    last_message: Optional[str] = None
    last_message_at: Optional[datetime] = None


class ConversationDetailResponse(ConversationBase):
    """Schema for detailed conversation response (with messages)"""
    messages: List[ChatMessageResponse] = []


# ============ Chat Action Schemas ============

class SendMessageResponse(BaseModel):
    """Schema for send message response"""
    message_id: int
    conversation_id: int


class ToolConfirmation(BaseModel):
    """Schema for tool confirmation request"""
    approved: bool
    user_note: Optional[str] = None


class StopGenerationResponse(BaseModel):
    """Schema for stop generation response"""
    message: str
    stopped: bool


# ============ SSE Event Schemas ============

class SSEStatusEvent(BaseModel):
    """Schema for SSE status event"""
    type: str  # 'thinking', 'tool_execution', 'rag_retrieval', 'web_search'
    message: str


class SSEContentEvent(BaseModel):
    """Schema for SSE content event"""
    delta: str
    message_id: int


class SSEToolConfirmationEvent(BaseModel):
    """Schema for SSE tool confirmation event"""
    action_id: int
    tool_name: str
    tool_args: Dict[str, Any]
    description: str


class SSEActionCompleteEvent(BaseModel):
    """Schema for SSE action complete event"""
    action_id: int
    action_type: str
    result: Optional[str] = None


class SSEMessageCompleteEvent(BaseModel):
    """Schema for SSE message complete event"""
    message_id: int


class SSEErrorEvent(BaseModel):
    """Schema for SSE error event"""
    message: str
    code: Optional[str] = None

