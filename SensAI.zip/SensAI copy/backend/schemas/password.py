"""
Password Change Schemas
Pydantic models for password change requests
"""

from pydantic import BaseModel, Field


class PasswordChange(BaseModel):
    """Schema for password change request"""
    current_password: str = Field(..., min_length=1)
    new_password: str = Field(..., min_length=8, max_length=100)

