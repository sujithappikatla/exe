"""
MCP Schemas
Pydantic schemas for MCP (Model Context Protocol) server management
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum


class MCPTransportType(str, Enum):
    """Enum for MCP transport types"""
    STDIO = "stdio"
    STREAMABLE_HTTP = "streamable_http"


# ============ MCP Server Schemas ============

class MCPServerBase(BaseModel):
    """Base schema for MCP servers"""
    name: str = Field(..., min_length=1, max_length=255, description="Unique identifier for the server")
    transport: MCPTransportType = Field(..., description="Transport type: stdio or streamable_http")
    
    # For streamable_http transport
    url: Optional[str] = Field(None, max_length=500, description="HTTP endpoint URL (required for streamable_http)")
    
    # For stdio transport
    command: Optional[str] = Field(None, max_length=500, description="Command to run (required for stdio)")
    args: Optional[List[str]] = Field(None, description="Command arguments as array (for stdio)")
    
    # Optional headers for HTTP auth
    headers: Optional[Dict[str, str]] = Field(default_factory=dict, description="HTTP headers for authentication")
    
    # Status
    is_active: bool = Field(default=True, description="Whether the server is active")


class MCPServerCreate(MCPServerBase):
    """Schema for creating a new MCP server"""
    pass


class MCPServerUpdate(BaseModel):
    """Schema for updating an MCP server"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    transport: Optional[MCPTransportType] = None
    url: Optional[str] = Field(None, max_length=500)
    command: Optional[str] = Field(None, max_length=500)
    args: Optional[List[str]] = None
    headers: Optional[Dict[str, str]] = None
    is_active: Optional[bool] = None


class MCPServerResponse(MCPServerBase):
    """Schema for MCP server response"""
    id: int
    user_id: Optional[int] = None  # None for system servers
    is_system: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ============ Conversation MCP Server Schemas ============

class ConversationMCPServerResponse(MCPServerResponse):
    """
    Schema for MCP server with conversation-specific toggle state
    Extends MCPServerResponse with is_enabled field
    """
    is_enabled: bool = Field(default=True, description="Whether this server is enabled for the conversation")


class MCPServerToggle(BaseModel):
    """Schema for toggling MCP server on/off for a conversation"""
    server_name: str = Field(..., description="Name of the MCP server to toggle")
    is_enabled: bool = Field(..., description="Enable or disable the server")


class MCPServerToggleResponse(BaseModel):
    """Schema for toggle response"""
    server_name: str
    is_enabled: bool
    message: str


# ============ MCP Tools Schema ============

class MCPToolInfo(BaseModel):
    """Schema for MCP tool information"""
    name: str
    description: Optional[str] = None
    input_schema: Optional[Dict[str, Any]] = None


class MCPServerToolsResponse(BaseModel):
    """Schema for listing tools from MCP servers"""
    server_name: str
    tools: List[MCPToolInfo]

