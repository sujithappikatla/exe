"""
Setup Verification Script
Checks that all required components are properly configured
"""

import sys
import os

def check_imports():
    """Check if all required packages can be imported"""
    print("Checking imports...")
    errors = []
    
    packages = [
        ("fastapi", "FastAPI"),
        ("uvicorn", "Uvicorn"),
        ("sqlalchemy", "SQLAlchemy"),
        ("pydantic", "Pydantic"),
        ("langchain", "LangChain"),
        ("langchain_openai", "LangChain OpenAI"),
        ("sse_starlette", "SSE Starlette"),
        ("jose", "Python JOSE"),
        ("passlib", "Passlib"),
    ]
    
    for package, name in packages:
        try:
            __import__(package)
            print(f"  ✅ {name}")
        except ImportError:
            print(f"  ❌ {name} - Not installed")
            errors.append(name)
    
    return errors

def check_env_file():
    """Check if .env file exists"""
    print("\nChecking environment configuration...")
    
    if not os.path.exists(".env"):
        print("  ⚠️  .env file not found")
        print("     Copy ENV_TEMPLATE.txt to .env and configure your settings")
        return False
    
    print("  ✅ .env file exists")
    
    # Check for required variables
    from dotenv import load_dotenv
    load_dotenv()
    
    required = ["SECRET_KEY", "LLM_MODEL"]
    missing = []
    
    for var in required:
        if not os.getenv(var):
            missing.append(var)
    
    if missing:
        print(f"  ⚠️  Missing required variables: {', '.join(missing)}")
        return False
    
    print("  ✅ Required environment variables set")
    return True

def check_database():
    """Check if database can be initialized"""
    print("\nChecking database setup...")
    
    try:
        from database import init_db, engine
        from sqlalchemy import inspect
        
        # Check if tables exist
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        
        expected_tables = ["users", "conversations", "messages", "agent_actions", "message_feedback"]
        existing = [t for t in expected_tables if t in tables]
        missing = [t for t in expected_tables if t not in tables]
        
        if existing:
            print(f"  ✅ Existing tables: {', '.join(existing)}")
        
        if missing:
            print(f"  ⚠️  Missing tables: {', '.join(missing)}")
            print("     Run: python init_chat_db.py")
            return False
        
        print("  ✅ All required tables exist")
        return True
        
    except Exception as e:
        print(f"  ❌ Database error: {e}")
        return False

def check_modules():
    """Check if all custom modules can be imported"""
    print("\nChecking custom modules...")
    errors = []
    
    modules = [
        ("database", "Database"),
        ("schemas", "Schemas"),
        ("routes", "Routes"),
        ("agents", "Agents"),
        ("services", "Services"),
        ("utils.sse", "SSE Utils"),
        ("config.settings", "Settings"),
    ]
    
    for module, name in modules:
        try:
            __import__(module)
            print(f"  ✅ {name}")
        except ImportError as e:
            print(f"  ❌ {name} - {e}")
            errors.append(name)
    
    return errors

def main():
    print("=" * 60)
    print("SensAI Backend - Setup Verification")
    print("=" * 60)
    print()
    
    all_good = True
    
    # Check imports
    import_errors = check_imports()
    if import_errors:
        all_good = False
        print(f"\n❌ Missing packages: {', '.join(import_errors)}")
        print("   Install with: pip install -r requirements.txt")
    
    # Check environment
    env_ok = check_env_file()
    if not env_ok:
        all_good = False
    
    # Check modules
    module_errors = check_modules()
    if module_errors:
        all_good = False
    
    # Check database
    db_ok = check_database()
    if not db_ok:
        all_good = False
    
    # Final summary
    print("\n" + "=" * 60)
    if all_good:
        print("✅ Setup verification passed!")
        print()
        print("Next steps:")
        print("1. Start the server: python app.py")
        print("2. Open API docs: http://localhost:8080/docs")
        print("3. Test the chat endpoints")
        print()
        print("For quick start guide, see: QUICK_START_CHAT.md")
    else:
        print("❌ Setup verification failed")
        print()
        print("Please fix the issues above and run this script again.")
        print()
        print("Common fixes:")
        print("- Install dependencies: pip install -r requirements.txt")
        print("- Create .env: cp ENV_TEMPLATE.txt .env (then edit)")
        print("- Initialize database: python init_chat_db.py")
    print("=" * 60)
    
    return 0 if all_good else 1

if __name__ == "__main__":
    sys.exit(main())

