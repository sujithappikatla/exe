"""
Database Migration Script for Admin Mode
Adds role and account_status columns to existing users table
"""

from database import engine, get_db, User
from sqlalchemy import text

def migrate_database():
    """
    Migrate database to add admin mode fields
    """
    print("Starting database migration for Admin Mode...")
    
    with engine.begin() as connection:
        # Check if columns already exist
        result = connection.execute(text("PRAGMA table_info(users)"))
        columns = [row[1] for row in result]
        
        # Add role column if it doesn't exist
        if 'role' not in columns:
            print("Adding 'role' column to users table...")
            connection.execute(text(
                "ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user' NOT NULL"
            ))
            print("✓ Added 'role' column")
        else:
            print("✓ 'role' column already exists")
        
        # Add account_status column if it doesn't exist
        if 'account_status' not in columns:
            print("Adding 'account_status' column to users table...")
            connection.execute(text(
                "ALTER TABLE users ADD COLUMN account_status VARCHAR(20) DEFAULT 'pending' NOT NULL"
            ))
            print("✓ Added 'account_status' column")
        else:
            print("✓ 'account_status' column already exists")
    
    # Update existing users
    print("\nUpdating existing users...")
    db = next(get_db())
    
    try:
        # Get all users
        users = db.query(User).all()
        
        if not users:
            print("No existing users found.")
        else:
            # Make the first user (by ID) an admin and set all to active
            first_user = min(users, key=lambda u: u.id)
            
            for user in users:
                if user.id == first_user.id:
                    user.role = "admin"
                    user.account_status = "active"
                    print(f"✓ Set user '{user.username}' (ID: {user.id}) as admin with active status")
                else:
                    # Set default role if not set
                    if not hasattr(user, 'role') or user.role is None:
                        user.role = "user"
                    # Set all existing users to active (they were already using the system)
                    if not hasattr(user, 'account_status') or user.account_status is None:
                        user.account_status = "active"
                    print(f"✓ Set user '{user.username}' (ID: {user.id}) as user with active status")
            
            db.commit()
            print(f"\n✓ Updated {len(users)} existing user(s)")
    
    except Exception as e:
        print(f"Error updating users: {e}")
        db.rollback()
    finally:
        db.close()
    
    print("\n✅ Database migration completed successfully!")
    print("\nNOTE: New users will now require admin approval before they can log in.")


if __name__ == "__main__":
    migrate_database()

