# Full Stack Integration Guide

## 🎉 Complete Setup

Your SensAI application is now fully integrated with both frontend and backend working together!

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         Frontend                             │
│                   React + Vite + Tailwind                    │
│                    http://localhost:5173                     │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  Login Page  │  │  Signup Page │  │ Theme Toggle │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│         │                  │                                 │
│         └──────────────────┴──────────────────┐             │
│                                               │             │
│                          ┌────────────────────▼───────┐     │
│                          │   API Service Layer       │     │
│                          │  - Token Management       │     │
│                          │  - Authentication API     │     │
│                          │  - Constants              │     │
│                          └────────────┬──────────────┘     │
└────────────────────────────────────────┼────────────────────┘
                                        │
                                        │ HTTP/HTTPS
                                        │ JSON + JWT
                                        │
┌────────────────────────────────────────▼────────────────────┐
│                         Backend                              │
│                     FastAPI + SQLAlchemy                     │
│                    http://localhost:8000                     │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │    Routes    │  │   Schemas    │  │   Database   │      │
│  │  - Signup    │  │  - Pydantic  │  │  - SQLite    │      │
│  │  - Login     │  │  - Validation│  │  - Users     │      │
│  │  - Logout    │  └──────────────┘  └──────────────┘      │
│  └──────┬───────┘                                           │
│         │                                                    │
│  ┌──────▼───────┐  ┌──────────────┐                        │
│  │   Utils      │  │    Config    │                        │
│  │  - JWT Auth  │  │  - Settings  │                        │
│  │  - Password  │  │  - CORS      │                        │
│  └──────────────┘  └──────────────┘                        │
└─────────────────────────────────────────────────────────────┘
```

## Running the Application

### Terminal 1: Backend

```bash
cd backend
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
python app.py
```

Backend will run on: **http://localhost:8000**

### Terminal 2: Frontend

```bash
cd frontend
npm run dev
```

Frontend will run on: **http://localhost:5173**

## Testing the Integration

### 1. Open the Frontend

Visit: http://localhost:5173

### 2. Sign Up Flow

1. Click on "Sign up" link
2. Fill in the form:
   - Email: `user@example.com`
   - Username: `myusername`
   - Password: `password123`
   - Confirm Password: `password123`
3. Click "Create account"
4. You should see a welcome message!
5. Check browser localStorage - you'll see:
   - `access_token`: Your JWT token
   - `user_data`: Your user information

### 3. Login Flow

1. Go back to Login page
2. Enter your credentials:
   - Email: `user@example.com`
   - Password: `password123`
3. Click "Sign in"
4. Welcome message appears!

### 4. Check Backend

Visit: http://localhost:8000/docs

You can test all endpoints interactively using Swagger UI!

## API Endpoints

### Authentication

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/signup` | Register new user | No |
| POST | `/api/auth/login` | Login user | No |
| POST | `/api/auth/logout` | Logout user | Yes |
| GET | `/api/auth/me` | Get current user | Yes |

### Health & Info

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | API info |
| GET | `/health` | Health check |
| GET | `/docs` | Interactive API docs |

## Data Flow

### Sign Up

```
1. User fills form → Frontend validates
2. Frontend sends POST to /api/auth/signup
   {
     "email": "user@example.com",
     "username": "johndoe",
     "password": "securepass123"
   }
3. Backend validates data (Pydantic)
4. Backend hashes password (bcrypt)
5. Backend creates user in database
6. Backend creates JWT token
7. Backend returns user + token
8. Frontend stores token in localStorage
9. User is logged in!
```

### Login

```
1. User enters credentials → Frontend validates
2. Frontend sends POST to /api/auth/login
   {
     "email": "user@example.com",
     "password": "securepass123"
   }
3. Backend finds user by email
4. Backend verifies password hash
5. Backend creates JWT token
6. Backend returns user + token
7. Frontend stores token in localStorage
8. User is logged in!
```

### Logout

```
1. User clicks logout
2. Frontend sends POST to /api/auth/logout
   Headers: { Authorization: "Bearer <token>" }
3. Backend verifies token
4. Backend returns success message
5. Frontend clears token from localStorage
6. User is logged out!
```

## JWT Token Structure

```json
{
  "user_id": 1,
  "email": "user@example.com",
  "username": "johndoe",
  "exp": 1760646255
}
```

Token expires after 30 minutes (configurable in `.env`).

## Security Features

- ✅ Password hashing with bcrypt
- ✅ JWT token authentication
- ✅ Token expiration
- ✅ CORS protection
- ✅ Input validation (Pydantic)
- ✅ SQL injection protection (SQLAlchemy ORM)
- ✅ Automatic token storage/removal
- ✅ 401 handling on frontend

## Environment Variables

### Backend (.env)

```env
DATABASE_URL=sqlite:///./sensai.db
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
HOST=0.0.0.0
PORT=8000
RELOAD=True
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
```

### Frontend (.env)

```env
VITE_API_BASE_URL=http://localhost:8000
```

## Database

### Current Setup

- **Type**: SQLite
- **File**: `backend/sensai.db`
- **Tables**: `users`

### User Table Schema

```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);
```

### Switching Database

To switch to PostgreSQL or MySQL, just update `DATABASE_URL` in `.env`:

```env
# PostgreSQL
DATABASE_URL=postgresql://user:password@localhost/dbname

# MySQL
DATABASE_URL=mysql+pymysql://user:password@localhost/dbname
```

The code is database-agnostic!

## Project Structure

```
SensAI/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ui/              # Shadcn components
│   │   │   └── ThemeToggle.jsx
│   │   ├── pages/
│   │   │   ├── LoginPage.jsx
│   │   │   └── SignUpPage.jsx
│   │   ├── services/
│   │   │   ├── api.js          # API calls + token management
│   │   │   └── constants.js    # API URLs and constants
│   │   ├── hooks/
│   │   │   └── useTheme.js
│   │   └── App.jsx
│   └── package.json
│
└── backend/
    ├── config/
    │   └── settings.py          # Environment configuration
    ├── database/
    │   ├── models.py           # SQLAlchemy models
    │   └── config.py           # DB connection
    ├── routes/
    │   └── auth.py             # Auth endpoints
    ├── schemas/
    │   ├── user.py             # User schemas
    │   └── auth.py             # Auth schemas
    ├── utils/
    │   └── auth.py             # JWT + password utilities
    ├── app.py                   # FastAPI app
    └── requirements.txt
```

## Browser Developer Tools

### Check Authentication

1. Open DevTools (F12)
2. Go to "Application" → "Local Storage"
3. Check for:
   - `access_token`
   - `user_data`

### Check Network Requests

1. Open DevTools → "Network" tab
2. Sign up or log in
3. See the API calls:
   - Request payload
   - Response data
   - Headers (including Authorization)

## Troubleshooting

### Backend not starting

```bash
# Check if port 8000 is already in use
lsof -ti:8000

# Kill the process
kill $(lsof -ti:8000)

# Restart backend
cd backend && source .venv/bin/activate && python app.py
```

### Frontend not connecting

1. Check `.env` file has correct `VITE_API_BASE_URL`
2. Restart frontend dev server
3. Clear browser cache and localStorage

### Database errors

```bash
# Delete and recreate database
cd backend
rm sensai.db
python app.py  # Will auto-create tables
```

### CORS errors

1. Check backend `.env` has correct `CORS_ORIGINS`
2. Ensure frontend URL is included
3. Restart backend

## Next Steps

### Recommended Features to Add

1. **Dashboard Page** - Protected route after login
2. **Password Reset** - Email-based password recovery
3. **Email Verification** - Verify email on signup
4. **User Profile** - Edit user information
5. **Refresh Tokens** - Longer sessions
6. **Remember Me** - Optional longer token expiration
7. **Social Auth** - Google, GitHub, etc.
8. **2FA** - Two-factor authentication

### Production Deployment

1. **Backend**:
   - Use PostgreSQL/MySQL
   - Set strong `SECRET_KEY`
   - Disable debug mode
   - Set up HTTPS
   - Use production ASGI server (Gunicorn + Uvicorn)
   - Set up logging and monitoring

2. **Frontend**:
   - Build for production: `npm run build`
   - Deploy to Vercel, Netlify, or static hosting
   - Update `VITE_API_BASE_URL` to production backend URL

3. **Database**:
   - Set up automated backups
   - Use connection pooling
   - Set up migrations with Alembic

## Success! 🎉

Your full-stack authentication system is complete and working!

- ✅ Modern React frontend with Tailwind CSS
- ✅ FastAPI backend with JWT authentication
- ✅ SQLAlchemy ORM with SQLite (switchable to any DB)
- ✅ Proper code organization and separation
- ✅ Token-based authentication
- ✅ Dark/light theme support
- ✅ Form validation
- ✅ Error handling
- ✅ CORS configured
- ✅ Production-ready architecture

Open http://localhost:5173 and start testing! 🚀

