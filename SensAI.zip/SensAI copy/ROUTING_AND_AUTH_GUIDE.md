# Routing and Authentication Guide

## 🎯 Overview

The application now has a complete authentication system with protected routes, a main dashboard with sidebar navigation, and a settings page.

## 📁 New Structure

### Frontend Components

```
frontend/src/
├── contexts/
│   └── AuthContext.jsx          # Global auth state management
├── components/
│   ├── ProtectedRoute.jsx       # Protects authenticated pages
│   ├── PublicRoute.jsx          # Prevents logged-in users from auth pages
│   ├── Sidebar.jsx              # Collapsible sidebar with navigation
│   └── ...
├── layouts/
│   └── MainLayout.jsx           # Main layout with sidebar
├── pages/
│   ├── LoginPage.jsx            # Login page (updated)
│   ├── SignUpPage.jsx           # Signup page (updated)
│   ├── HomePage.jsx             # Dashboard after login
│   └── SettingsPage.jsx         # User settings
└── App.jsx                       # Router configuration
```

### Backend Endpoints

```
backend/
├── routes/auth.py               # Added change-password endpoint
└── schemas/password.py          # Password change schema
```

## 🚦 Routing System

### Public Routes (Unauthenticated)

- `/login` - Login page
- `/signup` - Sign up page

**Behavior**: If user is already authenticated, automatically redirects to `/` (home page)

### Protected Routes (Authenticated)

- `/` - Home/Dashboard page
- `/settings` - Settings page

**Behavior**: If user is not authenticated, automatically redirects to `/login`

### Route Protection

```javascript
// Public Route Example
<Route
  path="/login"
  element={
    <PublicRoute>
      <LoginPage />
    </PublicRoute>
  }
/>

// Protected Route Example
<Route
  path="/"
  element={
    <ProtectedRoute>
      <MainLayout />
    </ProtectedRoute>
  }
>
  <Route index element={<HomePage />} />
  <Route path="settings" element={<SettingsPage />} />
</Route>
```

## 🔐 Authentication Context

### Features

- **Global state management** for user authentication
- **Persistent login** using localStorage
- **Auto-login check** on app load
- **Login/logout** functions
- **User data updates**

### Usage

```javascript
import { useAuth } from '@/contexts/AuthContext';

function MyComponent() {
  const { user, isAuthenticated, login, logout, updateUser } = useAuth();
  
  // Access user data
  console.log(user.username);
  
  // Check if authenticated
  if (isAuthenticated) {
    // Show authenticated UI
  }
  
  // Logout
  await logout();
}
```

## 🎨 Main Layout & Sidebar

### Sidebar Features

1. **Collapsible Design**
   - Click arrow button to collapse/expand
   - Collapsed: Shows only icons
   - Expanded: Shows icons + labels

2. **Site Name**
   - Displays "SensAI" at the top
   - Hidden when collapsed

3. **Navigation**
   - Home button (currently the only nav item)
   - Easy to add more navigation links

4. **User Menu (Bottom)**
   - User avatar with username and email
   - Click to show popup menu with:
     - **Settings** - Navigate to settings page
     - **Logout** - Sign out and redirect to login

### Sidebar States

**Expanded (default)**:
```
┌─────────────────────┐
│ SensAI          ◀   │
├─────────────────────┤
│ 🏠 Home            │
│                     │
│                     │
├─────────────────────┤
│ 👤 username        │
│    email@email.com  │
└─────────────────────┘
```

**Collapsed**:
```
┌───┐
│ ▶ │
├───┤
│ 🏠 │
│   │
│   │
├───┤
│ 👤 │
└───┘
```

## ⚙️ Settings Page

### Sections

1. **User Details**
   - Email (read-only)
   - Username (read-only)
   - Note about contacting support for changes

2. **Change Password**
   - Current password field
   - New password field (min 8 characters)
   - Confirm new password field
   - Validation:
     - All fields required
     - New password must be 8+ chars
     - Passwords must match
   - Success/error messages

3. **Appearance (Theme)**
   - Light theme button
   - Dark theme button
   - Shows current theme
   - Immediately applies theme change

## 🏠 Home Page

### Current Features

- Welcome message with username
- Placeholder cards for future features:
  - Quick Stats
  - Recent Activity
  - Notifications

### Ready for Expansion

The home page is designed to be easily extended with:
- Real statistics
- Activity feeds
- Charts and graphs
- Quick actions

## 🔄 User Flow

### New User Flow

1. Visit application → Redirected to `/login`
2. Click "Sign up" → Navigate to `/signup`
3. Fill form and submit
4. **Auto-logged in** with success animation
5. Click "Continue to Dashboard" → `/` (home page)
6. See main layout with sidebar

### Returning User Flow

1. Visit application
2. If token exists → Auto-login → `/` (home page)
3. If no token → Redirected to `/login`
4. Enter credentials
5. Login successful → `/` (home page)

### Settings Flow

1. Click on username at bottom of sidebar
2. Popup appears with "Settings" and "Logout"
3. Click "Settings" → Navigate to `/settings`
4. Change password or theme
5. Click sidebar navigation to return

### Logout Flow

1. Click on username at bottom of sidebar
2. Click "Logout" in popup
3. Backend logout called
4. Local storage cleared
5. Redirected to `/login`

## 🔌 API Integration

### Login

```javascript
const response = await authAPI.login(formData);
login(response.user, response.token.access_token);
navigate('/', { replace: true });
```

### Signup

```javascript
const response = await authAPI.signUp(signUpData);
login(response.user, response.token.access_token);
// Show success screen
```

### Logout

```javascript
await authAPI.logout(); // Calls backend
// Auth context automatically clears local data
navigate('/login');
```

### Change Password

```javascript
await authAPI.changePassword({
  current_password: 'current',
  new_password: 'newpass123',
});
```

## 🛡️ Security Features

1. **JWT Tokens**
   - Stored in localStorage
   - Sent with every authenticated request
   - 30-minute expiration (configurable)

2. **Protected Routes**
   - Automatic redirect if not authenticated
   - Token validation on protected endpoints

3. **Password Security**
   - Bcrypt hashing on backend
   - Minimum 8 characters for new passwords
   - Current password verification required

4. **Auto-logout**
   - On 401 responses
   - On token expiration
   - Manual logout clears all data

## 🎨 Theme System

### Storage

- Theme preference stored in localStorage
- Key: `theme`
- Values: `'light'` or `'dark'`

### Application

- Applied to document root via `dark` class
- All Shadcn components automatically adapt
- Custom CSS uses theme tokens

### Access

```javascript
const { theme, toggleTheme } = useTheme();

// Current theme
console.log(theme); // 'light' or 'dark'

// Toggle
toggleTheme();
```

## 📱 Responsive Design

All components are fully responsive:

- **Sidebar**: Adapts to mobile screens
- **Settings**: Stack elements on mobile
- **Forms**: Full width on mobile
- **Layout**: Proper spacing at all breakpoints

## 🚀 Future Enhancements

### Planned Features

1. **Navigation**
   - Add more menu items to sidebar
   - Breadcrumbs
   - Back button

2. **Profile**
   - Upload avatar
   - Edit profile fields
   - Account deletion

3. **Security**
   - Two-factor authentication
   - Session management
   - Login history

4. **Settings**
   - Email notifications
   - Privacy settings
   - Account preferences

5. **Dashboard**
   - Real-time stats
   - Activity timeline
   - Quick actions

## 📝 Component API

### AuthContext

```javascript
const {
  user,              // Current user object or null
  isAuthenticated,   // Boolean
  isLoading,         // Boolean (during initial check)
  login,             // Function(userData, token)
  logout,            // Async function()
  updateUser,        // Function(updatedData)
} = useAuth();
```

### Sidebar

No props required - uses auth context internally

### MainLayout

Uses React Router `<Outlet />` for nested routes

### Protected/Public Routes

```javascript
<ProtectedRoute>
  {children}
</ProtectedRoute>

<PublicRoute>
  {children}
</PublicRoute>
```

## 🧪 Testing

### Test Authentication

1. **Fresh start**: Clear localStorage → Redirects to login
2. **Login**: Enter credentials → Redirects to home
3. **Refresh**: Page reload → Stays logged in
4. **Logout**: Click logout → Redirects to login
5. **Protected**: Try `/settings` without login → Redirects to login
6. **Public**: Try `/login` when logged in → Redirects to home

### Test Settings

1. Navigate to settings
2. Try changing password with wrong current password
3. Try mismatched passwords
4. Successfully change password
5. Toggle theme
6. Verify persistence

## 🎯 Best Practices

1. **Always use `navigate`** instead of `window.location`
2. **Use auth context** for authentication state
3. **Protected components** should check `isAuthenticated`
4. **Loading states** during auth checks
5. **Error handling** on all API calls

---

**Everything is now ready!** You have a complete, production-ready authentication system with routing, protected pages, and user settings. 🎉

