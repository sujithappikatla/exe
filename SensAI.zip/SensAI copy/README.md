# SensAI - Full Stack Authentication System

A modern, production-ready full-stack application with React frontend and FastAPI backend featuring complete JWT authentication.

## 🚀 Quick Start

### Prerequisites

- Node.js (v18+)
- Python (3.12+)
- npm or yarn

### Setup & Run

**Terminal 1 - Backend:**
```bash
cd backend
source .venv/bin/activate
python app.py
```
Backend runs on: http://localhost:8000

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```
Frontend runs on: http://localhost:5173

Then visit http://localhost:5173 and create an account!

## 📋 Features

### Frontend
- ✅ React 19 + Vite 7
- ✅ Tailwind CSS v4
- ✅ Shadcn UI components
- ✅ Dark/Light theme with persistence
- ✅ Login & Sign up pages
- ✅ JWT token management
- ✅ Form validation
- ✅ Responsive design
- ✅ Clean code architecture

### Backend
- ✅ FastAPI (latest)
- ✅ SQLAlchemy ORM
- ✅ SQLite (switchable to PostgreSQL/MySQL)
- ✅ JWT authentication
- ✅ Password hashing (bcrypt)
- ✅ Pydantic validation
- ✅ CORS configured
- ✅ Interactive API docs
- ✅ Database-agnostic code

## 📁 Project Structure

```
SensAI/
├── frontend/               # React + Vite frontend
│   ├── src/
│   │   ├── components/    # UI components
│   │   ├── pages/         # Login & Signup pages
│   │   ├── services/      # API calls & constants
│   │   ├── hooks/         # Custom hooks (theme)
│   │   └── App.jsx
│   └── package.json
│
├── backend/               # FastAPI backend
│   ├── config/           # Settings & configuration
│   ├── database/         # Models & DB connection
│   ├── routes/           # API endpoints
│   ├── schemas/          # Pydantic schemas
│   ├── utils/            # Auth utilities
│   ├── app.py            # Main application
│   └── requirements.txt
│
├── INTEGRATION_GUIDE.md  # Full integration guide
└── README.md             # This file
```

## 🔐 Authentication Flow

1. **Sign Up**: User registers → Backend creates account → Returns JWT token → Frontend stores token
2. **Login**: User logs in → Backend verifies credentials → Returns JWT token → Frontend stores token
3. **Logout**: Frontend calls logout endpoint → Backend validates → Frontend clears token

## 📚 Documentation

- **INTEGRATION_GUIDE.md** - Complete setup and integration guide
- **frontend/README.md** - Frontend-specific documentation
- **backend/README.md** - Backend-specific documentation
- **API Docs** - http://localhost:8000/docs (when backend is running)

## 🛠️ Tech Stack

| Frontend | Backend |
|----------|---------|
| React 19.2 | FastAPI 0.115 |
| Vite 7.1 | SQLAlchemy 2.0 |
| Tailwind CSS 4.1 | Pydantic 2.10 |
| Shadcn UI | Python-Jose (JWT) |
| Lucide Icons | Bcrypt (Passlib) |
| JavaScript | SQLite/PostgreSQL/MySQL |

## 🔧 Environment Variables

**Backend (.env):**
```env
DATABASE_URL=sqlite:///./sensai.db
SECRET_KEY=your-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=30
CORS_ORIGINS=http://localhost:5173
```

**Frontend (.env):**
```env
VITE_API_BASE_URL=http://localhost:8000
```

## 🌐 API Endpoints

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | `/api/auth/signup` | Register user | No |
| POST | `/api/auth/login` | Login user | No |
| POST | `/api/auth/logout` | Logout user | Yes |
| GET | `/api/auth/me` | Get current user | Yes |
| GET | `/health` | Health check | No |
| GET | `/docs` | API documentation | No |

## 🗄️ Database

### Current: SQLite
Development database stored in `backend/sensai.db`

### Switch to PostgreSQL
```env
DATABASE_URL=postgresql://user:password@localhost/dbname
```

### Switch to MySQL
```env
DATABASE_URL=mysql+pymysql://user:password@localhost/dbname
```

**No code changes needed!** Just update the URL.

## 🎨 Features in Detail

### Dark/Light Theme
- System preference detection
- localStorage persistence
- Toggle button in top-right
- Smooth transitions

### Form Validation
- Email format validation
- Username requirements (3+ chars, alphanumeric + underscore)
- Password strength (8+ chars for signup)
- Password confirmation matching
- Real-time error messages

### Security
- Bcrypt password hashing
- JWT token authentication
- Token expiration (30 min default)
- CORS protection
- SQL injection protection (ORM)
- Input validation (Pydantic)

## 📱 Responsive Design

Works perfectly on:
- 📱 Mobile devices
- 💻 Tablets
- 🖥️ Desktops

## 🧪 Testing

### Test API Endpoints

```bash
# Health check
curl http://localhost:8000/health

# Sign up
curl -X POST http://localhost:8000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","username":"testuser","password":"password123"}'

# Login
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

### Interactive Testing

Visit http://localhost:8000/docs for Swagger UI where you can test all endpoints interactively!

## 🚀 Production Deployment

### Backend
1. Use PostgreSQL/MySQL instead of SQLite
2. Set strong `SECRET_KEY`
3. Set `RELOAD=False`
4. Use production ASGI server (Gunicorn + Uvicorn)
5. Set up HTTPS
6. Configure logging

### Frontend
1. Build: `npm run build`
2. Deploy to Vercel/Netlify/S3
3. Update `VITE_API_BASE_URL` to production backend

### Database
1. Set up automated backups
2. Use connection pooling
3. Run migrations with Alembic

## 📝 Code Quality

- ✅ Clean architecture
- ✅ Separation of concerns
- ✅ Type hints (Python)
- ✅ JSDoc comments (JavaScript)
- ✅ Error handling
- ✅ Validation at all levels
- ✅ Zero linter errors
- ✅ Production-ready patterns

## 🔄 Next Steps

Recommended features to add:
1. Password reset flow
2. Email verification
3. User profile editing
4. Refresh tokens
5. Social authentication
6. Two-factor authentication
7. Dashboard page
8. Protected routes

## 📖 Learn More

- [React Documentation](https://react.dev)
- [FastAPI Documentation](https://fastapi.tiangolo.com)
- [Tailwind CSS](https://tailwindcss.com)
- [Shadcn UI](https://ui.shadcn.com)
- [SQLAlchemy](https://www.sqlalchemy.org)

## 🤝 Contributing

This is a personal project, but feel free to fork and modify for your own use!

## 📄 License

MIT

---

**Built with ❤️ using modern best practices**

For detailed setup and integration instructions, see [INTEGRATION_GUIDE.md](./INTEGRATION_GUIDE.md)

