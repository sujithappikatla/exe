import { AppSidebar } from "./components/AppSidebar"
import { SidebarProvider, SidebarTrigger } from "./components/ui/sidebar"
import { ThemeProvider } from "./hooks/use-theme"
import { Route, Routes } from "react-router-dom"
import { Home } from "./app/Home"
import { ListJobs } from "./app/listJobs"
import { CreateJobs } from "./app/CreateJobs"




function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="evalservice-theme">
      <SidebarProvider>
        <div className="w-full flex min-h-screen">
          <AppSidebar />
          <main className="w-full flex-1 p-6">
            <div className="flex items-stretch justify-between">
              <SidebarTrigger className="mb-4" />
            </div>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/list-jobs" element={<ListJobs />} />
              <Route path="/create-job" element={<CreateJobs />} />
            </Routes>
          </main>
        </div>
      </SidebarProvider>
    </ThemeProvider>
  )
}

export default App
