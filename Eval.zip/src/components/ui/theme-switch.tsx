import { Moon, Sun } from "lucide-react"
import { useTheme } from "@/hooks/use-theme"
import { Button } from "@/components/ui/button"

export function ThemeSwitch() {
  const { theme, setTheme } = useTheme()

  return (
    <div 
    onClick={() => setTheme(theme === "dark" ? "light" : "dark")} 
    className="border-1 hover:border-2 hover:bg-gray-200  dark:hover:bg-gray-900 *:border-gray-900 flex items-center justify-center py-0 px-2 rounded-sm transition-all duration-300 cursor-pointer ">
        
        <div className="relative w-5 h-5">
            <Sun className="absolute h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0"/>
            <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100"/>
        </div>
        
        <span className="ml-2 text-md">{theme.charAt(0).toUpperCase() + theme.slice(1)}</span>
    </div>


    // <Button
    //   variant="ghost"
    //   size="icon"
    //   onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
    //   className="border-2 border-green-500 flex items-center justify-center"
    // >
    //     {
    //         theme == "light" ? 
    //         <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
    //         :
    //         <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
    //     }
    //   <span className="ml-80 text-xs">{theme}</span>
    // </Button>
  )
} 