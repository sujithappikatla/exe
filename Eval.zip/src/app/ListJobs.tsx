import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"
import { PlusIcon } from "lucide-react"
import { Link } from "react-router-dom"
type Job = {
    id: string
    name: string
    description: string
    status: string
    createdAt: string
}


export function ListJobs() {


    const [jobs, setJobs] = useState<Job[]>([])


    useEffect(() => {
        const jobs = [
            {
                id: "1",
                name: "Job 1",
                description: "Description 1",
                status: "active",
                createdAt: "2021-01-01"
            },
            {
                id: "2",
                name: "Job 2",
                description: "Description 2",
                status: "active",
                createdAt: "2021-01-01"
            },
            {
                id: "3",
                name: "Job 3",
                description: "Description 3",
                status: "active",
                createdAt: "2021-01-01"
            }
        ]
        // setJobs(jobs)
    }, [])

    return (
        <div className="w-full h-full">
            
            {jobs.length === 0 && (
                <div className="w-full h-full flex flex-col items-center justify-center gap-2">
                    <div className="text-sm text-gray-500">No jobs found</div>
                    
                    <Link to="/create-job" className="flex flex-row gap-2 items-center justify-center">
                        <Button variant="outline" className="bg-amber-100 text-amber-900 hover:bg-amber-200 cursor-pointer">                        
                                <PlusIcon className="w-4 h-4" />
                                <span className="text-sm">Create Job</span>
                        </Button>
                    </Link>
                </div>
            )}

            {jobs.length > 0 && (
                <div className="flex flex-col gap-2">
                {jobs.map((job) => (
                    
                    <div key={job.id} className="w-full rounded-sm p-2 shadow-xs hover:shadow-md hover:border-gray-300 border-1 transition-all duration-300 shadow-gray-200 dark:shadow-gray-700 flex flex-row gap-2 items-center justify-between cursor-pointer center">
                       
                        <div className="flex flex-col gap-2">
                            <div className="text-lg text-orange-900">{job.name}</div>
                            <div className="text-sm text-gray-500">{job.description}</div>
                        </div>
                        <div className="h-full items-center justify-center">
                            <div className="text-sm text-gray-500">{job.createdAt}</div>
                        </div>
                    </div>

                    

                    
                ))}
                </div>
            )}
        </div>
    )
}