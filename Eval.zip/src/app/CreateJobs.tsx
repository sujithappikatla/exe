

export function CreateJobs() {
    return (
        <div>
            <h1>Create Job</h1>
        </div>
    )
}