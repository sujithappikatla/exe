import { RotateCcw, ThumbsUp, ThumbsDown, Copy, Share2 } from 'lucide-react'

export type ActionType = 'regenerate' | 'like' | 'dislike' | 'copy' | 'share'

export type ActionsProps = {
  messageId: string
  onAction?: (action: ActionType, messageId: string) => void
  copyText?: string
}

export default function Actions({ messageId, onAction, copyText }: ActionsProps) {
  function emit(action: ActionType) {
    onAction?.(action, messageId)
  }

  const buttonClass =
    'rounded pt-2 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors'

  return (
    <div className="flex items-center gap-2  text-sm">
      <button className={`${buttonClass} cursor-pointer`} aria-label="Regenerate" title="Regenerate" onClick={() => emit('regenerate')}>
        <RotateCcw className="h-4 w-4" />
      </button>
      <span className="w-1" />
      <button className={`${buttonClass} cursor-pointer`} aria-label="Like" title="Like" onClick={() => emit('like')}>
        <ThumbsUp className="h-4 w-4" />
      </button>
      <span className="w-1" />
      <button className={`${buttonClass} cursor-pointer`} aria-label="Dislike" title="Dislike" onClick={() => emit('dislike')}>
        <ThumbsDown className="h-4 w-4" />
      </button>
      <span className="w-1" />
      <button
        className={`${buttonClass} cursor-pointer`}
        aria-label="Copy"
        title="Copy"
        onClick={() => {
          if (copyText) safeCopy(copyText)
          emit('copy')
        }}
      >
        <Copy className="h-4 w-4" />
      </button>
      <span className="w-1" />
      <button className={`${buttonClass} cursor-pointer`} aria-label="Share" title="Share" onClick={() => emit('share')}>
        <Share2 className="h-4 w-4" />
      </button>
    </div>
  )
}

function safeCopy(text: string) {
  try {
    void navigator.clipboard.writeText(text)
  } catch {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.left = '-9999px'
    document.body.appendChild(ta)
    ta.focus()
    ta.select()
    try {
      document.execCommand('copy')
    } finally {
      document.body.removeChild(ta)
    }
  }
}

