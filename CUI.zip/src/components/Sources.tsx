import { useState, useEffect, useRef } from 'react'
import { ExternalLink, ChevronLeft, ChevronRight } from 'lucide-react'
import SourceSheet from './SourceSheet'
import type { Source } from '../types/protocol'

export interface SourcesProps {
  sources: Source[]
}

export default function Sources({ sources }: SourcesProps) {
  const [isSheetOpen, setIsSheetOpen] = useState(false)
  const prevSourcesLength = useRef(0)
  const [newSourcesCount, setNewSourcesCount] = useState(0)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(false)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  // Handle fade-in animation for new sources
  useEffect(() => {
    if (sources.length > prevSourcesLength.current) {
      // New sources added, mark them for animation
      setNewSourcesCount(sources.length - prevSourcesLength.current)
      prevSourcesLength.current = sources.length
      
      // Clear animation after animation completes
      const timer = setTimeout(() => {
        setNewSourcesCount(0)
      }, 600)
      
      return () => clearTimeout(timer)
    } else {
      // Sources replaced or removed
      prevSourcesLength.current = sources.length
      setNewSourcesCount(0)
    }
  }, [sources.length])

  // Check scroll state
  const checkScrollState = () => {
    const container = scrollContainerRef.current
    if (!container) return

    const { scrollLeft, scrollWidth, clientWidth } = container
    setCanScrollLeft(scrollLeft > 0)
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 1)
  }

  // Handle scroll buttons
  const scrollLeft = () => {
    const container = scrollContainerRef.current
    if (!container) return
    container.scrollBy({ left: -280, behavior: 'smooth' }) // Card width + gap
  }

  const scrollRight = () => {
    const container = scrollContainerRef.current
    if (!container) return
    container.scrollBy({ left: 280, behavior: 'smooth' }) // Card width + gap
  }

  // Check scroll state on mount and when sources change
  useEffect(() => {
    checkScrollState()
  }, [sources.length])

  // Add scroll event listener
  useEffect(() => {
    const container = scrollContainerRef.current
    if (!container) return

    container.addEventListener('scroll', checkScrollState)
    return () => container.removeEventListener('scroll', checkScrollState)
  }, [])

  if (!sources || sources.length === 0) return null

  const handleCardClick = () => {
    setIsSheetOpen(true)
  }

  const handleCloseSheet = () => {
    setIsSheetOpen(false)
  }

  return (
    <>
      <div className="mb-4 animate-fade-in" style={{ animation: 'fadeIn 0.3s ease-in-out' }}>
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-sm font-medium text-neutral-300 flex items-center gap-2">
            <span>Sources</span>
            <span className="text-xs text-neutral-500">({sources.length})</span>
          </h4>
          
          {/* Scroll buttons */}
          <div className="flex items-center gap-1">
            <button
              onClick={scrollLeft}
              disabled={!canScrollLeft}
              className={`p-1 rounded-md scroll-button ${
                canScrollLeft 
                  ? 'text-neutral-400 hover:text-neutral-200' 
                  : 'text-neutral-600 cursor-not-allowed'
              }`}
              aria-label="Scroll left"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={scrollRight}
              disabled={!canScrollRight}
              className={`p-1 rounded-md scroll-button ${
                canScrollRight 
                  ? 'text-neutral-400 hover:text-neutral-200' 
                  : 'text-neutral-600 cursor-not-allowed'
              }`}
              aria-label="Scroll right"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        {/* Horizontal scrollable container */}
        <div 
          ref={scrollContainerRef}
          className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide"
        >
          {sources.map((source, index) => {
            const isNewSource = newSourcesCount > 0 && index >= sources.length - newSourcesCount
            return (
            <div
              key={index}
              onClick={handleCardClick}
              className={`flex-shrink-0 w-64 bg-neutral-800/50 border border-neutral-700 rounded-lg p-3 cursor-pointer hover:bg-neutral-800/70 hover:border-neutral-600 transition-all duration-200 ${
                isNewSource ? 'animate-fade-in' : ''
              }`}
              style={{
                animation: isNewSource ? 'fadeIn 0.5s ease-in-out' : undefined
              }}
            >
              {/* Source Header */}
              <div className="flex items-start justify-between mb-2">
                <h5 className="font-medium text-neutral-100 text-sm truncate pr-2">
                  {source.name}
                </h5>
                {source.url && (
                  <ExternalLink className="h-3 w-3 text-neutral-400 flex-shrink-0 mt-0.5" />
                )}
              </div>

              {/* Source URL (if present) */}
              {source.url && (
                <p className="text-xs text-neutral-500 mb-2 truncate">
                  {source.url}
                </p>
              )}

              {/* Source Content Preview - Fixed 3 lines with ellipsis */}
              <div className="text-xs text-neutral-300 leading-relaxed">
                <div 
                  className="line-clamp-3 overflow-hidden"
                  style={{
                    display: '-webkit-box',
                    WebkitLineClamp: 3,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden'
                  }}
                >
                  {/* Show plain text content */}
                  <p className="whitespace-pre-wrap">{source.content}</p>
                </div>
              </div>
            </div>
            )
          })}
        </div>
      </div>

      {/* Source Sheet */}
      <SourceSheet 
        sources={sources}
        isOpen={isSheetOpen}
        onClose={handleCloseSheet}
      />
    </>
  )
}
