import Markdown from './Markdown'
import Actions, { type ActionType } from './Actions'
import Thinking from './Thinking'
import Sources from './Sources'
import type { ChatRole, NodeUpdate, Source } from '../types/protocol'

export type MessageProps = {
  id: string
  role: ChatRole
  content: string
  isStreaming?: boolean
  nodeUpdates?: NodeUpdate[]
  thinkingOpen?: boolean
  onThinkingToggle?: (open: boolean) => void
  autoMinimizedThinking?: boolean
  isThinking?: boolean
  sources?: Source[]
}

export default function Message({ 
  id, 
  role, 
  content, 
  isStreaming, 
  nodeUpdates = [],
  thinkingOpen = false,
  onThinkingToggle = () => {},
  autoMinimizedThinking = false,
  isThinking = false,
  sources = []
}: MessageProps) {
  const isUser = role === 'user'

  if (isUser) {
    return (
      <div key={id} className="flex w-full justify-end">
        <div
          className={
            'max-w-[85%] rounded-2xl rounded-br-md bg-neutral-600 px-4 py-3 text-sm text-white shadow-sm break-words'
          }
        >
          <Markdown className="leading-7" content={content} />
        </div>
      </div>
    )
  }

  // Assistant message: bubble + optional reasoning panel + actions below
  return (
    <div key={id} className="w-full">
      <div className="flex w-full justify-start">
        <div
          className={
            'w-full rounded-2xl rounded-bl-md  pt-4 py-3 text-sm text-neutral-100 shadow-sm break-words'
          }
        >
          {nodeUpdates.length > 0 ? (
            <div className="">
              <Thinking 
                nodeUpdates={nodeUpdates}
                isOpen={thinkingOpen}
                onToggle={onThinkingToggle}
                autoMinimized={autoMinimizedThinking}
                isThinking={isThinking}
              />
            </div>
          ) : null}

          {sources.length > 0 ? (
            <div className="">
              <Sources sources={sources} />
            </div>
          ) : null}

          <Markdown className="leading-7" content={content} />
          {isStreaming ? <StreamingDots /> : null}
        </div>
      </div>
      {!isStreaming ? (
        <div className="flex w-full justify-start pl-1">
          <Actions messageId={id} onAction={handleAction} copyText={content} />
        </div>
      ) : null}
    </div>
  )

  function handleAction(action: ActionType, messageId: string) {
    const event = new CustomEvent('sb:message-action', { detail: { action, messageId } })
    window.dispatchEvent(event)
  }
}

function StreamingDots() {
  return (
    <span className="ml-1 inline-flex items-center gap-1 align-baseline" aria-label="streaming">
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-current [animation-delay:-0.2s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-current [animation-delay:-0.1s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-current" />
    </span>
  )
}


