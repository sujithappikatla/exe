import type { FormEvent } from 'react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Plus, Mic, Globe, ChevronDown, Send, Square } from 'lucide-react'

type AgentType = {
  id: 'fast' | 'slow'
  label: string
  description: string
}

type PromptInputProps = {
  placeholder?: string
  onSend?: (message: string) => void
  models?: Array<{ id: string; label: string }>
  defaultModelId?: string
  onModelChange?: (modelId: string) => void
  agentTypes?: AgentType[]
  defaultAgentTypeId?: 'fast' | 'slow'
  onAgentTypeChange?: (agentTypeId: 'fast' | 'slow') => void
  onHeightChange?: (height: number) => void
  isStreaming?: boolean
  onStop?: () => void
}

export default function PromptInput({
  placeholder = 'What would you like to know?',
  onSend,
  models = [
    { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' },
    { id: 'gemini-2.0-flash-lite', label: 'Gemini 2.0 Flash Lite' },
    { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash' },
  ],
  defaultModelId,
  onModelChange,
  agentTypes = [
    { id: 'fast', label: 'Fast Generation', description: 'Generates quicker responses' },
    { id: 'slow', label: 'Slow Generation', description: 'Slower but more accurate answers' },
  ],
  defaultAgentTypeId,
  onAgentTypeChange,
  onHeightChange,
  isStreaming = false,
  onStop,
}: PromptInputProps) {
  const [value, setValue] = useState('')
  const [isModelOpen, setIsModelOpen] = useState(false)
  const [isAgentTypeOpen, setIsAgentTypeOpen] = useState(false)

  const [selectedModelId, setSelectedModelId] = useState(
    defaultModelId ?? models[0]?.id ?? 'gpt-4',
  )

  const [selectedAgentTypeId, setSelectedAgentTypeId] = useState<'fast' | 'slow'>(
    defaultAgentTypeId ?? agentTypes[0]?.id ?? 'fast',
  )

  const selectedModelLabel = useMemo(
    () => models.find((m) => m.id === selectedModelId)?.label ?? 'Model',
    [models, selectedModelId],
  )

  const selectedAgentType = useMemo(
    () => agentTypes.find((a) => a.id === selectedAgentTypeId),
    [agentTypes, selectedAgentTypeId],
  )

  function handleSubmit(event: FormEvent) {
    event.preventDefault()
    const trimmed = value.trim()
    if (!trimmed) return
    onSend?.(trimmed)
    setValue('')
  }

  function handleSelectModel(modelId: string) {
    setSelectedModelId(modelId)
    setIsModelOpen(false)
    onModelChange?.(modelId)
  }

  function handleSelectAgentType(agentTypeId: 'fast' | 'slow') {
    setSelectedAgentTypeId(agentTypeId)
    setIsAgentTypeOpen(false)
    onAgentTypeChange?.(agentTypeId)
  }

  // Auto-resize textarea and report overall component height to parent
  const rootRef = useRef<HTMLDivElement | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement | null>(null)

  function autoResizeTextarea() {
    const el = textareaRef.current
    if (!el) return
    el.style.height = '0px'
    el.style.height = Math.min(el.scrollHeight, 320) + 'px' // cap ~20rem
  }

  useEffect(() => {
    autoResizeTextarea()
  }, [value])

  useEffect(() => {
    if (!rootRef.current || !onHeightChange) return
    const ro = new ResizeObserver(() => {
      if (rootRef.current) onHeightChange(rootRef.current.offsetHeight)
    })
    ro.observe(rootRef.current)
    return () => ro.disconnect()
  }, [onHeightChange])

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      // synthesize a submit
      const form = (e.currentTarget.closest('form') as HTMLFormElement | null)
      form?.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }))
    }
  }

  return (
    <div ref={rootRef} className="fixed inset-x-0 bottom-0 z-50 flex justify-center p-4 scale-105">
      <form
        onSubmit={handleSubmit}
        className="relative w-full max-w-4xl rounded-2xl border border-neutral-600/80 bg-neutral-900/70 shadow-xl backdrop-blur-md"
        aria-label="Prompt input"
      >
        {/* gradient background layer */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10 rounded-2xl opacity-70"
          /* Rich purple gradient similar to the original design */
          style={{
            background:
              'linear-gradient(120deg, rgba(55,55,55,0.8) 0%, rgba(120,53,15,0.6) 40%, rgba(55,58,55,0.8) 100%)',
          }}
        />
        <div className="px-4 pt-3 text-neutral-100 drop-shadow-[0_1px_1px_rgba(0,0,0,0.6)]">
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            rows={1}
            className="w-full max-h-80 resize-none overflow-auto bg-transparent text-base text-neutral-100 placeholder:text-neutral-200/70 outline-none"
            aria-label="Prompt"
          />
        </div>

        <div className="flex items-center justify-between gap-2 border-t border-neutral-700/50 px-2 py-2">
          <div className="flex items-center gap-1.5">
            {/* <ToolbarIconButton ariaLabel="Add" title="Add">
              <Plus className="h-5 w-5" />
            </ToolbarIconButton>

            <ToolbarIconButton ariaLabel="Voice" title="Voice">
              <Mic className="h-5 w-5" />
            </ToolbarIconButton>

            <ToolbarPillButton>
              <Globe className="h-5 w-5" />
              <span className="text-sm">Search</span>
            </ToolbarPillButton> */}

            <div className="mx-1 h-4 w-px bg-neutral-800" />

            <div className="relative">
              <button
                type="button"
                onClick={() => setIsModelOpen((s) => !s)}
                className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-neutral-100"
                aria-haspopup="listbox"
                aria-expanded={isModelOpen}
                aria-label="Select model"
              >
                <span className="text-sm">{selectedModelLabel}</span>
                <ChevronDown className="h-4 w-4" />
              </button>

              {isModelOpen && (
                <ul
                  role="listbox"
                  className="absolute bottom-full left-0 mb-2 min-w-40 overflow-hidden rounded-lg border border-neutral-800 bg-neutral-900/95 p-1 shadow-xl backdrop-blur"
                >
                  {models.map((m) => (
                    <li key={m.id}>
                      <button
                        type="button"
                        role="option"
                        aria-selected={m.id === selectedModelId}
                        onClick={() => handleSelectModel(m.id)}
                        className={
                          'flex w-full items-center justify-between gap-3 rounded-md px-3 py-2 text-left text-sm text-neutral-200 hover:bg-neutral-800'
                        }
                      >
                        <span>{m.label}</span>
                        {m.id === selectedModelId ? (
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4 text-blue-500"><path d="M20 6 9 17l-5-5"/></svg>
                        ) : null}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="relative">
              <button
                type="button"
                onClick={() => setIsAgentTypeOpen((s) => !s)}
                className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-neutral-100"
                aria-haspopup="listbox"
                aria-expanded={isAgentTypeOpen}
                aria-label="Select agent type"
              >
                <span className="text-sm">{selectedAgentType?.label ?? 'Agent Type'}</span>
                <ChevronDown className="h-4 w-4" />
              </button>

              {isAgentTypeOpen && (
                <ul
                  role="listbox"
                  className="absolute bottom-full left-0 mb-2 min-w-56 overflow-hidden rounded-lg border border-neutral-800 bg-neutral-900/95 p-1 shadow-xl backdrop-blur"
                >
                  {agentTypes.map((agent) => (
                    <li key={agent.id}>
                      <button
                        type="button"
                        role="option"
                        aria-selected={agent.id === selectedAgentTypeId}
                        onClick={() => handleSelectAgentType(agent.id)}
                        className="flex w-full flex-col items-start gap-1 rounded-md px-3 py-2 text-left text-neutral-200 hover:bg-neutral-800"
                      >
                        <div className="flex w-full items-center justify-between">
                          <span className="text-sm font-medium">{agent.label}</span>
                          {agent.id === selectedAgentTypeId ? (
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4 text-blue-500"><path d="M20 6 9 17l-5-5"/></svg>
                          ) : null}
                        </div>
                        <span className="text-xs text-neutral-400">{agent.description}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {isStreaming ? (
            <button
              type="button"
              onClick={onStop}
              aria-label="Stop"
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-700 text-white shadow-md transition-colors hover:bg-amber-500"
            >
              <Square className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="submit"
              aria-label="Send"
              disabled={value.trim().length === 0}
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-700 text-white shadow-md transition-colors hover:bg-emerald-500 disabled:cursor-not-allowed disabled:opacity-40 hover:cursor-pointer hover:scale-105 disabled:hover:bg-emerald-600"
            >
              <Send className="h-5 w-5" />
            </button>
          )}
        </div>
      </form>
    </div>
  )
}

function ToolbarIconButton({
  ariaLabel,
  title,
  children,
}: {
  ariaLabel: string
  title?: string
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      aria-label={ariaLabel}
      title={title}
      className="rounded-md p-2 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-neutral-200"
    >
      {children}
    </button>
  )
}

function ToolbarPillButton({ children }: { children: React.ReactNode }) {
  return (
    <button
      type="button"
      className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-neutral-200"
    >
      {children}
    </button>
  )
}

// removed legacy inline icons in favor of lucide-react


