import type { ReactNode } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import rehypeHighlight from 'rehype-highlight'
import rehypeRaw from 'rehype-raw'
import rehypeSanitize, { defaultSchema } from 'rehype-sanitize'
import type { Components } from 'react-markdown'

export type MarkdownProps = {
  content: string
  className?: string
  components?: Components
}

const defaultComponents: Components = {
  h1: ({ ...props }) => (
    <h1 className="mb-3 mt-6 text-2xl font-semibold tracking-tight text-neutral-100" {...props} />
  ),
  h2: ({ ...props }) => (
    <h2 className="mb-2 mt-5 text-xl font-semibold tracking-tight text-neutral-200" {...props} />
  ),
  h3: ({ ...props }) => (
    <h3 className="mb-1.5 mt-4 text-lg font-semibold text-neutral-200" {...props} />
  ),
  p: ({ ...props }) => <p className="mb-3 text-neutral-300" {...props} />,
  a: ({ ...props }) => (
    <a
      className="text-blue-400 underline decoration-blue-400/50 underline-offset-2 hover:text-blue-300"
      target="_blank"
      rel="noopener noreferrer"
      {...props}
    />
  ),
  ul: ({ ...props }) => (
    <ul className="mb-3 ml-6 list-disc marker:text-neutral-400" {...props} />
  ),
  ol: ({ ...props }) => (
    <ol className="mb-3 ml-6 list-decimal marker:text-neutral-400" {...props} />
  ),
  li: ({ ...props }) => <li className="my-1 leading-7" {...props} />,
  blockquote: ({ ...props }) => (
    <blockquote
      className="mb-3 border-l-4 border-neutral-700 pl-3 text-neutral-300"
      {...props}
    />
  ),
  table: ({ ...props }) => (
    <div className="mb-4 overflow-x-auto rounded-lg border border-neutral-800">
      <table className="w-full border-collapse text-left text-sm" {...props} />
    </div>
  ),
  th: ({ ...props }) => (
    <th className="bg-neutral-900 px-3 py-2 font-medium text-neutral-200" {...props} />
  ),
  td: ({ ...props }) => (
    <td className="px-3 py-2 align-top text-neutral-300" {...props} />
  ),
  img: ({ ...props }) => (
    <img className="my-3 max-h-[28rem] w-auto max-w-full rounded-lg" {...props} />
  ),
  code: ({ inline, children, className, ...props }: { inline?: boolean; children?: ReactNode; className?: string }) => {
    if (inline) {
      return (
        <code
          className={
            'inline align-baseline rounded bg-neutral-800 border-neutral-700 px-1.5 py-0.5 text-[0.9em] text-neutral-100 leading-3 whitespace-normal break-words max-w-full ' +
            (className ?? '')
          }
          {...props}
        >
          {children}
        </code>
      )
    }
    // Heuristic: render short single-line "code blocks" as inline code pills
    const text = getPlainText(children)
    if (text && !text.includes('\n') && text.trim().length <= 120) {
      return (
        <code
          className={
            'inline align-baseline rounded border border-neutral-300/20 bg-neutral-500/10 px-1.5 py-1.5 text-[0.9em] text-neutral-300 leading-6 whitespace-normal break-words max-w-full ' +
            (className ?? '')
          }
          {...props}
        >
          {text}
        </code>
      )
    }
    const lang = (className || '').replace('language-', '').toUpperCase()
    const codeText = text
    return (
      <div className="mb-3 overflow-hidden rounded-lg  bg-neutral-900/40">
        <div className="flex items-center justify-between border-b border-neutral-800 bg-neutral-900/60 px-3 py-2 text-xs uppercase tracking-wide text-neutral-400">
          <span>{lang || 'CODE'}</span>
          <button
            type="button"
            className="cursor-pointer rounded px-2 py-1 text-neutral-300 hover:bg-neutral-800 hover:text-neutral-100"
            onClick={() => copyText(codeText)}
          >
            Copy
          </button>
        </div>
        <pre className="overflow-x-auto bg-neutral-950/30 p-3 text-neutral-100 leading-6">
          <code className={className} {...props}>
            {children}
          </code>
        </pre>
      </div>
    )
  },
}

export default function Markdown({ content, className, components }: MarkdownProps) {
  // Replace invalid-void <source>..</source> with a custom non-void tag <sb-source>..</sb-source>
  const processed = content.replace(/<\s*source(\s[^>]*)?>([\s\S]*?)<\/\s*source\s*>/gi, '<sb-source$1>$2</sb-source>')

  // Extend sanitize schema to allow our custom <source> tag with a 'type' attribute
  const extendedSchema = {
    ...defaultSchema,
    tagNames: [...(defaultSchema.tagNames || []), 'sb-source'],
    attributes: {
      ...(defaultSchema.attributes || {}),
      'sb-source': ['type'],
    },
  }

  const extendedComponents: Components = {
    // @ts-expect-error: custom tag
    'sb-source': ({ children }: { children?: ReactNode }) => (
      <span className="rounded-md border border-amber-500/30 bg-amber-500/10 px-1.5 py-0.5 text-amber-300">
        {children}
      </span>
    ),
  }

  return (
    <div className={"prose prose-invert max-w-none prose-pre:leading-6 prose-pre:m-0 " + (className ?? '')}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        // Parse raw HTML first, then sanitize, then highlight
        rehypePlugins={[rehypeRaw, [rehypeSanitize, extendedSchema], rehypeHighlight]}
        // NOTE: raw HTML is intentionally disabled for safety
        components={{ ...defaultComponents, ...extendedComponents, ...(components ?? {}) }}
      >
        {processed}
      </ReactMarkdown>
    </div>
  )
}

function getPlainText(node: ReactNode): string {
  if (node == null) return ''
  if (typeof node === 'string' || typeof node === 'number') return String(node)
  if (Array.isArray(node)) return node.map(getPlainText).join('')
  // @ts-ignore - react-markdown children can be complex, try common shape
  if (node.props && node.props.children) return getPlainText(node.props.children)
  return ''
}

function copyText(text?: string) {
  if (!text) return
  try {
    void navigator.clipboard.writeText(text)
  } catch {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.left = '-9999px'
    document.body.appendChild(ta)
    ta.focus()
    ta.select()
    try {
      document.execCommand('copy')
    } finally {
      document.body.removeChild(ta)
    }
  }
}


