import { useEffect } from 'react'
import { X, ExternalLink } from 'lucide-react'
import Markdown from './Markdown'
import type { Source } from '../types/protocol'

export interface SourceSheetProps {
  sources: Source[]
  isOpen: boolean
  onClose: () => void
}

export default function SourceSheet({ sources, isOpen, onClose }: SourceSheetProps) {
  // Close on Escape key
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener('keydown', handleEscape)
      // Prevent body scroll when sheet is open
      document.body.style.overflow = 'hidden'
    }

    return () => {
      document.removeEventListener('keydown', handleEscape)
      document.body.style.overflow = 'unset'
    }
  }, [isOpen, onClose])

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-[100]"
        onClick={onClose}
      />
      
      {/* Sheet */}
      <div className={`fixed top-0 right-0 h-full w-full max-w-2xl bg-neutral-900 border-l border-neutral-700 z-[101] transform transition-transform duration-300 ease-in-out flex flex-col ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-700 flex-shrink-0">
          <h2 className="text-lg font-semibold text-neutral-100">
            Sources ({sources.length})
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-neutral-800 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-neutral-400" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 min-h-0">
          {sources.map((source, index) => (
            <div 
              key={index}
              className="border border-neutral-700 rounded-lg bg-neutral-800/50 overflow-hidden"
            >
              {/* Source Header */}
              <div className="p-4 border-b border-neutral-700 bg-neutral-800/30">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-neutral-100 text-lg">
                    {source.name}
                  </h3>
                  {source.url && (
                    <a
                      href={source.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-blue-400 hover:text-blue-300 text-sm transition-colors"
                    >
                      <ExternalLink className="h-4 w-4" />
                      Open
                    </a>
                  )}
                </div>
                {source.url && (
                  <p className="text-neutral-400 text-sm mt-1 break-all">
                    {source.url}
                  </p>
                )}
              </div>

              {/* Source Content */}
              <div className="p-4">
                <div className="prose prose-neutral prose-invert max-w-none">
                  <Markdown content={source.content} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}
