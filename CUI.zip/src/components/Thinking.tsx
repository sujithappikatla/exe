import { useEffect, useRef } from 'react'
import { ChevronDown, ChevronUp } from 'lucide-react'
import type { NodeUpdate } from '../types/protocol'

export interface ThinkingProps {
  nodeUpdates: NodeUpdate[]
  isOpen: boolean
  onToggle: (open: boolean) => void
  autoMinimized?: boolean
  isThinking?: boolean
}

export default function Thinking({ nodeUpdates, isOpen, onToggle, isThinking = false }: ThinkingProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  
  // Auto-scroll to latest update
  useEffect(() => {
    if (isOpen && scrollContainerRef.current && nodeUpdates.length > 0) {
      const container = scrollContainerRef.current
      container.scrollTop = container.scrollHeight
    }
  }, [nodeUpdates.length, isOpen])

  if (nodeUpdates.length === 0) return null

  return (
    <div className="mb-4 rounded-lg border border-neutral-700 bg-neutral-800/50">
      <button
        onClick={() => onToggle(!isOpen)}
        className="flex w-full items-center justify-between p-3 text-left text-sm text-neutral-300 hover:bg-neutral-700/30 transition-colors"
      >
        <div className="flex items-center gap-2">
          <span className={`font-medium ${isThinking ? 'animate-pulse' : ''}`}>
            Thinking
          </span>
          <span className="text-xs text-neutral-500">
            {nodeUpdates.length} update{nodeUpdates.length !== 1 ? 's' : ''}
          </span>
        </div>
        {isOpen ? (
          <ChevronUp className="h-4 w-4" />
        ) : (
          <ChevronDown className="h-4 w-4" />
        )}
      </button>
      
      {isOpen && (
        <div className="border-t border-neutral-700 bg-neutral-900/30">
          <div ref={scrollContainerRef} className="max-h-64 overflow-y-auto p-3 space-y-2">
            {nodeUpdates.map((update, index) => {
              const isLatest = index === nodeUpdates.length - 1
              return (
                <div
                  key={update.id}
                  className={`flex items-start gap-2 text-sm text-neutral-400 ${isLatest && isThinking ? 'animate-pulse' : ''}`}
                >
                  <div className="mt-1.5 h-1.5 w-1.5 rounded-full bg-neutral-500 flex-shrink-0" />
                  <div className="flex-1 leading-relaxed">
                    {update.content}
                  </div>
                  <div className="text-xs text-neutral-600 flex-shrink-0">
                    {new Date(update.timestamp).toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit',
                      second: '2-digit'
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
