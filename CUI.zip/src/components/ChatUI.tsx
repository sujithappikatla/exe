import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import PromptInput from './PromptInput'
import Message from './Message'
import { startRun, openRunStream, generateId } from '../lib/api'
import type { BackendMessage, ChatMessage, NodeUpdate, Source } from '../types/protocol'

type ChatUIProps = {
  initialMessages?: ChatMessage[]
  models?: Array<{ id: string; label: string }>
}

export default function ChatUI({ initialMessages = [], models }: ChatUIProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages)
  const [currentModelId, setCurrentModelId] = useState(models?.[0]?.id ?? 'gemini-2.0-flash')
  const [currentAgentType, setCurrentAgentType] = useState<'fast' | 'slow'>('fast')
  const [isStreaming, setIsStreaming] = useState(false)
  const [threadId] = useState<string>(() => generateId())
  const [thinkingStates, setThinkingStates] = useState<Record<string, { isOpen: boolean, autoMinimized: boolean }>>({})
  const [isThinking, setIsThinking] = useState(false)
  const abortRef = useRef<AbortController | null>(null)
  const eventSourceRef = useRef<EventSource | null>(null)

  // Dynamic background based on message presence
  useEffect(() => {
    const hasMessages = messages.length > 0
    if (hasMessages) {
      // Switch to neutral background for conversations
      document.body.style.setProperty('background', '#262626', 'important') // bg-neutral-800 equivalent
    } else {
      // Show purple gradient background
      document.body.style.setProperty('background', 'linear-gradient(120deg, rgba(88,28,135,0.4) 0%, rgba(120,53,15,0.25) 40%, rgba(30,58,138,0.4) 100%), #0c0d10', 'important')
    }
    document.body.style.backgroundAttachment = 'fixed'
  }, [messages.length])

  const scrollContainerRef = useRef<HTMLDivElement | null>(null)
  const bottomSentinelRef = useRef<HTMLDivElement | null>(null)
  const userTriggeredAutoScrollRef = useRef(true)
  const isAtBottomRef = useRef(true)
  const pendingForceScrollRef = useRef(false)
  const [inputHeight, setInputHeight] = useState(96)

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'auto') => {
    const container = scrollContainerRef.current
    if (!container) return
    container.scrollTo({ top: container.scrollHeight, behavior })
  }, [])

  // Observe whether the bottom sentinel is visible within the scroll container
  useEffect(() => {
    const container = scrollContainerRef.current
    const sentinel = bottomSentinelRef.current
    if (!container || !sentinel) return

    const observer = new IntersectionObserver(
      (entries) => {
        const isIntersecting = entries.some((e) => e.isIntersecting)
        isAtBottomRef.current = isIntersecting
        userTriggeredAutoScrollRef.current = isIntersecting
      },
      { root: container, threshold: 1.0 },
    )

    observer.observe(sentinel)

    const handleManualScroll = () => {
      const threshold = 2
      const dist = container.scrollHeight - container.scrollTop - container.clientHeight
      const atBottom = dist <= threshold
      isAtBottomRef.current = atBottom
      if (!atBottom) userTriggeredAutoScrollRef.current = false
    }
    container.addEventListener('scroll', handleManualScroll, { passive: true })

    return () => {
      observer.disconnect()
      container.removeEventListener('scroll', handleManualScroll)
    }
  }, [])

  // When messages change, auto-scroll if enabled or if a new user message was added
  const lastMessageKey = useMemo(
    () => messages.map((m) => `${m.id}:${m.content.length}:${m.isStreaming ? 1 : 0}`).join('|'),
    [messages],
  )
  useEffect(() => {
    if (userTriggeredAutoScrollRef.current || pendingForceScrollRef.current) {
      requestAnimationFrame(() => scrollToBottom('auto'))
      pendingForceScrollRef.current = false
    }
  }, [lastMessageKey, scrollToBottom])

  // Function to handle thinking toggle for individual messages
  const handleThinkingToggle = useCallback((messageId: string, isOpen: boolean) => {
    setThinkingStates(prev => ({
      ...prev,
      [messageId]: {
        ...prev[messageId],
        isOpen
      }
    }))
    // Note: No need to update global state anymore since we use per-message state
  }, [messages])

  // Get thinking state for a message
  const getThinkingState = useCallback((messageId: string) => {
    return thinkingStates[messageId] || { isOpen: false, autoMinimized: false }
  }, [thinkingStates])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      abortRef.current?.abort()
      eventSourceRef.current?.close()
      // Reset to default background on unmount
      document.body.style.background = '#374151'
      document.body.style.backgroundAttachment = 'fixed'
    }
  }, [])

  async function handleSend(text: string) {
    // Force auto-scroll for this send operation
    pendingForceScrollRef.current = true
    
    // Add user message
    const userId = `user_${Date.now()}`
    const userMessage: ChatMessage = { 
      id: userId, 
      role: 'user', 
      content: text,
      thread_id: threadId
    }
    setMessages((prev) => [...prev, userMessage])

    // Create streaming assistant message placeholder
    const assistantId = `assistant_${Date.now()}`
    const assistantMessage: ChatMessage = {
      id: assistantId,
      role: 'assistant',
      content: '',
      isStreaming: true,
      thread_id: threadId,
      isThinking: true
    }
    setMessages((prev) => [...prev, assistantMessage])
    setIsStreaming(true)
    setIsThinking(true)
    
    // Initialize thinking state for this message
    setThinkingStates(prev => ({
      ...prev,
      [assistantId]: { isOpen: true, autoMinimized: false }
    }))

    try {
      // Start the run
      const runResponse = await startRun(text, threadId, undefined, currentModelId, currentAgentType)
      
      if (runResponse.type !== 'run_started') {
        throw new Error('Failed to start run')
      }

      const runId = runResponse.run_id!
      
      // Update messages with run_id
      setMessages((prev) => prev.map((m) => 
        m.id === assistantId ? { ...m, run_id: runId } : m
      ))

      // Abort any existing stream
      abortRef.current?.abort()
      eventSourceRef.current?.close()
      
      // Create new abort controller
      abortRef.current = new AbortController()

      // Open the event stream
      eventSourceRef.current = openRunStream(
        runId,
        threadId,
        0,
        abortRef.current.signal,
        (message: BackendMessage) => {
          handleStreamEvent(message, assistantId)
        }
      )

    } catch (error) {
      console.error('Error sending message:', error)
      setMessages((prev) =>
        prev.map((m) => 
          m.id === assistantId 
            ? { ...m, isStreaming: false, content: `Error: ${error instanceof Error ? error.message : 'Unknown error'}` }
            : m
        )
      )
      setIsStreaming(false)
    }
  }

  function handleStreamEvent(message: BackendMessage, assistantId: string) {
    switch (message.type) {
      case 'node_update':
        const nodeContent = message.payload.content || message.payload.node_content || ''
        if (nodeContent) {
          const nodeUpdate: NodeUpdate = {
            id: `${message.run_id}-${Date.now()}-${Math.random()}`,
            content: nodeContent,
            timestamp: Date.now()
          }
          setMessages((prev) => 
            prev.map((m) => 
              m.id === assistantId 
                ? { 
                    ...m, 
                    nodeUpdates: [...(m.nodeUpdates || []), nodeUpdate]
                  }
                : m
            )
          )
        }
        break

      case 'source_update':
        if (message.payload.sources && Array.isArray(message.payload.sources)) {
          const newSources: Source[] = message.payload.sources
          setMessages((prev) => 
            prev.map((m) => 
              m.id === assistantId 
                ? { ...m, sources: [...(m.sources || []), ...newSources] }
                : m
            )
          )
        }
        break

      case 'message_stream':
        const delta = message.payload.delta || ''
        // Stop thinking shimmer and auto-collapse when message streaming starts
        if (delta) {
          setIsThinking(false)
          // Find the current message and check if it's thinking
          setMessages((prev) => {
            const updatedMessages = prev.map((m) => 
              m.id === assistantId 
                ? { ...m, content: m.content + delta, isThinking: false }
                : m
            )
            // Check if the current message was thinking and collapse if so
            const currentMessage = prev.find(m => m.id === assistantId)
            if (currentMessage?.isThinking) {
              // Update thinking state for this specific message
              setThinkingStates(prevStates => ({
                ...prevStates,
                [assistantId]: { isOpen: false, autoMinimized: true }
              }))
              // Note: No need for global state updates anymore
            }
            return updatedMessages
          })
        }
        if (isAtBottomRef.current) {
          requestAnimationFrame(() => scrollToBottom('auto'))
        }
        break

      case 'run_completed':
        setMessages((prev) => 
          prev.map((m) => 
            m.id === assistantId 
              ? { ...m, isStreaming: false, isThinking: false }
              : m
          )
        )
        setIsStreaming(false)
        setIsThinking(false)
        eventSourceRef.current?.close()
        break

      case 'run_failed':
        const errorMessage = message.payload.error || 'Run failed'
        setMessages((prev) => 
          prev.map((m) => 
            m.id === assistantId 
              ? { ...m, isStreaming: false, isThinking: false, content: m.content + `\n\nError: ${errorMessage}` }
              : m
          )
        )
        setIsStreaming(false)
        setIsThinking(false)
        eventSourceRef.current?.close()
        break

      case 'tool_call':
      case 'tool_progress':
      case 'tool_result':
        // Tool events are handled elsewhere if needed
        break

      default:
        // Handle other message types as needed
        console.log('Unhandled message type:', message.type, message)
        break
    }
  }

  function handleStop() {
    abortRef.current?.abort()
    eventSourceRef.current?.close()
    setIsStreaming(false)
    setIsThinking(false)
    setMessages((prev) =>
      prev.map((m, i, arr) => 
        i === arr.length - 1 && m.role === 'assistant' 
          ? { ...m, isStreaming: false, isThinking: false } 
          : m
      )
    )
  }

  const hasMessages = messages.length > 0

  return (
    <div className="flex h-dvh flex-col text-neutral-100 relative">
      {/* ChatUI Logo/Heading */}
      {hasMessages ? (
        // Fixed top-left position when messages exist
        <div className="fixed top-4 left-4 z-40">
          <h1 className="text-xl font-bold text-neutral-100 chatui-heading">ChatUI</h1>
        </div>
      ) : (
        // Centered when no messages
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <h1 className="text-5xl font-bold text-neutral-100 mb-20 chatui-heading">ChatUI</h1>
        </div>
      )}

      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto px-4 pt-6"
        style={{ paddingBottom: inputHeight + 24 }}
      >
        <div className="mx-auto flex w-full max-w-4xl flex-col gap-3">
          {messages.map((m) => {
            const thinkingState = getThinkingState(m.id)
            return (
              <Message
                key={m.id}
                {...m}
                thinkingOpen={thinkingState.isOpen}
                onThinkingToggle={(isOpen) => handleThinkingToggle(m.id, isOpen)}
                autoMinimizedThinking={thinkingState.autoMinimized}
                isThinking={m.isThinking || false}
              />
            )
          })}
          <div ref={bottomSentinelRef} />
        </div>
      </div>

      <PromptInput
        onSend={handleSend}
        models={models}
        defaultModelId={currentModelId}
        onModelChange={(id) => setCurrentModelId(id)}
        defaultAgentTypeId={currentAgentType}
        onAgentTypeChange={(type) => setCurrentAgentType(type)}
        onHeightChange={setInputHeight}
        isStreaming={isStreaming}
        onStop={handleStop}
      />
    </div>
  )
}

export type { ChatMessage }