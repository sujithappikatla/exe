// Backend MESSAGE types
export type MessageType = 
  | 'run_start'
  | 'run_started'
  | 'run_completed'
  | 'run_failed'
  | 'message_stream'
  | 'node_update'
  | 'source_update'
  | 'custom'
  | 'tool_call'
  | 'tool_progress'
  | 'tool_result'

export interface BackendMessage {
  type: MessageType
  thread_id?: string
  run_id?: string
  payload: Record<string, any>
}

// Frontend chat types
export type ChatRole = 'user' | 'assistant'
export type MessageState = 'pending' | 'streaming' | 'completed' | 'errored'

export interface NodeUpdate {
  id: string
  content: string
  timestamp: number
}

export interface Source {
  name: string
  url?: string
  content: string
}

export interface ChatMessage {
  id: string
  role: ChatRole
  content: string
  isStreaming?: boolean
  thread_id?: string
  run_id?: string
  nodeUpdates?: NodeUpdate[]
  isThinking?: boolean
  sources?: Source[]
}

// API Response types
export interface RunResponse {
  type: MessageType
  thread_id: string
  run_id: string
  payload: Record<string, any>
}