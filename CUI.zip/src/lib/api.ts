import type { BackendMessage, RunResponse, ChatMessage } from '../types/protocol'

const BASE = (import.meta as any).env?.VITE_BACKEND_URL ?? 'http://localhost:8000'

/**
 * Start a new run with a user message
 */
export async function startRun(
  message: string, 
  threadId?: string, 
  runId?: string, 
  model?: string, 
  agentType?: 'fast' | 'slow'
): Promise<RunResponse> {
  const payload: BackendMessage = {
    type: 'run_start',
    thread_id: threadId,
    run_id: runId,
    payload: {
      message: message,
      model: model,
      agent_type: agentType
    }
  }

  const res = await fetch(`${BASE}/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  
  if (!res.ok) {
    throw new Error(`Failed to start run: ${res.status} ${res.statusText}`)
  }
  
  return res.json()
}

/**
 * Open a stream to receive run events
 */
export function openRunStream(
  runId: string, 
  threadId: string, 
  startFrom: number = 0,
  signal: AbortSignal, 
  onEvent: (message: BackendMessage) => void
) {
  const url = `${BASE}/run/${encodeURIComponent(runId)}/${encodeURIComponent(threadId)}/${startFrom}`
  
  const eventSource = new EventSource(url)
  
  eventSource.onmessage = (event) => {
    try {
      const message: BackendMessage = JSON.parse(event.data)
      onEvent(message)
    } catch (error) {
      console.error('Failed to parse event data:', error)
    }
  }
  
  eventSource.onerror = (error) => {
    console.error('EventSource error:', error)
    eventSource.close()
  }
  
  // Close the connection when aborted
  signal.addEventListener('abort', () => {
    eventSource.close()
  })
  
  return eventSource
}

/**
 * Generate a simple UUID for thread/run IDs
 */
export function generateId(): string {
  return 'xxxx-xxxx-4xxx-yxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0
    const v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}