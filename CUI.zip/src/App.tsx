import ChatUI from './components/ChatUI'
import { useEffect } from 'react'

function App() {
  useEffect(() => {
    document.title = 'ChatUI'
  }, [])
  return (
    <>
      <ChatUI
        models={[
          { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' },
          { id: 'gemini-2.0-flash-lite', label: 'Gemini 2.0 Flash Lite' },
          { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash' },
        ]}
      />
      <ScriptedActionsLogger />
    </>
  )
}

export default App

// Demo glue to surface Actions events in devtools
import React from 'react'
function ScriptedActionsLogger() {
  React.useEffect(() => {
    function handler(e: any) {
      // eslint-disable-next-line no-console
      console.log('Action:', e.detail)
    }
    window.addEventListener('sb:message-action', handler as EventListener)
    return () => window.removeEventListener('sb:message-action', handler as EventListener)
  }, [])
  return null
}
