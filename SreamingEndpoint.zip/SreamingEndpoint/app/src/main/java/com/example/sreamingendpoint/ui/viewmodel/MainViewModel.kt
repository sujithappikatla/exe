package com.example.sreamingendpoint.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sreamingendpoint.data.models.ExplainResponse
import com.example.sreamingendpoint.data.repository.GeminiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val repository: GeminiRepository) : ViewModel() {
    private val _explanationState = MutableStateFlow<ExplainResponse?>(null)
    val explanationState = _explanationState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    fun getExplanation(analysis: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _explanationState.value = null // Clear previous content
            try {
                repository.getExplanationStream(analysis).collect { response ->
                    _explanationState.value = response
                }
            } catch (e: Exception) {
                // Handle error
            } finally {
                _isLoading.value = false
            }
        }
    }
} 