package com.example.sreamingendpoint

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.sreamingendpoint.data.api.GeminiApi
import com.example.sreamingendpoint.data.repository.GeminiRepository
import com.example.sreamingendpoint.ui.theme.SreamingEndpointTheme
import com.example.sreamingendpoint.ui.viewmodel.MainViewModel
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Retrofit and dependencies
        val retrofit = Retrofit.Builder()
            .baseUrl("https://c2s-endpoint-server-305533803718.us-central1.run.app")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val api = retrofit.create(GeminiApi::class.java)
        val repository = GeminiRepository(api)
        viewModel = MainViewModel(repository)

        enableEdgeToEdge()
        setContent {
            SreamingEndpointTheme {
                ExplanationScreen(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExplanationScreen(viewModel: MainViewModel) {
    var inputText by remember { mutableStateOf("") }
    val explanation = viewModel.explanationState.collectAsStateWithLifecycle()
    val isLoading = viewModel.isLoading.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    LaunchedEffect(explanation.value) {
        // Auto-scroll to bottom when new content arrives
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Gemini Explain") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                label = { Text("Enter analysis text") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )

            Button(
                onClick = { 
                    viewModel.getExplanation(inputText)
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading.value
            ) {
                Text(if (isLoading.value) "Loading..." else "Get Explanation")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(scrollState)
                ) {
                    Text(
                        text = explanation.value?.content ?: "",
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    if (isLoading.value) {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        )
                    }
                }
            }

            explanation.value?.citations?.let { citations ->
                if (citations.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Citations:", style = MaterialTheme.typography.titleMedium)
                    citations.forEach { citation ->
                        Text("- ${citation.title}")
                    }
                }
            }
        }
    }
}