package com.example.sreamingendpoint.data.models

data class Citation(
    val title: String,
    val uri: String
) 