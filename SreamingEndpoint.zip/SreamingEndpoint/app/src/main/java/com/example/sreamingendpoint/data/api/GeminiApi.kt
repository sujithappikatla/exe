package com.example.sreamingendpoint.data.api

import com.example.sreamingendpoint.data.models.ExplainRequest
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Streaming

interface GeminiApi {
    @Streaming
    @POST("/api/gemini/explain-stream")
    suspend fun getExplanationStream(
        @Body request: ExplainRequest
    ): ResponseBody
} 