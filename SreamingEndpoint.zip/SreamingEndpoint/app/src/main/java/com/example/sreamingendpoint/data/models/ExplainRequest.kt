package com.example.sreamingendpoint.data.models

data class ExplainRequest(
    val analysis: String
) 