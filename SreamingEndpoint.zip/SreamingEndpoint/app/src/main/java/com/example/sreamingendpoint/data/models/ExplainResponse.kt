package com.example.sreamingendpoint.data.models

data class ExplainResponse(
    val content: String,
    val rendered_content: String,
    val citations: List<Citation>
) 