package com.example.sreamingendpoint.data.repository

import com.example.sreamingendpoint.data.api.GeminiApi
import com.example.sreamingendpoint.data.models.ExplainRequest
import com.example.sreamingendpoint.data.models.ExplainResponse
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.BufferedReader
import java.io.InputStreamReader

class GeminiRepository(private val api: GeminiApi) {
    private val gson = Gson()

    fun getExplanationStream(analysis: String): Flow<ExplainResponse> = flow {
        val response = api.getExplanationStream(ExplainRequest(analysis))
        val reader = BufferedReader(InputStreamReader(response.byteStream()))
        
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            line?.let { jsonLine ->
                try {
                    val explainResponse = gson.fromJson(jsonLine, ExplainResponse::class.java)
                    emit(explainResponse)
                    // Add a small delay to make the streaming visible
                    kotlinx.coroutines.delay(50)
                } catch (e: Exception) {
                    // Handle JSON parsing error
                }
            }
        }
    }.flowOn(Dispatchers.IO)
} 