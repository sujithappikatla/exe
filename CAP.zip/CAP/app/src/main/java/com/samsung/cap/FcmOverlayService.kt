package com.samsung.cap

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.samsung.cap.ui.theme.CAPTheme

/**
 * Foreground service that displays FCM messages as full-screen overlay windows using Jetpack Compose.
 * Displays HTML content from FCM messages in a WebView.
 */
class FcmOverlayService : Service() {

    companion object {
        private const val TAG = "FcmOverlayService"
        private const val NOTIFICATION_CHANNEL_ID = "fcm_overlay_service"
        private const val NOTIFICATION_CHANNEL_NAME = "FCM Overlay Service"
        private const val NOTIFICATION_ID = 100
        
        const val EXTRA_HTML_CONTENT = "extra_html_content"
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: ComposeView? = null

    override fun onCreate() {
        super.onCreate()
        println("FcmOverlayService: onCreate")
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        println("FcmOverlayService: onStartCommand")
        
        // Create notification channel and start as foreground service
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        
        // Check if this start command contains message data
        intent?.let {
            val htmlContent = it.getStringExtra(EXTRA_HTML_CONTENT)
            if (htmlContent != null) {
                println("FcmOverlayService: Showing overlay with HTML content (${htmlContent.length} chars)")
                showOverlay(htmlContent)
            }
        }
        
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        println("FcmOverlayService: onDestroy")
        removeOverlay()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notification channel for FCM overlay service"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification() = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
        .setContentTitle("CAP Service Running")
        .setContentText("Listening for FCM messages")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setOngoing(true)
        .build()

    /**
     * Shows the full-screen overlay with HTML content in a WebView using Jetpack Compose.
     */
    private fun showOverlay(htmlContent: String) {
        println("FcmOverlayService: showOverlay called")
        
        // Remove existing overlay if any
        removeOverlay()
        
        // Check overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            println("FcmOverlayService: Overlay permission not granted!")
            return
        }
        
        try {
            // Create lifecycle owner for Compose
            val lifecycleOwner = OverlayLifecycleOwner()
            lifecycleOwner.performStart()
            
            // Create ComposeView
            overlayView = ComposeView(this).apply {
                setViewTreeLifecycleOwner(lifecycleOwner)
                setViewTreeSavedStateRegistryOwner(lifecycleOwner)
                
                setContent {
                    CAPTheme {
                        OverlayContent(
                            htmlContent = htmlContent,
                            onClose = { removeOverlay() }
                        )
                    }
                }
            }
            
            // Set up window parameters for complete full-screen overlay (covering system bars)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_FULLSCREEN or
                        WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = 0
                // Make it cover status bar and navigation bar
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            
            // Add view to WindowManager
            windowManager.addView(overlayView, params)
            
            println("FcmOverlayService: Overlay displayed successfully")
            
        } catch (e: Exception) {
            println("FcmOverlayService: Error showing overlay: ${e.message}")
            e.printStackTrace()
        }
    }

    /**
     * Removes the overlay from the screen.
     */
    private fun removeOverlay() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
                println("FcmOverlayService: Overlay removed")
            } catch (e: Exception) {
                println("FcmOverlayService: Error removing overlay: ${e.message}")
            }
            overlayView = null
        }
    }
}

/**
 * Lifecycle owner for ComposeView in a Service context.
 */
private class OverlayLifecycleOwner : LifecycleOwner, SavedStateRegistryOwner {
    
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    
    override val lifecycle: Lifecycle
        get() = lifecycleRegistry
    
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry
    
    fun performStart() {
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
    }
}

/**
 * Composable content for the FCM message overlay with WebView.
 */
@Composable
fun OverlayContent(
    htmlContent: String,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // WebView covering entire screen
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    
                    // WebView settings
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        builtInZoomControls = false
                        displayZoomControls = false
                    }
                    
                    // Set background color
                    setBackgroundColor(Color.WHITE)
                    
                    // Set WebViewClient to handle links
                    webViewClient = WebViewClient()
                    
                    // Load HTML content
                    loadDataWithBaseURL(
                        null,
                        htmlContent,
                        "text/html",
                        "UTF-8",
                        null
                    )
                    
                    println("FcmOverlayService: WebView created and HTML loaded")
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        
        // Floating close button at top-right corner
        IconButton(
            onClick = {
                println("FcmOverlayService: Close button clicked")
                onClose()
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 48.dp, end = 16.dp)
                .size(48.dp)
                .background(
                    androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.6f),
                    CircleShape
                )
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = androidx.compose.ui.graphics.Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
