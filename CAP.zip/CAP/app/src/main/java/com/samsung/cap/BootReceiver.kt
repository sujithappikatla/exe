package com.samsung.cap

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

/**
 * BroadcastReceiver that starts the FCM overlay service on device boot.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        println("BootReceiver: onReceive - action: ${intent?.action}")
        
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            println("BootReceiver: Boot completed, starting overlay service")
            
            // Check if overlay permission is granted
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                println("BootReceiver: Overlay permission not granted, cannot start service")
                return
            }
            
            // Start the overlay service
            val serviceIntent = Intent(context, FcmOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            
            println("BootReceiver: Service start intent sent")
        }
    }
}

