package com.samsung.cap

import android.app.Application
import android.content.Intent
import android.os.Build
import android.provider.Settings

/**
 * Application class that initializes the FCM overlay service when the app starts.
 */
class CapApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        println("CapApplication: onCreate")
        
        // Start the overlay service if we have permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startOverlayService()
        } else {
            println("CapApplication: Overlay permission not granted, service will start after permission is granted")
        }
    }
    
    /**
     * Starts the FCM overlay foreground service.
     */
    fun startOverlayService() {
        println("CapApplication: Starting FcmOverlayService")
        val serviceIntent = Intent(this, FcmOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}

