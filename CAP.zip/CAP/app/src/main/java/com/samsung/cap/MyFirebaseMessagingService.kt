package com.samsung.cap

import android.content.Intent
import android.os.Build
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Firebase Messaging Service to handle FCM data messages and token updates.
 * 
 * This service:
 * - Logs new FCM tokens to the console
 * - Receives data messages and sends them to FcmOverlayService for display
 */
class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "FCM_SERVICE"
    }

    /**
     * Called when a new FCM token is generated.
     * This happens on first app launch and when the token is refreshed.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        println("==============================================")
        println("FCM_TOKEN: New FCM Token: $token")
        println("==============================================")
    }

    /**
     * Called when a data message is received from FCM.
     * Sends the message data to FcmOverlayService for display.
     */
    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        
        println("==============================================")
        println("FCM Service: Message received from: ${message.from}")
        
        // Extract only the "message" field which contains HTML content
        val data = message.data
        val htmlContent = data["message"] ?: "<html><body><h1>No message content</h1></body></html>"
        
        println("FCM Service: HTML message length: ${htmlContent.length} characters")
        
        // Send message to overlay service via direct Intent
        showOverlayViaService(htmlContent)
        
        println("==============================================")
    }

    /**
     * Sends the FCM message to FcmOverlayService for display as overlay.
     */
    private fun showOverlayViaService(htmlContent: String) {
        println("FCM Service: Sending message to FcmOverlayService")
        
        val serviceIntent = Intent(this, FcmOverlayService::class.java).apply {
            putExtra(FcmOverlayService.EXTRA_HTML_CONTENT, htmlContent)
        }
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            println("FCM Service: Service intent sent successfully")
        } catch (e: Exception) {
            println("FCM Service: Error starting overlay service: ${e.message}")
            e.printStackTrace()
        }
    }
}
