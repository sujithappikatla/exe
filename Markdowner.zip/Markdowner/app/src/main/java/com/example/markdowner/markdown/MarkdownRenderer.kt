package com.example.markdowner.markdown


import com.example.markdowner.syntax.SyntaxHighlighter
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.times
import coil.compose.AsyncImage
import com.example.markdowner.markdown.MarkdownTheme
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString


@Composable
fun MarkdownContent(
    markdown: String,
    modifier: Modifier = Modifier,
    theme: MarkdownTheme = MarkdownTheme.Default
) {
    val parser = remember { MarkdownParser() }
    val elements by remember(markdown) { 
        derivedStateOf { parser.parse(markdown) }
    }
    
    val clipboardManager = LocalClipboardManager.current
    
    CompositionLocalProvider(
        LocalTextSelectionColors provides TextSelectionColors(
            handleColor = Color(0xFF26772A),
            backgroundColor = Color(0x3326772A)
        )
    ) {
        SelectionContainer {
            LazyColumn(
                modifier = modifier,
                verticalArrangement = Arrangement.spacedBy(theme.verticalSpacing)
            ) {
                items(elements) { element ->
                    MarkdownElement(element, theme)
                }
            }
        }
    }
}

@Composable
private fun MarkdownElement(
    element: MarkdownElement,
    theme: MarkdownTheme
) {

    Log.i("TAGG", "--------"+element.toString())
    when (element) {
        is MarkdownElement.Header -> HeaderElement(element, theme)
        is MarkdownElement.Paragraph -> ParagraphElement(element, theme)
        is MarkdownElement.CodeBlock -> CodeBlockElement(element, theme)
        is MarkdownElement.MarkdownList -> ListElement(element, theme)
        is MarkdownElement.BlockQuote -> BlockQuoteElement(element, theme)
        is MarkdownElement.Table -> TableElement(element, theme)
        is MarkdownElement.Image -> ImageElement(element, theme)
        is MarkdownElement.Link -> LinkElement(element, theme)
    }
}

@Composable
private fun HeaderElement(
    header: MarkdownElement.Header,
    theme: MarkdownTheme
) {
    val style = when (header.level) {
        1 -> theme.h1Style
        2 -> theme.h2Style
        3 -> theme.h3Style
        4 -> theme.h4Style
        5 -> theme.h5Style
        else -> theme.h6Style
    }
    
    theme.customHeaderComposable?.invoke(header.text, header.level) ?: run {
        Text(
            text = header.text,
            style = style,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = theme.headerMargins.top)
        )
    }
    if(header.level == 1)
    {
        HorizontalDivider()
    }
}

@Composable
private fun ParagraphElement(
    paragraph: MarkdownElement.Paragraph,
    theme: MarkdownTheme
) {

    Text(
        text = parseInlineFormatting(paragraph.text, theme),
        style = theme.paragraphStyle,
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                top = theme.paragraphMargins.top,
                bottom = theme.paragraphMargins.bottom
            )
    )
}

@Composable
private fun CodeBlockElement(
    codeBlock: MarkdownElement.CodeBlock,
    theme: MarkdownTheme
) {
    val highlighter = remember { SyntaxHighlighter() }
    val highlightedCode = remember(codeBlock.code, codeBlock.language) {
        highlighter.highlight(codeBlock.code, codeBlock.language)
    }

    theme.customCodeBlockComposable?.invoke(codeBlock.code, codeBlock.language) ?: run {
        Text(
            text = highlightedCode,
            style = theme.codeStyle,
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = theme.codeBackground,
                    shape = MaterialTheme.shapes.small
                )
                .padding(theme.codeBlockPadding)
        )
    }
}

@Composable
private fun ListElement(
    list: MarkdownElement.MarkdownList,
    theme: MarkdownTheme
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                top = theme.listMargins.top,
                bottom = theme.listMargins.bottom
            )
    ) {
        list.items.forEach { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = theme.listIndentation * item.level)
            ) {
                Text(
                    text = if (list.isOrdered) "${list.items.indexOf(item) + 1}." else "•",
                    style = theme.listItemStyle,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = parseInlineFormatting(item.text, theme),
                    style = theme.listItemStyle
                )
            }
            Spacer(modifier = Modifier.height(theme.listItemSpacing))
        }
    }
}

@Composable
private fun BlockQuoteElement(
    blockQuote: MarkdownElement.BlockQuote,
    theme: MarkdownTheme
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = (blockQuote.level - 1) * theme.quoteIndentation,
                top = theme.quoteMargins.top,
                bottom = theme.quoteMargins.bottom
            )
    ) {
        // Vertical line
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(Color.LightGray.copy(alpha = 0.5f))
        )
        // Quote content with padding
        Text(
            text = blockQuote.text,
            style = theme.quoteStyle,
            modifier = Modifier
                .weight(1f)
                .padding(start = 12.dp, top = 4.dp, bottom = 4.dp)
        )
    }
}

@Composable
private fun TableElement(
    table: MarkdownElement.Table,
    theme: MarkdownTheme
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = theme.tableMargins.top)
            .clip(MaterialTheme.shapes.small)
            .border(
                width = 1.dp,
                color = theme.tableBorderColor,
                shape = MaterialTheme.shapes.small
            )
    ) {
        // Headers
        Row(
            Modifier
                .fillMaxWidth()
                .background(theme.tableHeaderBackground)
        ) {
            table.headers.forEach { header ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .border(
                            width = 0.5.dp,
                            color = theme.tableBorderColor.copy(alpha = 0.5f)
                        )
                ) {
                    Text(
                        text = header,
                        style = theme.paragraphStyle.copy(
                            fontWeight = FontWeight.Bold,
                            color = theme.tableHeaderTextColor
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(all = theme.tableCellPadding)
                    )
                }
            }
        }
        
        // Rows with alternating background
        table.rows.forEachIndexed { index, row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(
                        if (index % 2 == 0) theme.tableRowBackgroundEven
                        else theme.tableRowBackgroundOdd
                    )
            ) {
                row.forEach { cell ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = 0.5.dp,
                                color = theme.tableBorderColor.copy(alpha = 0.5f)
                            )
                    ) {
                        Text(
                            text = cell,
                            style = theme.paragraphStyle,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(all = theme.tableCellPadding)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageElement(
    image: MarkdownElement.Image,
    theme: MarkdownTheme
) {
    if (!theme.loadImages) return
    
    theme.customImageComposable?.invoke(image.altText, image.url) ?: run {
        AsyncImage(
            model = image.url,
            contentDescription = image.altText,
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    top = theme.imageMargins.top,
                    bottom = theme.imageMargins.bottom
                )
                .heightIn(max = theme.maxImageSize),
            contentScale = ContentScale.FillWidth
        )
    }
}

@Composable
private fun LinkElement(
    link: MarkdownElement.Link,
    theme: MarkdownTheme
) {
    theme.customLinkComposable?.invoke(link.text, link.url) ?: run {
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(
                    color = theme.linkColor,
                    textDecoration = TextDecoration.Underline
                )) {
                    append(link.text)
                }
            },
            style = theme.paragraphStyle,
            modifier = Modifier.clickable {
                // Handle link click - you might want to pass a callback through theme
                // or handle this differently based on your needs
            }
        )
    }
}

private fun parseInlineFormatting(text: String, theme: MarkdownTheme) = buildAnnotatedString {
    var currentIndex = 0
    
    while (currentIndex < text.length) {
        when {
            text.startsWith("**", currentIndex) -> {
                // Bold text (two asterisks)
                val endIndex = text.indexOf("**", currentIndex + 2)
                if (endIndex != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(text.substring(currentIndex + 2, endIndex))
                    }
                    currentIndex = endIndex + 2
                }
                else
                {
                    append(text[currentIndex])
                    currentIndex++
                }
            }
            text.startsWith("*", currentIndex) -> {
                // Italic text (single asterisk)
                val endIndex = text.indexOf("*", currentIndex + 1)
                if (endIndex != -1) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(text.substring(currentIndex + 1, endIndex))
                    }
                    currentIndex = endIndex + 1
                }
                else
                {
                    append(text[currentIndex])
                    currentIndex++
                }
            }
            text.startsWith("`", currentIndex) -> {
                // Inline code
                val endIndex = text.indexOf("`", currentIndex + 1)
                if (endIndex != -1) {
                    withStyle(SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        background = theme.codeBackground
                    )) {
                        append(text.substring(currentIndex + 1, endIndex))
                    }
                    currentIndex = endIndex + 1
                }
                else
                {
                    append(text[currentIndex])
                    currentIndex++
                }
            }
            else -> {
                append(text[currentIndex])
                currentIndex++
            }
        }
    }
} 