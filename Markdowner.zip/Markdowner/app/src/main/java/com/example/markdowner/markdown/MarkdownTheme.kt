package com.example.markdowner.markdown

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit

data class MarkdownTheme(
    // Typography
    val h1Style: TextStyle = TextStyle(
        fontSize = 28.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 36.sp
    ),
    val h2Style: TextStyle = TextStyle(
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 32.sp
    ),
    val h3Style: TextStyle = TextStyle(
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 28.sp
    ),
    val h4Style: TextStyle = TextStyle(
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 24.sp
    ),
    val h5Style: TextStyle = TextStyle(
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 22.sp
    ),
    val h6Style: TextStyle = TextStyle(
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 20.sp
    ),
    val paragraphStyle: TextStyle = TextStyle(
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    val codeStyle: TextStyle = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    val quoteStyle: TextStyle = TextStyle(
        fontSize = 16.sp,
        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
        lineHeight = 24.sp
    ),
    val listItemStyle: TextStyle = TextStyle(
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),

    // Text Customization
    val letterSpacing: TextUnit = 0.sp,
    val textAlign: TextAlign = TextAlign.Start,

    // Colors
    val linkColor: Color = Color.Blue,
    val codeBackground: Color = Color.LightGray.copy(0.3f),
    val quoteBackground: Color = Color.LightGray.copy(alpha = 0.3f),
    val tableBorderColor: Color = Color.Gray,

    // Spacing
    val headerSpacing: Dp = 16.dp,
    val paragraphSpacing: Dp = 8.dp,
    val listItemSpacing: Dp = 4.dp,
    val listIndentation: Dp = 24.dp,
    val codeBlockPadding: Dp = 8.dp,
    val quoteIndicatorWidth: Dp = 4.dp,
    val tableCellPadding: Dp = 12.dp,
    val verticalSpacing: Dp = 16.dp,

    // Behavior
    val showIncompleteFormatting: Boolean = true,
    val loadImages: Boolean = true,
    val maxImageSize: Dp = 300.dp,

    // Custom Composables
    val customHeaderComposable: (@Composable (String, Int) -> Unit)? = null,
    val customCodeBlockComposable: (@Composable (String, String?) -> Unit)? = null,
    val customLinkComposable: (@Composable (String, String) -> Unit)? = null,
    val customImageComposable: (@Composable (String, String) -> Unit)? = null,

    // Element Margins
    val headerMargins: ElementMargins = ElementMargins(top = 5.dp, bottom = 5.dp),
    val paragraphMargins: ElementMargins = ElementMargins(top = 8.dp, bottom = 8.dp),
    val codeBlockMargins: ElementMargins = ElementMargins(top = 16.dp, bottom = 16.dp),
    val quoteMargins: ElementMargins = ElementMargins(top = 16.dp, bottom = 16.dp),
    val listMargins: ElementMargins = ElementMargins(top = 8.dp, bottom = 8.dp),
    val tableMargins: ElementMargins = ElementMargins(top = 16.dp, bottom = 16.dp),
    val imageMargins: ElementMargins = ElementMargins(top = 16.dp, bottom = 16.dp),

    // Table Colors
    val tableHeaderBackground: Color = Color(0xFF2B2B2B),
    val tableHeaderTextColor: Color = Color.White,
    val tableRowBackgroundEven: Color = Color.White,
    val tableRowBackgroundOdd: Color = Color(0xFFF5F5F5),

    val quoteIndentation: Dp = 24.dp,
    val quoteLineColor: Color = Color.LightGray.copy(alpha = 0.5f),

    // Syntax highlighting colors
    val syntaxKeyword: Color = Color(0xFF0033B3),  // blue
    val syntaxString: Color = Color(0xFF067D17),   // green
    val syntaxNumber: Color = Color(0xFF1750EB),   // bright blue
    val syntaxComment: Color = Color(0xFF8C8C8C),  // gray
    val syntaxType: Color = Color(0xFF00627A),     // teal
) {
    companion object {
        val Default = MarkdownTheme()
    }
}

data class ElementMargins(
    val top: Dp = 0.dp,
    val bottom: Dp = 0.dp
) 