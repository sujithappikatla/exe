package com.example.markdowner.markdown

sealed class MarkdownElement {
    data class Header(
        val text: String,
        val level: Int
    ) : MarkdownElement()

    data class Paragraph(
        val text: String
    ) : MarkdownElement()

    data class CodeBlock(
        val code: String,
        val language: String? = null
    ) : MarkdownElement()

    data class MarkdownList(
        val items: List<ListItem>,
        val isOrdered: Boolean
    ) : MarkdownElement()

    data class ListItem(
        val text: String,
        val level: Int = 0
    )

    data class BlockQuote(
        val text: String,
        val level: Int = 1
    ) : MarkdownElement()

    data class Table(
        val headers: List<String>,
        val rows: List<List<String>>
    ) : MarkdownElement()

    data class Link(
        val text: String,
        val url: String
    ) : MarkdownElement()

    data class Image(
        val altText: String,
        val url: String
    ) : MarkdownElement()
} 