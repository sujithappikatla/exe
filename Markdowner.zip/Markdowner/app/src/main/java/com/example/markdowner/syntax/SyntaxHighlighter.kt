package com.example.markdowner.syntax

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle

class SyntaxHighlighter {
    // Color scheme
    private val keywordColor = Color(0xFF0033B3)     // Blue
    private val typeColor = Color(0xFF00627A)        // Teal
    private val stringColor = Color(0xFF067D17)      // Green
    private val numberColor = Color(0xFF1750EB)      // Bright Blue
    private val commentColor = Color(0xFF8C8C8C)     // Gray
    private val functionColor = Color(0xFF7A2DA3)    // Purple
    private val constantColor = Color(0xFFC77A4B)    // Orange

    fun highlight(code: String, language: String?): AnnotatedString = buildAnnotatedString {
        when (language?.lowercase()) {
            "kotlin" -> highlightKotlin(code)
            "java" -> highlightJava(code)
            "python" -> highlightPython(code)
            "cpp", "c++" -> highlightCpp(code)
            "javascript", "js" -> highlightJavaScript(code)
            else -> highlightGeneric(code)
        }
    }

    private fun AnnotatedString.Builder.highlightKotlin(code: String) {
        val keywords = setOf(
            "fun", "val", "var", "class", "object", "interface", 
            "when", "if", "else", "for", "while", "do", "try", 
            "catch", "finally", "throw", "return", "continue", "break",
            "package", "import", "as", "is", "in", "!in", "by", "init"
        )
        val types = setOf(
            "String", "Int", "Boolean", "Float", "Double", "Long", 
            "List", "Map", "Set", "Array", "Unit", "Nothing", "Any"
        )
        
        var inString = false
        var inComment = false
        var currentToken = StringBuilder()
        
        code.forEachIndexed { index, char ->
            when {
                inComment -> {
                    if (char == '\n') {
                        withStyle(SpanStyle(color = Color(0xFF8C8C8C))) {
                            append(currentToken.toString())
                            append(char)
                        }
                        currentToken.clear()
                        inComment = false
                    } else {
                        currentToken.append(char)
                    }
                }
                inString -> {
                    currentToken.append(char)
                    if (char == '"' && code.getOrNull(index - 1) != '\\') {
                        withStyle(SpanStyle(color = Color(0xFF067D17))) {
                            append(currentToken.toString())
                        }
                        currentToken.clear()
                        inString = false
                    }
                }
                char == '/' && code.getOrNull(index + 1) == '/' -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    inComment = true
                    currentToken.append(char)
                }
                char == '"' -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    inString = true
                    currentToken.append(char)
                }
                char.isLetterOrDigit() || char == '_' -> {
                    currentToken.append(char)
                }
                else -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    append(char)
                }
            }
        }
        
        if (currentToken.isNotEmpty()) {
            appendToken(currentToken.toString(), keywords, types)
        }
    }

    private fun AnnotatedString.Builder.highlightJava(code: String) {
        val keywords = setOf(
            "abstract", "assert", "boolean", "break", "byte", "case", "catch",
            "char", "class", "const", "continue", "default", "do", "double",
            "else", "enum", "extends", "final", "finally", "float", "for",
            "if", "implements", "import", "instanceof", "int", "interface",
            "long", "native", "new", "package", "private", "protected",
            "public", "return", "short", "static", "strictfp", "super",
            "switch", "synchronized", "this", "throw", "throws", "transient",
            "try", "void", "volatile", "while", "true", "false", "null"
        )
        
        val types = setOf(
            "String", "Integer", "Boolean", "Float", "Double", "Long",
            "List", "Map", "Set", "Array", "Object", "Class", "Exception"
        )

        highlightCode(code, keywords, types)
    }

    private fun AnnotatedString.Builder.highlightPython(code: String) {
        val keywords = setOf(
            "and", "as", "assert", "break", "class", "continue", "def",
            "del", "elif", "else", "except", "finally", "for", "from",
            "global", "if", "import", "in", "is", "lambda", "nonlocal",
            "not", "or", "pass", "raise", "return", "try", "while",
            "with", "yield", "True", "False", "None"
        )
        
        val types = setOf(
            "int", "float", "str", "list", "dict", "set", "tuple",
            "bool", "bytes", "object", "Exception"
        )

        highlightCode(code, keywords, types)
    }

    private fun AnnotatedString.Builder.highlightCpp(code: String) {
        val keywords = setOf(
            "auto", "break", "case", "catch", "class", "const", "continue",
            "default", "delete", "do", "else", "enum", "explicit", "export",
            "extern", "for", "friend", "goto", "if", "inline", "mutable",
            "namespace", "new", "operator", "private", "protected", "public",
            "register", "return", "sizeof", "static", "struct", "switch",
            "template", "this", "throw", "try", "typedef", "typename",
            "union", "using", "virtual", "volatile", "while"
        )
        
        val types = setOf(
            "bool", "char", "double", "float", "int", "long", "short",
            "signed", "unsigned", "void", "wchar_t", "string", "vector",
            "map", "set", "list", "queue", "stack", "pair"
        )

        highlightCode(code, keywords, types)
    }

    private fun AnnotatedString.Builder.highlightJavaScript(code: String) {
        val keywords = setOf(
            "async", "await", "break", "case", "catch", "class", "const",
            "continue", "debugger", "default", "delete", "do", "else",
            "export", "extends", "finally", "for", "function", "if",
            "import", "in", "instanceof", "let", "new", "return", "super",
            "switch", "this", "throw", "try", "typeof", "var", "void",
            "while", "with", "yield", "true", "false", "null", "undefined"
        )
        
        val types = setOf(
            "Array", "Boolean", "Date", "Error", "Function", "JSON",
            "Math", "Number", "Object", "RegExp", "String", "Promise",
            "Map", "Set", "Symbol", "BigInt"
        )

        highlightCode(code, keywords, types)
    }

    private fun AnnotatedString.Builder.highlightCode(
        code: String,
        keywords: Set<String>,
        types: Set<String>
    ) {
        var inString = false
        var inChar = false
        var inComment = false
        var inMultilineComment = false
        var currentToken = StringBuilder()
        
        code.forEachIndexed { index, char ->
            when {
                inMultilineComment -> {
                    currentToken.append(char)
                    if (char == '/' && code.getOrNull(index - 1) == '*') {
                        withStyle(SpanStyle(color = commentColor)) {
                            append(currentToken.toString())
                        }
                        currentToken.clear()
                        inMultilineComment = false
                    }
                }
                inComment -> {
                    if (char == '\n') {
                        withStyle(SpanStyle(color = commentColor)) {
                            append(currentToken.toString())
                            append(char)
                        }
                        currentToken.clear()
                        inComment = false
                    } else {
                        currentToken.append(char)
                    }
                }
                inString -> {
                    currentToken.append(char)
                    if (char == '"' && code.getOrNull(index - 1) != '\\') {
                        withStyle(SpanStyle(color = stringColor)) {
                            append(currentToken.toString())
                        }
                        currentToken.clear()
                        inString = false
                    }
                }
                inChar -> {
                    currentToken.append(char)
                    if (char == '\'' && code.getOrNull(index - 1) != '\\') {
                        withStyle(SpanStyle(color = stringColor)) {
                            append(currentToken.toString())
                        }
                        currentToken.clear()
                        inChar = false
                    }
                }
                char == '/' && code.getOrNull(index + 1) == '*' -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    inMultilineComment = true
                    currentToken.append(char)
                }
                char == '/' && code.getOrNull(index + 1) == '/' -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    inComment = true
                    currentToken.append(char)
                }
                char == '"' -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    inString = true
                    currentToken.append(char)
                }
                char == '\'' -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    inChar = true
                    currentToken.append(char)
                }
                char.isLetterOrDigit() || char == '_' -> {
                    currentToken.append(char)
                }
                else -> {
                    if (currentToken.isNotEmpty()) {
                        appendToken(currentToken.toString(), keywords, types)
                        currentToken.clear()
                    }
                    append(char)
                }
            }
        }
        
        if (currentToken.isNotEmpty()) {
            appendToken(currentToken.toString(), keywords, types)
        }
    }

    private fun AnnotatedString.Builder.appendToken(
        token: String,
        keywords: Set<String>,
        types: Set<String>
    ) {
        when {
            keywords.contains(token) -> withStyle(SpanStyle(color = keywordColor)) { append(token) }
            types.contains(token) -> withStyle(SpanStyle(color = typeColor)) { append(token) }
            token.matches(Regex("\\d+(\\.\\d+)?")) -> withStyle(SpanStyle(color = numberColor)) { append(token) }
            token.matches(Regex("[A-Z][A-Z0-9_]+")) -> withStyle(SpanStyle(color = constantColor)) { append(token) }
            token.matches(Regex("[a-zA-Z_][a-zA-Z0-9_]*\\s*\\(")) -> withStyle(SpanStyle(color = functionColor)) { append(token) }
            else -> append(token)
        }
    }

    private fun AnnotatedString.Builder.highlightGeneric(code: String) {
        append(code)
    }
} 