package com.example.markdowner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _markdownContent = MutableStateFlow("")
    val markdownContent = _markdownContent.asStateFlow()

    init {
        streamContent()
    }

    private fun streamContent() {
        viewModelScope.launch {
//            val chunks = sampleMarkdown.split("\n\n")
//            chunks.forEach { chunk ->
//                delay(500) // Delay between chunks
//                _markdownContent.update { current ->
//                    if (current.isEmpty()) chunk
//                    else "$current\n\n$chunk"
//                }
//            }

            val len = sampleMarkdown.length
            var idx = 0
            val offset = 10
            while(idx+offset < len)
            {
                _markdownContent.update{current ->
                    "$current${sampleMarkdown.substring(idx, idx+offset)}"

                }
                idx += offset
                delay(10)
            }

        }
    }

    companion object {
        private val sampleMarkdown = """         # Segment Trees: Efficient Data Structures for Range Queries

Segment trees are powerful tree data structures used to efficiently perform range queries on an array.  They allow for quick updates and retrieval of information about sub-arrays, such as sum, minimum, maximum, etc., within a given range.

## I. Core Concepts

A segment tree is a binary tree where each node represents an interval (or segment) of the input array.

* **Leaf Nodes:** Represent single elements of the input array.
    * hello
    * hello2
* **Internal Nodes:** Represent the aggregation of their children's intervals.  The aggregation operation depends on the specific query (sum, min, max, etc.).

**Example:**  Consider an array `arr = [1, 3, 5, 7, 9, 11]`.  A segment tree representing the sum of elements in each segment might look like this:

```
                                     36 (Sum of entire array)
                                    /       \
                              10 (1+3+5+1)          26 (7+9+11)
                             /  \                    /   \
                         4(1+3)   6(5+1)         16(7+9)  11
                        / \    / \                /  \     
                       1   3  5   1             7   9     11
```


## II. Operations

### A. Construction

Building a segment tree involves recursively dividing the input array into halves and creating nodes to represent the segments.  The complexity is O(n), where n is the array size.

### B. Querying

To query a range [l, r], we traverse the tree, only visiting nodes whose intervals overlap with the query range.  The complexity is O(log n).

### C. Updating

To update an element at a specific index, we traverse the tree from the leaf node representing that element up to the root, updating the aggregated values along the path. The complexity is O(log n).


## III. Python Code Implementation (Sum Query)

This implementation demonstrates a segment tree for sum queries.  It can be easily adapted for other aggregation operations by changing the `aggregate` function.

```python
class SegmentTree:
    def __init__(self, arr):
        self.n = len(arr)
        self.tree = [0] * (2 * self.n)  # Double the size to handle leaves and internal nodes efficiently

        # Build the segment tree
        self._build(arr)

    def _build(self, arr):
        # Copy the input array to the leaf nodes of the tree
        for i in range(self.n):
            self.tree[self.n + i] = arr[i]

        # Build the internal nodes from bottom up
        for i in range(self.n - 1, 0, -1):
            self.tree[i] = self.aggregate(self.tree[i << 1], self.tree[i << 1 | 1])  #aggregate left and right child

    def aggregate(self, a, b):
        return a + b  # Change this for min, max, etc.

    def query(self, l, r):
        ""${'"'}Query the sum of elements in the range [l, r] (inclusive).""${'"'}
        res = 0
        l += self.n  # Adjust indices to account for leaf nodes
        r += self.n

        while l < r:
            if l & 1:  # If l is odd
                res += self.tree[l]
                l += 1
            if r & 1:  # If r is odd
                r -= 1
                res += self.tree[r]
            l >>= 1  # Divide l and r by 2
            r >>= 1
        return res

    def update(self, index, val):
        ""${'"'}Update the value at index to val.""${'"'}
        index += self.n
        self.tree[index] = val
        while index > 1:
            self.tree[index >> 1] = self.aggregate(self.tree[index], self.tree[index ^ 1]) # ^1 gets sibling node
            index >>= 1



# Example usage:
arr = [1, 3, 5, 7, 9, 11]
st = SegmentTree(arr)

print(f"Sum of array: {st.query(0, len(arr)-1)}")  # Output: 36
print(f"Sum of [1, 3]: {st.query(1, 3)}")  # Output: 15
st.update(1,10) # update the second element to 10
print(f"Sum of array after update: {st.query(0, len(arr)-1)}") # Output: 44

```

## IV. Advantages and Disadvantages

**Advantages:**

* **Efficient range queries:** O(log n) time complexity.
* **Efficient updates:** O(log n) time complexity.
* **Versatile:**  Adaptable to various aggregation operations.


**Disadvantages:**

* **Space complexity:** Requires 2n space, potentially higher than other data structures for small arrays.
* **Implementation complexity:** More complex to implement compared to simpler data structures.


Segment trees are best suited for scenarios where numerous range queries and updates are required on a large array.  Their efficient performance makes them a valuable tool in various algorithms and applications.

        """.trimIndent()
    }
} 