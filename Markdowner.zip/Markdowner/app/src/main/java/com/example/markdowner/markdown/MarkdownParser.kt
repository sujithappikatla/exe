package com.example.markdowner.markdown

import android.util.Log
import org.commonmark.node.*
import org.commonmark.parser.Parser
import org.commonmark.ext.gfm.tables.TablesExtension
import org.commonmark.ext.gfm.strikethrough.StrikethroughExtension
import org.commonmark.ext.gfm.tables.TableCell
import org.commonmark.ext.gfm.tables.TableRow
import org.commonmark.ext.gfm.tables.TableBlock
import org.commonmark.ext.gfm.tables.TableHead
import org.commonmark.ext.gfm.tables.TableBody
import org.commonmark.node.Visitor
import kotlin.reflect.typeOf

class MarkdownParser {
    private val parser: Parser = Parser.builder()
        .extensions(listOf(
            TablesExtension.create(),
            StrikethroughExtension.create()
        ))
        .build()

    fun parse(markdown: String): List<MarkdownElement> {
        val document = parser.parse(markdown)
        val elements = mutableListOf<MarkdownElement>()
        
        document.accept(object : AbstractVisitor() {
            override fun visit(heading: Heading) {
                elements.add(MarkdownElement.Header(
                    text = getNodeText(heading),
                    level = heading.level
                ))
            }

            override fun visit(paragraph: Paragraph) {
                elements.add(MarkdownElement.Paragraph(
                    text = getNodeText(paragraph)
                ))
            }

            override fun visit(code: FencedCodeBlock) {
                elements.add(MarkdownElement.CodeBlock(
                    code = code.literal ?: "",
                    language = code.info
                ))
            }

            override fun visit(bulletList: BulletList) {
                val items = mutableListOf<MarkdownElement.ListItem>()
                var node = bulletList.firstChild
                while (node != null) {
                    if (node is ListItem) {
                        // Get the main text
                        val mainText = node.firstChild?.let { getNodeText(it) } ?: ""
                        
                        // Calculate nesting level
                        val level = getListItemLevel(node)
                        
                        // Add the main item
                        items.add(MarkdownElement.ListItem(
                            text = mainText,
                            level = level
                        ))
                        
                        // Handle nested lists
                        var child = node.firstChild?.next
                        while (child != null) {
                            if (child is BulletList) {
                                // Recursively visit nested list
                                var nestedNode = child.firstChild
                                while (nestedNode != null) {
                                    if (nestedNode is ListItem) {
                                        items.add(MarkdownElement.ListItem(
                                            text = getNodeText(nestedNode),
                                            level = level + 1  // Increment level for nested items
                                        ))
                                    }
                                    nestedNode = nestedNode.next
                                }
                            }
                            child = child.next
                        }
                    }
                    node = node.next
                }
                
                elements.add(MarkdownElement.MarkdownList(
                    items = items,
                    isOrdered = false
                ))
            }

            override fun visit(orderedList: OrderedList) {
                // Similar changes for ordered lists
                val items = mutableListOf<MarkdownElement.ListItem>()
                var node = orderedList.firstChild
                while (node != null) {
                    if (node is ListItem) {
                        // Get the main text
                        val mainText = node.firstChild?.let { getNodeText(it) } ?: ""
                        
                        // Calculate nesting level
                        val level = getListItemLevel(node)
                        
                        // Add the main item
                        items.add(MarkdownElement.ListItem(
                            text = mainText,
                            level = level
                        ))
                        
                        // Handle nested lists
                        var child = node.firstChild?.next
                        while (child != null) {
                            if (child is OrderedList) {
                                // Recursively visit nested list
                                var nestedNode = (child as OrderedList).firstChild
                                while (nestedNode != null) {
                                    if (nestedNode is ListItem) {
                                        items.add(MarkdownElement.ListItem(
                                            text = getNodeText(nestedNode),
                                            level = level + 1  // Increment level for nested items
                                        ))
                                    }
                                    nestedNode = nestedNode.next
                                }
                            }
                            child = child!!.next
                        }
                    }
                    node = node.next
                }
                
                elements.add(MarkdownElement.MarkdownList(
                    items = items,
                    isOrdered = true
                ))
            }

            override fun visit(blockQuote: BlockQuote) {
                // Process this blockquote and all its nested quotes
                val quotes = mutableListOf<MarkdownElement.BlockQuote>()
                processBlockQuote(blockQuote, 1, quotes)
                // Add quotes in reverse order to maintain proper nesting
                elements.addAll(quotes.reversed())
            }

            private fun processBlockQuote(blockQuote: BlockQuote, currentLevel: Int, quotes: MutableList<MarkdownElement.BlockQuote>) {
                var currentNode = blockQuote.firstChild
                val content = StringBuilder()
                
                while (currentNode != null) {
                    when (currentNode) {
                        is BlockQuote -> {
                            // Create a new blockquote element with increased level
                            processBlockQuote(currentNode, currentLevel + 1, quotes)
                        }
                        else -> {
                            content.append(getNodeText(currentNode))
                            if (currentNode.next != null && currentNode.next !is BlockQuote) {
                                content.append("\n")
                            }
                        }
                    }
                    currentNode = currentNode.next
                }

                // Only add non-empty blockquotes
                if (content.isNotEmpty()) {
                    quotes.add(MarkdownElement.BlockQuote(
                        text = content.toString().trim(),
                        level = currentLevel
                    ))
                }
            }

            override fun visit(link: Link) {
                elements.add(MarkdownElement.Link(
                    text = getNodeText(link),
                    url = link.destination ?: ""
                ))
            }

            override fun visit(image: Image) {
                elements.add(MarkdownElement.Image(
                    altText = image.title ?: "",
                    url = image.destination ?: ""
                ))
            }

            override fun visit(customBlock: CustomBlock) {
                Log.i("TAG","-------" +customBlock.javaClass.name)
                if (customBlock is TableBlock) {
                    val headers = mutableListOf<String>()
                    val rows = mutableListOf<List<String>>()
                    
                    var currentRow = customBlock.firstChild
                    while (currentRow != null) {
                        Log.i("TAG", "Row type: ${currentRow.javaClass.name}")
                        
                        if (currentRow is TableHead) {
                            // Handle header row
                            var headerCell = currentRow.firstChild
                            while (headerCell != null) {
                                if (headerCell is TableRow) {
                                    var cell = headerCell.firstChild
                                    while (cell != null) {
                                        if (cell is TableCell) {
                                            headers.add(getNodeText(cell))
                                            Log.i("TAG", "Header: ${getNodeText(cell)}")
                                        }
                                        cell = cell.next
                                    }
                                }
                                headerCell = headerCell.next
                            }
                        } else if (currentRow is TableBody) {
                            // Handle body rows
                            var bodyRow = currentRow.firstChild
                            while (bodyRow != null) {
                                if (bodyRow is TableRow) {
                                    val rowCells = mutableListOf<String>()
                                    var cell = bodyRow.firstChild
                                    while (cell != null) {
                                        if (cell is TableCell) {
                                            rowCells.add(getNodeText(cell))
                                            Log.i("TAG", "Cell: ${getNodeText(cell)}")
                                        }
                                        cell = cell.next
                                    }
                                    if (rowCells.isNotEmpty()) {
                                        rows.add(rowCells)
                                    }
                                }
                                bodyRow = bodyRow.next
                            }
                        }
                        currentRow = currentRow.next
                    }
                    
                    Log.i("TAG", "Table parsed - Headers: $headers, Rows: $rows")
                    
                    if (headers.isNotEmpty() || rows.isNotEmpty()) {
                        elements.add(MarkdownElement.Table(
                            headers = headers,
                            rows = rows
                        ))
                    }
                }
                super.visit(customBlock)
            }
        })
        
        return elements
    }

    private fun getNodeText(node: Node): String {
        val text = StringBuilder()
        var child = node.firstChild
        while (child != null) {
            when (child) {
                is Text -> text.append(child.literal)
                is Emphasis -> text.append("*${getNodeText(child)}*")
                is StrongEmphasis -> text.append("**${getNodeText(child)}**")
                is Code -> text.append("`${child.literal}`")
                is Link -> text.append("[${getNodeText(child)}](${child.destination})")
                else -> text.append(getNodeText(child))
            }
            child = child.next
        }
        return text.toString()
    }

    private fun getListItemLevel(node: Node): Int {
        var level = 0
        var parent = node.parent
        while (parent != null) {
            if (parent is ListItem) level++
            parent = parent.parent
        }
        return level
    }

    private fun getBlockQuoteLevel(node: Node): Int {
        var level = 1
        var parent = node.parent
        while (parent != null) {
            if (parent is BlockQuote) level++
            parent = parent.parent
        }
        return level
    }
} 