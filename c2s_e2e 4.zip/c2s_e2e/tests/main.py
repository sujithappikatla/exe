import streamlit as st
import base64
from vertexai.generative_models import SafetySetting
import vertexai
from vertexai.generative_models import GenerativeModel, Part, Tool
from vertexai.preview.generative_models import grounding
from google import genai
from google.genai import types
import json

vertexai.init(project="account-pocs", location="us-central1")

gemini_2_client = genai.Client(
    vertexai=True, project="account-pocs", location="us-central1")


st.set_page_config(layout="wide")
st.title("Circle to Search")

full, roi = st.columns(2)

with full:
    st.subheader("Full Screen Image")
    full_screen_image = st.file_uploader(
        "Upload full screen image", type=['png', 'jpg', 'jpeg'])
    if full_screen_image:
        st.image(full_screen_image)

with roi:
    st.subheader("Region of Interest")
    roi_image = st.file_uploader(
        "Upload ROI image", type=['png', 'jpg', 'jpeg'])
    if roi_image:
        st.image(roi_image)


def encode_image(image_file):
    if image_file is not None:
        # Convert image to base64
        bytes_data = image_file.getvalue()
        encoded = base64.b64encode(bytes_data).decode()
        return encoded
    return None


# Input parameters
st.sidebar.header("Parameters")
grade = st.sidebar.number_input("Grade", min_value=1, max_value=12, value=8)
subject = st.sidebar.selectbox(
    "Subject", ["mathematics", "science", "english", "history"])
context = st.sidebar.text_area("Additional Context", "Help solve the problem")
model_version = st.sidebar.selectbox(
    "Model Version",
    ["Gemini 1.5 Flash", "Gemini 2.0 Flash"],
    help="Select the Gemini model version to use"
)

# model configuration for without grounding
generation_config_standard = {
    "max_output_tokens": 8192,
    "temperature": 1,
    "top_p": 0.95,
}

# model configuration for with grounding
generation_config_grounding = {
    "max_output_tokens": 8192,
    "temperature": 0,
    "top_p": 0.95,
}


prompt_template_without_grounding = f"""
**Prompt Template:**

**System:** You are an expert educational assistant designed to help students learn. Your goal is to analyze images provided by the student, understand their learning needs based on the grade and subject they are studying, and provide relevant information and guidance.
You will be provided with two images as input.
- The first image is the full screen image.
- The second image is the region of interest (ROI) image.

**Understanding Region of Interest (ROI) Theory:**

* **Purpose of ROI:** The Region of Interest (ROI) image is provided to focus attention on a specific part of the full-screen image. This allows for a more detailed analysis of a particular element, concept, or problem within the larger context.
* **Contextual Relevance:**  Analyzing the relationship between the ROI and the full-screen image is crucial.
    * **Contextually Relevant ROI:**  The ROI is a specific detail or area within the broader subject depicted in the full-screen image. Understanding the full context is necessary to fully interpret the ROI. For example, a circled part of a cell diagram in a biology textbook image.
    * **Contextually Independent ROI:** The ROI might represent a separate, focused question or problem that, while potentially related to the subject, doesn't directly depend on the details of the entire full-screen image. For example, a close-up of a mathematical equation separate from the broader page it's on.
* **Leveraging ROI in Search:** The ROI guides the search process, allowing for more targeted and efficient retrieval of information. By focusing on the specific details within the ROI, the search can be refined to address the student's immediate learning need.

**Class/Grade:** {grade}
**Subject:** {subject}

**Additional Context:** {context}

**Task:** Analyze the provided images and context to assist the student.

**Safety Protocol (Crucial - Execute First):**

1. **Analyze Image Content:** Carefully examine both images for any inappropriate content. This includes, but is not limited to:
    * **Violence and Harm:** Depictions of violence, self-harm, or harm to others.
    * **Hate Speech:** Content promoting discrimination or hatred based on race, religion, gender, sexual orientation, etc.
    * **Sexually Suggestive Content:** Explicit or suggestive imagery or text.
    * **Illegal Activities:** Depictions or discussions of illegal activities.
    * **Private or Confidential Information:** Sensitive personal data.

2. **Inappropriate Content Detection:**
    * **If inappropriate content is detected in either image, IMMEDIATELY respond with the following and cease further processing:**
       "I have detected potentially inappropriate content in the image(s) provided. I cannot process this request further. Please ensure all submitted materials adhere to ethical and safe learning guidelines."

**Processing Instructions (If no inappropriate content is detected):**

1. **Generate Google Search Query (Concise and Keyword-Focused):**
    * **If `roi_image_data` is provided:**
        * **Determine Contextual Relevance:** Analyze if the region of interest in `roi_image_data` is contextually related to the full screen image in `full_screen_image_data`.
        * **If Contextually Relevant:** Formulate a *concise* Google search query using a few highly relevant keywords describing the specific content of the `roi_image_data` *within the context* of the overall subject matter of the `full_screen_image_data`. Focus on terms relevant to **{subject}** for **{grade}**.
        * **If Contextually Independent:** Formulate a *concise* Google search query using a few highly relevant keywords that specifically describe the content depicted in the `roi_image_data`. The search should be focused solely on understanding the elements within the ROI, relevant to **{subject}** for **{grade}**.
    * **If `roi_image_data` is NOT provided:** Formulate a *concise* Google search query using a few highly relevant keywords describing the content of `full_screen_image_data`, relevant to **{subject}** for **{grade}**.

2. **Generate Quick Follow-Up Queries (2 words each):** Provide 3-4 very short, two-word search queries that directly follow up on the initial search query and the image content.

3. **Generate Suggested Queries (Brief):** Provide 3-4 slightly longer, brief search queries that a student might find helpful for exploring related concepts or gaining a deeper understanding, within the context of **{subject}** for **{grade}**.

4. **Categorize the Query:** Based on the image content and context, categorize the query into one of the following:
    * **Generic Summary:** The image requires a general explanation or identification.
    * **Mathematical Problem Solving:** The image contains a mathematical problem.
    * **Code Fixing or Error Identification:** The image contains code with errors or requires debugging.
    * **Drawing Identification:** The image is a drawing that needs to be identified or explained.

5. **Synthesize Response based on Category:**

    * **If Category is Generic Summary or Drawing Identification:**
        * Provide a brief summary of the image content and its relevance to **{subject}** for **{grade}**. Explicitly mention whether the ROI was contextually relevant or independent in your summary and tailor the summary accordingly. If an ROI was provided without context to the full image, ensure the summary focuses primarily on the ROI.
        * **Do not provide a direct answer or solution.**

    * **If Category is Mathematical Problem Solving:**
        * Provide a brief summary of the mathematical problem presented.
        * Provide a step-by-step approach to solve the problem, tailored to the understanding of a **{grade}** student in **{subject}**.
        * Clearly state the final answer.

    * **If Category is Code Fixing or Error Identification:**
        * Provide a brief summary of the code and the likely purpose.
        * Identify the specific error(s) present in the code.
        * Provide the corrected code snippet.
        * Briefly explain the correction and the reasoning behind it, suitable for a **{grade}** student in **{subject}**.

**Output Format:**

**Search Query:** [Concise Google Search Query with Key Keywords]

**Quick Follow-Up Queries:**
* [Two Word Query 1]
* [Two Word Query 2]
* [Two Word Query 3]
* [Two Word Query 4]

**Suggested Queries:**
* [Brief Suggested Query 1]
* [Brief Suggested Query 2]
* [Brief Suggested Query 3]
* [Brief Suggested Query 4]

**Query Category:** [Categorized Query Type: Generic Summary, Mathematical Problem Solving, Code Fixing or Error Identification, Drawing Identification]

**Summary:** [Brief Summary of the Query and Synthesized Response according to Grade and Subject, explicitly addressing ROI contextual relevance]

**(Only if Query Category is Mathematical Problem Solving):**
**Step-by-Step Solution:**
[Step 1: ...]
[Step 2: ...]
[Step 3: ...]
**Answer:** [Final Answer]

**(Only if Query Category is Code Fixing or Error Identification):**
**Error Identification:** [Description of the error(s)]
**Corrected Code:**
[Corrected Code Snippet]
**Explanation:** [Brief explanation of the correction]
"""
system_instructions_without_grounding = """You are a highly skilled and detail-oriented educational assistant AI. Your primary function is to analyze visual information (images) provided by students, understand their learning context (grade and subject), and generate relevant outputs to aid their studies. You are equipped with robust safety protocols to prevent the generation of inappropriate content. Your outputs will vary based on the identified category of the student's query, providing either targeted search assistance or step-by-step solutions as required. Adherence to the specified grade level and subject is paramount in all your responses."""

safety_settings = [
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        threshold=SafetySetting.HarmBlockThreshold.OFF
    ),
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
        threshold=SafetySetting.HarmBlockThreshold.OFF
    ),
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
        threshold=SafetySetting.HarmBlockThreshold.OFF
    ),
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold=SafetySetting.HarmBlockThreshold.OFF
    ),
]


system_instructions_with_grounding = """You are a educational AI assistant. Your task is to provide a detailed summary of the search query in the process or concept:
1. Analyze the search query
2. Provide a comprehensive summary in 200 words
3. Include relevant citations from reliable sources
4. Format the response with clear sections for Summary and Citations
"""


intial_analysis_response = ""

prompt_template_with_grounding = f"""
Provide only references from Google. Do not add square brackets or provide citations separately. Generate a summary of the search query in the process or concept in 200 words:
\n{st.session_state.get("intial_analysis_response", "")}
"""

# # Sidebar inputs for editing prompts and system instructions
# st.sidebar.header("Edit Prompts and Instructions")
# custom_prompt = st.sidebar.text_area(
#     "Custom Prompt", value=prompt_template_without_grounding)
# custom_system_instruction = st.sidebar.text_area(
#     "Custom System Instruction", value=system_instructions_without_grounding)

# # Use custom inputs if provided, otherwise use default
# prompt_to_use = custom_prompt if custom_prompt else prompt_template_without_grounding
# system_instruction_to_use = custom_system_instruction if custom_system_instruction else system_instructions_without_grounding


def generate_gemini_1_5():
    model = GenerativeModel(
        "gemini-1.5-flash-002",
        system_instruction=[system_instructions_without_grounding]
    )

    prompt = prompt_template_without_grounding.format(
        grade=grade,
        subject=subject,
        context=context
    )

    content = [Part.from_data(data=base64.b64decode(encode_image(full_screen_image)), mime_type="image/jpeg"),
               Part.from_data(data=base64.b64decode(
                   encode_image(roi_image)), mime_type="image/jpeg"),
               prompt]

    responses = model.generate_content(
        content,
        generation_config=generation_config_standard,
        safety_settings=safety_settings,
        stream=False,
    )
    return responses.text


def generate_gemini_2():
    model = "gemini-2.0-flash-exp"
    generation_config = types.GenerateContentConfig(
        max_output_tokens=8192,
        temperature=1,
        top_p=0.95,
        response_modalities=["TEXT"],
        safety_settings=[types.SafetySetting(
            category="HARM_CATEGORY_HATE_SPEECH",
            threshold="OFF"
        ), types.SafetySetting(
            category="HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold="OFF"
        ), types.SafetySetting(
            category="HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold="OFF"
        ), types.SafetySetting(
            category="HARM_CATEGORY_HARASSMENT",
            threshold="OFF"
        )],
        system_instruction=[types.Part.from_text(
            system_instructions_without_grounding)]
    )
    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_bytes(
                    data=base64.b64decode(encode_image(full_screen_image)),
                    mime_type="image/jpeg"
                ),
                types.Part.from_bytes(
                    data=base64.b64decode(encode_image(roi_image)),
                    mime_type="image/jpeg"
                ),
                types.Part.from_text(prompt_template_without_grounding)
            ]
        )
    ]
    response = gemini_2_client.models.generate_content(
        model=model,
        contents=contents,
        config=generation_config,
    )
    return response.text


def generate_analysis():
    if model_version == "Gemini 2.0 Flash":
        return generate_gemini_2()
    else:
        return generate_gemini_1_5()


def generate_gemini_1_5_with_grounding():
    tools = [
        Tool.from_google_search_retrieval(
            google_search_retrieval=grounding.GoogleSearchRetrieval()
        ),
    ]
    model = GenerativeModel(
        "gemini-1.5-flash-002",
        system_instruction=[system_instructions_with_grounding],
        tools=tools
    )

    content = [prompt_template_with_grounding]

    responses = model.generate_content(
        content,
        generation_config=generation_config_grounding,
        safety_settings=safety_settings,
        stream=False,
    )
    return responses


def generate_gemini_2_with_grounding():
    model = "gemini-2.0-flash-exp"
    tools = [
        types.Tool(google_search=types.GoogleSearch())
    ]
    generation_config = types.GenerateContentConfig(
        max_output_tokens=8192,
        temperature=0,
        top_p=0.95,
        safety_settings=[types.SafetySetting(
            category="HARM_CATEGORY_HATE_SPEECH",
            threshold="OFF"
        ), types.SafetySetting(
            category="HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold="OFF"
        ), types.SafetySetting(
            category="HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold="OFF"
        ), types.SafetySetting(
            category="HARM_CATEGORY_HARASSMENT",
            threshold="OFF"
        )],
        system_instruction=[types.Part.from_text(
            system_instructions_with_grounding)],
        tools=tools
    )
    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_text(
                    prompt_template_with_grounding.format(intial_analysis_response=st.session_state.get("intial_analysis_response", "")))
            ]
        )
    ]

    response = gemini_2_client.models.generate_content(
        model=model,
        contents=contents,
        config=generation_config,
    )
    return response.model_dump_json()


if st.button("Analyze Images"):
    if full_screen_image is None:
        st.error("Please upload at least the full screen image")
    else:
        with st.spinner("Analyzing images..."):
            intial_analysis_response = generate_analysis()
            st.session_state["intial_analysis_response"] = intial_analysis_response
st.markdown(st.session_state.get("intial_analysis_response", ""))


def render_response(response: dict):
    """
    Renders the API response on Streamlit UI, strictly following the instructions:
    1. Parse each object into respective variables.
    2. Render the entire text on the Streamlit UI.
    3. For each 'segment' in 'grounding_supports', match the segment's text in main_text,
       then right after the last word of that matched segment, insert bracketed indexes
       like [2][3], hyperlinking them to the corresponding web URIs.
    4. Increment the API's 0-based indices by 1 when displaying on the UI.
    5. Below the text, render all sources from the citations (title + hyperlinked URI).
    6. Finally, render the search entrypoint HTML snippet.
    """

    # 1) Parse each object into respective variables
    candidate = response["candidates"][0]
    content = candidate["content"]
    # Typically a list of text segments; assume one here
    text_parts = content["parts"]
    main_text = text_parts[0]["text"]

    # Check if grounding metadata exists
    if "grounding_metadata" not in candidate:
        st.markdown(main_text, unsafe_allow_html=True)
        return

    grounding_metadata = candidate["grounding_metadata"]

    # Check if required grounding data exists
    if not grounding_metadata.get("grounding_supports") or not grounding_metadata.get("grounding_chunks"):
        st.markdown(main_text, unsafe_allow_html=True)
        if "search_entry_point" in grounding_metadata:
            st.markdown(grounding_metadata["search_entry_point"]["rendered_content"],
                        unsafe_allow_html=True)
        return

    # Each has .segment.text and .grounding_chunk_indices
    grounding_supports = grounding_metadata["grounding_supports"]
    # Each has ["web"]["uri"] and ["web"]["title"]
    grounding_chunks = grounding_metadata["grounding_chunks"]
    search_entrypoint_html = grounding_metadata["search_entry_point"]["rendered_content"]

    # 2) We'll keep a mutable copy of main_text for insertions
    final_text = main_text

    # 3) Sort segments by their start_index so we process in reading order
    segments_sorted = sorted(
        grounding_supports, key=lambda x: x["segment"]["start_index"])

    # We'll use a rolling 'search_pos' so subsequent matches don't conflict with prior insertions
    search_pos = 0

    for seg_info in segments_sorted:
        seg_text = seg_info["segment"]["text"]
        chunk_indices = seg_info["grounding_chunk_indices"]

        # Find the segment's text in final_text, starting from search_pos
        match_index = final_text.find(seg_text, search_pos)
        if match_index == -1:
            # If not found, skip this segment
            continue

        # Build the bracketed/hyperlinked citations
        # e.g. <a href="uri" target="_blank">[2]</a><a href="uri2" target="_blank">[3]</a>
        citations_html = ""
        for chunk_index in chunk_indices:
            display_num = chunk_index + 1  # 0-based to 1-based
            chunk_uri = grounding_chunks[chunk_index]["web"]["uri"]
            citations_html += f'<a href="{
                chunk_uri}" target="_blank">[{display_num}]</a>'

        # Insert the bracketed links right after seg_text
        insertion_pos = match_index + len(seg_text)
        final_text = (
            final_text[:insertion_pos]
            + citations_html
            + final_text[insertion_pos:]
        )

        # Advance search_pos beyond this insertion to avoid re-matching the same text
        search_pos = insertion_pos + len(citations_html)

    # 4) Render the updated text (with citations inserted) on Streamlit
    st.markdown(final_text, unsafe_allow_html=True)

    # 5) Render the sources from citations below
    st.markdown("### Sources")
    for i, chunk_info in enumerate(grounding_chunks):
        title = chunk_info["web"]["title"]
        uri = chunk_info["web"]["uri"]
        st.markdown(
            f'{i+1}. <a href="{uri}" target="_blank">{title}</a>', unsafe_allow_html=True)

    # 6) Finally, render the search entrypoint HTML snippet
    st.markdown(search_entrypoint_html, unsafe_allow_html=True)


grounding_result = None


# if intial_analysis_response:
if st.button("Generate with Grounding"):
    with st.spinner("Generating summary with grounding..."):
        if model_version == "Gemini 2.0 Flash":
            grounding_result = generate_gemini_2_with_grounding()
            render_response(json.loads(grounding_result))
        else:
            grounding_result = generate_gemini_1_5_with_grounding()
            render_response(grounding_result.to_dict())
st.session_state["initial_analysis_response"] = ""
