# API Documentation

## Table of Contents
- [Overview](#overview)
- [Common Response Format](#common-response-format)
- [Error Handling](#error-handling)
  - [Error Categories](#error-categories)
  - [Error Codes](#error-codes)
- [Endpoints](#endpoints)
  - [Health Check](#health-check)
  - [Web Search](#web-search)
  - [Image Search](#image-search)
  - [Video Search](#video-search)
  - [Discovery Engine - Add Sites](#discovery-engine-add-sites)
  - [Discovery Engine - Search](#discovery-engine-search)
  - [Gemini - Analyze](#gemini-analyze)
  - [Gemini - Explain](#gemini-explain)

## Overview

This API provides various search and analysis capabilities including web search, image search, video search, discovery engine functionality, and Gemini-powered image analysis.

## Common Response Format

All endpoints return responses in the following JSON format:

### Success Response
```json
{
    "success": true,
    "data": <response_data>,
    "status_code": 200
}
```

### Error Response
```json
{
    "success": false,
    "error": "ERR-XXX: Error message description",
    "status_code": <http_status_code>
}
```

## Error Handling

### Error Categories

The API uses a standardized error coding system with the following categories:

- **1xx - API and Rate Limit Errors**: Issues related to API keys, rate limits, and service availability
- **2xx - Data Processing Errors**: Issues with input data, validation, and parsing
- **3xx - Model and Generation Errors**: Issues with AI models and content generation
- **4xx - Configuration Errors**: Issues with system configuration and environment setup
- **5xx - Infrastructure Errors**: Issues with services, network, and resources

### Error Codes

| Error Code | Description | HTTP Status | Common Scenarios |
|------------|-------------|-------------|------------------|
| ERR-101 | API Key Invalid | 400 | Invalid or missing API credentials |
| ERR-102 | API Request Failed | 400 | Generic API failure |
| ERR-111 | API Limit Exceeded | 429 | Rate limit or quota exceeded |
| ERR-121 | Service Unavailable | 503 | Service temporarily down |
| ERR-131 | Request Timeout | 408 | Request took too long to process |
| ERR-201 | Invalid Input Format | 400 | Malformed request data |
| ERR-202 | Missing Required Fields | 400 | Required parameters not provided |
| ERR-211 | Data Validation Failed | 400 | Input data fails validation rules |
| ERR-212 | Parsing Failed | 400 | Unable to parse request/response data |
| ERR-221 | Image Processing Failed | 400 | Issues with image data processing |
| ERR-222 | Video Processing Failed | 400 | Issues with video data processing |
| ERR-301 | Model Initialization Failed | 500 | AI model startup failure |
| ERR-302 | Model Not Found | 404 | Requested model unavailable |
| ERR-311 | Failed to Generate Response | 500 | AI generation failure |
| ERR-321 | Content Safety Violation | 400 | Content flagged as inappropriate |
| ERR-331 | Context Processing Failed | 400 | Unable to process context data |
| ERR-401 | Missing Configuration | 500 | Required config not found |
| ERR-402 | Invalid Configuration | 500 | Config validation failed |
| ERR-411 | Environment Setup Failed | 500 | Environment initialization error |
| ERR-421 | Service Configuration Failed | 500 | Service setup failure |
| ERR-501 | Service Connection Failed | 503 | Unable to connect to service |
| ERR-502 | Database Error | 500 | Database operation failed |
| ERR-511 | Network Error | 503 | Network connectivity issues |
| ERR-521 | Resource Not Available | 503 | Required resource unavailable |

## Endpoints

### Health Check

**Endpoint:** `GET /health`

Returns the health status of the API.

**Response:**
```json
{
    "success": true,
    "data": {
        "status": "healthy",
        "timestamp": 1234567890.123
    },
    "status_code": 200
}
```

### Web Search

**Endpoint:** `POST /api/web-search`

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/web-search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "query": "solar flares effects on earth",
    "gl": "us",
    "lr": "lang_en",
    "num": 5,
    "safe": true
  }'
```

**Request Body:**
```json
{
    "query": "string (required)",
    "gl": "string (optional) - Geolocation of end user (e.g., 'us', 'uk', 'in')",
    "lr": "string (optional) - Language restriction (e.g., 'lang_en' for English)",
    "num": "integer (optional, default: 10, max: 10) - Number of results",
    "safe": "boolean (optional, default: true) - Safe search",
    "start": "integer (optional, default: 1) - Start index"
}
```

**Success Response:**
```json
{
    "success": true,
    "data": [
        {
            "title": "What are Solar Flares? | NASA Space Place",
            "link": "https://spaceplace.nasa.gov/solar-flares",
            "snippet": "Solar flares are giant explosions on the Sun that send energy, light and high speed particles into space. These flares are often associated with..."
        }
    ],
    "status_code": 200
}
```

**Error Response Example:**
```json
{
    "success": false,
    "error": "ERR-101: API Key Invalid",
    "status_code": 400
}
```

### Image Search

**Endpoint:** `POST /api/image-search`

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/image-search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "query": "cute puppies playing",
    "image_size": "LARGE",
    "image_type": "photo",
    "num": 5,
    "safe": true
  }'
```

**Request Body:**
```json
{
    "query": "string (required)",
    "gl": "string (optional) - Geolocation",
    "lr": "string (optional) - Language restriction",
    "num": "integer (optional, default: 10, max: 10)",
    "safe": "boolean (optional, default: true)",
    "start": "integer (optional, default: 1)",
    "image_size": "string (optional) - One of: HUGE, ICON, LARGE, MEDIUM, SMALL, XLARGE, XXLARGE",
    "image_type": "string (optional) - One of: clipart, face, lineart, stock, photo, animated",
    "image_color": "string (optional) - One of: color, gray, mono, trans"
}
```

**Success Response:**
```json
{
    "success": true,
    "data": [
        {
            "title": "Cute Puppy Playing",
            "image_url": "https://example.com/puppy.jpg",
            "context_url": "https://example.com/pet-photos",
            "height": 1080,
            "width": 1920
        }
    ],
    "status_code": 200
}
```

### Video Search

**Endpoint:** `POST /api/video-search`

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/video-search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "query": "python programming tutorial",
    "language": "en",
    "region_code": "US",
    "max_results": 5,
    "order": "viewCount",
    "duration": "medium",
    "definition": "high"
  }'
```

**Request Body:**
```json
{
    "query": "string (required)",
    "language": "string (optional) - ISO 639-1 language code",
    "region_code": "string (optional) - ISO 3166-1 alpha-2 country code",
    "max_results": "integer (optional, default: 10, max: 50)",
    "order": "string (optional) - One of: date, rating, relevance, title, viewCount",
    "duration": "string (optional) - One of: short (<4m), medium (4-20m), long (>20m)",
    "definition": "string (optional) - One of: high, standard",
    "safe_search": "string (optional) - One of: none, moderate, strict"
}
```

**Success Response:**
```json
{
    "success": true,
    "data": [
        {
            "title": "Python Programming Tutorial for Beginners",
            "thumbnail_url": "https://i.ytimg.com/vi/abc123/default.jpg",
            "channel_title": "Programming Tutorials",
            "duration": "00:15:30",
            "url": "https://youtube.com/watch?v=abc123"
        }
    ],
    "status_code": 200
}
```

### Discovery Engine - Add Sites

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/discovery-engine/add-sites \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "websites": [
      "www.wikipedia.org",
      "www.nasa.gov",
      "www.science.org"
    ]
  }'
```

**Example Response:**
```json
{
    "success": true,
    "data": [
        "wikipedia.org",
        "nasa.gov",
        "science.org"
    ],
    "status_code": 200
}
```

### Discovery Engine - Search

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/discovery-engine/search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "query": "solar flares impact on satellites",
    "websites": [
      "nasa.gov",
      "science.org"
    ]
  }'
```

**Example Response:**
```json
{
    "success": true,
    "data": [
        {
            "title": "Solar Flares and Space Weather",
            "link": "https://science.nasa.gov/solar-flares",
            "snippet": "Solar flares are intense bursts of radiation coming from the release of magnetic energy associated with sunspots..."
        }
    ],
    "status_code": 200
}
```

### Gemini - Analyze

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/gemini/analyze \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "full_image": "'$(base64 full_image.jpg)'",
    "roi_image": "'$(base64 roi_image.jpg)'",
    "mime_type1": "image/jpeg",
    "mime_type2": "image/jpeg",
    "extended_context": {
      "grade": "10",
      "subject": "Physics",
      "context": "Studying vector addition and force diagrams"
    }
  }'
```

**Example Response:**
```json
{
    "success": true,
    "data": {
        "search_query": "vector addition physics force diagram",
        "quick_followup_queries": [
            "force components",
            "vector resolution",
            "free body"
        ],
        "suggested_queries": [
            "how to solve vector addition problems",
            "force diagram analysis steps",
            "physics vector components calculation"
        ],
        "for_next_step": "vector addition physics force diagram"
    },
    "status_code": 200
}
```

### Gemini - Explain

**Endpoint:** `POST /api/gemini/explain`

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/gemini/explain \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "analysis":  "vector addition physics force diagram"
  }'
```

**Example Response:**
```json
{
    "success": true,
    "data": {
        "content": "Vector addition in physics involves combining two or more vectors to determine their resultant...",
        "rendered_content": "<p>Vector addition in physics involves combining two or more vectors to determine their resultant...</p>",
        "citations": [
            {
                "title": "Understanding Vector Addition - Physics Classroom",
                "uri": "https://www.physicsclassroom.com/vectors"
            }
        ]
    },
    "status_code": 200
}
```

### Gemini - Explain Stream

**Endpoint:** `POST /api/gemini/explain-stream`

Streaming version of the explain endpoint that uses HTTP chunked transfer encoding to return results incrementally.

**Request Example:**
```bash
curl -X POST http://localhost:8080/api/gemini/explain-stream \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -d '{
    "analysis":  "vector addition physics force diagram"
  }'
```

**Request Body:**
```json
{
    "analysis": "string (required) - The analysis text to explain"
}
```

**Response Format:**
The endpoint streams newline-delimited JSON objects. Each chunk is a complete JSON object containing:
```json
{
    "content": "Current accumulated explanation text...",
    "rendered_content": "HTML rendered version (populated in final chunk)",
    "citations": [] // List of citations (populated in final chunk)
}
```

**Example Stream Response:**
```json
{"content": "Vector addition in physics", "rendered_content": "", "citations": []}
{"content": "Vector addition in physics involves combining two", "rendered_content": "", "citations": []}
{"content": "Vector addition in physics involves combining two or more vectors to determine their resultant...", "rendered_content": "", "citations": []}
{
    "content": "Vector addition in physics involves combining two or more vectors to determine their resultant...",
    "rendered_content": "<p>Vector addition in physics involves combining two or more vectors to determine their resultant...</p>",
    "citations": [
        {
            "title": "Understanding Vector Addition - Physics Classroom",
            "uri": "https://www.physicsclassroom.com/vectors"
        }
    ]
}
```

**Notes:**
- The response is streamed as newline-delimited JSON objects
- Each chunk contains the accumulated content so far
- The final chunk includes additional metadata (rendered_content and citations)
- Content is streamed progressively while rendered_content and citations are only available in the final chunk
- Use a streaming-capable client to process the response chunks

## Server Configuration

The server runs on port 8080 by default, but this can be configured using the `PORT` environment variable. The server uses Waitress as the WSGI server in production. 