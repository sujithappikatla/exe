from flask import Flask, jsonify, request, Response
import os
import signal
import sys
import logging
from werkzeug.exceptions import HTTPException
from typing import Any, Dict, List, Optional, Union
import time
from functools import wraps
import base64
import json

from web_search import WebSearchClient
from image_search import ImageSearchClient
from video_search import VideoSearchClient
from discovery_engine import DiscoveryEngineClient
from gemini import GeminiClient
from error_codes import get_error_message, get_error_code

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Track the server state
is_shutting_down = False

def shutdown_handler(signum: int, frame: Any) -> None:
    """Handle graceful shutdown when receiving SIGTERM."""
    global is_shutting_down
    logger.info(f"Received signal {signum}. Starting graceful shutdown...")
    is_shutting_down = True

# Register shutdown handler for SIGTERM (used by Cloud Run to stop containers)
signal.signal(signal.SIGTERM, shutdown_handler)

def validate_request_json(required_fields: List[str] = None):
    """
    Decorator to validate request JSON and required fields.
    
    Args:
        required_fields: List of required field names in the request JSON
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not request.is_json:
                return jsonify({
                    "success": False,
                    "error": "Request must be JSON",
                    "status_code": 400
                }), 400

            data = request.get_json()
            
            if required_fields:
                missing_fields = [field for field in required_fields if field not in data]
                if missing_fields:
                    return jsonify({
                        "success": False,
                        "error": f"Missing required fields: {', '.join(missing_fields)}",
                        "status_code": 400
                    }), 400
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def success_response(data: Any) -> tuple[Dict, int]:
    """
    Create a standardized success response.
    
    Args:
        data: Response data to be returned
        
    Returns:
        Tuple of response dictionary and HTTP status code
    """
    return jsonify({
        "success": True,
        "data": data,
        "status_code": 200
    }), 200

@app.before_request
def check_shutdown() -> Any:
    """Check if server is shutting down before processing new requests."""
    if is_shutting_down:
        logger.warning("Server is shutting down. Rejecting new requests.")
        response = jsonify({
            "success": False,
            "error": "Server is shutting down",
            "status_code": 503
        })
        response.status_code = 503
        return response

@app.errorhandler(Exception)
def handle_exception(e: Exception) -> tuple[Dict, int]:
    """Handle all exceptions globally."""
    logger.exception("An error occurred while processing the request")
    
    # Handle HTTP exceptions
    if isinstance(e, HTTPException):
        error_code = get_error_code(e.description)
        response = {
            "success": False,
            "error": get_error_message(error_code),
            "status_code": e.code
        }
        return jsonify(response), e.code
    
    # Handle client-specific errors
    if isinstance(e, (WebSearchClient.SearchError, 
                     ImageSearchClient.SearchError,
                     VideoSearchClient.SearchError,
                     DiscoveryEngineClient.ConfigurationError,
                     GeminiClient.ConfigurationError,
                     GeminiClient.AnalysisError)):
        error_code = get_error_code(str(e))
        response = {
            "success": False,
            "error": get_error_message(error_code),
            "status_code": 400
        }
        return jsonify(response), 400

    # Handle other exceptions
    error_code = get_error_code(str(e))
    response = {
        "success": False,
        "error": get_error_message(error_code),
        "status_code": 500
    }
    logger.exception(f"Internal error: {str(e)}")
    return jsonify(response), 500

@app.route('/health', methods=['GET'])
def health_check() -> Dict:
    """Health check endpoint for Cloud Run."""
    return success_response({
        "status": "healthy",
        "timestamp": time.time()
    })

@app.route('/api/web-search', methods=['POST'])
@validate_request_json(['query'])
def web_search() -> Dict:
    """
    Perform web search using Google Custom Search API.
    
    Request Body:
        {
            "query": str (required),
            "gl": str (optional),
            "lr": str (optional),
            "num": int (optional),
            "safe": bool (optional),
            "start": int (optional)
        }
    
    Returns:
        List of search results with metadata
    """
    try:
        data = request.get_json()
        client = WebSearchClient()
        
        # Extract optional parameters
        optional_params = {k: v for k, v in data.items() 
                         if k in ['gl', 'lr', 'num', 'safe', 'start'] and v is not None}
        
        results = client.search(query=data['query'], **optional_params)
        return success_response(results)
    except Exception as e:
        raise

@app.route('/api/image-search', methods=['POST'])
@validate_request_json(['query'])
def image_search() -> Dict:
    """
    Perform image search using Google Custom Search API.
    
    Request Body:
        {
            "query": str (required),
            "gl": str (optional),
            "lr": str (optional),
            "num": int (optional),
            "safe": bool (optional),
            "start": int (optional),
            "image_size": str (optional),
            "image_type": str (optional),
            "image_color": str (optional)
        }
    
    Returns:
        List of image search results with metadata
    """
    try:
        data = request.get_json()
        client = ImageSearchClient()
        
        # Extract optional parameters
        optional_params = {k: v for k, v in data.items() 
                         if k in ['gl', 'lr', 'num', 'safe', 'start', 
                                'image_size', 'image_type', 'image_color'] 
                         and v is not None}
        
        results = client.search(query=data['query'], **optional_params)
        return success_response(results)
    except Exception as e:
        raise

@app.route('/api/video-search', methods=['POST'])
@validate_request_json(['query'])
def video_search() -> Dict:
    """
    Perform video search using YouTube Data API.
    
    Request Body:
        {
            "query": str (required),
            "language": str (optional),
            "region_code": str (optional),
            "max_results": int (optional),
            "order": str (optional),
            "duration": str (optional),
            "definition": str (optional),
            "safe_search": str (optional)
        }
    
    Returns:
        List of video search results with metadata
    """
    try:
        data = request.get_json()
        client = VideoSearchClient()
        
        # Extract optional parameters
        optional_params = {k: v for k, v in data.items() 
                         if k in ['language', 'region_code', 'max_results', 'order',
                                'duration', 'definition', 'safe_search'] 
                         and v is not None}
        
        results = client.search(query=data['query'], **optional_params)
        return success_response(results)
    except Exception as e:
        raise

@app.route('/api/discovery-engine/add-sites', methods=['POST'])
@validate_request_json(['websites'])
def add_target_sites() -> Dict:
    """
    Add target websites to Discovery Engine.
    
    Request Body:
        {
            "websites": List[str] (required)
        }
    
    Returns:
        List of all target sites after addition
    """
    try:
        data = request.get_json()
        client = DiscoveryEngineClient()
        
        results = client.setup_and_add_target_sites(websites=data['websites'])
        return success_response(results)
    except Exception as e:
        raise

@app.route('/api/discovery-engine/search', methods=['POST'])
@validate_request_json(['query', 'websites'])
def discovery_engine_search() -> Dict:
    """
    Search across specified websites using Discovery Engine.
    
    Request Body:
        {
            "query": str (required),
            "websites": List[str] (required)
        }
    
    Returns:
        List of search results from specified websites
    """
    try:
        data = request.get_json()
        client = DiscoveryEngineClient()
        
        results = client.setup_and_search(
            query=data['query'],
            websites=data['websites']
        )
        return success_response(results)
    except Exception as e:
        raise

@app.route('/api/gemini/analyze', methods=['POST'])
@validate_request_json(['full_image', 'roi_image'])
def gemini_analyze() -> Dict:
    """
    Analyze images using the latest version of Gemini API.
    
    Request Body:
        {
            "full_image": str (required, base64 encoded image),
            "roi_image": str (required, base64 encoded image),
            "mime_type1": str (optional, defaults to "image/jpeg"),
            "mime_type2": str (optional, defaults to "image/jpeg"),
            "extended_context": Dict[str, str] (optional) containing:
                - grade: Grade level (e.g., "6", "7", "8")
                - subject: Subject area (e.g., "Math", "Science")
                - context: Additional context about the topic
        }
    
    Returns:
        Dictionary containing:
            - search_query: Main search query
            - quick_followup_queries: List of follow-up queries
            - suggested_queries: List of suggested queries
            - for_next_step: Query for next step
    """
    try:
        data = request.get_json()
        logger.info(f"Gemini analyze request: {json.dumps(data, indent=2)}")
        client = GeminiClient()
        
        # Extract optional parameters
        full_image_mime_type = data.get('full_image_mime_type', 'image/jpeg')
        roi_image_mime_type = data.get('roi_image_mime_type', 'image/jpeg')
        extended_context = data.get('extended_context')
        
        try:
            # Decode base64 strings to bytes
            full_image_bytes = base64.b64decode(data['full_image'])
            roi_image_bytes = base64.b64decode(data['roi_image'])
        except Exception as e:
            logger.error(f"Failed to decode base64 image: {str(e)}")
            return jsonify({
                "success": False,
                "error": "Invalid image data. Please ensure images are properly encoded.",
                "status_code": 400
            }), 400
        
        results = client.analyze_v2(
            full_image_bytes=full_image_bytes,
            roi_image_bytes=roi_image_bytes,
            mime_type1=full_image_mime_type,
            mime_type2=roi_image_mime_type,
            extended_context=extended_context
        )
        return success_response(results)
    except Exception as e:
        raise

@app.route('/api/gemini/explain', methods=['POST'])
@validate_request_json(['analysis'])
def gemini_explain() -> Dict:
    """
    Generate educational explanation based on image analysis using the latest version of Gemini API.
    
    Request Body:
        {
            "analysis": Dict[str, str] (required) containing analysis results
        }
    
    Returns:
        Dictionary containing:
            - content: Main explanation text
            - rendered_content: Rendered version of the content (if available)
            - citations: List of citation dictionaries with title and uri
    """
    try:
        data = request.get_json()
        logger.info(f"Gemini explain request: {json.dumps(data, indent=2)}")
        client = GeminiClient()
        
        results = client.explanation_v2(analysis=data['analysis'])
        return success_response(results)
    except Exception as e:
        raise

@app.route('/api/gemini/explain-stream', methods=['POST'])
@validate_request_json(['analysis'])
def gemini_explain_stream():
    """
    Stream educational explanation based on image analysis.
    Uses HTTP chunked transfer encoding.
    
    Request Body:
        {
            "analysis": Dict[str, str] (required) containing analysis results
        }
    
    Returns:
        Streamed chunks of explanation text
    """
    try:
        data = request.get_json()
        logger.info(f"Gemini explain stream request: {json.dumps(data, indent=2)}")
        client = GeminiClient()

        def generate():
            try:
                for chunk in client.explanation_v2_stream(analysis=data['analysis']):
                    yield json.dumps(chunk) + '\n'
            except Exception as e:
                logger.error(f"Streaming error: {str(e)}")
                raise

        return Response(
            generate(),
            mimetype='application/x-ndjson'  # Use newline-delimited JSON format
        )
        
    except Exception as e:
        raise

if __name__ == '__main__':
    # Get port from environment variable (Cloud Run sets this)
    port = int(os.getenv('PORT', '8080'))
    
    try:
        from waitress import serve
        serve(app, host='0.0.0.0', port=port)
    except Exception as e:
        logger.critical(f"Failed to start server: {e}")
        sys.exit(1)
