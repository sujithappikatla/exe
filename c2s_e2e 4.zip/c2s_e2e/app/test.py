from image_search import ImageSearchClient  
from video_search import VideoSearchClient
from web_search import WebSearchClient
from discovery_engine import DiscoveryEngineClient
from gemini import GeminiClient
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
import json


def test_web_search():
    try:
        # Initialize the client
        client = WebSearchClient()
        
        # Example search with parameters
        results = client.search(
            query="what are solar flares",
            # gl="us",              # Search from US perspective
            # lr="en",              # English results only
            num=2,                # Get 5 results
            # safe=True,            # Safe search on
            # start=1               # Start from first result
        )
        
        print(f"Found {len(results)} results")
        for result in results:
            print("\nWeb details:")
            for key, value in result.items():
                print(f"{key}: {value}")
    except (WebSearchClient.SearchError, ValueError) as e:
        logger.error(f"Error during search: {str(e)}")



def test_image_search():
    try:
        # Initialize the client
        client = ImageSearchClient()
        
        # Example image search with parameters
        results = client.search(
            query="cute puppies",
            # gl="us",                # Search from US perspective
            # lr="en",                # English results only
            num=2,                  # Get 5 results
            # safe=True,              # Safe search on
            # start=1,                # Start from first result
            # image_size="LARGE",     # Large images only
            # image_type="face",     # Photos only
            # image_color="gray"     # Color images only
        )
        
        print(f"Found {len(results)} images")
        for result in results:
            print("\nImage details:")
            for key, value in result.items():
                print(f"{key}: {value}")
    except (ImageSearchClient.SearchError, ValueError) as e:
        logger.error(f"Error during image search: {str(e)}")

def test_video_search():
    try:
        # Initialize the client
        client = VideoSearchClient()
        
        # Example video search with parameters
        results = client.search(
            query="python programming tutorial",
            # language="en",                # English content
            # region_code="US",             # US region
            max_results=2,                # Get 5 results
            # order="viewCount",            # Sort by view count
            # duration="medium",            # Medium length videos
            # definition="high",            # HD videos
            # safe_search="moderate"        # Moderate safe search
        )
        
        print(f"Found {len(results)} videos")
        for result in results:
            print("\nVideo details:")
            for key, value in result.items():
                print(f"{key}: {value}")
    except (VideoSearchClient.SearchError, ValueError) as e:
        logger.error(f"Error during video search: {str(e)}")


def test_discovery_engine_add_website():
    try:
        # Initialize client
        client = DiscoveryEngineClient()
        
        # Example 1: Add target sites
        websites_to_add = ["www.wikipedia.org", "www.nasa.gov", "www.science.org"]
        all_sites = client.setup_and_add_target_sites(websites=websites_to_add)
        print(f"\nTotal target sites: {len(all_sites)}")
        print("Target sites:")
        for site in all_sites:
            print(f"- {site}")

    except DiscoveryEngineClient.ConfigurationError as e:
        logger.error(f"Error: {str(e)}")



def test_discovery_engine_search():
    try:
        # Initialize client
        client = DiscoveryEngineClient()

        websites_to_search = ["www.wikipedia.org"]
        # Example 2: Search across the added websites
        results = client.setup_and_search(
            query="What are solar flares?",
            websites=websites_to_search
        )
        
        # Print search results
        print(f"\nFound {len(results)} results:")
        for result in results:
            print("\nResult details:")
            for key, value in result.items():
                print(f"{key}: {value}")
                
    except DiscoveryEngineClient.ConfigurationError as e:
        logger.error(f"Error: {str(e)}")


def test_gemini_search_queries():
    try:
        # Example usage
        client = GeminiClient()
        
        # Load test images
        with open("./full.png", "rb") as f:
            image1_bytes = f.read()
        with open("./roi.png", "rb") as f:
            image2_bytes = f.read()

        extended_context = "How to send REST API requests in python"
        
        # Generate search queries
        queries = client.generate_search_queries(image1_bytes, image2_bytes, mime_type1="image/png", mime_type2="image/png", extended_context=extended_context)
        logger.info(json.dumps(queries, indent=2))
        
    except (GeminiClient.ConfigurationError, GeminiClient.AnalysisError) as e:
        logger.error(f"Error: {str(e)}")


def test_gemini_analyze_and_explain():
    try:
        # Example usage
        client = GeminiClient()
        
        # Load test images
        with open("./full.png", "rb") as f:
            image1_bytes = f.read()
        with open("./roi.png", "rb") as f:
            image2_bytes = f.read()

        extended_context = "python code"
        # Analyze images and get explanation
        result = client.analyze_and_explain(image1_bytes, image2_bytes, mime_type1="image/png", mime_type2="image/png", extended_context=extended_context)
        
        # Print results
        print("\nAnalysis Results:")
        print(json.dumps(result["analysis"], indent=2))
        
        print("\nEducational Explanation:")
        print(result["explanation"]["content"])
        
    except (GeminiClient.ConfigurationError, GeminiClient.AnalysisError) as e:
        logger.error(f"Error: {str(e)}")


if __name__ == "__main__":
    test_web_search()
    test_image_search()
    test_video_search()
    test_discovery_engine_add_website()
    test_discovery_engine_search()
    test_gemini_search_queries()
    test_gemini_analyze_and_explain()