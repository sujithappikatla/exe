import google.auth
import google.auth.transport.requests

# Automatically detect and use the attached service account on Cloud Run
credentials, _ = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])

# Refresh credentials to obtain a fresh access token
request = google.auth.transport.requests.Request()
credentials.refresh(request)
access_token = credentials.token

print(access_token)

print(credentials.expiry)