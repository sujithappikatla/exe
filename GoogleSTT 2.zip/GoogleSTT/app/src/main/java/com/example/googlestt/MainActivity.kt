package com.example.googlestt

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.googlestt.ui.theme.GoogleSTTTheme
import com.example.googlestt.viewmodel.SpeechViewModel

class MainActivity : ComponentActivity() {
    companion object {
        private const val TAG = "MainActivity"
    }
    
    private val speechViewModel: SpeechViewModel by viewModels()
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        Log.d(TAG, "Permission request result: $isGranted")
        if (isGranted) {
            Log.d(TAG, "Audio permission granted")
        } else {
            Log.e(TAG, "Audio permission denied")
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Check and request audio permission
        val hasPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        
        Log.d(TAG, "Has audio permission: $hasPermission")
        
        if (!hasPermission) {
            Log.d(TAG, "Requesting audio permission")
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        
        setContent {
            GoogleSTTTheme {
                SpeechTranscriptionScreen(speechViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeechTranscriptionScreen(viewModel: SpeechViewModel) {
    val isRecording by viewModel.isRecording.collectAsState()
    val currentTranscript by viewModel.currentTranscript.collectAsState()
    val finalTranscript by viewModel.finalTranscript.collectAsState()
    
    val scrollState = rememberScrollState()
    
    LaunchedEffect(currentTranscript, finalTranscript) {
        // Auto scroll to bottom when text changes
        scrollState.animateScrollTo(scrollState.maxValue)
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Google Speech to Text") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Transcription area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outline,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                ) {
                    // Final transcript
                    if (finalTranscript.isNotEmpty()) {
                        Text(
                            text = finalTranscript.trim(),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Normal,
                            lineHeight = 24.sp
                        )
                    }
                    
                    // Interim transcript
                    if (currentTranscript.isNotEmpty()) {
                        Text(
                            text = if (finalTranscript.isNotEmpty()) " $currentTranscript" else currentTranscript,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Light,
                            color = MaterialTheme.colorScheme.secondary,
                            lineHeight = 24.sp
                        )
                    }
                    
                    // Placeholder when empty
                    if (finalTranscript.isEmpty() && currentTranscript.isEmpty()) {
                        Text(
                            text = "Press the microphone button to start recording...",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Light,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 24.sp
                        )
                    }
                }
            }
            
            // Control buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Clear button
                OutlinedButton(
                    onClick = { viewModel.clearTranscripts() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Clear")
                }
                
                // Record/Stop button
                Button(
                    onClick = {
                        Log.d("MainActivity", "Record button clicked, current recording state: $isRecording")
                        if (isRecording) {
                            Log.d("MainActivity", "Stopping recording")
                            viewModel.stopRecording()
                        } else {
                            Log.d("MainActivity", "Starting recording")
                            viewModel.startRecording()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(if (isRecording) "Stop" else "Record")
                }
            }
        }
    }
}