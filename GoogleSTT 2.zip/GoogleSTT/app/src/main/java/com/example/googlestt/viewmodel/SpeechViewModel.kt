package com.example.googlestt.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.googlestt.audio.AudioRecorderManager
import com.example.googlestt.speech.GoogleSpeechConfig
import com.example.googlestt.speech.GoogleSpeechService
import com.example.googlestt.speech.SpeechResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.launch

class SpeechViewModel(application: Application) : AndroidViewModel(application) {
    companion object {
        private const val TAG = "SpeechViewModel"
    }
    
    private val audioRecorderManager = AudioRecorderManager(application)
    private val speechService = GoogleSpeechService(GoogleSpeechConfig())
    
    // UI state
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording
    
    private val _currentTranscript = MutableStateFlow("")
    val currentTranscript: StateFlow<String> = _currentTranscript
    
    private val _finalTranscript = MutableStateFlow("")
    val finalTranscript: StateFlow<String> = _finalTranscript
    
    /**
     * Start recording and transcribing
     */
    fun startRecording() {
        Log.d(TAG, "startRecording called")
        if (_isRecording.value) {
            Log.w(TAG, "Already recording, ignoring start request")
            return
        }
        
        _isRecording.value = true
        _currentTranscript.value = ""
        Log.d(TAG, "Recording state set to true")
        
        viewModelScope.launch {
            try {
                Log.d(TAG, "Initializing speech service")
                speechService.initialize()
                
                Log.d(TAG, "Starting audio recording")
                val audioFlow = audioRecorderManager.startRecording()
                
                Log.d(TAG, "Processing audio stream with Google STT")
                speechService.processAudioStream(audioFlow)
                    .retryWhen { cause, attempt ->
                        // Check if the error is the one we want to retry
                        val shouldRetry = cause.message?.contains("Max duration", ignoreCase = true) == true

                        if (shouldRetry) {
                            Log.w(TAG, "processAudioStream failed with 'Max Duration' (attempt ${attempt + 1}). Retrying immediately.")
                            // Since we need to reconnect after max duration error, we should clean up
                            // the old speech client and create a new one when retrying
                            try {
                                // Make sure we keep recording state true during reconnection
                                _isRecording.value = true
                                
                                // Clean up existing resources
                                speechService.close()
                                
                                // Reinitialize the speech service
                                Log.d(TAG, "Reinitializing speech service after max duration error")
                                speechService.initialize()
                                
                                true // Signal to retry
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to reinitialize after max duration error: ${e.message}", e)
                                false // Signal not to retry if reinitialization fails
                            }
                        } else {
                            Log.e(TAG, "processAudioStream failed with non-retryable error (attempt ${attempt + 1}): ${cause.message}. Will not retry.")
                            false // Signal to stop retrying and propagate the error
                        }
                    }
                    .collect { result ->
                        when (result) {
                            is SpeechResult.Interim -> {
                                Log.d(TAG, "Received interim result: ${result.text}")
                                _currentTranscript.value = result.text
                            }
                            is SpeechResult.Final -> {
                                Log.d(TAG, "Received final result: ${result.text}")
                                _finalTranscript.value += " ${result.text}"
                                _currentTranscript.value = ""
                            }
                        }
                    }
            } catch (e: Exception) {
                Log.e(TAG, "Error during recording: ${e.message}", e)
                stopRecording()
            }
        }
    }
    
    /**
     * Stop recording and transcribing
     */
    fun stopRecording() {
        Log.d(TAG, "stopRecording called")
        if (!_isRecording.value) {
            Log.w(TAG, "Not recording, ignoring stop request")
            return
        }
        
        audioRecorderManager.stopRecording()
        _isRecording.value = false
        Log.d(TAG, "Recording state set to false")
        
        // Add any remaining interim transcript to the final transcript
        if (_currentTranscript.value.isNotEmpty()) {
            Log.d(TAG, "Adding remaining interim transcript to final: ${_currentTranscript.value}")
            _finalTranscript.value += " ${_currentTranscript.value}"
            _currentTranscript.value = ""
        }
    }
    
    /**
     * Clear transcripts
     */
    fun clearTranscripts() {
        Log.d(TAG, "Clearing transcripts")
        _currentTranscript.value = ""
        _finalTranscript.value = ""
    }
    
    override fun onCleared() {
        super.onCleared()
        Log.d(TAG, "ViewModel being cleared, cleaning up resources")
        audioRecorderManager.stopRecording()
        speechService.close()
    }
} 