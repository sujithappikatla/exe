package com.example.googlestt.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.ByteArrayOutputStream
import java.io.IOException

class AudioRecorderManager(private val context: Context) {
    companion object {
        private const val TAG = "AudioRecorderManager"
        // Audio recording parameters
        private const val SAMPLE_RATE = 16000 // 16kHz
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val BUFFER_SIZE_FACTOR = 2
    }

    private var audioRecord: AudioRecord? = null
    private var bufferSize: Int = AudioRecord.getMinBufferSize(
        SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT
    ) * BUFFER_SIZE_FACTOR
    private var isRecording = false

    /**
     * Starts audio recording and returns a flow of audio data
     */
    fun startRecording(): Flow<ByteArray> = flow {
        try {
            Log.d(TAG, "Initializing AudioRecord with buffer size: $bufferSize")
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "Failed to initialize AudioRecord")
                throw IOException("Failed to initialize AudioRecord")
            }

            Log.d(TAG, "AudioRecord initialized successfully")
            val buffer = ByteArray(bufferSize)
            audioRecord?.startRecording()
            isRecording = true
            Log.d(TAG, "Started recording audio")

            while (isRecording) {
                val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (bytesRead > 0) {
                    // Copy only the bytes that were read
                    val audioData = buffer.copyOfRange(0, bytesRead)
                    emit(audioData)
                } else if (bytesRead < 0) {
                    Log.e(TAG, "Error reading audio data: $bytesRead")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during audio recording: ${e.message}", e)
            throw e
        } finally {
            Log.d(TAG, "Stopping recording in finally block")
            stopRecording()
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Stops the audio recording
     */
    fun stopRecording() {
        Log.d(TAG, "stopRecording called, current recording state: $isRecording")
        isRecording = false
        audioRecord?.let { recorder ->
            if (recorder.state == AudioRecord.STATE_INITIALIZED) {
                try {
                    Log.d(TAG, "Stopping AudioRecord")
                    recorder.stop()
                } catch (e: IllegalStateException) {
                    Log.w(TAG, "Recorder was already stopped")
                }
            }
            Log.d(TAG, "Releasing AudioRecord")
            recorder.release()
            audioRecord = null
        }
    }

    /**
     * Checks if recording is currently active
     */
    fun isRecording(): Boolean = isRecording
} 