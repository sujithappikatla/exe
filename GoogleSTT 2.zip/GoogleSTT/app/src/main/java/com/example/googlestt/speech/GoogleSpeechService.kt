package com.example.googlestt.speech

import android.util.Log
import com.google.api.gax.core.FixedCredentialsProvider
import com.google.api.gax.rpc.ApiStreamObserver
import com.google.api.gax.rpc.ClientStream
import com.google.api.gax.rpc.ResponseObserver
import com.google.api.gax.rpc.StreamController
import com.google.auth.oauth2.AccessToken
import com.google.auth.oauth2.GoogleCredentials
import com.google.cloud.speech.v2.AutoDetectDecodingConfig
import com.google.cloud.speech.v2.ExplicitDecodingConfig
import com.google.cloud.speech.v2.RecognitionConfig
import com.google.cloud.speech.v2.RecognitionFeatures
import com.google.cloud.speech.v2.RecognizeRequest
import com.google.cloud.speech.v2.SpeechClient
import com.google.cloud.speech.v2.SpeechSettings
import com.google.cloud.speech.v2.StreamingRecognitionConfig
import com.google.cloud.speech.v2.StreamingRecognitionFeatures
import com.google.cloud.speech.v2.StreamingRecognizeRequest
import com.google.cloud.speech.v2.StreamingRecognizeResponse
import com.google.protobuf.ByteString
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.trySendBlocking
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Sealed class to represent both interim and final results
 */
sealed class SpeechResult {
    data class Interim(val text: String) : SpeechResult()
    data class Final(val text: String) : SpeechResult()
}

data class GoogleSpeechConfig(
    val language_code: String = "en-US",
    val project_id: String = "cloud-learning-443407",
    val auth_token:String = "ya29.c.c0ASRK0GbVYbODJycn7OHWQrhu8ZFZOmeL41YZAjen4SRL5DdSlVr2nQ9eS4T0WKh3Gpx-jkuiGwzhtXrQa1F1yEV23NVFiZsfX9WijfSafkssMQABXa791S7eOKuLg2HrzVYJUN1-h4Me4e1bclRhf9_ucMtfort4Qj12lu5DLE0AJd-fAhuapd7nihsk3pE4Aq0jBw1rmzQ8YaNm5qg0pny79h2nZS2eNcvT3PcItG2VYDj7MVIV3xInLJxVOysa--2vYNj5MeKVWwz0kVnfGFRqWbPVsnkQCW3nyd-LpdpdZEmtc7il2FpP5wPwl11VSD5rzGwvXCQQlBw365ZPbrNu6zbV22hoby1mIpD0bdtOJ-nz9MHEA-WxG385CgIzw2Z30Mxk0XhJYoh0Xb-BYn72n9ujsJuz8ykbyMWgXaqz2I_Q0v0ZIhSUbOzm8bhi--w0JS8spfBSdFt4X9f4kF9efUlSzFF2e3s9fQqk_bq7j9fB9U0BO8JbuouBnYql0Mmsn4dxFp6y7ySJcwIakYRU3WyZqcJj6Vo81v5bkvlgOjjuq-j8-9r1t8Xc9nvaurbXeMirI6699njiflhORjjlddokM_QIhhalStm8c0uim_zmwwd3M8pQ4QV8QcoOWhh19xzx_iy47gRinisaoRonkm3zX1ZYpokkn9YOogqJd3aXofjbRrjuXszc30aVc5QsF56io5B68UygMc67osgjiSwsQkc4q-ijmSV4nokRzeyloSu74ypYs9nj2ws-F86WwaMef2d9S_r_nxFgSUZgSS71Z798pq9w9_olpuI1c4q2Q6QXR3-05qV3i-wFcMkS55omvajvBpYtIYbVZF-4ZoUoOinJR74w-3UOF69e_ochw5lZxlfowRb42nW6w7a5UeJvuFSsXqim0Ve6Si_B1bzZVls_5OFf-k7a92wxxZoZsz6iYaq2j07d4FfuZnMM7umM_VFblZfxfUBd9uutladizqX3YnmbvqRnRrau0vuJoYM7req",
    val location_id:String = "us-central1",
    val recognizer_id:String = "_",
    val model_name:String = "chirp_2"
)

class GoogleSpeechService( config : GoogleSpeechConfig) {

    private val TAG = "GoogleSpeechService"
    private val SAMPLE_RATE_HERTZ = 16000
    private val LANGUAGE_CODE = config.language_code
    private val DUMMY_AUTH_TOKEN = config.auth_token
    // Google Cloud configuration
    private val PROJECT_ID = config.project_id
    private val LOCATION_ID = config.location_id
    private val RECOGNIZER_ID = config.recognizer_id
    private val RECOGNITION_MODEL = config.model_name

    // Error string to detect max duration error
    private val MAX_DURATION_ERROR = "Max duration of 5 minutes reached for stream"

    
    // Computed property for the full recognizer name
    private val recognizerName: String
        get() = "projects/$PROJECT_ID/locations/$LOCATION_ID/recognizers/$RECOGNIZER_ID"

    private var speechClient: SpeechClient? = null
    private var requestStream: ClientStream<StreamingRecognizeRequest>? = null
    
    /**
     * Initialize the Google STT client with auth token
     */
    suspend fun initialize(authToken: String = DUMMY_AUTH_TOKEN) = withContext(Dispatchers.IO) {
        Log.d(TAG, "Initializing Google Speech Service")
        try {
            // Create GoogleCredentials from the OAuth 2.0 access token
            val googleCredentials = GoogleCredentials.create(AccessToken(authToken, null))
            Log.d(TAG, "Created Google credentials")

            // Build SpeechSettings with the custom credentials provider
            val speechSettings = SpeechSettings.newBuilder()
                .setCredentialsProvider(FixedCredentialsProvider.create(googleCredentials))
                .setEndpoint("us-central1-speech.googleapis.com:443")
                .build()
            Log.d(TAG, "Built speech settings")
            
            // Create the SpeechClient
            try {
                Log.d(TAG, "Attempting to create Speech client")
                speechClient = SpeechClient.create(speechSettings)
                Log.d(TAG, "Created Speech client successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create Speech client: ${e.message}", e)
                Log.e(TAG, "Exception class: ${e.javaClass.name}")
                Log.e(TAG, "Stack trace: ${e.stackTraceToString()}")
                throw e
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing speech service: ${e.message}", e)
            Log.e(TAG, "Exception class: ${e.javaClass.name}")
            Log.e(TAG, "Stack trace: ${e.stackTraceToString()}")
            throw e
        }
    }

    /**
     * Process streaming audio data and return real-time transcriptions
     */
    fun processAudioStream(audioDataFlow: Flow<ByteArray>): Flow<SpeechResult> = callbackFlow {
        Log.d(TAG, "Starting audio stream processing")
        if (speechClient == null) {
            Log.d(TAG, "Speech client is null, initializing")
            try {
                initialize()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize speech client: ${e.message}", e)
                close(e)
                return@callbackFlow
            }
        }
        
        val client = speechClient ?: run {
            Log.e(TAG, "Speech client is still null after initialization")
            close(IllegalStateException("Speech client is not initialized"))
            return@callbackFlow
        }
        
        // Create the recognition config
        val recognitionConfig = RecognitionConfig.newBuilder()
            .setExplicitDecodingConfig(
                ExplicitDecodingConfig.newBuilder()
                    .setAudioChannelCount(1)
                    .setEncoding(ExplicitDecodingConfig.AudioEncoding.LINEAR16)
                    .setSampleRateHertz(SAMPLE_RATE_HERTZ)
                    .build()
            )
//            .setAutoDecodingConfig(AutoDetectDecodingConfig.getDefaultInstance())
            .addLanguageCodes( LANGUAGE_CODE)
            .setModel(RECOGNITION_MODEL)
            .setFeatures(RecognitionFeatures.newBuilder()
                .setEnableAutomaticPunctuation(true)
                .setEnableWordTimeOffsets(false)
                .build()
            )
            .build()
        Log.d(TAG, "Created recognition config")
        
        // Create the streaming config
        val streamingConfig = StreamingRecognitionConfig.newBuilder()
            .setConfig(recognitionConfig)
            .setStreamingFeatures(
                StreamingRecognitionFeatures.newBuilder()
                    .setInterimResults(true)
                    .build()
            )
            .build()
        Log.d(TAG, "Created streaming config")
        
        // Define audioCollectionJob variable at a higher scope
        var audioCollectionJob = GlobalScope.launch(Dispatchers.IO) {}

        // Create the response observer
        val responseObserver = object : ResponseObserver<StreamingRecognizeResponse> {
            override fun onStart(controller: StreamController) {
                Log.d(TAG, "Stream started")
            }

            override fun onResponse(response: StreamingRecognizeResponse) {
                if (response.resultsCount > 0) {
                    val result = response.getResults(0)
                    if (result.alternativesCount > 0) {
                        val transcript = result.getAlternatives(0).transcript
                        val isFinal = result.isFinal

                        Log.d(TAG, "Received ${if (isFinal) "final" else "interim"} result: $transcript")

                        if (isFinal) {
                            trySendBlocking(SpeechResult.Final(transcript))
                        } else {
                            trySendBlocking(SpeechResult.Interim(transcript))
                        }
                    }
                }
            }

            override fun onError(t: Throwable) {
                Log.e(TAG, "Stream error: ${t.message}", t)
                Log.e(TAG, "Error class: ${t.javaClass.name}")
                Log.e(TAG, "Stack trace: ${t.stackTraceToString()}")
                
                // Check if the error is due to reaching the maximum duration
                if (t.message?.contains(MAX_DURATION_ERROR, ignoreCase = true) == true) {
                    Log.w(TAG, "Max duration error detected. Letting retry mechanism handle reconnection.")
                    // Cancel the audio collection job before closing
                    audioCollectionJob.cancel()
                    // We'll close with a specific exception that contains the max duration error message
                    // This will be caught by the retry mechanism in SpeechViewModel
                    close(Exception(MAX_DURATION_ERROR))
                } else {
                    close(t)
                }
            }

            override fun onComplete() {
                Log.d(TAG, "Stream completed")
                close()
            }
        }
        
        // Start the streaming call
        Log.d(TAG, "Starting streaming call")
        try {
            requestStream = client.streamingRecognizeCallable().splitCall(responseObserver)
            Log.d(TAG, "Streaming call started successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start streaming call: ${e.message}", e)
            Log.e(TAG, "Exception class: ${e.javaClass.name}")
            Log.e(TAG, "Stack trace: ${e.stackTraceToString()}")
            close(e)
            return@callbackFlow
        }
        
        // Send the initial configuration request
        val initialRequest = StreamingRecognizeRequest.newBuilder()
            .setRecognizer(recognizerName)
            .setStreamingConfig(streamingConfig)
            .build()
        
        try {
            requestStream?.send(initialRequest)
            Log.d(TAG, "Sent initial configuration request")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send initial configuration: ${e.message}", e)
            close(e)
            return@callbackFlow
        }
        
        // Launch a coroutine to collect audio data and send it
        audioCollectionJob = GlobalScope.launch(Dispatchers.IO) {
            try {
                Log.d(TAG, "Starting audio data collection")
                audioDataFlow.collect { audioData ->
                    try {
                        val audioRequest = StreamingRecognizeRequest.newBuilder()
                            .setAudio(ByteString.copyFrom(audioData))
                            .build()
                        requestStream?.send(audioRequest)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error sending audio data: ${e.message}", e)
                        if (e.message?.contains("half-closed", ignoreCase = true) == true) {
                            Log.w(TAG, "Stream is already half-closed, cancelling audio collection")
                            cancel() // Cancel this coroutine
                            return@collect
                        }
                    }
                }
                Log.d(TAG, "Finished collecting audio data, closing send")
                try {
                    requestStream?.closeSend()
                } catch (e: Exception) {
                    Log.w(TAG, "Error closing stream send: ${e.message}")
                    // Stream is already closed or half-closed, ignore the error
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing audio stream: ${e.message}", e)
                Log.e(TAG, "Exception class: ${e.javaClass.name}")
                Log.e(TAG, "Stack trace: ${e.stackTraceToString()}")
                try {
                    requestStream?.closeSend()
                } catch (closeException: Exception) {
                    Log.w(TAG, "Error closing request stream: ${closeException.message}")
                    // Stream is already closed or half-closed, ignore the error
                }
            }
        }
        
        awaitClose {
            Log.d(TAG, "Closing stream and cleaning up resources")
            audioCollectionJob.cancel() // Cancel the audio collection job
            try {
                requestStream?.closeSend()
            } catch (e: Exception) {
                Log.w(TAG, "Error closing request stream: ${e.message}")
                // Stream is already closed or half-closed, ignore the error
            }
            
            if (speechClient != null) {
                try {
                    Log.d(TAG, "Awaiting speech client termination")
                    speechClient?.awaitTermination(500, TimeUnit.MILLISECONDS)
                } catch (e: Exception) {
                    Log.w(TAG, "Error terminating speech client: ${e.message}")
                } finally {
                    Log.d(TAG, "Closing speech client")
                    speechClient?.close()
                    speechClient = null
                }
            }
            
            requestStream = null
        }
    }
    
    /**
     * Close the speech client
     */
    fun close() {
        Log.d(TAG, "Closing Google Speech Service")
        if (requestStream != null) {
            try {
                requestStream?.closeSend()
            } catch (e: Exception) {
                Log.w(TAG, "Error closing request stream: ${e.message}")
            } finally {
                requestStream = null
            }
        }
        
        if (speechClient != null) {
            try {
                Log.d(TAG, "Awaiting speech client termination")
                speechClient?.awaitTermination(500, TimeUnit.MILLISECONDS)
            } catch (e: Exception) {
                Log.w(TAG, "Error terminating speech client: ${e.message}")
            } finally {
                Log.d(TAG, "Closing speech client")
                speechClient?.close()
                speechClient = null
            }
        }
    }
} 