# NFC Reader App

An Android app built with Kotlin and Jetpack Compose that reads NFC cards and displays all available data.

## Features

- **Complete NFC Support**: Reads various NFC tag types including Mifare Classic, Mifare Ultralight, ISO-DEP, NFC-A, NFC-B, NFC-F, and NFC-V
- **NDEF Message Parsing**: Extracts and displays NDEF messages with proper text and URI parsing
- **Raw Data Display**: Shows raw data from different NFC technologies
- **Modern UI**: Built with Jetpack Compose and Material Design 3
- **Real-time Reading**: Automatically detects and reads NFC tags when brought near the device

## How to Use

1. **Enable NFC**: Make sure NFC is enabled in your device settings
2. **Launch the App**: Open the NFC Reader app
3. **Scan NFC Card**: Hold your NFC card/tag near the back of your device
4. **View Data**: The app will automatically read and display all available data from the NFC tag

## Supported Data Types

### NDEF Messages
- Text records (with language detection)
- URI records (with prefix handling)
- MIME media records
- Custom records

### Raw Technology Data
- **Mifare Classic**: Sector count, block count, size, and type information
- **Mifare Ultralight**: Type detection and page data reading
- **ISO-DEP**: Historical bytes and Hi Layer response
- **NFC-A**: ATQA and SAK values
- **NFC-B**: Application data and protocol information

### Tag Information
- Unique tag ID
- Supported technologies
- NDEF capabilities (size, writability, formatability)
- Tag type identification

## Technical Details

- **Minimum SDK**: API 30 (Android 11)
- **Target SDK**: API 34 (Android 14)
- **NFC Technologies Supported**: All major NFC technologies
- **Architecture**: MVVM pattern with Compose state management

## Permissions

The app requires the following permissions:
- `android.permission.NFC` - To access NFC hardware
- `android.hardware.nfc` - NFC hardware feature requirement

## Project Structure

```
app/src/main/java/com/example/nfc/
├── MainActivity.kt          # Main activity with NFC handling and UI
├── data/
│   └── NFCData.kt          # Data models for NFC information
└── utils/
    └── NFCReader.kt        # Utility class for reading NFC tags
```

## Building and Running

1. Clone the repository
2. Open in Android Studio
3. Ensure you have an NFC-enabled Android device
4. Build and run the app
5. Test with various NFC cards/tags

## Supported NFC Card Types

- **Payment Cards**: Credit/debit cards with EMV chips
- **Transit Cards**: Public transportation cards
- **Access Cards**: Hotel key cards, office access cards
- **NDEF Tags**: Programmable NFC tags with stored data
- **Custom Tags**: Any NFC-compliant tags

## Error Handling

The app includes comprehensive error handling for:
- NFC not available on device
- NFC disabled in settings
- Tag reading failures
- Unsupported tag types
- Connection timeouts

## Note

This app is designed for educational and debugging purposes. It reads publicly available data from NFC tags and does not attempt to bypass any security measures or access protected data.
