package com.example.nfc.utils

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.Tag
import android.nfc.tech.*
import com.example.nfc.data.NFCMessage
import com.example.nfc.data.NFCRecord
import com.example.nfc.data.NFCTagData
import java.nio.charset.Charset

/**
 * Utility class for reading NFC tags and extracting data
 */
object NFCReader {

    /**
     * Reads all available data from an NFC tag
     */
    fun readTag(tag: Tag): NFCTagData {
        val tagId = bytesToHex(tag.id)
        val techList = tag.techList.toList()
        val ndefMessages = readNdefMessages(tag)
        val rawData = extractRawData(tag)
        val tagType = determineTagType(tag)
        val ndefInfo = getNdefInfo(tag)
        val detailedInfo = getDetailedTagInfo(tag)

        return NFCTagData(
            id = tagId,
            techList = techList,
            ndefMessages = ndefMessages,
            rawData = rawData,
            tagType = tagType,
            isNdefFormattable = ndefInfo.isNdefFormattable,
            maxSize = ndefInfo.maxSize,
            isWritable = ndefInfo.isWritable,
            tagSize = detailedInfo.tagSize,
            sectorCount = detailedInfo.sectorCount,
            blockCount = detailedInfo.blockCount,
            pageCount = detailedInfo.pageCount,
            atqa = detailedInfo.atqa,
            sak = detailedInfo.sak,
            applicationData = detailedInfo.applicationData,
            protocolInfo = detailedInfo.protocolInfo,
            historicalBytes = detailedInfo.historicalBytes,
            hiLayerResponse = detailedInfo.hiLayerResponse,
            manufacturer = detailedInfo.manufacturer,
            isConnected = detailedInfo.isConnected,
            timeout = detailedInfo.timeout,
            canMakeReadOnly = ndefInfo.canMakeReadOnly,
            ndefType = ndefInfo.ndefType,
            ndefUsedSize = ndefInfo.ndefUsedSize
        )
    }

    /**
     * Reads NDEF messages from the tag if available
     */
    private fun readNdefMessages(tag: Tag): List<NFCMessage> {
        val messages = mutableListOf<NFCMessage>()
        
        if (tag.techList.contains(Ndef::class.java.name)) {
            try {
                val ndef = Ndef.get(tag)
                ndef?.connect()
                val ndefMessage = ndef?.ndefMessage
                ndefMessage?.let { msg ->
                    messages.add(parseNdefMessage(msg))
                }
                ndef?.close()
            } catch (e: Exception) {
                // Handle exception silently and continue
            }
        }
        
        return messages
    }

    /**
     * Parses an Android NdefMessage into our custom NFCMessage
     */
    private fun parseNdefMessage(ndefMessage: NdefMessage): NFCMessage {
        val records = ndefMessage.records.map { record ->
            NFCRecord(
                type = String(record.type, Charset.forName("UTF-8")),
                payload = parsePayload(record),
                id = String(record.id, Charset.forName("UTF-8")),
                tnf = record.tnf,
                mimeType = record.toMimeType() ?: ""
            )
        }
        return NFCMessage(records)
    }

    /**
     * Parses the payload of an NDEF record
     */
    private fun parsePayload(record: NdefRecord): String {
        return when (record.tnf) {
            NdefRecord.TNF_WELL_KNOWN -> {
                when {
                    record.type.contentEquals(NdefRecord.RTD_TEXT) -> parseTextRecord(record)
                    record.type.contentEquals(NdefRecord.RTD_URI) -> parseUriRecord(record)
                    else -> bytesToHex(record.payload)
                }
            }
            NdefRecord.TNF_MIME_MEDIA -> String(record.payload, Charset.forName("UTF-8"))
            NdefRecord.TNF_ABSOLUTE_URI -> String(record.payload, Charset.forName("UTF-8"))
            else -> bytesToHex(record.payload)
        }
    }

    /**
     * Parses a text record from NDEF
     */
    private fun parseTextRecord(record: NdefRecord): String {
        val payload = record.payload
        if (payload.isEmpty()) return ""
        
        val textEncoding = if ((payload[0].toInt() and 128) == 0) "UTF-8" else "UTF-16"
        val languageCodeLength = payload[0].toInt() and 51
        
        return try {
            String(
                payload,
                languageCodeLength + 1,
                payload.size - languageCodeLength - 1,
                Charset.forName(textEncoding)
            )
        } catch (e: Exception) {
            bytesToHex(payload)
        }
    }

    /**
     * Parses a URI record from NDEF
     */
    private fun parseUriRecord(record: NdefRecord): String {
        val payload = record.payload
        if (payload.isEmpty()) return ""
        
        val uriIdentifier = payload[0].toInt() and 0xFF
        val uriPrefixes = arrayOf(
            "", "http://www.", "https://www.", "http://", "https://", "tel:", "mailto:",
            "ftp://anonymous:anonymous@", "ftp://ftp.", "ftps://", "sftp://", "smb://",
            "nfs://", "ftp://", "dav://", "news:", "telnet://", "imap:", "rtsp://",
            "urn:", "pop:", "sip:", "sips:", "tftp:", "btspp://", "btl2cap://",
            "btgoep://", "tcpobex://", "irdaobex://", "file://", "urn:epc:id:",
            "urn:epc:tag:", "urn:epc:pat:", "urn:epc:raw:", "urn:epc:",
            "urn:nfc:"
        )
        
        val prefix = if (uriIdentifier < uriPrefixes.size) uriPrefixes[uriIdentifier] else ""
        val uri = String(payload, 1, payload.size - 1, Charset.forName("UTF-8"))
        
        return prefix + uri
    }

    /**
     * Extracts raw data from various NFC technologies
     */
    private fun extractRawData(tag: Tag): String {
        val dataBuilder = StringBuilder()
        
        // Try to read from different technologies
        tag.techList.forEach { tech ->
            when (tech) {
                MifareClassic::class.java.name -> {
                    dataBuilder.append("MifareClassic Data: ")
                    dataBuilder.append(readMifareClassic(tag))
                    dataBuilder.append("\n")
                }
                MifareUltralight::class.java.name -> {
                    dataBuilder.append("MifareUltralight Data: ")
                    dataBuilder.append(readMifareUltralight(tag))
                    dataBuilder.append("\n")
                }
                IsoDep::class.java.name -> {
                    dataBuilder.append("IsoDep Data: ")
                    dataBuilder.append(readIsoDep(tag))
                    dataBuilder.append("\n")
                }
                NfcA::class.java.name -> {
                    dataBuilder.append("NfcA Data: ")
                    dataBuilder.append(readNfcA(tag))
                    dataBuilder.append("\n")
                }
                NfcB::class.java.name -> {
                    dataBuilder.append("NfcB Data: ")
                    dataBuilder.append(readNfcB(tag))
                    dataBuilder.append("\n")
                }
            }
        }
        
        return dataBuilder.toString().trim()
    }

    /**
     * Reads Mifare Classic data
     */
    private fun readMifareClassic(tag: Tag): String {
        return try {
            val mifareClassic = MifareClassic.get(tag)
            mifareClassic?.connect()
            val sectorCount = mifareClassic?.sectorCount ?: 0
            val blockCount = mifareClassic?.blockCount ?: 0
            val size = mifareClassic?.size ?: 0
            val type = when (mifareClassic?.type) {
                MifareClassic.TYPE_CLASSIC -> "Classic"
                MifareClassic.TYPE_PLUS -> "Plus"
                MifareClassic.TYPE_PRO -> "Pro"
                else -> "Unknown"
            }
            mifareClassic?.close()
            "Type: $type, Sectors: $sectorCount, Blocks: $blockCount, Size: $size bytes"
        } catch (e: Exception) {
            "Error reading MifareClassic: ${e.message}"
        }
    }

    /**
     * Reads Mifare Ultralight data
     */
    private fun readMifareUltralight(tag: Tag): String {
        return try {
            val mifareUltralight = MifareUltralight.get(tag)
            mifareUltralight?.connect()
            val type = when (mifareUltralight?.type) {
                MifareUltralight.TYPE_ULTRALIGHT -> "Ultralight"
                MifareUltralight.TYPE_ULTRALIGHT_C -> "Ultralight C"
                else -> "Unknown"
            }
            // Read first few pages
            val pages = StringBuilder()
            for (i in 0..3) {
                try {
                    val page = mifareUltralight?.readPages(i)
                    page?.let { pages.append("Page $i: ${bytesToHex(it)}\n") }
                } catch (e: Exception) {
                    break
                }
            }
            mifareUltralight?.close()
            "Type: $type\n$pages"
        } catch (e: Exception) {
            "Error reading MifareUltralight: ${e.message}"
        }
    }

    /**
     * Reads ISO-DEP data
     */
    private fun readIsoDep(tag: Tag): String {
        return try {
            val isoDep = IsoDep.get(tag)
            isoDep?.connect()
            val historicalBytes = isoDep?.historicalBytes
            val hiLayerResponse = isoDep?.hiLayerResponse
            isoDep?.close()
            
            val result = StringBuilder()
            historicalBytes?.let { result.append("Historical Bytes: ${bytesToHex(it)}\n") }
            hiLayerResponse?.let { result.append("Hi Layer Response: ${bytesToHex(it)}\n") }
            result.toString()
        } catch (e: Exception) {
            "Error reading IsoDep: ${e.message}"
        }
    }

    /**
     * Reads NFC-A data
     */
    private fun readNfcA(tag: Tag): String {
        return try {
            val nfcA = NfcA.get(tag)
            nfcA?.connect()
            val atqa = nfcA?.atqa
            val sak = nfcA?.sak
            nfcA?.close()
            
            "ATQA: ${atqa?.let { bytesToHex(it) } ?: "N/A"}, SAK: ${sak?.toString(16) ?: "N/A"}"
        } catch (e: Exception) {
            "Error reading NfcA: ${e.message}"
        }
    }

    /**
     * Reads NFC-B data
     */
    private fun readNfcB(tag: Tag): String {
        return try {
            val nfcB = NfcB.get(tag)
            nfcB?.connect()
            val applicationData = nfcB?.applicationData
            val protocolInfo = nfcB?.protocolInfo
            nfcB?.close()
            
            "App Data: ${applicationData?.let { bytesToHex(it) } ?: "N/A"}, Protocol Info: ${protocolInfo?.let { bytesToHex(it) } ?: "N/A"}"
        } catch (e: Exception) {
            "Error reading NfcB: ${e.message}"
        }
    }

    /**
     * Data class for NDEF information
     */
    private data class NdefInfo(
        val isNdefFormattable: Boolean = false,
        val maxSize: Int = 0,
        val isWritable: Boolean = false,
        val canMakeReadOnly: Boolean = false,
        val ndefType: String = "",
        val ndefUsedSize: Int = 0
    )

    /**
     * Data class for detailed tag information
     */
    private data class DetailedTagInfo(
        val tagSize: Int = 0,
        val sectorCount: Int = 0,
        val blockCount: Int = 0,
        val pageCount: Int = 0,
        val atqa: String = "",
        val sak: String = "",
        val applicationData: String = "",
        val protocolInfo: String = "",
        val historicalBytes: String = "",
        val hiLayerResponse: String = "",
        val manufacturer: String = "",
        val isConnected: Boolean = false,
        val timeout: Int = 0
    )

    /**
     * Gets NDEF information from the tag
     */
    private fun getNdefInfo(tag: Tag): NdefInfo {
        var isNdefFormattable = false
        var maxSize = 0
        var isWritable = false
        var canMakeReadOnly = false
        var ndefType = ""
        var ndefUsedSize = 0

        if (tag.techList.contains(Ndef::class.java.name)) {
            try {
                val ndef = Ndef.get(tag)
                ndef?.connect()
                maxSize = ndef?.maxSize ?: 0
                isWritable = ndef?.isWritable ?: false
                canMakeReadOnly = ndef?.canMakeReadOnly() ?: false
                ndefType = ndef?.type ?: ""
                
                // Calculate used size from NDEF message
                val ndefMessage = ndef?.ndefMessage
                ndefUsedSize = ndefMessage?.toByteArray()?.size ?: 0
                
                ndef?.close()
            } catch (e: Exception) {
                // Handle silently
            }
        }

        if (tag.techList.contains(NdefFormatable::class.java.name)) {
            isNdefFormattable = true
        }

        return NdefInfo(
            isNdefFormattable = isNdefFormattable,
            maxSize = maxSize,
            isWritable = isWritable,
            canMakeReadOnly = canMakeReadOnly,
            ndefType = ndefType,
            ndefUsedSize = ndefUsedSize
        )
    }

    /**
     * Gets detailed tag information from various technologies
     */
    private fun getDetailedTagInfo(tag: Tag): DetailedTagInfo {
        var tagSize = 0
        var sectorCount = 0
        var blockCount = 0
        var pageCount = 0
        var atqa = ""
        var sak = ""
        var applicationData = ""
        var protocolInfo = ""
        var historicalBytes = ""
        var hiLayerResponse = ""
        var manufacturer = ""
        var isConnected = false
        var timeout = 0

        // Get Mifare Classic info
        if (tag.techList.contains(MifareClassic::class.java.name)) {
            try {
                val mifareClassic = MifareClassic.get(tag)
                mifareClassic?.connect()
                sectorCount = mifareClassic?.sectorCount ?: 0
                blockCount = mifareClassic?.blockCount ?: 0
                tagSize = mifareClassic?.size ?: 0
                isConnected = mifareClassic?.isConnected ?: false
                mifareClassic?.close()
            } catch (e: Exception) {
                // Handle silently
            }
        }

        // Get Mifare Ultralight info
        if (tag.techList.contains(MifareUltralight::class.java.name)) {
            try {
                val mifareUltralight = MifareUltralight.get(tag)
                mifareUltralight?.connect()
                val type = mifareUltralight?.type ?: 0
                pageCount = when (type) {
                    MifareUltralight.TYPE_ULTRALIGHT -> 16
                    MifareUltralight.TYPE_ULTRALIGHT_C -> 48
                    else -> 0
                }
                isConnected = mifareUltralight?.isConnected ?: false
                mifareUltralight?.close()
            } catch (e: Exception) {
                // Handle silently
            }
        }

        // Get NFC-A info
        if (tag.techList.contains(NfcA::class.java.name)) {
            try {
                val nfcA = NfcA.get(tag)
                nfcA?.connect()
                atqa = nfcA?.atqa?.let { bytesToHex(it) } ?: ""
                sak = nfcA?.sak?.toString(16)?.uppercase() ?: ""
                isConnected = nfcA?.isConnected ?: false
                // NfcA does have timeout property
                timeout = nfcA?.timeout ?: 0
                nfcA?.close()
            } catch (e: Exception) {
                // Handle silently
            }
        }

        // Get NFC-B info
        if (tag.techList.contains(NfcB::class.java.name)) {
            try {
                val nfcB = NfcB.get(tag)
                nfcB?.connect()
                applicationData = nfcB?.applicationData?.let { bytesToHex(it) } ?: ""
                protocolInfo = nfcB?.protocolInfo?.let { bytesToHex(it) } ?: ""
                isConnected = nfcB?.isConnected ?: false
                nfcB?.close()
            } catch (e: Exception) {
                // Handle silently
            }
        }

        // Get ISO-DEP info
        if (tag.techList.contains(IsoDep::class.java.name)) {
            try {
                val isoDep = IsoDep.get(tag)
                isoDep?.connect()
                historicalBytes = isoDep?.historicalBytes?.let { bytesToHex(it) } ?: ""
                hiLayerResponse = isoDep?.hiLayerResponse?.let { bytesToHex(it) } ?: ""
                isConnected = isoDep?.isConnected ?: false
                // IsoDep does have timeout property
                if (timeout == 0) { // Only set if not already set by NfcA
                    timeout = isoDep?.timeout ?: 0
                }
                isoDep?.close()
            } catch (e: Exception) {
                // Handle silently
            }
        }

        // Determine manufacturer from tag ID
        manufacturer = determineManufacturer(tag.id)

        return DetailedTagInfo(
            tagSize = tagSize,
            sectorCount = sectorCount,
            blockCount = blockCount,
            pageCount = pageCount,
            atqa = atqa,
            sak = sak,
            applicationData = applicationData,
            protocolInfo = protocolInfo,
            historicalBytes = historicalBytes,
            hiLayerResponse = hiLayerResponse,
            manufacturer = manufacturer,
            isConnected = isConnected,
            timeout = timeout
        )
    }

    /**
     * Determines manufacturer from tag ID
     */
    private fun determineManufacturer(tagId: ByteArray): String {
        if (tagId.isEmpty()) return "Unknown"
        
        val firstByte = tagId[0].toInt() and 0xFF
        return when (firstByte) {
            0x04 -> "NXP Semiconductors"
            0x02 -> "STMicroelectronics"
            0x05 -> "Infineon Technologies"
            0x01 -> "Motorola"
            0x03 -> "Hitachi"
            else -> "Unknown (0x${firstByte.toString(16).uppercase()})"
        }
    }

    /**
     * Determines the tag type based on available technologies
     */
    private fun determineTagType(tag: Tag): String {
        return when {
            tag.techList.contains(MifareClassic::class.java.name) -> "Mifare Classic"
            tag.techList.contains(MifareUltralight::class.java.name) -> "Mifare Ultralight"
            tag.techList.contains(IsoDep::class.java.name) -> "ISO 14443-4 (ISO-DEP)"
            tag.techList.contains(NfcA::class.java.name) -> "NFC-A (ISO 14443-3A)"
            tag.techList.contains(NfcB::class.java.name) -> "NFC-B (ISO 14443-3B)"
            tag.techList.contains(NfcF::class.java.name) -> "NFC-F (JIS 6319-4)"
            tag.techList.contains(NfcV::class.java.name) -> "NFC-V (ISO 15693)"
            else -> "Unknown"
        }
    }

    /**
     * Converts byte array to hex string
     */
    private fun bytesToHex(bytes: ByteArray): String {
        return bytes.joinToString("") { "%02X".format(it) }
    }
}
