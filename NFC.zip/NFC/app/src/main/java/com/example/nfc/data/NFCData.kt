package com.example.nfc.data

/**
 * Data class representing NFC tag information
 */
data class NFCTagData(
    val id: String = "",
    val techList: List<String> = emptyList(),
    val ndefMessages: List<NFCMessage> = emptyList(),
    val rawData: String = "",
    val tagType: String = "Unknown",
    val isNdefFormattable: Boolean = false,
    val maxSize: Int = 0,
    val isWritable: Boolean = false,
    val tagSize: Int = 0,
    val sectorCount: Int = 0,
    val blockCount: Int = 0,
    val pageCount: Int = 0,
    val atqa: String = "",
    val sak: String = "",
    val applicationData: String = "",
    val protocolInfo: String = "",
    val historicalBytes: String = "",
    val hiLayerResponse: String = "",
    val manufacturer: String = "",
    val isConnected: Boolean = false,
    val timeout: Int = 0,
    val canMakeReadOnly: Boolean = false,
    val ndefType: String = "",
    val ndefUsedSize: Int = 0
)

/**
 * Data class representing an NDEF message
 */
data class NFCMessage(
    val records: List<NFCRecord> = emptyList()
)

/**
 * Data class representing an NDEF record
 */
data class NFCRecord(
    val type: String = "",
    val payload: String = "",
    val id: String = "",
    val tnf: Short = 0,
    val mimeType: String = ""
)

/**
 * Enum for different NFC reading states
 */
enum class NFCReadState {
    IDLE,
    READING,
    SUCCESS,
    ERROR
}
