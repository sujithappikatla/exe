package com.example.nfc

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nfc.data.NFCReadState
import com.example.nfc.data.NFCTagData
import com.example.nfc.ui.theme.NFCTheme
import com.example.nfc.utils.NFCReader

class MainActivity : ComponentActivity() {
    
    private var nfcAdapter: NfcAdapter? = null
    private var pendingIntent: PendingIntent? = null
    private var intentFilters: Array<IntentFilter>? = null
    
    // State for NFC data
    private var nfcTagData by mutableStateOf<NFCTagData?>(null)
    private var readState by mutableStateOf(NFCReadState.IDLE)
    private var errorMessage by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Initialize NFC
        initializeNFC()
        
        setContent {
            NFCTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NFCReaderScreen(
                        nfcTagData = nfcTagData,
                        readState = readState,
                        errorMessage = errorMessage,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
        
        // Handle intent if app was launched by NFC
        handleIntent(intent)
    }
    
    private fun initializeNFC() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not available on this device", Toast.LENGTH_LONG).show()
            return
        }
        
        if (!nfcAdapter!!.isEnabled) {
            Toast.makeText(this, "NFC is disabled. Please enable it in settings", Toast.LENGTH_LONG).show()
        }
        
        // Create pending intent
        pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_MUTABLE
        )
        
        // Setup intent filters
        val ndefFilter = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED)
        val tagFilter = IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED)
        val techFilter = IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED)
        
        intentFilters = arrayOf(ndefFilter, tagFilter, techFilter)
    }
    
    override fun onResume() {
        super.onResume()
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, intentFilters, null)
    }
    
    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }
    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }
    
    private fun handleIntent(intent: Intent) {
        val action = intent.action
        if (NfcAdapter.ACTION_NDEF_DISCOVERED == action ||
            NfcAdapter.ACTION_TAG_DISCOVERED == action ||
            NfcAdapter.ACTION_TECH_DISCOVERED == action) {
            
            val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
            tag?.let {
                readNFCTag(it)
            }
        }
    }
    
    private fun readNFCTag(tag: Tag) {
        readState = NFCReadState.READING
        errorMessage = ""
        
        try {
            val tagData = NFCReader.readTag(tag)
            nfcTagData = tagData
            readState = NFCReadState.SUCCESS
        } catch (e: Exception) {
            errorMessage = "Error reading NFC tag: ${e.message}"
            readState = NFCReadState.ERROR
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NFCReaderScreen(
    nfcTagData: NFCTagData?,
    readState: NFCReadState,
    errorMessage: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Contactless,
                    contentDescription = "NFC",
                    modifier = Modifier.size(32.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "NFC Reader",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Status indicator
        when (readState) {
            NFCReadState.IDLE -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Contactless,
                            contentDescription = "Ready",
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Ready to scan",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Hold your NFC card near the device",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            
            NFCReadState.READING -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Reading NFC tag...",
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                }
            }
            
            NFCReadState.ERROR -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Error",
                            modifier = Modifier.size(32.dp),
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Error",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
            
            NFCReadState.SUCCESS -> {
                // Show NFC data
                nfcTagData?.let { data ->
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Summary Card
                        item {
                            NFCDataCard(
                                title = "📋 Quick Summary",
                                content = buildString {
                                    append("Type: ${data.tagType}\n")
                                    if (data.manufacturer.isNotEmpty()) {
                                        append("Manufacturer: ${data.manufacturer}\n")
                                    }
                                    if (data.maxSize > 0) {
                                        append("NDEF Capacity: ${data.ndefUsedSize}/${data.maxSize} bytes\n")
                                    }
                                    append("Writable: ${if (data.isWritable) "✅ Yes" else "❌ No"}\n")
                                    append("Technologies: ${data.techList.size}")
                                }
                            )
                        }
                        
                        // Tag ID
                        item {
                            NFCDataCard(
                                title = "Tag ID",
                                content = data.id.ifEmpty { "N/A" }
                            )
                        }
                        
                        // Tag Type
                        item {
                            NFCDataCard(
                                title = "Tag Type",
                                content = data.tagType
                            )
                        }
                        
                        // Technologies
                        item {
                            NFCDataCard(
                                title = "Supported Technologies",
                                content = data.techList.joinToString("\n") { it.substringAfterLast('.') }
                            )
                        }
                        
                        // Manufacturer Info
                        if (data.manufacturer.isNotEmpty()) {
                            item {
                                NFCDataCard(
                                    title = "Manufacturer",
                                    content = data.manufacturer
                                )
                            }
                        }
                        
                        // NDEF Info
                        item {
                            NFCDataCard(
                                title = "NDEF Information",
                                content = buildString {
                                    append("Max Size: ${if (data.maxSize > 0) "${data.maxSize} bytes" else "Unknown"}\n")
                                    append("Used Size: ${if (data.ndefUsedSize > 0) "${data.ndefUsedSize} bytes" else "0 bytes"}\n")
                                    append("Available: ${if (data.maxSize > 0 && data.ndefUsedSize >= 0) "${data.maxSize - data.ndefUsedSize} bytes" else "Unknown"}\n")
                                    append("Writable: ${if (data.isWritable) "Yes" else "No"}\n")
                                    append("NDEF Formattable: ${if (data.isNdefFormattable) "Yes" else "No"}\n")
                                    append("Can Make Read-Only: ${if (data.canMakeReadOnly) "Yes" else "No"}\n")
                                    if (data.ndefType.isNotEmpty()) {
                                        append("NDEF Type: ${data.ndefType}\n")
                                    }
                                    append("Has NDEF Data: ${if (data.ndefMessages.isNotEmpty()) "Yes" else "No"}")
                                }
                            )
                        }
                        
                        // Physical Properties
                        if (data.tagSize > 0 || data.sectorCount > 0 || data.blockCount > 0 || data.pageCount > 0) {
                            item {
                                NFCDataCard(
                                    title = "Physical Properties",
                                    content = buildString {
                                        if (data.tagSize > 0) {
                                            append("Total Size: ${data.tagSize} bytes\n")
                                        }
                                        if (data.sectorCount > 0) {
                                            append("Sectors: ${data.sectorCount}\n")
                                        }
                                        if (data.blockCount > 0) {
                                            append("Blocks: ${data.blockCount}\n")
                                        }
                                        if (data.pageCount > 0) {
                                            append("Pages: ${data.pageCount}\n")
                                        }
                                        if (data.timeout > 0) {
                                            append("Timeout: ${data.timeout}ms")
                                        }
                                    }.trimEnd('\n')
                                )
                            }
                        }
                        
                        // Protocol Information
                        if (data.atqa.isNotEmpty() || data.sak.isNotEmpty() || data.applicationData.isNotEmpty() || 
                            data.protocolInfo.isNotEmpty() || data.historicalBytes.isNotEmpty() || data.hiLayerResponse.isNotEmpty()) {
                            item {
                                NFCDataCard(
                                    title = "Protocol Information",
                                    content = buildString {
                                        if (data.atqa.isNotEmpty()) {
                                            append("ATQA: ${data.atqa}\n")
                                        }
                                        if (data.sak.isNotEmpty()) {
                                            append("SAK: ${data.sak}\n")
                                        }
                                        if (data.applicationData.isNotEmpty()) {
                                            append("Application Data: ${data.applicationData}\n")
                                        }
                                        if (data.protocolInfo.isNotEmpty()) {
                                            append("Protocol Info: ${data.protocolInfo}\n")
                                        }
                                        if (data.historicalBytes.isNotEmpty()) {
                                            append("Historical Bytes: ${data.historicalBytes}\n")
                                        }
                                        if (data.hiLayerResponse.isNotEmpty()) {
                                            append("Hi Layer Response: ${data.hiLayerResponse}")
                                        }
                                    }.trimEnd('\n')
                                )
                            }
                        }
                        
                        // NDEF Messages
                        if (data.ndefMessages.isNotEmpty()) {
                            items(data.ndefMessages.withIndex().toList()) { (index, message) ->
                                NFCDataCard(
                                    title = "NDEF Message ${index + 1}",
                                    content = buildString {
                                        message.records.forEachIndexed { recordIndex, record ->
                                            append("Record ${recordIndex + 1}:\n")
                                            append("  Type: ${record.type}\n")
                                            append("  Payload: ${record.payload}\n")
                                            if (record.id.isNotEmpty()) {
                                                append("  ID: ${record.id}\n")
                                            }
                                            append("  TNF: ${record.tnf}\n")
                                            if (record.mimeType.isNotEmpty()) {
                                                append("  MIME Type: ${record.mimeType}\n")
                                            }
                                            append("\n")
                                        }
                                    }
                                )
                            }
                        }
                        
                        // Raw Data
                        if (data.rawData.isNotEmpty()) {
                            item {
                                NFCDataCard(
                                    title = "Raw Data",
                                    content = data.rawData
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NFCDataCard(
    title: String,
    content: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = content,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(4.dp)
                    )
                    .padding(8.dp)
                    .fillMaxWidth()
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun NFCReaderScreenPreview() {
    NFCTheme {
        NFCReaderScreen(
            nfcTagData = null,
            readState = NFCReadState.IDLE,
            errorMessage = "",
            modifier = Modifier.padding(16.dp)
        )
    }
}