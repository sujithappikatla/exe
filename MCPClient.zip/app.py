import json
import streamlit as st
import logging
import asyncio
import threading
from typing import Dict, Any, List

# Import our modules
from mcp_client import MCPClient
from llm_client import OpenAIClient
import ui_components as ui
from utils import run_async, handle_connection_config, parse_tool_arguments, format_tool_result

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set page config
st.set_page_config(
    page_title="MCP Client",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Initialize session state variables
if "initialized" not in st.session_state:
    st.session_state.initialized = True
    st.session_state.connected = False
    st.session_state.mcp_client = None
    st.session_state.llm_client = None
    st.session_state.available_tools = []
    st.session_state.server_info = None
    st.session_state.tool_call = None
    st.session_state.tool_result = None
    st.session_state.conversation_counter = 0

# Function to connect to MCP server
def connect_to_mcp_server(connection_config: Dict[str, Any]):
    """Connect to an MCP server based on the connection configuration."""
    connection_type = connection_config["type"]
    
    try:
        # Create MCP client if it doesn't exist
        if st.session_state.mcp_client is None:
            st.session_state.mcp_client = MCPClient()
        else:
            # Clean up existing client
            run_async(st.session_state.mcp_client.cleanup())
        
        # Connect to the server based on connection type
        if connection_type == "stdio":
            run_async(st.session_state.mcp_client.connect_stdio(
                connection_config["command"], 
                connection_config["args"],
                connection_config.get("env")
            ))
        elif connection_type == "SSE":
            run_async(st.session_state.mcp_client.connect_sse(
                connection_config["url"]
            ))
        elif connection_type == "HTTP Streaming":
            run_async(st.session_state.mcp_client.connect_http_streaming(
                connection_config["url"]
            ))
        
        # Get available tools
        st.session_state.available_tools = st.session_state.mcp_client.available_tools
        st.session_state.connected = True
        
        # Add server connection message to chat
        ui.add_message(
            "system", 
            f"Connected to MCP server ({connection_type}) with {len(st.session_state.available_tools)} tools available."
        )
        
        return True
    except Exception as e:
        logger.error(f"Failed to connect to MCP server: {e}")
        st.error(f"Failed to connect to MCP server: {str(e)}")
        st.session_state.connected = False
        return False

# Function to handle user messages
def handle_user_message(message: str):
    """Process user messages and interact with MCP tools."""
    if not message:
        return
    
    # First, add user message to chat
    ui.add_message("user", message)
    
    # Get tool schemas for OpenAI
    tools = None
    if st.session_state.connected and st.session_state.mcp_client:
        tools = st.session_state.mcp_client.get_tool_schemas()
    
    # Generate response from OpenAI
    try:
        response_text, tool_call = st.session_state.llm_client.generate_response(
            message, tools
        )
        
        # If no tool call, just display the response
        if not tool_call:
            ui.add_message("assistant", response_text)
            return
        
        # Store the tool call for display
        st.session_state.tool_call = tool_call
        
        # Call the MCP tool
        if st.session_state.connected and st.session_state.mcp_client:
            tool_name = tool_call["tool_name"]
            arguments = parse_tool_arguments(tool_call["arguments"])
            
            # Before calling the tool, verify MCP connection is still active
            if not hasattr(st.session_state.mcp_client, 'session') or st.session_state.mcp_client.session is None:
                logger.error("MCP client session is not active")
                ui.add_message(
                    "system", 
                    "Error: MCP server connection is not active. Please reconnect."
                )
                st.session_state.connected = False
                return

            # Verify the tool exists on the server
            available_tool_names = [tool.name for tool in st.session_state.available_tools]
            if tool_name not in available_tool_names:
                logger.error(f"Tool '{tool_name}' not found in available tools: {available_tool_names}")
                ui.add_message(
                    "system", 
                    f"Error: Tool '{tool_name}' not found on the MCP server. Available tools: {', '.join(available_tool_names)}"
                )
                return
            
            # Verify the tool is available and can be called
            tool_verified = run_async(
                st.session_state.mcp_client.verify_tool_call(tool_name)
            )
            
            if not tool_verified:
                logger.error(f"Tool '{tool_name}' verification failed")
                ui.add_message(
                    "system", 
                    f"Error: Tool '{tool_name}' verification failed. The tool might not be properly registered or accessible."
                )
                return
            
            # Display the tool call in the UI
            ui.add_message(
                "assistant", 
                f"I'll use the {tool_name} tool to help with this."
            )
            
            try:
                # Call the tool
                logger.info(f"About to execute tool call for '{tool_name}'")
                tool_result = run_async(
                    st.session_state.mcp_client.call_tool(tool_name, arguments)
                )
                logger.info(f"Tool call executed successfully, processing result: {tool_result}")
                
                # Format and store the result
                formatted_result = format_tool_result(tool_result)
                st.session_state.tool_result = formatted_result
                
                # Add tool result to chat
                ui.add_message("tool", formatted_result)
                
                # Generate final response with tool result
                logger.info("Generating final response with tool result")
                final_response, _ = st.session_state.llm_client.generate_response(
                    "", tools, formatted_result
                )
                
                # Add final response to chat
                ui.add_message("assistant", final_response)
                
            except Exception as e:
                logger.error(f"Error calling MCP tool: {e}", exc_info=True)
                ui.add_message(
                    "system", 
                    f"Error calling tool {tool_name}: {str(e)}"
                )
                # Try to continue with a direct response
                try:
                    fallback_response, _ = st.session_state.llm_client.generate_response(
                        f"The tool call to {tool_name} failed with error: {str(e)}. Please provide a response without using the tool.",
                        None
                    )
                    ui.add_message("assistant", fallback_response)
                except Exception as fallback_e:
                    logger.error(f"Fallback response also failed: {fallback_e}")
                    ui.add_message("assistant", "I apologize, but I couldn't complete the tool call and also couldn't generate a fallback response.")
    except Exception as e:
        logger.error(f"Error generating response: {e}")
        ui.add_message("system", f"Error: {str(e)}")
        # Try fallback to simple chat without tools
        if tools:
            try:
                logger.info("Trying fallback to chat without tools")
                response_text, _ = st.session_state.llm_client.generate_response(
                    message, None
                )
                ui.add_message("assistant", response_text)
            except Exception as fallback_e:
                logger.error(f"Fallback also failed: {fallback_e}")
                ui.add_message("system", "Could not generate a response even without tools.")

def main():
    """Main application function."""
    st.title("🤖 MCP Client")
    
    # Display sidebar controls
    sidebar_config = ui.display_sidebar_controls()
    
    # Display server info
    ui.display_server_info(
        st.session_state.connected,
        st.session_state.server_info,
        st.session_state.available_tools
    )
    
    # Handle connection button
    if sidebar_config["connect_button"]:
        # Validate connection config
        try:
            connection_config = handle_connection_config(
                sidebar_config["connection_type"],
                sidebar_config["server_config"]
            )
            
            # Connect to MCP server
            if connect_to_mcp_server(connection_config):
                # Initialize OpenAI client
                st.session_state.llm_client = OpenAIClient(
                    api_key=sidebar_config["openai_api_key"] if sidebar_config["openai_api_key"] else None
                )
                
                # Set the model
                st.session_state.llm_client.set_model(sidebar_config["openai_model"])
                
                st.rerun()
        except ValueError as e:
            st.error(str(e))
    
    # Display chat interface
    user_input = ui.display_chat_interface()
    
    # Handle user input
    if user_input:
        handle_user_message(user_input)
        st.session_state.conversation_counter += 1
        st.rerun()
    
    # Display a connection reminder if not connected
    if not st.session_state.connected:
        st.info("👈 Configure and connect to an MCP server to start chatting")

if __name__ == "__main__":
    main() 