#!/usr/bin/env python3
import asyncio
import logging
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# Set up logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("mcp-simple")

async def main():
    if len(sys.argv) < 2:
        print("Usage: python mcp_simple.py <mcp_server_script.py>")
        return
    
    server_script = sys.argv[1]
    
    print(f"Connecting to MCP server: python {server_script}")
    
    server_params = StdioServerParameters(
        command="python",
        args=[server_script],
    )
    
    try:
        # Start the server and get communication streams
        async with stdio_client(server_params) as (read_stream, write_stream):
            print("Connected to MCP server streams")
            
            # Create session
            async with ClientSession(read_stream, write_stream) as session:
                print("Session created")
                
                # Initialize
                await session.initialize()
                print("Session initialized")
                
                # List tools
                tools_response = await session.list_tools()
                tools = tools_response.tools
                
                print(f"Available tools: {[tool.name for tool in tools]}")
                
                # Interactive mode
                if tools:
                    # Just call the first tool as a test
                    test_tool = tools[0]
                    print(f"Testing tool: {test_tool.name}")
                    
                    # Call the tool (this will depend on the tool's required arguments)
                    # For a notes app, try adding a note
                    if test_tool.name == "add_note":
                        result = await session.call_tool(test_tool.name, {
                            "note": "Test note from simple client",
                            "category": "Test"
                        })
                    elif test_tool.name == "list_notes":
                        result = await session.call_tool(test_tool.name, {})
                    else:
                        # Generic approach for other tools
                        result = await session.call_tool(test_tool.name, {})
                    
                    print(f"Tool result: {result.content}")
                
                print("Test completed successfully")
    
    except Exception as e:
        logger.error(f"Error: {e}")
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main()) 