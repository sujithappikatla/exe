import json
import logging
from typing import Dict, Any, Optional
import asyncio
import nest_asyncio

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Apply nest_asyncio to allow asyncio in Streamlit
nest_asyncio.apply()

def parse_tool_arguments(arguments_str: str) -> Dict[str, Any]:
    """Parse tool call arguments from string to dictionary.
    
    Args:
        arguments_str: JSON string of arguments
    
    Returns:
        Dictionary of parsed arguments
    """
    try:
        return json.loads(arguments_str)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse arguments: {e}")
        return {}

def format_tool_result(result: Any) -> str:
    """Format tool result for display and LLM consumption.
    
    Args:
        result: The result from tool execution
    
    Returns:
        Formatted result as string
    """
    if hasattr(result, 'content'):
        # Format MCP tool result
        content_list = result.content
        formatted_content = []
        
        for item in content_list:
            if hasattr(item, 'text'):
                formatted_content.append(item.text)
            elif isinstance(item, dict) and 'text' in item:
                formatted_content.append(item['text'])
            else:
                formatted_content.append(str(item))
        
        return "\n".join(formatted_content)
    
    # If result is not from MCP, try to serialize as JSON
    try:
        return json.dumps(result, indent=2)
    except (TypeError, json.JSONDecodeError):
        return str(result)

def run_async(coro):
    """Run an asyncio coroutine in a synchronous context.
    
    Args:
        coro: Asyncio coroutine to run
    
    Returns:
        Result of the coroutine
    """
    try:
        logger.info(f"Starting async operation: {coro.__qualname__ if hasattr(coro, '__qualname__') else str(coro)}")
        loop = asyncio.get_event_loop()
        result = loop.run_until_complete(coro)
        logger.info("Async operation completed successfully")
        return result
    except RuntimeError as e:
        if "This event loop is already running" in str(e):
            # We're in a running event loop (likely in IPython or Jupyter)
            # This shouldn't happen in Streamlit since we apply nest_asyncio
            logger.warning("Detected running event loop, creating new loop")
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            try:
                result = new_loop.run_until_complete(coro)
                return result
            except Exception as inner_e:
                logger.error(f"Error in async operation with new loop: {inner_e}")
                raise
            finally:
                new_loop.close()
                logger.info("New event loop closed")
        else:
            logger.error(f"Runtime error in async operation: {e}")
            raise
    except Exception as e:
        logger.error(f"Error in async operation: {e}")
        raise

def handle_connection_config(connection_type: str, server_config: Dict) -> Dict:
    """Validate and prepare connection configuration.
    
    Args:
        connection_type: Connection type (stdio, SSE, HTTP Streaming)
        server_config: Server configuration
    
    Returns:
        Validated configuration dict
    """
    config = {"type": connection_type}
    
    if connection_type == "stdio":
        # Validate stdio config
        if not server_config.get("command"):
            raise ValueError("Command is required for stdio connection")
        if not server_config.get("args"):
            raise ValueError("At least one argument is required for stdio connection")
        
        config.update({
            "command": server_config["command"],
            "args": server_config["args"],
            "env": server_config.get("env", {})
        })
    else:
        # Validate URL config
        if not server_config.get("url"):
            raise ValueError(f"URL is required for {connection_type} connection")
        
        config["url"] = server_config["url"]
    
    return config 