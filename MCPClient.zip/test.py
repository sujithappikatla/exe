from mcp.server.fastmcp import FastMCP
import os
import uuid
import json
import logging

# Set up logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("mcp-server")

# Create FastMCP instance
mcp = FastMCP("Notes App")

NOTEFILE_PATH = os.path.join(os.path.dirname(__file__), "notes.json")


def ensure_note_file():
    if not os.path.exists(NOTEFILE_PATH):
        with open(NOTEFILE_PATH, "w") as f:
            f.write("[]")


@mcp.tool()
def add_note(note: str, category: str) -> str:
    """
    Add a new note to the notes file.

    Args:
        note (str): The note to add.
        category (str): The category of the note.

    Returns:
        str: A message indicating that the note was added.
    """    
    logger.debug(f"Adding note: {note} in category: {category}")
    ensure_note_file()

    note_id = uuid.uuid4().hex
    new_note = {
        "note_id": note_id,
        "note": note,
        "category": category,
    }
    with open(NOTEFILE_PATH, "r") as f:
        notes = json.load(f)
    notes.append(new_note)
    with open(NOTEFILE_PATH, "w") as f:
        json.dump(notes, f, indent=4)
    logger.debug(f"Note added with ID: {note_id}")
    return f"Note added Succesfully with id: {note_id}"


@mcp.tool()
def list_notes() -> str:
    """
    List all notes in the notes file.

    Returns:
        str: A message listing all notes.
    """
    logger.debug("Listing all notes")
    ensure_note_file()
    with open(NOTEFILE_PATH, "r") as f:
        notes = json.load(f)

    notes.sort(key=lambda note: note['note_id'])
    result = "\n".join([f"Note ID: {note['note_id']} Category: {note['category']} Note : {note['note']} " for note in notes])
    logger.debug(f"Found {len(notes)} notes")
    return result


@mcp.tool()
def delete_note(note_id: str) -> str:
    """
    Delete a note from the notes file.

    Args:
        note_id (str): The note id to delete.

    Returns:
        str: A message indicating that the note was deleted.
    """
    logger.debug(f"Deleting note with ID: {note_id}")
    ensure_note_file()
    with open(NOTEFILE_PATH, "r") as f:
        notes = json.load(f)
    original_count = len(notes)
    notes = [note for note in notes if note['note_id'] != note_id]
    with open(NOTEFILE_PATH, "w") as f:
        json.dump(notes, f, indent=4)
    logger.debug(f"Deleted {original_count - len(notes)} notes")
    return f"Note deleted Succesfully"


if __name__ == "__main__":
    logger.info("Starting MCP Notes App Server")
    try:
        mcp.run()
    except Exception as e:
        logger.error(f"Error running MCP server: {e}")
        import traceback
        traceback.print_exc()


