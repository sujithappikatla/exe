import json
import streamlit as st
from typing import Dict, List, Any

def display_sidebar_controls():
    """Display sidebar controls for MCP server configuration and model settings."""
    with st.sidebar:
        st.title("MCP Client Configuration")
        
        # Connection type selection
        connection_type = st.selectbox(
            "Connection Type",
            ["stdio", "SSE", "HTTP Streaming"],
            index=0,
            help="Select the MCP server transport type"
        )
        
        server_config = {}
        
        if connection_type == "stdio":
            # stdio connection options
            st.subheader("stdio Connection")
            server_config["command"] = st.text_input(
                "Command",
                value="python",
                help="Command to execute the server (e.g., python, node)"
            )
            server_config["args"] = st.text_input(
                "Arguments",
                value="server.py",
                help="Arguments to pass to the command (space-separated)"
            ).split()
            
            # Optional environment variables
            with st.expander("Environment Variables"):
                env_vars = st.text_area(
                    "Environment Variables (JSON)",
                    value='{"KEY": "value"}',
                    help="JSON object with environment variables"
                )
                try:
                    server_config["env"] = json.loads(env_vars)
                except json.JSONDecodeError:
                    st.error("Invalid JSON for environment variables")
                    server_config["env"] = {}
        else:
            # SSE or HTTP Streaming connection options
            st.subheader(f"{connection_type} Connection")
            server_config["url"] = st.text_input(
                "Server URL",
                value="http://localhost:3000/mcp" if connection_type == "HTTP Streaming" else "http://localhost:3000/sse",
                help=f"URL for the {connection_type} endpoint"
            )
        
        # OpenAI model settings
        st.subheader("LLM Settings")
        openai_model = st.selectbox(
            "OpenAI Model",
            ["gpt-4o-mini", "gpt-3.5-turbo", "gpt-4o", "gpt-4"],
            index=0,
            help="Select the OpenAI model to use"
        )
        
        openai_api_key = st.text_input(
            "OpenAI API Key",
            type="password",
            help="Your OpenAI API key (leave empty to use environment variable)"
        )
        
        # Connect button
        connect_button = st.button("Connect to MCP Server")
        
        # Model name reminder
        st.info(f"Using model: {openai_model}")
    
    return {
        "connection_type": connection_type,
        "server_config": server_config,
        "openai_model": openai_model,
        "openai_api_key": openai_api_key,
        "connect_button": connect_button
    }

def display_server_info(connected: bool, server_info: Dict = None, available_tools: List = None):
    """Display MCP server information and available tools."""
    with st.sidebar:
        st.subheader("Server Status")
        
        if connected:
            st.success("✅ Connected")
            
            if server_info:
                st.text(f"Name: {server_info.get('name', 'Unknown')}")
                st.text(f"Version: {server_info.get('version', 'Unknown')}")
            
            if available_tools:
                with st.expander("Available Tools"):
                    for tool in available_tools:
                        st.write(f"**{tool.name}**")
                        if tool.description:
                            st.write(tool.description)
                        st.code(json.dumps(tool.inputSchema, indent=2), language="json")
        else:
            st.error("❌ Not Connected")

def display_chat_interface():
    """Display the chat interface."""
    # Initialize chat history if it doesn't exist
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    # Display chat messages
    for message in st.session_state.messages:
        role = message["role"]
        with st.chat_message(role):
            if role == "tool":
                st.info("Tool Call Result:")
                st.json(message["content"])
            else:
                st.write(message["content"])
    
    # Input for new messages
    user_input = st.chat_input("Enter your message...")
    
    return user_input

def display_tool_call(tool_call: Dict, tool_result: Any = None):
    """Display tool call information."""
    if not tool_call:
        return
    
    with st.expander("Tool Call Details", expanded=True):
        st.write(f"**Tool:** {tool_call['tool_name']}")
        
        # Display arguments
        st.write("**Arguments:**")
        try:
            args = json.loads(tool_call['arguments'])
            st.json(args)
        except:
            st.code(tool_call['arguments'])
        
        # Display result if available
        if tool_result is not None:
            st.write("**Result:**")
            st.json(tool_result)

def add_message(role: str, content: Any):
    """Add a message to the chat history."""
    st.session_state.messages.append({"role": role, "content": content})

def clear_chat():
    """Clear the chat history."""
    st.session_state.messages = [] 