# MCP Client

A Streamlit-based client application for interacting with Model Context Protocol (MCP) servers through OpenAI's LLM.

## Features

- Connect to MCP servers using three different transport types:
  - stdio (for local server processes)
  - Server-Sent Events (SSE)
  - HTTP Streaming
- Use OpenAI's chat completions API with MCP tools
- Interactive chat interface built with Streamlit
- Support for viewing available tools and server information
- Display of tool calls and their results in a user-friendly way
- Conversation history management

## Installation

1. Clone this repository:
   ```bash
   git clone <repository-url>
   cd <repository-directory>
   ```

2. Install the required packages:
   ```bash
   pip install mcp openai streamlit nest-asyncio
   ```

3. Set up your OpenAI API key:
   ```bash
   export OPENAI_API_KEY=your_api_key_here
   ```
   
   Or enter it in the application UI.

## Usage

1. Run the Streamlit application:
   ```bash
   streamlit run app.py
   ```

2. Configure the MCP server connection in the sidebar:
   - Choose connection type (stdio, SSE, or HTTP Streaming)
   - For stdio: provide the command and arguments to start the server
   - For SSE/HTTP Streaming: provide the server URL
   - Configure OpenAI settings (model, API key)

3. Click "Connect to MCP Server"

4. Once connected, start chatting with the LLM, which will use the available MCP tools as needed

## Connect to Different MCP Servers

### stdio Example (Local Python Server)

- Command: `python`
- Arguments: `path/to/server.py`

### SSE Example

- URL: `http://localhost:3000/sse`

### HTTP Streaming Example

- URL: `http://localhost:3000/mcp`

## Project Structure

- `app.py` - Main Streamlit application
- `mcp_client.py` - MCP client implementation
- `llm_client.py` - OpenAI client implementation
- `ui_components.py` - UI components for Streamlit
- `utils.py` - Utility functions

## Requirements

- Python 3.8+
- OpenAI API key
- MCP server to connect to

## License

MIT

## Resources

- [Model Context Protocol](https://modelcontextprotocol.io/)
- [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [OpenAI API Documentation](https://platform.openai.com/docs/api-reference)
- [Streamlit Documentation](https://docs.streamlit.io/)
