import asyncio
import logging
from typing import Dict, List, Optional, Tuple, Any
from contextlib import AsyncExitStack

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.client.sse import sse_client
from mcp.client.streamable_http import streamablehttp_client

# Set up logger
logger = logging.getLogger(__name__)

class MCPClient:
    """MCP Client that supports multiple transport types (stdio, SSE, HTTP Streaming)."""
    
    def __init__(self):
        """Initialize the MCP client."""
        self.session = None
        self.exit_stack = AsyncExitStack()
        self.available_tools = []
        self.transport_type = None
        self.server_info = None
    
    async def connect_stdio(self, command: str, args: List[str], env: Optional[Dict[str, str]] = None):
        """Connect to MCP server using stdio transport.
        
        Args:
            command: The command to execute the server (e.g., python, node)
            args: List of arguments to pass to the command
            env: Optional environment variables
        """
        server_params = StdioServerParameters(
            command=command,
            args=args,
            env=env
        )
        
        logger.info(f"Connecting to stdio MCP server with command: {command} {' '.join(args)}")
        
        # Start the server and get communication streams
        stdio_transport = await self.exit_stack.enter_async_context(stdio_client(server_params))
        self.read_stream, self.write_stream = stdio_transport
        
        # Create and initialize session
        self.session = await self.exit_stack.enter_async_context(
            ClientSession(self.read_stream, self.write_stream)
        )
        
        self.transport_type = "stdio"
        await self._initialize_session()
    
    async def connect_sse(self, url: str):
        """Connect to MCP server using SSE transport.
        
        Args:
            url: The URL of the SSE endpoint
        """
        logger.info(f"Connecting to SSE MCP server at {url}")
        
        # Create SSE client context
        sse_context = await self.exit_stack.enter_async_context(sse_client(url=url))
        self.read_stream, self.write_stream = sse_context
        
        # Create and initialize session
        self.session = await self.exit_stack.enter_async_context(
            ClientSession(self.read_stream, self.write_stream)
        )
        
        self.transport_type = "sse"
        await self._initialize_session()
    
    async def connect_http_streaming(self, url: str):
        """Connect to MCP server using HTTP Streaming transport.
        
        Args:
            url: The URL of the HTTP Streaming endpoint
        """
        logger.info(f"Connecting to HTTP Streaming MCP server at {url}")
        
        # Create HTTP Streaming client context
        http_context = await self.exit_stack.enter_async_context(streamablehttp_client(url))
        self.read_stream, self.write_stream, _ = http_context
        
        # Create and initialize session
        self.session = await self.exit_stack.enter_async_context(
            ClientSession(self.read_stream, self.write_stream)
        )
        
        self.transport_type = "http_streaming"
        await self._initialize_session()
    
    async def _initialize_session(self):
        """Initialize the session and get available tools."""
        if not self.session:
            raise RuntimeError("Client session is not initialized.")
            
        # Initialize the connection
        await self.session.initialize()
        
        # List available tools
        tools_response = await self.session.list_tools()
        self.available_tools = tools_response.tools
        
        logger.info(f"Connected to MCP Server ({self.transport_type}). "
                   f"Available tools: {[tool.name for tool in self.available_tools]}")
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]):
        """Call a tool on the MCP server.
        
        Args:
            tool_name: Name of the tool to call
            arguments: Arguments to pass to the tool
            
        Returns:
            Result of the tool call
        """
        if not self.session:
            raise RuntimeError("Client session is not initialized.")
            
        logger.info(f"Calling tool '{tool_name}' with arguments: {arguments}")
        
        try:
            # Validate the tool exists
            tool_exists = any(tool.name == tool_name for tool in self.available_tools)
            if not tool_exists:
                logger.error(f"Tool '{tool_name}' not found in available tools")
                raise ValueError(f"Tool '{tool_name}' not found in available tools")
            
            logger.info(f"Sending call_tool request to MCP server for '{tool_name}'")
            result = await self.session.call_tool(tool_name, arguments)
            logger.info(f"Received result from tool '{tool_name}': {result}")
            return result
        except Exception as e:
            logger.error(f"Error executing tool '{tool_name}': {e}")
            raise
    
    async def list_tools(self):
        """Get the list of available tools from the server."""
        if not self.session:
            raise RuntimeError("Client session is not initialized.")
            
        response = await self.session.list_tools()
        self.available_tools = response.tools
        return self.available_tools
    
    def get_tool_schemas(self):
        """Get the schemas for available tools in a format suitable for OpenAI."""
        return [{
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description or f"Tool: {tool.name}",
                "parameters": tool.inputSchema
            }
        } for tool in self.available_tools]
    
    async def cleanup(self):
        """Clean up resources."""
        await self.exit_stack.aclose()
        self.session = None
        logger.info("MCP Client resources cleaned up.")
    
    async def verify_tool_call(self, tool_name: str):
        """Verify that a tool can be called by checking if it exists and is callable.
        
        Args:
            tool_name: Name of the tool to verify
            
        Returns:
            Boolean indicating if the tool exists and is callable
        """
        if not self.session:
            logger.error("Client session is not initialized")
            return False
            
        # First check if the tool exists in available tools
        tool_exists = any(tool.name == tool_name for tool in self.available_tools)
        if not tool_exists:
            logger.error(f"Tool '{tool_name}' not found in available tools")
            return False
            
        # Get the tool definition
        tool = next(t for t in self.available_tools if t.name == tool_name)
        
        logger.info(f"Tool '{tool_name}' exists with schema: {tool.inputSchema}")
        return True 




client = None    


async def loop():
    global client
    counter = 0
    while True:
        print(client.get_tool_schemas())
        await asyncio.sleep(4)
        counter += 1
        if counter > 10:
            break


async def create_client():
    global client
    client = MCPClient()
    await client.connect_sse("http://localhost:8000/sse")


async def main():
    """Main function to connect, get schemas, and cleanup."""
    global client
    await create_client()
    try:
        print(client.get_tool_schemas())
        await loop()
    except Exception as e:
        print(e)
    finally:
        print("--------------------------------")
        if client:
            await client.cleanup()

if __name__ == "__main__":
    asyncio.run(main())