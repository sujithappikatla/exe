import logging
from typing import Dict, List, Tuple, Any

import openai

# Set up logger
logger = logging.getLogger(__name__)

class OpenAIClient:
    """OpenAI client for the MCP application."""
    
    def __init__(self, api_key: str = None):
        """Initialize the OpenAI client.
        
        Args:
            api_key: The OpenAI API key (optional if set in environment)
        """
        if api_key:
            self.client = openai.OpenAI(api_key=api_key)
        else:
            self.client = openai.OpenAI()  # Uses OPENAI_API_KEY environment variable
        
        self.model = "gpt-4o-mini"  # Default model
        self.conversation_history = []
    
    def set_model(self, model_name: str):
        """Set the model to use for chat completions.
        
        Args:
            model_name: Name of the OpenAI model
        """
        self.model = model_name
        logger.info(f"Set OpenAI model to {model_name}")
    
    def generate_response(
        self, 
        prompt: str, 
        tools: List[Dict] = None, 
        tool_result: Dict = None
    ) -> Tuple[str, Dict]:
        """Generate a response using OpenAI's API.
        
        Args:
            prompt: The user's prompt
            tools: Optional list of tools to make available to the model
            tool_result: Optional results from a previous tool call
        
        Returns:
            Tuple of (response text, tool call information if any)
        """
        # Add user message to history
        if prompt:  # Only add if not empty
            self.conversation_history.append({"role": "user", "content": prompt})
        
        # Prepare the API call
        kwargs = {
            "model": self.model,
            "messages": self.conversation_history,
            "max_tokens": 4096,
        }
        
        # Add tools if provided
        if tools:
            kwargs["tools"] = tools
        
        # Call the API
        response = self.client.chat.completions.create(**kwargs)
        
        # Get the response content
        message = response.choices[0].message
        
        # Check if the model wants to call a tool
        tool_call = None
        if hasattr(message, 'tool_calls') and message.tool_calls:
            # We have a tool call
            tc = message.tool_calls[0]
            tool_call = {
                "tool_name": tc.function.name,
                "arguments": tc.function.arguments,
                "id": tc.id
            }
            logger.info(f"Model wants to call tool: {tool_call['tool_name']}")
            
            # Add assistant message with tool call to history
            self.conversation_history.append(message)
            
            # If we already have the tool result, add it to history
            if tool_result:
                self.conversation_history.append({
                    "role": "tool",
                    "tool_call_id": tool_call["id"],
                    "content": str(tool_result)
                })
                
                # Generate a new response that incorporates the tool results
                kwargs["messages"] = self.conversation_history
                response = self.client.chat.completions.create(**kwargs)
                message = response.choices[0].message
                tool_call = None  # Reset since we've already processed the tool
        
        # Add the final assistant response to history
        self.conversation_history.append(message)
        
        return message.content, tool_call
    
    def clear_history(self):
        """Clear the conversation history."""
        self.conversation_history = []
        logger.info("Conversation history cleared.") 