from logic.llm_client import OpenAIClient
from logic.mcp_client import MCPClient
import streamlit as st

mcp_client = None

class Manager:
    def __init__(self):
        self.llm_client = None
        self.tool_server_mapping = {}
        
    def init_llm_client(self, model_name, api_key):
        self.llm_client = OpenAIClient(api_key)
        self.llm_client.set_model(model_name)

    async def init_mcp_clients(self, servers):
        global mcp_client
        try:
            mcp_client = MCPClient()
            if servers[0]["server_type"] == "stdio":
                await mcp_client.connect_stdio(servers[0]["server_command"].split(" ")[0], servers[0]["server_command"].split(" ")[1:])
            elif servers[0]["server_type"] == "sse":
                await mcp_client.connect_sse(servers[0]["server_url"])
            elif servers[0]["server_type"] == "http":
                await mcp_client.connect_http(servers[0]["server_url"])
                
            tools = await mcp_client.list_tools()

            for tool in tools:
                self.tool_server_mapping[tool.name] = 0  
                print(f"Tool: {tool.name} -> Server: {servers[0]['server_url']}")
        except Exception as e:
            print(e)
        finally:
            # await mcp_client.cleanup()
            pass

            

    def print_tool_server_mapping(self):
        st.session_state["tools"] = []
        for tool, server in self.tool_server_mapping.items():
            st.session_state["tools"].append(tool)


    def send_message(self, message):
        response, tool_call = self.llm_client.generate_response(message)
        return response
       
