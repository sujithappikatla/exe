import streamlit as st
import asyncio
import logging
from logic.manager import Manager
from ui.sidebar import display_sidebar
from ui.chat import display_chat_interface

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

st.set_page_config(
    page_title="MCP Client",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)


async def main():

    if "connected" not in st.session_state:
        st.session_state["connected"] = False

    st.title("Chat with LLM and MCP Servers")

    state = display_sidebar()

    if state["connect"]:
        st.session_state["connected"] = True

    if st.session_state["connected"]:
        if "manager" not in st.session_state:
            st.session_state["manager"] = Manager()
            st.session_state.manager.init_llm_client(state["model_name"], state["api_key"])
            print("--------------------------------")
            print(st.session_state["servers"])
            print("--------------------------------")
            if st.session_state["servers"].__len__() > 0:
                await st.session_state.manager.init_mcp_clients(state["servers"])
            # st.session_state.manager.print_tool_server_mapping()
        display_chat_interface(st.session_state.manager)



if __name__ == "__main__":
    asyncio.run(main())


