import streamlit as st

def display_sidebar():

    st.sidebar.title("App Configuration")

    st.sidebar.header("LLM Model Settings")

    model_name = st.sidebar.text_input("Model Name", value="gpt-4o-mini")
    api_key = st.sidebar.text_input("API Key", value="sk-proj-pQ6TCOLZQSKNgobz")

    st.sidebar.divider()

    st.sidebar.header("MCP Server Settings")



    if "servers" not in st.session_state:
        st.session_state.servers = []

    server_type = st.sidebar.selectbox("Server Type", ["stdio", "sse", "http"], key="server_type")
    server_command = ""
    server_args = ""
    server_url = ""
    if server_type == "stdio":
        server_command = st.sidebar.text_input("Command (ex: python, node)", value="python server.py")
    elif server_type == "sse":
        server_url = st.sidebar.text_input("Server URL (example: http://0.0.0.0:8000/sse)", value="http://0.0.0.0:8000")
    elif server_type == "http":
        server_url = st.sidebar.text_input("Server URL (example: http://0.0.0.0:8000/mcp)", value="http://0.0.0.0:8000")
    
    new_server_btn = st.sidebar.button("Add MCP Server")

    if new_server_btn:
        st.session_state.servers.append({
            "server_type": server_type,
            "server_command": server_command + " " + server_args,
            "server_url": server_url
        })

    for idx, server in enumerate(st.session_state.servers):

        with st.sidebar.container(border=True):
            cols = st.columns([10, 2],vertical_alignment="center")  # Wide for text, narrow for button
            with cols[0]:

                st.markdown(f"**Server Type:** {server['server_type']}")
                if server['server_type'] == "stdio":
                    st.markdown(f"**cmd :** {server['server_command']}")
                elif server['server_type'] == "sse":
                    st.markdown(f"**url :** {server['server_url']}")
                elif server['server_type'] == "http":
                    st.markdown(f"**url :** {server['server_url']}")
            with cols[1]:
                if st.button("❌", key=f"delete_{idx}"):
                    st.session_state.servers.pop(idx)
                    st.rerun()  # Refresh to update the list

    st.sidebar.divider()
    
    connect = st.sidebar.button("Connect to MCP Servers")


    

    

    if "tools" in st.session_state:
        st.sidebar.divider()
        st.sidebar.header("Tools")
        for tool in st.session_state.tools:
            st.sidebar.write(tool)


    return {"connect": connect, "model_name": model_name, "api_key": api_key, "servers": st.session_state.servers}