import streamlit as st
from logic.manager import Manager

def display_chat_interface(manager: Manager):


    # Initialize chat history in session_state
    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
    
    # Chat interface
    if prompt := st.chat_input("Enter a message:"):

        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        # Add bot response (echo for demo)
        response = manager.send_message(prompt)
        st.session_state.messages.append({"role": "assistant", "content": response})
        with st.chat_message("assistant"):
            st.markdown(response)
