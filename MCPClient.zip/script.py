#!/usr/bin/env python3
import asyncio
import json
import logging
import os
import argparse
import sys
from typing import Dict, List, Any, Optional, Tuple

import openai
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("mcp-cli")

class MCPClient:
    """MCP Client that supports stdio transport."""
    
    def __init__(self):
        """Initialize the MCP client."""
        self.session = None
        self.available_tools = []
        self.stdio_transport = None
        self.read_stream = None
        self.write_stream = None
    
    async def connect_stdio(self, command: str, args: List[str], env: Optional[Dict[str, str]] = None):
        """Connect to MCP server using stdio transport."""
        server_params = StdioServerParameters(
            command=command,
            args=args,
            env=env
        )
        
        logger.info(f"Connecting to stdio MCP server with command: {command} {' '.join(args)}")
        
        try:
            # Start the server and get communication streams
            self.stdio_transport = await stdio_client(server_params).__aenter__()
            self.read_stream, self.write_stream = self.stdio_transport
            
            # Create session
            self.session = await ClientSession(
                self.read_stream, self.write_stream
            ).__aenter__()
            
            # Initialize the connection
            await self.session.initialize()
            
            # List available tools
            tools_response = await self.session.list_tools()
            self.available_tools = tools_response.tools
            
            logger.info(f"Connected to MCP Server. Available tools: {[tool.name for tool in self.available_tools]}")
        except Exception as e:
            logger.error(f"Failed to connect to MCP server: {e}")
            await self.cleanup()
            raise RuntimeError(f"Failed to connect to MCP server: {e}")
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]):
        """Call a tool on the MCP server."""
        if not self.session:
            raise RuntimeError("Client session is not initialized.")
            
        logger.info(f"Calling tool '{tool_name}' with arguments: {arguments}")
        
        try:
            # Validate the tool exists
            tool_exists = any(tool.name == tool_name for tool in self.available_tools)
            if not tool_exists:
                logger.error(f"Tool '{tool_name}' not found in available tools")
                raise ValueError(f"Tool '{tool_name}' not found in available tools")
            
            logger.info(f"Sending call_tool request to MCP server for '{tool_name}'")
            result = await self.session.call_tool(tool_name, arguments)
            logger.info(f"Received result from tool '{tool_name}'")
            return result
        except Exception as e:
            logger.error(f"Error executing tool '{tool_name}': {e}")
            raise
    
    def get_tool_schemas(self):
        """Get the schemas for available tools in a format suitable for OpenAI."""
        return [{
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description or f"Tool: {tool.name}",
                "parameters": tool.inputSchema
            }
        } for tool in self.available_tools]
    
    async def cleanup(self):
        """Clean up resources."""
        logger.info("Cleaning up MCP Client resources...")
        
        try:
            if self.session:
                try:
                    await self.session.__aexit__(None, None, None)
                except Exception as e:
                    logger.error(f"Error during session cleanup: {e}")
                finally:
                    self.session = None
            
            # Clear resources
            self.read_stream = None
            self.write_stream = None
            self.stdio_transport = None
            logger.info("MCP Client resources cleaned up.")
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")


class OpenAIClient:
    """OpenAI client for the MCP CLI application."""
    
    def __init__(self, api_key: str = None):
        """Initialize the OpenAI client."""
        if api_key:
            self.client = openai.OpenAI(api_key=api_key)
        else:
            self.client = openai.OpenAI()  # Uses OPENAI_API_KEY environment variable
        
        self.model = "gpt-4o-mini"  # Default model
        self.conversation_history = []
    
    def set_model(self, model_name: str):
        """Set the model to use for chat completions."""
        self.model = model_name
        logger.info(f"Set OpenAI model to {model_name}")
    
    def generate_response(
        self, 
        prompt: str, 
        tools: List[Dict] = None, 
        tool_result: Dict = None
    ) -> Tuple[str, Dict]:
        """Generate a response using OpenAI's API."""
        # Add user message to history if not empty
        if prompt:
            self.conversation_history.append({"role": "user", "content": prompt})
        
        # Prepare the API call
        kwargs = {
            "model": self.model,
            "messages": self.conversation_history,
            "max_tokens": 4096,
        }
        
        # Add tools if provided
        if tools:
            kwargs["tools"] = tools
        
        # Call the API
        response = self.client.chat.completions.create(**kwargs)
        
        # Get the response content
        message = response.choices[0].message
        
        # Check if the model wants to call a tool
        tool_call = None
        if hasattr(message, 'tool_calls') and message.tool_calls:
            # We have a tool call
            tc = message.tool_calls[0]
            tool_call = {
                "tool_name": tc.function.name,
                "arguments": tc.function.arguments,
                "id": tc.id
            }
            logger.info(f"Model wants to call tool: {tool_call['tool_name']}")
            
            # Add assistant message with tool call to history
            self.conversation_history.append(message)
            
            # If we already have the tool result, add it to history
            if tool_result:
                self.conversation_history.append({
                    "role": "tool",
                    "tool_call_id": tool_call["id"],
                    "content": str(tool_result)
                })
                
                # Generate a new response that incorporates the tool results
                kwargs["messages"] = self.conversation_history
                response = self.client.chat.completions.create(**kwargs)
                message = response.choices[0].message
                tool_call = None  # Reset since we've already processed the tool
        
        # Add the final assistant response to history
        self.conversation_history.append(message)
        
        return message.content, tool_call
    
    def clear_history(self):
        """Clear the conversation history."""
        self.conversation_history = []
        logger.info("Conversation history cleared.")


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="MCP CLI Tool")
    parser.add_argument("--command", default="python", help="Command to execute the MCP server")
    parser.add_argument("--args", nargs="+", required=True, help="Arguments for the MCP server command")
    parser.add_argument("--model", default="gpt-4o-mini", help="OpenAI model to use")
    parser.add_argument("--api-key", help="OpenAI API key (optional if set in environment)")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    
    return parser.parse_args()


def format_tool_result(result):
    """Format tool result for display and LLM consumption."""
    if hasattr(result, 'content'):
        # Format MCP tool result
        content_list = result.content
        formatted_content = []
        
        for item in content_list:
            if hasattr(item, 'text'):
                formatted_content.append(item.text)
            elif isinstance(item, dict) and 'text' in item:
                formatted_content.append(item['text'])
            else:
                formatted_content.append(str(item))
        
        return "\n".join(formatted_content)
    
    # If result is not from MCP, try to serialize as JSON
    try:
        return json.dumps(result, indent=2)
    except (TypeError, json.JSONDecodeError):
        return str(result)


def parse_tool_arguments(arguments_str):
    """Parse tool call arguments from string to dictionary."""
    try:
        return json.loads(arguments_str)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse arguments: {e}")
        return {}


async def main_async():
    """Main async function."""
    args = parse_arguments()
    
    # Set up logging level
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.setLevel(logging.DEBUG)
    
    # Initialize clients
    mcp_client = MCPClient()
    openai_client = OpenAIClient(api_key=args.api_key)
    
    # Set OpenAI model
    openai_client.set_model(args.model)
    
    try:
        # Connect to MCP server
        print(f"Connecting to MCP server: {args.command} {' '.join(args.args)}")
        try:
            await mcp_client.connect_stdio(args.command, args.args)
            print(f"Connected! Available tools: {[tool.name for tool in mcp_client.available_tools]}")
        except Exception as e:
            print(f"Failed to connect to MCP server: {e}")
            return
        
        # Main interaction loop
        print("\nMCP CLI Tool - Type 'quit' to exit, 'clear' to clear conversation history")
        print("Type your questions and I'll respond, using MCP tools when needed.")
        print("=" * 70)
        
        while True:
            # Get user input
            user_input = input("\nYou: ").strip()
            
            # Check for exit command
            if user_input.lower() == "quit":
                break
                
            # Check for clear history command
            if user_input.lower() == "clear":
                openai_client.clear_history()
                print("Conversation history cleared.")
                continue
            
            # Get tool schemas
            tools = mcp_client.get_tool_schemas()
            
            try:
                # Generate response
                print("\nAssistant: ", end="", flush=True)
                response_text, tool_call = openai_client.generate_response(user_input, tools)
                
                # If no tool call, just display the response
                if not tool_call:
                    print(response_text)
                    continue
                
                # Process tool call
                tool_name = tool_call["tool_name"]
                arguments = parse_tool_arguments(tool_call["arguments"])
                
                print(f"I'll use the {tool_name} tool to help with this.")
                print(f"Calling {tool_name}...", end="", flush=True)
                
                try:
                    # Call the tool
                    tool_result = await mcp_client.call_tool(tool_name, arguments)
                    
                    # Format result
                    formatted_result = format_tool_result(tool_result)
                    
                    print(" done!")
                    print(f"\nTool result: {formatted_result}")
                    
                    # Generate final response with tool result
                    final_response, _ = openai_client.generate_response("", tools, formatted_result)
                    print(f"\nAssistant: {final_response}")
                    
                except Exception as e:
                    print(" failed!")
                    print(f"Error: {str(e)}")
                    
                    # Generate fallback response
                    fallback_response, _ = openai_client.generate_response(
                        f"The tool call to {tool_name} failed with error: {str(e)}. Please provide a response without using the tool.",
                        None
                    )
                    print(f"\nAssistant: {fallback_response}")
            
            except Exception as e:
                logger.error(f"Error generating response: {e}")
                print(f"Error: {str(e)}")
                
                # Try fallback
                try:
                    fallback_response, _ = openai_client.generate_response(user_input, None)
                    print(f"\nAssistant: {fallback_response}")
                except Exception as fallback_e:
                    print(f"Could not generate a response: {str(fallback_e)}")
    
    except KeyboardInterrupt:
        print("\nReceived keyboard interrupt. Exiting...")
    
    except Exception as e:
        logger.error(f"Error: {e}")
        print(f"Error: {str(e)}")
    
    finally:
        # Clean up
        print("Cleaning up resources...")
        try:
            await mcp_client.cleanup()
        except Exception as e:
            logger.error(f"Error during final cleanup: {e}")
        print("\nMCP CLI Tool closed.")


def main():
    """Main entry point."""
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
