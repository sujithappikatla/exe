import os
from datetime import timedelta
from anyio import to_thread
import httpx
from fastapi import FastAPI, HTTPException
import uvicorn
import google.auth
from google.auth.transport.requests import Request
from google.cloud import storage

app = FastAPI(title="tokenServer")
SCOPES = ("https://www.googleapis.com/auth/cloud-platform",)
ASSEMBLYAI_TOKEN_URL = "https://streaming.assemblyai.com/v3/token"
ASSEMBLYAI_DEFAULT_TTL = 600  # AssemblyAI enforces 1-600 seconds; we use max.
GCS_BUCKET = ""
GCS_OBJECT = ""
GCS_SIGNED_URL_TTL = 60 * 60 * 2  # 2 hours


@app.get("/", tags=["root"])
async def read_root() -> dict[str, str]:
    return {"message": "tokenServer API is running"}


@app.get("/health", tags=["health"])
async def health() -> dict[str, str]:
    return {"status": "ok"}


async def _get_gcp_access_token() -> dict[str, str | None]:
    """Fetch an access token using Application Default Credentials."""

    def _obtain() -> dict[str, str | None]:
        credentials, _ = google.auth.default(scopes=SCOPES)
        if not credentials.valid or not credentials.token:
            credentials.refresh(Request())
        expires_at = credentials.expiry.isoformat() if credentials.expiry else None
        return {"access_token": credentials.token, "expires_at": expires_at}

    return await to_thread.run_sync(_obtain)


@app.get("/gcp/token", tags=["gcp"])
async def gcp_token() -> dict[str, str | None]:
    """
    Return an OAuth2 access token (ADC) for Google Cloud services like STT.
    Ensures token is refreshed with the requested scopes before returning.
    """
    try:
        return await _get_gcp_access_token()
    except Exception as exc:  # pragma: no cover - surface ADC issues to client
        raise HTTPException(status_code=500, detail=f"Failed to get GCP token: {exc}") from exc


async def _get_assemblyai_token() -> dict[str, int | str]:
    """Request a short-lived token from AssemblyAI's streaming token endpoint."""
    # api_key = os.getenv("ASSEMBLYAI_API_KEY")
    api_key = ""
    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="ASSEMBLYAI_API_KEY is not configured in the environment.",
        )

    headers = {"Authorization": api_key}
    params = {"expires_in_seconds": ASSEMBLYAI_DEFAULT_TTL}

    async with httpx.AsyncClient(timeout=10) as client:
        try:
            response = await client.get(ASSEMBLYAI_TOKEN_URL, headers=headers, params=params)
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPStatusError as exc:
            raise HTTPException(
                status_code=exc.response.status_code,
                detail=f"AssemblyAI error: {exc.response.text}",
            ) from exc
        except httpx.RequestError as exc:
            raise HTTPException(status_code=502, detail=f"AssemblyAI request failed: {exc}") from exc

    token = data.get("token")
    if not token:
        raise HTTPException(status_code=502, detail="AssemblyAI token missing in response.")

    return {"token": token, "expires_in_seconds": ASSEMBLYAI_DEFAULT_TTL}


@app.get("/assemblyai/token", tags=["assemblyai"])
async def assemblyai_token() -> dict[str, int | str]:
    """
    Return a short-lived token for AssemblyAI streaming APIs.
    Set ASSEMBLYAI_API_KEY in the environment. TTL fixed at 600 seconds (AssemblyAI max).
    """
    return await _get_assemblyai_token()

async def _get_gcs_signed_url() -> dict[str, str | int]:
    """Generate a download signed URL for the configured GCS object."""

    def _sign() -> dict[str, str | int]:
        # 1. Load default credentials (will be the Compute Engine ones on Cloud Run)
        # Ensure you request the 'cloud-platform' scope to allow IAM signing
        credentials, project_id = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        
        # 2. MANDATORY: Refresh credentials to populate the 'token' field
        # Without this, credentials.token will be None and signing will fail
        auth_request = Request()
        credentials.refresh(auth_request)

        client = storage.Client()
        bucket = client.bucket(GCS_BUCKET)
        blob = bucket.blob(GCS_OBJECT)
        url = blob.generate_signed_url(
            version="v4",
            expiration=timedelta(seconds=GCS_SIGNED_URL_TTL),
            method="GET",
            # Pass the service account email to tell the library which identity to sign as
            service_account_email=credentials.service_account_email,
            access_token=credentials.token 
        )
        return {
            "bucket": GCS_BUCKET,
            "object": GCS_OBJECT,
            "url": url,
            "expires_in_seconds": GCS_SIGNED_URL_TTL,
        }

    try:
        return await to_thread.run_sync(_sign)
    except Exception as exc:  # pragma: no cover - surface ADC or signing issues
        raise HTTPException(status_code=500, detail=f"Failed to sign URL: {exc}") from exc


@app.get("/gcp/presign", tags=["gcp"])
async def gcp_presign() -> dict[str, str | int]:
    """
    Return a signed download URL for the fixed GCS object in ska-test-bucket.
    URL expires in 2 hours.
    """
    return await _get_gcs_signed_url()


# Run locally with: uvicorn main:app --reload
def main() -> None:
    uvicorn.run(app, host="0.0.0.0", port=8080)


if __name__ == "__main__":
    main()