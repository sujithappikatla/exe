package com.example.stt

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AudioRecorder(
    private val webSocketClient: SpeechToTextWebSocketClient
) {
    companion object {
        private const val SAMPLE_RATE = 16000 // 16kHz, same as in Python client
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        // Calculate buffer size in bytes (100ms chunks like in Python client)
        private val BUFFER_SIZE_IN_BYTES = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT
        ).coerceAtLeast(SAMPLE_RATE * 2 / 10) // 100ms of audio at 16kHz, 16-bit
    }

    private var audioRecord: AudioRecord? = null
    private var isRecording = false

    // Initialize the AudioRecord object
    fun init(): Boolean {
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            BUFFER_SIZE_IN_BYTES
        )

        return audioRecord?.state == AudioRecord.STATE_INITIALIZED
    }

    // Start recording and sending audio to the WebSocket
    suspend fun startRecording() = withContext(Dispatchers.IO) {
        if (audioRecord == null || audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            if (!init()) {
                return@withContext
            }
        }

        isRecording = true
        audioRecord?.startRecording()

        val buffer = ByteArray(BUFFER_SIZE_IN_BYTES)
        
        try {
            while (isRecording) {
                val readSize = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (readSize > 0) {
                    // Send the audio chunk to the WebSocket
                    webSocketClient.sendAudioData(buffer.copyOf(readSize))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Stop recording
    fun stopRecording() {
        isRecording = false
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }
} 