package com.example.stt

import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI
import javax.net.ssl.SSLSocketFactory

class SpeechToTextWebSocketClient(
    serverURI: URI,
    private val onMessageCallback: (String) -> Unit,
    private val onConnectCallback: () -> Unit,
    private val onCloseCallback: () -> Unit
) : WebSocketClient(serverURI) {

    init {
        // For secure WebSocket connections (wss://)
        if (serverURI.scheme == "wss") {
            this.socket = SSLSocketFactory.getDefault().createSocket()
        }
    }

    override fun onOpen(handshakedata: ServerHandshake?) {
        onConnectCallback()
    }

    override fun onMessage(message: String?) {
        message?.let { onMessageCallback(it) }
    }

    override fun onClose(code: Int, reason: String?, remote: Boolean) {
        onCloseCallback()
    }

    override fun onError(ex: Exception?) {
        ex?.printStackTrace()
    }

    // Send binary audio data
    fun sendAudioData(byteArray: ByteArray) {
        if (isOpen) {
            send(byteArray)
        }
    }
} 