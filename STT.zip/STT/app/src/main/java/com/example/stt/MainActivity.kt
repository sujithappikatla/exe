package com.example.stt

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.stt.ui.theme.STTTheme
import kotlinx.coroutines.launch
import java.net.URI

class MainActivity : ComponentActivity() {
    
    // WebSocket server URL (same as in Python client)
//    private val WS_URL = "wss://speech-to-text-server-305533803718.us-west1.run.app"
    private val WS_URL = "ws://34.36.163.78:80/"

    // Variables for recording and WebSocket
    private var webSocketClient: SpeechToTextWebSocketClient? = null
    private var audioRecorder: AudioRecorder? = null
    
    // State variables
    private var isRecording = mutableStateOf(false)
    private var transcription = mutableStateOf("")
    private var isConnected = mutableStateOf(false)
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        initializeWebSocket()
        
        setContent {
            STTTheme {
                SpeechToTextScreen(
                    isConnected = isConnected.value,
                    isRecording = isRecording.value,
                    transcription = transcription.value,
                    onRecordButtonClick = { toggleRecording() }
                )
            }
        }
    }
    
    private fun initializeWebSocket() {
        webSocketClient = SpeechToTextWebSocketClient(
            URI(WS_URL),
            onMessageCallback = { message ->
                // Update transcription with new message from server
                transcription.value = message
            },
            onConnectCallback = {
                isConnected.value = true
            },
            onCloseCallback = {
                isConnected.value = false
                stopRecording()
            }
        )
        
        // Connect to the WebSocket server
        webSocketClient?.connect()
        
        // Initialize audio recorder
        audioRecorder = AudioRecorder(webSocketClient!!)
    }
    
    private fun toggleRecording() {
        if (!PermissionUtils.hasRecordAudioPermission(this)) {
            PermissionUtils.requestRecordAudioPermission(this) {
                startRecording()
            }
            return
        }
        
        if (isRecording.value) {
            stopRecording()
        } else {
            startRecording()
        }
    }
    
    private fun startRecording() {
        if (!isConnected.value) {
            // Try reconnecting
            webSocketClient?.connect()
            return
        }
        
        isRecording.value = true
        lifecycleScope.launch {
            audioRecorder?.startRecording()
        }
    }
    
    private fun stopRecording() {
        isRecording.value = false
        audioRecorder?.stopRecording()
    }
    
    override fun onDestroy() {
        stopRecording()
        webSocketClient?.close()
        super.onDestroy()
    }
}

@Composable
fun SpeechToTextScreen(
    isConnected: Boolean,
    isRecording: Boolean,
    transcription: String,
    onRecordButtonClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Status indicator
            ConnectionStatus(isConnected)
            
            // Transcription area
            TranscriptionArea(transcription)
            
            // Record button
            RecordButton(
                isRecording = isRecording,
                onClick = onRecordButtonClick
            )
        }
    }
}

@Composable
fun ConnectionStatus(isConnected: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(if (isConnected) Color.Green else Color.Red)
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Text(
            text = if (isConnected) "Connected" else "Disconnected",
            color = if (isConnected) Color.Green else Color.Red
        )
    }
}

@Composable
fun TranscriptionArea(transcription: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = transcription.ifEmpty { "Speak to see transcription here..." },
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            color = if (transcription.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun RecordButton(
    isRecording: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .padding(bottom = 32.dp)
            .size(80.dp),
        shape = RoundedCornerShape(40.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isRecording) Color.Red else MaterialTheme.colorScheme.primary
        )
    ) {
        Text(text = if (isRecording) "Stop" else "Record")
    }
}