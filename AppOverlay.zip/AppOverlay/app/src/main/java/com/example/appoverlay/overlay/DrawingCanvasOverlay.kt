package com.example.appoverlay.overlay

import android.content.Context
import android.content.Context.LAYOUT_INFLATER_SERVICE
import android.graphics.PixelFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import com.example.appoverlay.R
import com.example.appoverlay.util.LOGTAG
import com.example.appoverlay.view.CanvasView

class DrawingCanvasOverlay(cxt : Context, windowManager: WindowManager ) {
    private var drawingCanvasView: View? = null
    private var CXT: Context? = null
    private var WM:WindowManager? = null
    private var isInteractionMode = false
    private var layoutParams:WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, // or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        PixelFormat.TRANSLUCENT
    )

    init {
        CXT = cxt
        WM = windowManager
    }

    public fun create()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView create ")

        val inflater = CXT!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        drawingCanvasView = inflater.inflate(R.layout.canvas_layout, null)

        WM!!.addView(drawingCanvasView, layoutParams)
    }


    fun setPenColor(_color:Int)
    {
        val dw: CanvasView = drawingCanvasView!!.findViewById(R.id.drawingView)
        dw.changeToPen(_color)
    }

    fun setStrokeWidth(_width:Float)
    {
        val dw: CanvasView = drawingCanvasView!!.findViewById(R.id.drawingView)
        dw.setStrokeWidth(_width)
    }

    fun setToEraser()
    {
        val dw: CanvasView = drawingCanvasView!!.findViewById(R.id.drawingView)
        dw.changeToEraser()
    }

    public fun destroy()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView destroy ")
        if (WM != null && drawingCanvasView != null) {
            WM!!.removeView(drawingCanvasView)
        }
    }

    public fun toggleInteractionMode()
    {
        isInteractionMode = !isInteractionMode
        if(isInteractionMode)
        {
            layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        else
        {
            layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }

        WM!!.updateViewLayout(drawingCanvasView, layoutParams)
    }



}