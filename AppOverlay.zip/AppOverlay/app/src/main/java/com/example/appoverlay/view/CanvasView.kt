package com.example.appoverlay.view


import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import com.example.appoverlay.util.LOGTAG

data class PathData(val path:Path, val paint:Paint)

class CanvasView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var pathsToDraw:MutableList<PathData> = mutableListOf()
    private var currentPath = Path()
    private var currentPaint = Paint()
    private var currentStrokeWidth = 5f
    private var currentColor = Color.BLACK

    init {
        Log.i(LOGTAG, "Creating CanvasView...")
        currentPaint.apply {
            color = currentColor
            style = Paint.Style.STROKE
            isAntiAlias = true
            strokeWidth = currentStrokeWidth
        }

    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for ( pd in pathsToDraw) {
            canvas.drawPath(pd.path, pd.paint)
        }
        canvas.drawPath(currentPath, currentPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                currentPath.moveTo(x, y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                currentPath.lineTo(x, y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                // Nothing to do here for now
            }
        }

        return false
    }

    fun addCurrentPathDataToList()
    {
        pathsToDraw.add(PathData(currentPath, currentPaint))
    }

    fun createNewPath()
    {
        currentPath = Path()
        currentPaint = Paint()
        currentPaint.apply {
            color = currentColor
            strokeWidth = currentStrokeWidth
            isAntiAlias = true
            style = Paint.Style.STROKE
        }
    }

    fun setStrokeWidth(_width : Float)
    {
        addCurrentPathDataToList()
        currentStrokeWidth = _width
        createNewPath()
        Log.i(LOGTAG, "Stroke Width set to : $_width")
    }

    fun changeToEraser()
    {
        addCurrentPathDataToList()
        currentColor = Color.WHITE
        currentStrokeWidth = 50f
        createNewPath()
        currentPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        Log.i(LOGTAG, "Changed to Eraser")
    }

    fun changeToPen(_color:Int)
    {
        addCurrentPathDataToList()
        currentStrokeWidth = 5f
        currentColor = _color
        createNewPath()
        Log.i(LOGTAG, "Changed to Pen with color $_color")
    }
}
