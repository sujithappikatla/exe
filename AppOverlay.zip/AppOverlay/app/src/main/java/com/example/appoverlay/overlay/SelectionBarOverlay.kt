package com.example.appoverlay.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.GridLayout
import android.widget.ImageView
import androidx.core.content.ContextCompat
import com.example.appoverlay.R
import com.example.appoverlay.util.LOGTAG

class SelectionBarOverlay(
    cxt: Context,
    windowManager: WindowManager,
    drawingCanvasOverlay: DrawingCanvasOverlay,
    val stopService: () -> Unit
) {
    private var selectionBarView: View? = null
    private var CXT: Context? = null
    private var WM:WindowManager? = null
    private var layoutParams:WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )
    private val CANVAS = drawingCanvasOverlay

    init {
        CXT = cxt
        WM = windowManager
    }

    public fun create()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView create ")

        val inflater = CXT!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        selectionBarView = inflater.inflate(R.layout.selection_bar_layout, null)

        layoutParams.gravity = Gravity.LEFT
        WM!!.addView(selectionBarView, layoutParams)
        addColorItemsToView()
        addEraserItemToView()
        addToolSelectionItemToView()
        addCloseToView()
    }

    private fun addColorItemsToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val colors = intArrayOf(
            Color.BLACK,
            Color.WHITE,
            Color.RED,
            Color.GREEN,
            Color.BLUE
            // Add more colors as needed
        )

        // Inflate and add small circles to the GridLayout
        for (colorResId in colors) {
            val circleView = View(CXT)
            val circleDrawable = ContextCompat.getDrawable(CXT!!, R.drawable.circle) as GradientDrawable
            circleDrawable.setColor(colorResId)
            circleView.background = circleDrawable

            circleView.setOnClickListener {
                onColorSelect(colorResId)
            }

            val layoutParams = GridLayout.LayoutParams().apply {
                width = 100
                height = 100
                bottomMargin = 20
            }

            colorSelectionGrid.addView(circleView, layoutParams)
        }
    }

    private fun onColorSelect(_color:Int)
    {
        Log.i(LOGTAG, "Selecting Color : $_color")
        CANVAS.setPenColor(_color)
    }

    private fun onStrokeWidthSelect(_width:Float)
    {
        Log.i(LOGTAG, "Selecting Stroke Width : $_width")

        CANVAS.setStrokeWidth(_width)
    }

    private fun onEraserSelect()
    {
        Log.i(LOGTAG, "Selecting Eraser")

        CANVAS.setToEraser()
    }

    private fun addEraserItemToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val imageV = ImageView(CXT)
        imageV.setImageResource(R.drawable.eraser)
        imageV.setBackgroundResource(R.drawable.circular_background)

        val layoutParams = GridLayout.LayoutParams().apply {
            width = 100
            height = 100
            bottomMargin = 20
            topMargin = 20
        }

        imageV.setOnClickListener {
            CANVAS.setToEraser()
        }
        colorSelectionGrid.addView(imageV, layoutParams)
    }

    private fun addToolSelectionItemToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val imageV = ImageView(CXT)
        imageV.setImageResource(R.drawable.pen)
        imageV.setBackgroundResource(R.drawable.circular_background)

        //imageV.background = ColorDrawable(Color.LTGRAY)
        //imageV.setBackgroundResource(R.drawable.circular_background)

        //val _params = ViewGroup.LayoutParams(80, ViewGroup.LayoutParams.WRAP_CONTENT)
        //imageV.layoutParams = _params

        val layoutParams = GridLayout.LayoutParams().apply {
            width = 100
            height = 100
            bottomMargin = 20
            topMargin = 20
        }

        imageV.setOnClickListener {
            CANVAS.toggleInteractionMode()
        }

        colorSelectionGrid.addView(imageV, layoutParams)
    }

    public fun addCloseToView()
    {
        val colorSelectionGrid: GridLayout = selectionBarView!!.findViewById(R.id.colorSelectionGrid)

        val imageV = ImageView(CXT)
        imageV.setImageResource(R.drawable.close)
        imageV.setBackgroundResource(R.drawable.circular_background)

        val layoutParams = GridLayout.LayoutParams().apply {
            width = 100
            height = 100
            bottomMargin = 20
            topMargin = 20
        }

        imageV.setOnClickListener {
            stopService()
        }
        colorSelectionGrid.addView(imageV, layoutParams)
    }

    public fun destroy()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView destroy ")
        if (WM != null && selectionBarView != null) {
            WM!!.removeView(selectionBarView)
        }
    }

}