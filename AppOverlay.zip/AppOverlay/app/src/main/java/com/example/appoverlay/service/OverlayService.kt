package com.example.appoverlay.service


import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.view.WindowManager
import com.example.appoverlay.overlay.DrawingCanvasOverlay
import com.example.appoverlay.overlay.SelectionBarOverlay


class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private lateinit var drawingCanvasOverlay:DrawingCanvasOverlay
    private lateinit var selectionBarOverlay:SelectionBarOverlay

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        showOverlay()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
    }


    private fun showOverlay()
    {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        showDrawingCanvas()
        showSelectionBar()
    }

    private fun showDrawingCanvas()
    {
        drawingCanvasOverlay = DrawingCanvasOverlay(this, windowManager!!)
        drawingCanvasOverlay.create()
    }

    private fun showSelectionBar()
    {
        selectionBarOverlay = SelectionBarOverlay(this, windowManager!!, drawingCanvasOverlay!!) {
            stopSelf()
        }
        selectionBarOverlay.create()
    }


    private fun removeOverlay() {
        drawingCanvasOverlay?.destroy()
        selectionBarOverlay?.destroy()
    }
}
