from flask import Flask, request, jsonify
from flask_sock import Sock
import time
import datetime
import threading
import json

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'

# Initialize Sock for raw WebSockets
sock = Sock(app)

# # List to store WebSocket connections
# ws_clients = []

# # Function to stream data to clients
# def stream_data():
#     while True:
#         # Get current date and time as sample data
#         current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
#         data_json = json.dumps({'timestamp': current_time, 'data': 'Sample data'})
        
#         # Send data to all connected WebSocket clients
#         for ws in ws_clients[:]:
#             try:
#                 ws.send(data_json)
#             except Exception:
#                 # If sending fails, remove the client
#                 if ws in ws_clients:
#                     ws_clients.remove(ws)
        
#         # Sleep for a short interval
#         time.sleep(1)

# # Start the background thread for data streaming
# threading.Thread(target=stream_data, daemon=True).start()

# WebSocket endpoint
@sock.route('/websocket')
def websocket(ws):
    # Add the WebSocket to our clients list
    # ws_clients.append(ws)
    print(f"WebSocket client connected")
    
    try:
        # Keep the connection open and listen for messages
        while True:
            data = ws.receive()
            # Echo received data back to client
            ws.send(json.dumps({
                'status': 'received',
                'data': data,
                'timestamp': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
            }))
    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        # Remove client on disconnect
        # if ws in ws_clients:
        #     ws_clients.remove(ws)
        print("WebSocket client disconnected")

# REST API endpoints
@app.route('/api/data', methods=['GET'])
def get_data():
    """Simple REST endpoint to get data"""
    return jsonify({
        'timestamp': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
        'data': 'Sample REST API response'
    })

@app.route('/api/data', methods=['POST'])
def post_data():
    """Simple REST endpoint to receive data"""
    data = request.json
    return jsonify({
        'status': 'success',
        'received': data,
        'timestamp': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    })

if __name__ == '__main__':
    # Run the app with regular Flask
    app.run(host='0.0.0.0', port=8888, debug=True)
