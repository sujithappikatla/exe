import asyncio
import logging
import random
import string
from typing import Dict, Any, Optional
from datetime import datetime

import socketio
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from models import (
    CreateClassRequest, 
    JoinClassRequest, 
    SubmitAnswerRequest,
    NavigateQuestionRequest
)
from quiz_manager import QuizManager
from pdf_generator import PDFGenerator

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(title="Real-Time Quiz Application", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create Socket.IO server
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins="*"
)

# Create the combined ASGI app
socket_app = socketio.ASGIApp(sio, app)

# Initialize managers
quiz_manager = QuizManager()
pdf_generator = PDFGenerator()

def generate_class_code() -> str:
    """Generate a unique 6-digit alphanumeric class code."""
    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        if code not in quiz_manager.active_classes:
            return code

# Socket.IO Event Handlers

@sio.event
async def connect(sid, environ):
    """Handle client connection."""
    logger.info(f"Client connected: {sid}")

@sio.event
async def disconnect(sid):
    """Handle client disconnection."""
    logger.info(f"Client disconnected: {sid}")
    # Clean up any class data if this was a teacher or student
    await quiz_manager.handle_disconnect(sid, sio)

@sio.event
async def c2s_create_class(sid, data):
    """Handle teacher creating a new class."""
    try:
        request = CreateClassRequest(**data)
        class_code = generate_class_code()
        
        # Create the class
        await quiz_manager.create_class(
            class_code=class_code,
            teacher_sid=sid,
            teacher_name=request.teacher_name,
            quiz_data=request.quiz_data
        )
        
        # Join the teacher to the room
        await sio.enter_room(sid, class_code)
        
        # Send confirmation to teacher
        await sio.emit('s2c_class_created', {'class_code': class_code}, room=sid)
        
        logger.info(f"Class created: {class_code} by teacher {request.teacher_name}")
        
    except Exception as e:
        logger.error(f"Error creating class: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to create class'}, room=sid)

@sio.event
async def c2s_join_class(sid, data):
    """Handle student joining a class."""
    try:
        request = JoinClassRequest(**data)
        
        # Check if class exists
        if request.class_code not in quiz_manager.active_classes:
            await sio.emit('s2c_error', {'message': 'Invalid class code. Please try again.'}, room=sid)
            return
        
        # Add student to class
        success = await quiz_manager.add_student(
            class_code=request.class_code,
            student_sid=sid,
            student_name=request.student_name
        )
        
        if not success:
            await sio.emit('s2c_error', {'message': 'Failed to join class'}, room=sid)
            return
        
        # Join the student to the room
        await sio.enter_room(sid, request.class_code)
        
        # Send confirmation to student
        await sio.emit('s2c_join_successful', {
            'message': 'Waiting for the teacher to start the quiz.'
        }, room=sid)
        
        # Notify teacher about new student
        students_list = quiz_manager.get_students_list(request.class_code)
        teacher_sid = quiz_manager.active_classes[request.class_code]['teacher_sid']
        await sio.emit('s2c_student_joined', {'students': students_list}, room=teacher_sid)
        
        logger.info(f"Student {request.student_name} joined class {request.class_code}")
        
    except Exception as e:
        logger.error(f"Error joining class: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to join class'}, room=sid)

@sio.event
async def c2s_start_quiz(sid, data):
    """Handle teacher starting the quiz."""
    try:
        class_code = quiz_manager.get_class_code_by_teacher(sid)
        if not class_code:
            await sio.emit('s2c_error', {'message': 'No active class found'}, room=sid)
            return
        
        # Start the quiz and load first question
        success = await quiz_manager.start_quiz(class_code, sio)
        
        if not success:
            await sio.emit('s2c_error', {'message': 'Failed to start quiz'}, room=sid)
            return
        
        logger.info(f"Quiz started for class {class_code}")
        
    except Exception as e:
        logger.error(f"Error starting quiz: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to start quiz'}, room=sid)

@sio.event
async def c2s_navigate_question(sid, data):
    """Handle teacher navigating to next/previous question."""
    try:
        request = NavigateQuestionRequest(**data)
        class_code = quiz_manager.get_class_code_by_teacher(sid)
        
        if not class_code:
            await sio.emit('s2c_error', {'message': 'No active class found'}, room=sid)
            return
        
        success = await quiz_manager.navigate_question(class_code, request.direction, sio)
        
        if not success:
            await sio.emit('s2c_error', {'message': 'Failed to navigate question'}, room=sid)
            return
        
        logger.info(f"Question navigation: {request.direction} for class {class_code}")
        
    except Exception as e:
        logger.error(f"Error navigating question: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to navigate question'}, room=sid)

@sio.event
async def c2s_submit_answer(sid, data):
    """Handle student submitting an answer."""
    try:
        request = SubmitAnswerRequest(**data)
        class_code = quiz_manager.get_class_code_by_student(sid)
        
        if not class_code:
            await sio.emit('s2c_error', {'message': 'No active class found'}, room=sid)
            return
        
        # Check if timer is running
        class_data = quiz_manager.active_classes[class_code]
        if class_data['quiz_state']['timer_state'] != 'running':
            await sio.emit('s2c_error', {'message': 'Cannot submit answer when timer is not running'}, room=sid)
            return
        
        # Submit the answer
        success = await quiz_manager.submit_answer(
            class_code=class_code,
            student_sid=sid,
            question_id=request.question_id,
            answer=request.answer,
            sio=sio
        )
        
        if not success:
            await sio.emit('s2c_error', {'message': 'Failed to submit answer'}, room=sid)
            return
        
        logger.info(f"Answer submitted for question {request.question_id} in class {class_code}")
        
    except Exception as e:
        logger.error(f"Error submitting answer: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to submit answer'}, room=sid)

@sio.event
async def c2s_pause_timer(sid, data):
    """Handle teacher pausing the timer."""
    try:
        class_code = quiz_manager.get_class_code_by_teacher(sid)
        if not class_code:
            await sio.emit('s2c_error', {'message': 'No active class found'}, room=sid)
            return
        
        success = await quiz_manager.pause_timer(class_code, sio)
        
        if not success:
            await sio.emit('s2c_error', {'message': 'Failed to pause timer'}, room=sid)
            return
        
        logger.info(f"Timer paused for class {class_code}")
        
    except Exception as e:
        logger.error(f"Error pausing timer: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to pause timer'}, room=sid)

@sio.event
async def c2s_resume_timer(sid, data):
    """Handle teacher resuming the timer."""
    try:
        class_code = quiz_manager.get_class_code_by_teacher(sid)
        if not class_code:
            await sio.emit('s2c_error', {'message': 'No active class found'}, room=sid)
            return
        
        success = await quiz_manager.resume_timer(class_code, sio)
        
        if not success:
            await sio.emit('s2c_error', {'message': 'Failed to resume timer'}, room=sid)
            return
        
        logger.info(f"Timer resumed for class {class_code}")
        
    except Exception as e:
        logger.error(f"Error resuming timer: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to resume timer'}, room=sid)

@sio.event
async def c2s_end_quiz(sid, data):
    """Handle teacher ending the quiz."""
    try:
        class_code = quiz_manager.get_class_code_by_teacher(sid)
        if not class_code:
            await sio.emit('s2c_error', {'message': 'No active class found'}, room=sid)
            return
        
        success = await quiz_manager.end_quiz(class_code, sio)
        
        if not success:
            await sio.emit('s2c_error', {'message': 'Failed to end quiz'}, room=sid)
            return
        
        logger.info(f"Quiz ended for class {class_code}")
        
    except Exception as e:
        logger.error(f"Error ending quiz: {e}")
        await sio.emit('s2c_error', {'message': 'Failed to end quiz'}, room=sid)

# REST API Endpoints

@app.get("/")
async def root():
    """Root endpoint - redirect to teacher interface."""
    return FileResponse("teacher.html")

@app.get("/teacher")
async def teacher_page():
    """Serve the teacher interface."""
    return FileResponse("teacher.html")

@app.get("/teacher.html")
async def teacher_html():
    """Serve the teacher interface."""
    return FileResponse("teacher.html")

@app.get("/student")
async def student_page():
    """Serve the student interface."""
    return FileResponse("student.html")

@app.get("/student.html")
async def student_html():
    """Serve the student interface."""
    return FileResponse("student.html")

@app.get("/download-report/{class_code}/{student_sid}")
async def download_report(class_code: str, student_sid: str):
    """Generate and download PDF report for a student."""
    try:
        logger.info(f"PDF download request: class_code={class_code}, student_sid={student_sid}")
        
        # Get class data
        if class_code not in quiz_manager.active_classes:
            logger.error(f"Class {class_code} not found in active classes")
            logger.error(f"Available classes: {list(quiz_manager.active_classes.keys())}")
            raise HTTPException(status_code=404, detail="Class not found")
        
        class_data = quiz_manager.active_classes[class_code]
        logger.info(f"Found class data, students: {list(class_data['students'].keys())}")
        
        # Check if student exists
        if student_sid not in class_data['students']:
            logger.error(f"Student {student_sid} not found in class {class_code}")
            logger.error(f"Available students: {list(class_data['students'].keys())}")
            raise HTTPException(status_code=404, detail="Student not found")
        
        student_data = class_data['students'][student_sid]
        logger.info(f"Found student data: {student_data['name']}")
        
        # Generate PDF
        logger.info("Starting PDF generation...")
        pdf_content = pdf_generator.generate_report(
            student_name=student_data['name'],
            quiz_title=class_data['quiz_data']['title'],
            questions=class_data['quiz_data']['questions'],
            student_answers=student_data['answers']
        )
        logger.info(f"PDF generated successfully, size: {len(pdf_content)} bytes")
        
        # Return PDF response
        return Response(
            content=pdf_content,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=quiz_report_{student_data['name']}.pdf"}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error generating PDF report: {e}")
        logger.error(f"Error type: {type(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to generate report: {str(e)}")

@app.get("/api")
async def api_info():
    """API information endpoint."""
    return {"message": "Real-Time Quiz Application API", "status": "running"}

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "active_classes": len(quiz_manager.active_classes)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(socket_app, host="0.0.0.0", port=8000, log_level="info") 





    