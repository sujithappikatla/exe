import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from fpdf import FPDF
import unicodedata

logger = logging.getLogger(__name__)

class PDFGenerator:
    """Generates PDF reports for quiz results."""
    
    def __init__(self):
        pass
    
    def _clean_text(self, text: str) -> str:
        """Clean text by replacing Unicode characters with ASCII equivalents."""
        if not text:
            return ""
        
        # Replace common Unicode characters with ASCII equivalents
        replacements = {
            ''': "'",  # Left single quotation mark
            ''': "'",  # Right single quotation mark
            '"': '"',  # Left double quotation mark
            '"': '"',  # Right double quotation mark
            '–': '-',  # En dash
            '—': '-',  # Em dash
            '…': '...',  # Horizontal ellipsis
            '°': ' degrees',  # Degree symbol
            '×': 'x',  # Multiplication sign
            '÷': '/',  # Division sign
            '±': '+/-',  # Plus-minus sign
        }
        
        # Apply replacements
        cleaned_text = text
        for unicode_char, ascii_replacement in replacements.items():
            cleaned_text = cleaned_text.replace(unicode_char, ascii_replacement)
        
        # Normalize to ASCII (this will convert accented characters)
        try:
            cleaned_text = unicodedata.normalize('NFKD', cleaned_text)
            cleaned_text = cleaned_text.encode('ascii', 'ignore').decode('ascii')
        except Exception:
            # If normalization fails, just remove non-ASCII characters
            cleaned_text = ''.join(char for char in cleaned_text if ord(char) < 128)
        
        return cleaned_text
    
    def generate_report(self, student_name: str, quiz_title: str, questions: List[Dict[str, Any]], student_answers: Dict[str, str]) -> bytes:
        """Generate a PDF report for a student's quiz results."""
        try:
            # Clean input text
            student_name = self._clean_text(student_name)
            quiz_title = self._clean_text(quiz_title)
            
            # Create PDF instance with better margins
            pdf = FPDF()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.set_margins(15, 15, 15)
            pdf.add_page()
            
            # Header with background color
            pdf.set_fill_color(41, 128, 185)  # Professional blue
            pdf.set_text_color(255, 255, 255)  # White text
            pdf.set_font('Arial', 'B', 18)
            pdf.cell(0, 15, 'Quiz Report', 0, 1, 'C', True)
            pdf.ln(8)
            
            # Quiz details section with light background
            pdf.set_fill_color(245, 245, 245)  # Light gray background
            pdf.set_text_color(0, 0, 0)  # Black text
            pdf.set_font('Arial', 'B', 12)
            pdf.cell(0, 8, 'Quiz Information', 0, 1, 'L', True)
            pdf.ln(2)
            
            # Quiz details
            pdf.set_font('Arial', '', 11)
            pdf.cell(30, 6, 'Quiz:', 0, 0, 'L')
            pdf.set_font('Arial', 'B', 11)
            pdf.cell(0, 6, quiz_title, 0, 1, 'L')
            
            pdf.set_font('Arial', '', 11)
            pdf.cell(30, 6, 'Student:', 0, 0, 'L')
            pdf.set_font('Arial', 'B', 11)
            pdf.cell(0, 6, student_name, 0, 1, 'L')
            
            pdf.set_font('Arial', '', 11)
            pdf.cell(30, 6, 'Date:', 0, 0, 'L')
            pdf.set_font('Arial', 'B', 11)
            pdf.cell(0, 6, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), 0, 1, 'L')
            pdf.ln(8)
            
            # Calculate score
            correct_answers = 0
            total_questions = len(questions)
            
            for question in questions:
                student_answer = student_answers.get(question['id'])
                if student_answer == question['correct_option']:
                    correct_answers += 1
            
            # Score summary with color coding
            percentage = (correct_answers/total_questions*100) if total_questions > 0 else 0
            if percentage >= 80:
                score_color = (39, 174, 96)  # Green
            elif percentage >= 60:
                score_color = (243, 156, 18)  # Orange
            else:
                score_color = (231, 76, 60)   # Red
                
            pdf.set_fill_color(*score_color)
            pdf.set_text_color(255, 255, 255)  # White text
            pdf.set_font('Arial', 'B', 14)
            pdf.cell(0, 12, f'Final Score: {correct_answers}/{total_questions} ({percentage:.1f}%)', 0, 1, 'C', True)
            pdf.ln(10)
            
            # Questions and answers section header
            pdf.set_fill_color(52, 73, 94)  # Dark blue-gray
            pdf.set_text_color(255, 255, 255)  # White text
            pdf.set_font('Arial', 'B', 12)
            pdf.cell(0, 10, 'Detailed Results', 0, 1, 'L', True)
            pdf.ln(5)
            
            for i, question in enumerate(questions, 1):
                # Add page break if needed
                if pdf.get_y() > 240:
                    pdf.add_page()
                
                student_answer = student_answers.get(question['id'])
                is_correct = student_answer == question['correct_option']
                
                # Question header with light background
                pdf.set_fill_color(236, 240, 241)  # Very light gray
                pdf.set_text_color(44, 62, 80)  # Dark gray
                pdf.set_font('Arial', 'B', 11)
                pdf.cell(0, 8, f'Question {i}', 0, 1, 'L', True)
                pdf.ln(2)
                
                # Question text using manual text wrapping
                pdf.set_text_color(0, 0, 0)  # Black text
                pdf.set_font('Arial', '', 10)
                question_text = self._clean_text(question['text'])
                
                # Use manual text wrapping for better control
                question_lines = self._wrap_text(question_text, 85)
                for line in question_lines:
                    pdf.cell(0, 6, line, 0, 1)
                pdf.ln(3)
                
                # Options with better formatting
                pdf.set_font('Arial', 'B', 9)
                pdf.set_text_color(44, 62, 80)  # Dark gray
                pdf.cell(0, 5, 'Options:', 0, 1)
                pdf.ln(1)
                
                pdf.set_font('Arial', '', 9)
                for j, option in enumerate(question['options']):
                    option_letter = chr(65 + j)  # A, B, C, D...
                    cleaned_option = self._clean_text(option)
                    
                    # Handle long options with manual wrapping
                    option_text = f'   {option_letter}) {cleaned_option}'
                    if len(option_text) > 80:
                        # Use manual text wrapping
                        option_lines = self._wrap_text(option_text, 80)
                        for line in option_lines:
                            pdf.cell(0, 5, line, 0, 1)
                    else:
                        pdf.cell(0, 5, option_text, 0, 1)
                
                pdf.ln(3)
                
                # Answer section with color coding
                pdf.set_font('Arial', 'B', 9)
                
                # Student's answer
                if student_answer:
                    try:
                        student_option_index = question['options'].index(student_answer)
                        student_option_letter = chr(65 + student_option_index)
                        cleaned_student_answer = self._clean_text(student_answer)
                        
                        if is_correct:
                            pdf.set_text_color(39, 174, 96)  # Green for correct
                        else:
                            pdf.set_text_color(231, 76, 60)   # Red for incorrect
                            
                        answer_text = f'Your Answer: {student_option_letter}) {cleaned_student_answer}'
                        answer_lines = self._wrap_text(answer_text, 80)
                        for line in answer_lines:
                            pdf.cell(0, 5, line, 0, 1)
                    except ValueError:
                        cleaned_student_answer = self._clean_text(student_answer)
                        pdf.set_text_color(231, 76, 60)   # Red
                        answer_text = f'Your Answer: {cleaned_student_answer}'
                        answer_lines = self._wrap_text(answer_text, 80)
                        for line in answer_lines:
                            pdf.cell(0, 5, line, 0, 1)
                else:
                    pdf.set_text_color(149, 165, 166)  # Gray for no answer
                    pdf.set_font('Arial', 'I', 9)
                    pdf.cell(0, 5, 'Your Answer: No answer provided', 0, 1)
                
                # Correct answer
                try:
                    correct_option_index = question['options'].index(question['correct_option'])
                    correct_option_letter = chr(65 + correct_option_index)
                    cleaned_correct_answer = self._clean_text(question['correct_option'])
                    pdf.set_text_color(39, 174, 96)  # Green for correct answer
                    pdf.set_font('Arial', 'B', 9)
                    correct_text = f'Correct Answer: {correct_option_letter}) {cleaned_correct_answer}'
                    correct_lines = self._wrap_text(correct_text, 80)
                    for line in correct_lines:
                        pdf.cell(0, 5, line, 0, 1)
                except ValueError:
                    cleaned_correct_answer = self._clean_text(question['correct_option'])
                    pdf.set_text_color(39, 174, 96)  # Green
                    pdf.set_font('Arial', 'B', 9)
                    correct_text = f'Correct Answer: {cleaned_correct_answer}'
                    correct_lines = self._wrap_text(correct_text, 80)
                    for line in correct_lines:
                        pdf.cell(0, 5, line, 0, 1)
                
                # Result indicator with background
                pdf.ln(2)
                if is_correct:
                    pdf.set_fill_color(39, 174, 96)  # Green background
                    result_text = 'CORRECT'
                else:
                    pdf.set_fill_color(231, 76, 60)  # Red background
                    result_text = 'INCORRECT'
                    
                pdf.set_text_color(255, 255, 255)  # White text
                pdf.set_font('Arial', 'B', 9)
                pdf.cell(50, 6, f'Result: {result_text}', 0, 1, 'C', True)
                
                # Reset text color
                pdf.set_text_color(0, 0, 0)
                
                # Add reasoning if available with better formatting
                reasoning = question.get('reasoning')
                if reasoning:
                    pdf.ln(4)
                    
                    # Explanations header with background
                    pdf.set_fill_color(189, 195, 199)  # Light gray
                    pdf.set_text_color(44, 62, 80)     # Dark gray text
                    pdf.set_font('Arial', 'B', 9)
                    pdf.cell(0, 6, 'Explanations:', 0, 1, 'L', True)
                    pdf.ln(2)
                    
                    for j, option in enumerate(question['options']):
                        option_letter = chr(65 + j)  # A, B, C, D...
                        explanation = reasoning.get(option, '')
                        if explanation:
                            # Check if we need a page break
                            if pdf.get_y() > 260:
                                pdf.add_page()
                            
                            # Option header
                            cleaned_option = self._clean_text(option)
                            pdf.set_text_color(52, 73, 94)  # Dark blue-gray
                            pdf.set_font('Arial', 'B', 8)
                            
                            # Option header with simple approach
                            option_header = f'{option_letter}) {cleaned_option}:'
                            option_lines = self._wrap_text(option_header, 80)
                            for line in option_lines:
                                pdf.cell(0, 5, line, 0, 1)
                            
                            # Explanation text
                            pdf.set_text_color(0, 0, 0)  # Black text
                            pdf.set_font('Arial', '', 8)
                            cleaned_explanation = self._clean_text(explanation)
                            
                            # Use simple text wrapping instead of problematic multi_cell
                            explanation_lines = self._wrap_text(cleaned_explanation, 75)
                            for line in explanation_lines:
                                if pdf.get_y() > 270:
                                    pdf.add_page()
                                pdf.cell(0, 4, f'      {line}', 0, 1)
                            pdf.ln(2)
                
                # Add separator line between questions
                pdf.ln(3)
                pdf.set_draw_color(189, 195, 199)  # Light gray line
                # Line from left margin to right margin
                pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
                pdf.ln(8)
            
            # Footer with styling
            pdf.ln(10)
            pdf.set_draw_color(189, 195, 199)  # Light gray line
            # Line from left margin to right margin
            pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
            pdf.ln(5)
            
            pdf.set_text_color(127, 140, 141)  # Gray text
            pdf.set_font('Arial', 'I', 8)
            pdf.cell(0, 5, 'Generated by Real-Time Quiz Application', 0, 1, 'C')
            
            # Reset colors for any additional content
            pdf.set_text_color(0, 0, 0)
            pdf.set_draw_color(0, 0, 0)
            
            # Return PDF as bytes
            pdf_output = pdf.output(dest='S')
            return bytes(pdf_output) if isinstance(pdf_output, bytearray) else pdf_output
            
        except Exception as e:
            logger.error(f"Error generating PDF report: {e}")
            # Return a simple error PDF
            error_pdf = FPDF()
            error_pdf.add_page()
            error_pdf.set_font('Arial', 'B', 16)
            error_pdf.cell(0, 10, 'Error Generating Report', 0, 1, 'C')
            error_pdf.ln(10)
            error_pdf.set_font('Arial', '', 12)
            error_pdf.cell(0, 8, 'Sorry, there was an error generating your quiz report.', 0, 1, 'C')
            error_pdf.cell(0, 8, 'Please contact your teacher for assistance.', 0, 1, 'C')
            error_output = error_pdf.output(dest='S')
            return bytes(error_output) if isinstance(error_output, bytearray) else error_output
    
    def _wrap_text(self, text: str, max_width: int = 80) -> List[str]:
        """Helper method to wrap long text into multiple lines based on character count."""
        if not text:
            return []
            
        if len(text) <= max_width:
            return [text]
        
        words = text.split(' ')
        lines = []
        current_line = ""
        
        for word in words:
            # Check if adding this word would exceed the limit
            test_line = current_line + word + " "
            if len(test_line.strip()) <= max_width:
                current_line = test_line
            else:
                # Current line is full, save it and start new line
                if current_line.strip():
                    lines.append(current_line.strip())
                
                # Handle very long words that exceed max_width
                if len(word) > max_width:
                    # Split the word itself
                    while len(word) > max_width:
                        lines.append(word[:max_width])
                        word = word[max_width:]
                    current_line = word + " " if word else ""
                else:
                    current_line = word + " "
        
        # Add any remaining text
        if current_line.strip():
            lines.append(current_line.strip())
        
        return lines 