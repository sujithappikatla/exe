# Real-Time Quiz Application: Technical Specification

This document provides a detailed technical specification for building a real-time, multi-class quiz application using Python (FastAPI) and Socket.IO.

---

## 1. Core Features

### 1.1. Teacher Perspective

*   **Class Management:**
    *   **Create Class:** A teacher can start a new quiz session, which generates a unique 6-digit alphanumeric class code.
    *   **Lobby View:** Before the quiz starts, the teacher can see the class code and a live list of students who have joined the room.
*   **Quiz Control:**
    *   **Start/End Quiz:** Manually start and end the quiz for all students.
    *   **Question Navigation:** The teacher uploads the entire quiz at the start. During the quiz, they use "Next" and "Previous" controls to navigate through the questions. The server keeps track of the current position.
*   **Real-time Monitoring:**
    *   **Live Answer Tracking:** During a question, the teacher's dashboard shows which students have submitted an answer and which have not. The actual answers are not revealed to the teacher until the question time is over.
*   **Instruction Flow:**
    *   **Synchronized Timer:** Each question has a timer that is synchronized across all devices. The teacher can **pause** and **resume** this timer.
    *   **Explanation Pause:** After a question's timer expires, the application enters a "pause" state. The correct answer is revealed, allowing the teacher to explain it before moving on.

### 1.2. Student Perspective

*   **Joining a Class:**
    *   **Join with Code:** Students join a quiz session using the 6-digit code provided by the teacher and by providing a name.
    *   **Waiting Room:** After joining, students wait in a lobby until the teacher starts the quiz.
*   **Quiz Participation:**
    *   **Receive Questions:** The current question appears automatically on the student's screen.
    *   **Answer Submission:** Students select one of the provided options. The submission is locked in once chosen. Submissions are only accepted when the timer is actively running.
*   **Post-Quiz:**
    *   **Results Summary:** Students can view their final score.
    *   **PDF Report:** Students can download a PDF containing all questions, correct answers, reasoning for each option, and their own submitted answers.

### 1.3. Question Reasoning (Optional Feature)

*   **Enhanced Learning:** Each question can optionally include reasoning/explanation for each answer option.
*   **Educational Value:** The reasoning explains why each option is correct or incorrect, helping students learn from their mistakes.
*   **Flexible Implementation:** The reasoning field is optional - questions can be created with or without reasoning.
*   **PDF Integration:** When generating PDF reports, the reasoning for each option is included to provide comprehensive feedback.

---

## 2. Question Data Structure

Each question in the quiz can optionally include detailed reasoning for each answer option. The question structure is as follows:

```json
{
  "id": "unique_question_id",
  "text": "Question text here",
  "options": ["Option A", "Option B", "Option C"],
  "correct_option": "Option B",
  "timer": 30,
  "reasoning": {
    "Option A": "Explanation of why this option is incorrect",
    "Option B": "Explanation of why this option is correct",
    "Option C": "Explanation of why this option is incorrect"
  }
}
```

**Key Points:**
- The `reasoning` field is **optional** and can be omitted if not needed
- The `reasoning` object uses option text as keys and explanations as values
- Reasoning is included in PDF reports but not sent to students during the quiz
- Teachers can see the reasoning to help with explanations during the pause phase

---

## 3. Technical Stack

*   **Backend:** Python with **FastAPI**
*   **Real-Time Communication:** **`python-socketio`** library
*   **Frontend:** Any modern JavaScript framework (e.g., React, Vue, Svelte).

---

## 4. Communication Protocol (Socket.IO)

Communication between the server and clients (teacher/student browsers) will be handled via Socket.IO events. All data payloads will be in JSON format.

### 4.1. Socket.IO Rooms

*   A unique **Socket.IO Room** will be created for each class.
*   The room name will be the **6-digit class code**.
*   The server will manage joining and leaving these rooms to ensure that broadcasts only go to the intended class participants.

### 4.2. Event Naming Convention

*   **Client to Server (C2S):** Events sent from a browser to the server. `c2s_...`
*   **Server to Client (S2C):** Events sent from the server to one or more browsers. `s2c_...`

### 4.3. Socket.IO Events & Payloads

#### **Lobby & Connection Management**

*   **`c2s_create_class`**
    *   **Direction:** Teacher -> Server
    *   **Description:** A teacher requests to create a new class and uploads the entire quiz dataset. The server will store this data for the duration of the session.
    *   **Payload:**
        ```json
        {
          "teacher_name": "Mr. Smith",
          "quiz_data": {
            "title": "Algebra 101 Quiz",
            "questions": [
              {
                "id": "q1",
                "text": "What is 2 + 2?",
                "options": ["3", "4", "5"],
                "correct_option": "4",
                "timer": 30,
                "reasoning": {
                  "3": "This is incorrect. 2 + 2 equals 4, not 3.",
                  "4": "This is correct. 2 + 2 = 4 is basic addition.",
                  "5": "This is incorrect. 2 + 2 equals 4, not 5."
                }
              },
              {
                "id": "q2",
                "text": "What is the capital of France?",
                "options": ["London", "Berlin", "Paris"],
                "correct_option": "Paris",
                "timer": 25,
                "reasoning": {
                  "London": "This is incorrect. London is the capital of the United Kingdom.",
                  "Berlin": "This is incorrect. Berlin is the capital of Germany.",
                  "Paris": "This is correct. Paris is the capital city of France."
                }
              }
            ]
          }
        }
        ```
    *   **Server Response:** The server creates a unique 6-digit room code and sends it back.

*   **`s2c_class_created`**
    *   **Direction:** Server -> Teacher
    *   **Description:** Confirms class creation and provides the room code.
    *   **Payload:**
        ```json
        {
          "class_code": "A1B2C3"
        }
        ```

*   **`c2s_join_class`**
    *   **Direction:** Student -> Server
    *   **Description:** A student requests to join a class.
    *   **Payload:**
        ```json
        {
          "class_code": "A1B2C3",
          "student_name": "Alice"
        }
        ```

*   **`s2c_student_joined`**
    *   **Direction:** Server -> Teacher (in the specific class room)
    *   **Description:** Notifies the teacher that a new student has joined the lobby.
    *   **Payload:**
        ```json
        {
          "students": [
            {"id": "socket_id_1", "name": "Alice"},
            {"id": "socket_id_2", "name": "Bob"}
          ]
        }
        ```

*   **`s2c_join_successful`**
    *   **Direction:** Server -> Student
    *   **Description:** Confirms to the student that they have successfully joined the room and are in the waiting lobby.
    *   **Payload:**
        ```json
        {
          "message": "Waiting for the teacher to start the quiz."
        }
        ```

#### **Quiz Flow & Control**

*   **`c2s_start_quiz`**
    *   **Direction:** Teacher -> Server
    *   **Description:** The teacher starts the quiz, which triggers the server to send the first question (at index 0) to all participants.
    *   **Payload:** `{}`

*   **`c2s_navigate_question`**
    *   **Direction:** Teacher -> Server
    *   **Description:** Teacher requests to move to the next or previous question. The server finds the appropriate question in the stored list and broadcasts it.
    *   **Payload:**
        ```json
        {
          "direction": "next"
        }
        ```

*   **`s2c_load_question`**
    *   **Direction:** Server -> All in Room (Teacher + Students)
    *   **Description:** Sent to all participants to load the current question and start the timer. The `correct_option` is **omitted** for students.
    *   **Payload (Student Version):**
        ```json
        {
          "id": "q1",
          "text": "What is 2 + 2?",
          "options": ["3", "4", "5"],
          "timer": 30
        }
        ```
    *   **Payload (Teacher Version):** Includes correct answer and student status.
        ```json
        {
          "id": "q1",
          "text": "What is 2 + 2?",
          "options": ["3", "4", "5"],
          "correct_option": "4",
          "timer": 30,
          "students_status": [
            {"name": "Alice", "answered": false},
            {"name": "Bob", "answered": false}
          ]
        }
        ```

*   **`c2s_submit_answer`**
    *   **Direction:** Student -> Server
    *   **Description:** A student submits their answer for the current question. The server will only accept this if the quiz is active and the timer for the current question is in a 'running' state (not paused or stopped).
    *   **Payload:**
        ```json
        {
          "question_id": "q1",
          "answer": "4"
        }
        ```

*   **`s2c_update_student_status`**
    *   **Direction:** Server -> Teacher
    *   **Description:** Informs the teacher in real-time when a student has submitted an answer.
    *   **Payload:**
        ```json
        {
          "students_status": [
            {"name": "Alice", "answered": true},
            {"name": "Bob", "answered": false}
          ]
        }
        ```

*   **`s2c_question_timeout`**
    *   **Direction:** Server -> All in Room
    *   **Description:** Notifies everyone that the time for the current question is up. The application enters the "explanation pause" state.
    *   **Payload:**
        ```json
        {
          "question_id": "q1",
          "correct_option": "4"
        }
        ```

*   **`c2s_pause_timer`**
    *   **Direction:** Teacher -> Server
    *   **Description:** Teacher requests to pause the current question's timer. The server will record the remaining time.
    *   **Payload:** `{}`

*   **`s2c_timer_paused`**
    *   **Direction:** Server -> All in Room
    *   **Description:** Notifies all clients that the timer has been paused. Clients should halt their countdown display and disable answer submission.
    *   **Payload:** `{}`

*   **`c2s_resume_timer`**
    *   **Direction:** Teacher -> Server
    *   **Description:** Teacher requests to resume the timer.
    *   **Payload:** `{}`

*   **`s2c_timer_resumed`**
    *   **Direction:** Server -> All in Room
    *   **Description:** Notifies all clients to resume the countdown.
    *   **Payload:**
        ```json
        {
          "time_remaining": 18
        }
        ```

*   **`c2s_end_quiz`**
    *   **Direction:** Teacher -> Server
    *   **Description:** Teacher ends the quiz for everyone.
    *   **Payload:** `{}`

*   **`s2c_quiz_finished`**
    *   **Direction:** Server -> All in Room
    *   **Description:** Informs all participants that the quiz has ended and provides final results.
    *   **Payload (Student Version):**
        ```json
        {
          "results": {
            "score": 1,
            "total_questions": 2,
            "summary": [
              {
                "question_id": "q1",
                "question_text": "What is 2 + 2?",
                "options": ["3", "4", "5"],
                "your_answer": "4",
                "correct_answer": "4"
              },
              {
                "question_id": "q2",
                "question_text": "What is the capital of France?",
                "options": ["London", "Berlin", "Paris"],
                "your_answer": "London",
                "correct_answer": "Paris"
              }
            ]
          }
        }
        ```

*   **`s2c_quiz_statistics`**
    *   **Direction:** Server -> Teacher
    *   **Description:** Sent to the teacher immediately after quiz completion, providing comprehensive analytics and statistics about the quiz performance, student engagement, and question analysis.
    *   **Payload:**
        ```json
        {
          "quiz_overview": {
            "quiz_title": "Algebra 101 Quiz",
            "total_questions": 5,
            "total_students_joined": 25,
            "students_participated": 23,
            "completion_rate": 92.0
          },
          "performance_summary": {
            "average_score": 3.2,
            "average_percentage": 64.0,
            "highest_score": 5,
            "lowest_score": 1,
            "score_distribution": {
              "0-20%": 2,
              "21-40%": 3,
              "41-60%": 8,
              "61-80%": 7,
              "81-100%": 5
            }
          },
          "top_performers": [
            {
              "rank": 1,
              "name": "Alice Johnson",
              "score": 5,
              "percentage": 100.0,
              "total_answered": 5
            },
            {
              "rank": 2,
              "name": "Bob Smith",
              "score": 4,
              "percentage": 80.0,
              "total_answered": 5
            }
          ],
          "bottom_performers": [
            {
              "name": "Charlie Brown",
              "score": 1,
              "percentage": 20.0,
              "total_answered": 3
            }
          ],
          "question_analysis": [
            {
              "question_id": "q1",
              "question_text": "What is 2 + 2?",
              "total_students": 25,
              "total_answered": 24,
              "correct_answers": 22,
              "wrong_answers": 2,
              "success_rate": 88.0,
              "response_rate": 96.0,
              "difficulty_level": "Easy",
              "option_distribution": {
                "3": 1,
                "4": 22,
                "5": 1,
                "No Answer": 1
              },
              "most_popular_wrong_answer": {
                "option": "3",
                "count": 1
              }
            }
          ],
          "most_difficult_questions": [
            {
              "question_id": "q3",
              "question_text": "Solve for x: 2x + 5 = 15",
              "success_rate": 45.0,
              "difficulty_level": "Hard"
            }
          ],
          "least_difficult_questions": [
            {
              "question_id": "q1",
              "question_text": "What is 2 + 2?",
              "success_rate": 88.0,
              "difficulty_level": "Easy"
            }
          ],
          "participation_stats": {
            "full_participation": 20,
            "partial_participation": 3,
            "no_participation": 2,
            "average_response_rate": 89.2
          },
          "engagement_insights": {
            "students_answered_all": 20,
            "students_answered_none": 2,
            "students_answered_some": 3,
            "most_engaged_students": ["Alice Johnson", "Bob Smith", "Carol Davis"],
            "least_engaged_students": ["Dave Wilson", "Eve Martinez"]
          }
        }
        ```

#### **Error Handling**

*   **`s2c_error`**
    *   **Direction:** Server -> Client (specific one)
    *   **Description:** Used to send an error message to a specific client (e.g., student enters wrong class code).
    *   **Payload:**
        ```json
        {
          "message": "Invalid class code. Please try again."
        }
        ```

### 3.4. Timer Synchronization

Sending a time update every second (`tick`) from the server to all clients is inefficient and prone to network delays, causing timers to become unsynchronized.

A more robust and efficient approach is as follows:

1.  **Send Duration Once:** When the server sends the `s2c_load_question` event, it includes the total duration for that question (e.g., `timer: 30`).
2.  **Client-Side Countdown:** Upon receiving the question, each client (teacher and student) starts its own local countdown timer.
3.  **Server as Authority:** The server also starts its own authoritative timer for the same duration.
4.  **Pause and Resume:**
    *   On `c2s_pause_timer`, the server stops its authoritative timer and records the remaining time. It then broadcasts `s2c_timer_paused`. Clients should freeze their countdown display.
    *   On `c2s_resume_timer`, the server broadcasts `s2c_timer_resumed` with the remaining time. Clients restart their countdowns from this new value. The server also restarts its authoritative timer.
5.  **Timeout Event:** When the server's authoritative timer finally finishes, it broadcasts the `s2c_question_timeout` event. This is the single source of truth that the time is up. This forces any slightly out-of-sync clients to end the question and prevents late submissions.

This method ensures the user experience is smooth while the server remains in full control of the official timing.

---

## 5. Server-Side Data Structure

To manage multiple concurrent classes, the server should maintain an in-memory data structure. A Python dictionary is a suitable choice for this. This structure will be the single source of truth for the state of all active quizzes.

**Example Structure:**

```python
# A dictionary where each key is a unique 6-digit class_code.
# This top-level object holds all active classes.
# The data is cleared when a class ends.
active_classes = {
    "A1B2C3": {
        "teacher_sid": "teacher_socket_id_xyz",
        "quiz_data": {
            "title": "Algebra 101 Quiz",
            "questions": [
                # ... list of question objects ...
            ]
        },
        "quiz_state": {
            "current_question_index": 0,
            "timer_state": "running",  # "running", "paused", "stopped"
            "time_remaining_on_pause": 0,
            # Server-side timer object would also be stored here
        },
        "students": {
            # Key is the student's socket ID (sid) for quick lookups
            "student_socket_id_abc": {
                "name": "Alice",
                "answers": {
                    # Key is question_id, value is the submitted answer
                    "q1": "4",
                    "q2": "London"
                }
            },
            "student_socket_id_def": {
                "name": "Bob",
                "answers": {
                    "q1": "5"
                }
            }
        }
    },
    "D4E5F6": {
        # ... data for another class ...
    }
}
```

---

## 6. PDF Generation

*   **Trigger:** The student will request the PDF download from their final results screen.
*   **Implementation:** This can be handled by a standard FastAPI REST endpoint (e.g., `/download-report/{student_id}`).
*   **Data:** The server will use the stored session data (all questions, correct answers, reasoning for each option, and the student's answers) to generate the PDF. Libraries like `FPDF2` or `ReportLab` can be used for this purpose in Python.
*   **Enhanced Content:** The PDF will include:
    *   Student's name and quiz title
    *   Overall score and percentage
    *   For each question: question text, all options, student's answer, correct answer
    *   **Reasoning:** If available, explanations for why each option is correct or incorrect
    *   Clear marking of correct/incorrect answers
*   **Response:** The endpoint will return a response with `Content-Type: application/pdf`. 