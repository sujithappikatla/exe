from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

class Question(BaseModel):
    """Model for a quiz question."""
    id: str
    text: str
    options: List[str]
    correct_option: str
    timer: int = Field(gt=0, description="Timer in seconds")
    reasoning: Optional[Dict[str, str]] = Field(None, description="Optional reasoning for each option")

class QuizData(BaseModel):
    """Model for quiz data."""
    title: str
    questions: List[Question]

class CreateClassRequest(BaseModel):
    """Request model for creating a class."""
    teacher_name: str
    quiz_data: QuizData

class JoinClassRequest(BaseModel):
    """Request model for joining a class."""
    class_code: str = Field(min_length=6, max_length=6)
    student_name: str

class SubmitAnswerRequest(BaseModel):
    """Request model for submitting an answer."""
    question_id: str
    answer: str

class NavigateQuestionRequest(BaseModel):
    """Request model for navigating questions."""
    direction: str = Field(pattern="^(next|previous)$")

class StudentInfo(BaseModel):
    """Model for student information."""
    id: str
    name: str

class StudentsListResponse(BaseModel):
    """Response model for students list."""
    students: List[StudentInfo]

class ClassCreatedResponse(BaseModel):
    """Response model for class creation."""
    class_code: str

class JoinSuccessfulResponse(BaseModel):
    """Response model for successful join."""
    message: str

class StudentStatusInfo(BaseModel):
    """Model for student status information."""
    name: str
    answered: bool

class UpdateStudentStatusResponse(BaseModel):
    """Response model for student status updates."""
    students_status: List[StudentStatusInfo]

class QuestionForStudent(BaseModel):
    """Model for question sent to students (without correct answer)."""
    id: str
    text: str
    options: List[str]
    timer: int

class QuestionForTeacher(BaseModel):
    """Model for question sent to teacher (with correct answer and student status)."""
    id: str
    text: str
    options: List[str]
    correct_option: str
    timer: int
    students_status: List[StudentStatusInfo]

class QuestionTimeoutResponse(BaseModel):
    """Response model for question timeout."""
    question_id: str
    correct_option: str

class TimerResumedResponse(BaseModel):
    """Response model for timer resumed."""
    time_remaining: int

class QuestionSummary(BaseModel):
    """Model for question summary in results."""
    question_id: str
    question_text: str
    options: List[str]
    your_answer: Optional[str] = None
    correct_answer: str
    reasoning: Optional[Dict[str, str]] = None

class QuizResults(BaseModel):
    """Model for quiz results."""
    score: int
    total_questions: int
    summary: List[QuestionSummary]

class QuizFinishedResponse(BaseModel):
    """Response model for quiz finished."""
    results: QuizResults

class ErrorResponse(BaseModel):
    """Response model for errors."""
    message: str

class TimerPausedResponse(BaseModel):
    """Response model for timer paused."""
    pass  # Empty payload as per spec

class HealthCheckResponse(BaseModel):
    """Response model for health check."""
    status: str
    timestamp: str
    active_classes: int 