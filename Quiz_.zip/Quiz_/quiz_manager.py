import asyncio
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from models import QuizData, StudentStatusInfo, QuestionSummary

logger = logging.getLogger(__name__)

class QuizManager:
    """Manages all active quiz classes and their state."""
    
    def __init__(self):
        # Main data structure as specified in the requirements
        self.active_classes: Dict[str, Dict[str, Any]] = {}
        self.timer_tasks: Dict[str, asyncio.Task] = {}  # Track timer tasks
        self.cleanup_task: Optional[asyncio.Task] = None  # Track cleanup task
    
    def start_cleanup_task(self):
        """Start the periodic cleanup task if not already running."""
        if self.cleanup_task is None or self.cleanup_task.done():
            try:
                self.cleanup_task = asyncio.create_task(self._periodic_cleanup())
                logger.info("Started periodic cleanup task")
            except RuntimeError:
                # No event loop running, cleanup task will be started later
                logger.debug("No event loop running, cleanup task not started")
    
    async def create_class(self, class_code: str, teacher_sid: str, teacher_name: str, quiz_data: QuizData) -> bool:
        """Create a new quiz class."""
        try:
            # Start cleanup task on first class creation
            self.start_cleanup_task()
            
            self.active_classes[class_code] = {
                "teacher_sid": teacher_sid,
                "teacher_name": teacher_name,
                "quiz_data": {
                    "title": quiz_data.title,
                    "questions": [q.dict() for q in quiz_data.questions]
                },
                "quiz_state": {
                    "current_question_index": 0,
                    "timer_state": "stopped",  # "running", "paused", "stopped"
                    "time_remaining_on_pause": 0,
                    "quiz_started": False,
                    "quiz_ended": False
                },
                "students": {}
            }
            return True
        except Exception as e:
            logger.error(f"Error creating class {class_code}: {e}")
            return False
    
    async def add_student(self, class_code: str, student_sid: str, student_name: str) -> bool:
        """Add a student to a class."""
        try:
            if class_code not in self.active_classes:
                return False
            
            # Check if quiz has already started
            if self.active_classes[class_code]['quiz_state']['quiz_started']:
                return False
            
            self.active_classes[class_code]['students'][student_sid] = {
                "name": student_name,
                "answers": {}
            }
            return True
        except Exception as e:
            logger.error(f"Error adding student to class {class_code}: {e}")
            return False
    
    def get_students_list(self, class_code: str) -> List[Dict[str, str]]:
        """Get list of students in a class."""
        if class_code not in self.active_classes:
            return []
        
        students = []
        for sid, student_data in self.active_classes[class_code]['students'].items():
            students.append({
                "id": sid,
                "name": student_data['name']
            })
        return students
    
    def get_class_code_by_teacher(self, teacher_sid: str) -> Optional[str]:
        """Find class code by teacher socket ID."""
        for class_code, class_data in self.active_classes.items():
            if class_data['teacher_sid'] == teacher_sid:
                return class_code
        return None
    
    def get_class_code_by_student(self, student_sid: str) -> Optional[str]:
        """Find class code by student socket ID."""
        for class_code, class_data in self.active_classes.items():
            if student_sid in class_data['students']:
                return class_code
        return None
    
    async def start_quiz(self, class_code: str, sio) -> bool:
        """Start the quiz and load the first question."""
        try:
            if class_code not in self.active_classes:
                return False
            
            class_data = self.active_classes[class_code]
            class_data['quiz_state']['quiz_started'] = True
            class_data['quiz_state']['current_question_index'] = 0
            
            # Load first question
            await self._load_current_question(class_code, sio)
            return True
        except Exception as e:
            logger.error(f"Error starting quiz for class {class_code}: {e}")
            return False
    
    async def navigate_question(self, class_code: str, direction: str, sio) -> bool:
        """Navigate to next or previous question."""
        try:
            if class_code not in self.active_classes:
                return False
            
            class_data = self.active_classes[class_code]
            quiz_state = class_data['quiz_state']
            questions = class_data['quiz_data']['questions']
            current_index = quiz_state['current_question_index']
            
            # Cancel current timer
            await self._cancel_timer(class_code)
            
            if direction == "next" and current_index < len(questions) - 1:
                quiz_state['current_question_index'] += 1
            elif direction == "previous" and current_index > 0:
                quiz_state['current_question_index'] -= 1
            else:
                return False  # Invalid navigation
            
            # Load the new question
            await self._load_current_question(class_code, sio)
            return True
        except Exception as e:
            logger.error(f"Error navigating question for class {class_code}: {e}")
            return False
    
    async def submit_answer(self, class_code: str, student_sid: str, question_id: str, answer: str, sio) -> bool:
        """Submit a student's answer."""
        try:
            if class_code not in self.active_classes:
                return False
            
            class_data = self.active_classes[class_code]
            
            # Check if student exists
            if student_sid not in class_data['students']:
                return False
            
            # Store the answer
            class_data['students'][student_sid]['answers'][question_id] = answer
            
            # Update teacher with student status
            await self._update_teacher_student_status(class_code, sio)
            return True
        except Exception as e:
            logger.error(f"Error submitting answer for class {class_code}: {e}")
            return False
    
    async def pause_timer(self, class_code: str, sio) -> bool:
        """Pause the current question timer."""
        try:
            if class_code not in self.active_classes:
                return False
            
            class_data = self.active_classes[class_code]
            quiz_state = class_data['quiz_state']
            
            if quiz_state['timer_state'] != 'running':
                return False
            
            # Calculate remaining time accurately
            if class_code in self.timer_tasks and 'timer_start_time' in quiz_state:
                timer_task = self.timer_tasks[class_code]
                if not timer_task.done():
                    elapsed_time = datetime.now().timestamp() - quiz_state['timer_start_time']
                    current_question = class_data['quiz_data']['questions'][quiz_state['current_question_index']]
                    quiz_state['time_remaining_on_pause'] = max(0, current_question['timer'] - int(elapsed_time))
                    timer_task.cancel()
            
            quiz_state['timer_state'] = 'paused'
            
            # Notify all clients
            await sio.emit('s2c_timer_paused', {}, room=class_code)
            return True
        except Exception as e:
            logger.error(f"Error pausing timer for class {class_code}: {e}")
            return False
    
    async def resume_timer(self, class_code: str, sio) -> bool:
        """Resume the current question timer."""
        try:
            if class_code not in self.active_classes:
                return False
            
            class_data = self.active_classes[class_code]
            quiz_state = class_data['quiz_state']
            
            if quiz_state['timer_state'] != 'paused':
                return False
            
            remaining_time = quiz_state['time_remaining_on_pause']
            quiz_state['timer_state'] = 'running'
            
            # Start timer with remaining time
            await self._start_question_timer_with_duration(class_code, remaining_time, sio)
            
            # Notify all clients to resume with remaining time
            await sio.emit('s2c_timer_resumed', {
                'time_remaining': remaining_time
            }, room=class_code)
            
            return True
        except Exception as e:
            logger.error(f"Error resuming timer for class {class_code}: {e}")
            return False
    
    async def end_quiz(self, class_code: str, sio) -> bool:
        """End the quiz and send results to all participants."""
        try:
            if class_code not in self.active_classes:
                return False
            
            class_data = self.active_classes[class_code]
            class_data['quiz_state']['quiz_ended'] = True
            class_data['quiz_state']['timer_state'] = 'stopped'
            
            # Cancel any running timer
            await self._cancel_timer(class_code)
            
            # Send results to all students
            await self._send_quiz_results(class_code, sio)
            
            # Generate and send comprehensive statistics to teacher
            await self._send_quiz_statistics(class_code, sio)
            
            return True
        except Exception as e:
            logger.error(f"Error ending quiz for class {class_code}: {e}")
            return False
    
    async def handle_disconnect(self, sid: str, sio):
        """Handle client disconnection."""
        try:
            # Check if this was a teacher
            class_code = self.get_class_code_by_teacher(sid)
            if class_code:
                # Check if quiz has ended
                class_data = self.active_classes[class_code]
                if class_data['quiz_state'].get('quiz_ended', False):
                    # Quiz has ended - keep class data for PDF generation
                    # Just mark teacher as disconnected but don't cleanup
                    class_data['teacher_disconnected'] = True
                    logger.info(f"Teacher disconnected from ended quiz {class_code}, keeping data for PDF generation")
                else:
                    # Quiz is still active - cleanup immediately
                    await self._cleanup_class(class_code)
                return
            
            # Check if this was a student
            class_code = self.get_class_code_by_student(sid)
            if class_code:
                # Remove student from class
                if class_code in self.active_classes:
                    if sid in self.active_classes[class_code]['students']:
                        del self.active_classes[class_code]['students'][sid]
                    
                    # Update teacher with updated student list if teacher is still connected
                    if not self.active_classes[class_code].get('teacher_disconnected', False):
                        teacher_sid = self.active_classes[class_code]['teacher_sid']
                        students_list = self.get_students_list(class_code)
                        await sio.emit('s2c_student_joined', {'students': students_list}, room=teacher_sid)
        except Exception as e:
            logger.error(f"Error handling disconnect for {sid}: {e}")
    
    async def _load_current_question(self, class_code: str, sio):
        """Load and broadcast the current question."""
        class_data = self.active_classes[class_code]
        quiz_state = class_data['quiz_state']
        questions = class_data['quiz_data']['questions']
        current_question = questions[quiz_state['current_question_index']]
        
        # Reset timer state
        quiz_state['timer_state'] = 'running'
        
        # Send question to students (without correct answer)
        student_question = {
            "id": current_question['id'],
            "text": current_question['text'],
            "options": current_question['options'],
            "timer": current_question['timer']
        }
        
        # Send to all students
        for student_sid in class_data['students'].keys():
            await sio.emit('s2c_load_question', student_question, room=student_sid)
        
        # Send question to teacher (with correct answer and student status)
        teacher_question = {
            "id": current_question['id'],
            "text": current_question['text'],
            "options": current_question['options'],
            "correct_option": current_question['correct_option'],
            "timer": current_question['timer'],
            "students_status": self._get_students_status(class_code, current_question['id'])
        }
        
        teacher_sid = class_data['teacher_sid']
        await sio.emit('s2c_load_question', teacher_question, room=teacher_sid)
        
        # Start the timer
        await self._start_question_timer(class_code, current_question['timer'], sio)
    
    async def _start_question_timer(self, class_code: str, duration: int, sio):
        """Start the authoritative timer for a question."""
        await self._start_question_timer_with_duration(class_code, duration, sio)
    
    async def _start_question_timer_with_duration(self, class_code: str, duration: int, sio):
        """Start the authoritative timer for a question with specific duration."""
        async def timer_task():
            try:
                await asyncio.sleep(duration)
                # Timer expired
                await self._handle_question_timeout(class_code, sio)
            except asyncio.CancelledError:
                pass  # Timer was cancelled (paused or question changed)
        
        # Cancel any existing timer
        await self._cancel_timer(class_code)
        
        # Record start time for accurate pause/resume
        if class_code in self.active_classes:
            self.active_classes[class_code]['quiz_state']['timer_start_time'] = datetime.now().timestamp()
        
        # Start new timer
        self.timer_tasks[class_code] = asyncio.create_task(timer_task())
    
    async def _cancel_timer(self, class_code: str):
        """Cancel the current timer for a class."""
        if class_code in self.timer_tasks:
            task = self.timer_tasks[class_code]
            if not task.done():
                task.cancel()
            del self.timer_tasks[class_code]
    
    async def _handle_question_timeout(self, class_code: str, sio):
        """Handle when a question timer expires."""
        try:
            class_data = self.active_classes[class_code]
            quiz_state = class_data['quiz_state']
            questions = class_data['quiz_data']['questions']
            current_question = questions[quiz_state['current_question_index']]
            
            quiz_state['timer_state'] = 'stopped'
            
            # Notify all clients that time is up
            await sio.emit('s2c_question_timeout', {
                'question_id': current_question['id'],
                'correct_option': current_question['correct_option']
            }, room=class_code)
            
        except Exception as e:
            logger.error(f"Error handling question timeout for class {class_code}: {e}")
    
    def _get_students_status(self, class_code: str, question_id: str) -> List[Dict[str, Any]]:
        """Get student status for a specific question."""
        class_data = self.active_classes[class_code]
        status = []
        
        for student_sid, student_data in class_data['students'].items():
            answered = question_id in student_data['answers']
            status.append({
                "name": student_data['name'],
                "answered": answered
            })
        
        return status
    
    async def _update_teacher_student_status(self, class_code: str, sio):
        """Update teacher with current student status."""
        class_data = self.active_classes[class_code]
        quiz_state = class_data['quiz_state']
        questions = class_data['quiz_data']['questions']
        current_question = questions[quiz_state['current_question_index']]
        
        students_status = self._get_students_status(class_code, current_question['id'])
        teacher_sid = class_data['teacher_sid']
        
        await sio.emit('s2c_update_student_status', {
            'students_status': students_status
        }, room=teacher_sid)
    
    async def _send_quiz_results(self, class_code: str, sio):
        """Send final quiz results to all students."""
        class_data = self.active_classes[class_code]
        questions = class_data['quiz_data']['questions']
        
        # Send results to each student
        for student_sid, student_data in class_data['students'].items():
            score = 0
            summary = []
            
            for question in questions:
                student_answer = student_data['answers'].get(question['id'])
                is_correct = student_answer == question['correct_option']
                if is_correct:
                    score += 1
                
                summary.append({
                    "question_id": question['id'],
                    "question_text": question['text'],
                    "options": question['options'],
                    "your_answer": student_answer,
                    "correct_answer": question['correct_option'],
                    "reasoning": question.get('reasoning')
                })
            
            results = {
                "score": score,
                "total_questions": len(questions),
                "summary": summary
            }
            
            await sio.emit('s2c_quiz_finished', {'results': results}, room=student_sid)
    
    async def _send_quiz_statistics(self, class_code: str, sio):
        """Generate and send comprehensive quiz statistics to the teacher."""
        try:
            class_data = self.active_classes[class_code]
            questions = class_data['quiz_data']['questions']
            students = class_data['students']
            teacher_sid = class_data['teacher_sid']
            
            if not students:
                return  # No students to analyze
            
            # Calculate individual student scores
            student_scores = []
            for student_sid, student_data in students.items():
                score = 0
                total_answered = 0
                question_details = []
                
                for question in questions:
                    student_answer = student_data['answers'].get(question['id'])
                    is_correct = student_answer == question['correct_option']
                    if student_answer is not None:
                        total_answered += 1
                        if is_correct:
                            score += 1
                    
                    question_details.append({
                        'question_id': question['id'],
                        'answered': student_answer is not None,
                        'correct': is_correct,
                        'answer': student_answer
                    })
                
                student_scores.append({
                    'name': student_data['name'],
                    'score': score,
                    'total_questions': len(questions),
                    'total_answered': total_answered,
                    'percentage': round((score / len(questions)) * 100, 1) if questions else 0,
                    'participation_rate': round((total_answered / len(questions)) * 100, 1) if questions else 0,
                    'question_details': question_details
                })
            
            # Sort by score for rankings
            student_scores.sort(key=lambda x: x['score'], reverse=True)
            
            # Top performers (up to 5)
            top_performers = student_scores[:5]
            
            # Bottom performers (up to 3, but only if more than 5 students)
            bottom_performers = student_scores[-3:] if len(student_scores) > 5 else []
            
            # Question-wise analysis
            question_analysis = []
            for question in questions:
                total_answered = 0
                correct_answers = 0
                wrong_answers = 0
                option_distribution = {}
                
                # Initialize option distribution
                for option in question['options']:
                    option_distribution[option] = 0
                option_distribution['No Answer'] = 0
                
                # Analyze each student's response
                for student_data in students.values():
                    answer = student_data['answers'].get(question['id'])
                    if answer is not None:
                        total_answered += 1
                        option_distribution[answer] += 1
                        if answer == question['correct_option']:
                            correct_answers += 1
                        else:
                            wrong_answers += 1
                    else:
                        option_distribution['No Answer'] += 1
                
                success_rate = round((correct_answers / len(students)) * 100, 1) if students else 0
                response_rate = round((total_answered / len(students)) * 100, 1) if students else 0
                
                # Find most popular wrong answer
                wrong_options = {k: v for k, v in option_distribution.items() 
                               if k != question['correct_option'] and k != 'No Answer' and v > 0}
                most_popular_wrong = max(wrong_options.items(), key=lambda x: x[1]) if wrong_options else None
                
                question_analysis.append({
                    'question_id': question['id'],
                    'question_text': question['text'][:100] + ('...' if len(question['text']) > 100 else ''),
                    'total_students': len(students),
                    'total_answered': total_answered,
                    'correct_answers': correct_answers,
                    'wrong_answers': wrong_answers,
                    'success_rate': success_rate,
                    'response_rate': response_rate,
                    'difficulty_level': 'Easy' if success_rate >= 80 else 'Medium' if success_rate >= 60 else 'Hard',
                    'option_distribution': option_distribution,
                    'most_popular_wrong_answer': {
                        'option': most_popular_wrong[0],
                        'count': most_popular_wrong[1]
                    } if most_popular_wrong else None
                })
            
            # Overall quiz statistics
            total_students = len(students)
            students_participated = sum(1 for s in student_scores if s['total_answered'] > 0)
            average_score = sum(s['score'] for s in student_scores) / total_students if total_students else 0
            average_percentage = sum(s['percentage'] for s in student_scores) / total_students if total_students else 0
            
            # Score distribution
            score_ranges = {'0-20%': 0, '21-40%': 0, '41-60%': 0, '61-80%': 0, '81-100%': 0}
            for student in student_scores:
                if student['percentage'] <= 20:
                    score_ranges['0-20%'] += 1
                elif student['percentage'] <= 40:
                    score_ranges['21-40%'] += 1
                elif student['percentage'] <= 60:
                    score_ranges['41-60%'] += 1
                elif student['percentage'] <= 80:
                    score_ranges['61-80%'] += 1
                else:
                    score_ranges['81-100%'] += 1
            
            # Find most and least difficult questions
            question_analysis.sort(key=lambda x: x['success_rate'])
            most_difficult = question_analysis[:3] if len(question_analysis) >= 3 else question_analysis
            least_difficult = question_analysis[-3:] if len(question_analysis) >= 3 else []
            
            # Participation insights
            full_participation = sum(1 for s in student_scores if s['participation_rate'] == 100)
            partial_participation = sum(1 for s in student_scores if 0 < s['participation_rate'] < 100)
            no_participation = sum(1 for s in student_scores if s['participation_rate'] == 0)
            
            # Compile comprehensive statistics
            statistics = {
                'quiz_overview': {
                    'quiz_title': class_data['quiz_data'].get('title', 'Untitled Quiz'),
                    'total_questions': len(questions),
                    'total_students_joined': total_students,
                    'students_participated': students_participated,
                    'completion_rate': round((students_participated / total_students) * 100, 1) if total_students else 0
                },
                'performance_summary': {
                    'average_score': round(average_score, 1),
                    'average_percentage': round(average_percentage, 1),
                    'highest_score': student_scores[0]['score'] if student_scores else 0,
                    'lowest_score': student_scores[-1]['score'] if student_scores else 0,
                    'score_distribution': score_ranges
                },
                'top_performers': [
                    {
                        'rank': idx + 1,
                        'name': student['name'],
                        'score': student['score'],
                        'percentage': student['percentage'],
                        'total_answered': student['total_answered']
                    }
                    for idx, student in enumerate(top_performers)
                ],
                'bottom_performers': [
                    {
                        'name': student['name'],
                        'score': student['score'],
                        'percentage': student['percentage'],
                        'total_answered': student['total_answered']
                    }
                    for student in reversed(bottom_performers)
                ] if bottom_performers else [],
                'question_analysis': question_analysis,
                'most_difficult_questions': most_difficult,
                'least_difficult_questions': least_difficult,
                'participation_stats': {
                    'full_participation': full_participation,
                    'partial_participation': partial_participation,
                    'no_participation': no_participation,
                    'average_response_rate': round(sum(q['response_rate'] for q in question_analysis) / len(question_analysis), 1) if question_analysis else 0
                },
                'engagement_insights': {
                    'students_answered_all': full_participation,
                    'students_answered_none': no_participation,
                    'students_answered_some': partial_participation,
                    'most_engaged_students': [s['name'] for s in student_scores if s['participation_rate'] == 100][:5],
                    'least_engaged_students': [s['name'] for s in student_scores if s['participation_rate'] < 50][:5]
                }
            }
            
            # Send statistics to teacher
            await sio.emit('s2c_quiz_statistics', statistics, room=teacher_sid)
            logger.info(f"Quiz statistics sent to teacher for class {class_code}")
            
        except Exception as e:
            logger.error(f"Error generating quiz statistics for class {class_code}: {e}")
    
    async def _cleanup_class(self, class_code: str):
        """Clean up a class when it's ended or teacher disconnects."""
        try:
            # Cancel any running timers
            await self._cancel_timer(class_code)
            
            # Remove from active classes
            if class_code in self.active_classes:
                del self.active_classes[class_code]
                
            logger.info(f"Cleaned up class {class_code}")
        except Exception as e:
            logger.error(f"Error cleaning up class {class_code}: {e}")
    
    async def _periodic_cleanup(self):
        """Periodically clean up old ended quizzes to prevent memory leaks."""
        while True:
            try:
                await asyncio.sleep(300)  # Check every 5 minutes
                current_time = datetime.now().timestamp()
                classes_to_remove = []
                
                for class_code, class_data in self.active_classes.items():
                    # Clean up ended quizzes that are older than 30 minutes
                    if (class_data['quiz_state'].get('quiz_ended', False) and 
                        class_data.get('teacher_disconnected', False)):
                        
                        # Check if quiz ended more than 30 minutes ago
                        # For now, just clean up disconnected ended quizzes after 5 minutes
                        # (since we don't track end time - could be improved)
                        classes_to_remove.append(class_code)
                
                # Clean up old classes
                for class_code in classes_to_remove:
                    await self._cleanup_class(class_code)
                    logger.info(f"Periodic cleanup: removed old ended quiz {class_code}")
                
            except Exception as e:
                logger.error(f"Error in periodic cleanup: {e}")
                await asyncio.sleep(60)  # Wait 1 minute before retrying
    
    def stop_cleanup_task(self):
        """Stop the periodic cleanup task."""
        if self.cleanup_task and not self.cleanup_task.done():
            self.cleanup_task.cancel()
            logger.info("Stopped periodic cleanup task") 