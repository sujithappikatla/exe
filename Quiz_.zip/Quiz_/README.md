# Real-Time Quiz Application Backend

A comprehensive FastAPI backend server for conducting real-time, multi-class quiz sessions using Socket.IO. This application allows teachers to create quiz sessions and students to join and participate in real-time quizzes with synchronized timers.

## Features

### 🎓 Teacher Features
- **Create Quiz Sessions**: Generate unique 6-digit room codes
- **Live Student Monitoring**: See who has joined and answered questions in real-time
- **Quiz Control**: Start, pause, resume, and end quizzes
- **Question Navigation**: Move between questions with next/previous controls
- **Timer Management**: Pause and resume question timers
- **Explanation Breaks**: Reveal correct answers after question timeout

### 🎓 Student Features
- **📱 Mobile-First Design**: Optimized interface for exceptional smartphone experience
- **⚡ Quick Join**: Auto-focus inputs with Enter key support for fast joining
- **🎨 Beautiful Gradients**: Sky-blue to green color scheme with elegant rounded corners
- **⏱️ Subtle Timer**: Compact "Time Remaining" display that doesn't overwhelm
- **🔄 Vertical Layout**: Options display one by one for focused mobile interaction
- **✨ Smooth Animations**: Gradient hover effects and gentle transitions throughout
- **📊 Elegant Results**: Beautiful gradient score display with comprehensive feedback
- **📄 PDF Reports**: Download comprehensive quiz reports with reasoning explanations
- **🎯 Educational Feedback**: Learn from detailed explanations for each answer option

### 🔧 Technical Features
- **Socket.IO Integration**: Real-time bidirectional communication
- **Timer Synchronization**: Accurate client-server timer coordination
- **Multi-class Support**: Handle multiple concurrent quiz sessions
- **Automatic Cleanup**: Handle disconnections and cleanup sessions
- **PDF Generation**: Create detailed student reports with reasoning explanations
- **Educational Reasoning**: Optional explanations for each answer option in questions

## Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd Quiz
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the server**
   ```bash
   # Simple startup
   python main.py
   
   # Or with the enhanced startup script (recommended)
   python start_quiz_app.py
   
   # Or using uvicorn directly
   uvicorn main:socket_app --host 0.0.0.0 --port 8000 --reload
   ```

4. **Access the application**
   - **Teacher Interface**: `http://localhost:8000/teacher.html` (or just `http://localhost:8000`)
   - **Student Interface**: `http://localhost:8000/student.html`
   - Health check: `http://localhost:8000/health`
   - API docs: `http://localhost:8000/docs`

## API Documentation

### REST Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Health check and API information |
| `/health` | GET | Detailed health status with active class count |
| `/download-report/{class_code}/{student_sid}` | GET | Download PDF report for student |

### Socket.IO Events

#### Connection Events

**Client → Server Events:**

| Event | Description | Payload |
|-------|-------------|---------|
| `c2s_create_class` | Teacher creates a new quiz class | `{teacher_name, quiz_data}` |
| `c2s_join_class` | Student joins a quiz class | `{class_code, student_name}` |

**Server → Client Events:**

| Event | Description | Payload |
|-------|-------------|---------|
| `s2c_class_created` | Confirms class creation | `{class_code}` |
| `s2c_student_joined` | Notifies teacher of new student | `{students: [{id, name}]}` |
| `s2c_join_successful` | Confirms student joined | `{message}` |

#### Quiz Control Events

**Client → Server Events:**

| Event | Description | Payload |
|-------|-------------|---------|
| `c2s_start_quiz` | Teacher starts the quiz | `{}` |
| `c2s_navigate_question` | Navigate to next/previous question | `{direction: "next"\|"previous"}` |
| `c2s_pause_timer` | Teacher pauses current timer | `{}` |
| `c2s_resume_timer` | Teacher resumes timer | `{}` |
| `c2s_end_quiz` | Teacher ends the quiz | `{}` |

**Server → Client Events:**

| Event | Description | Payload |
|-------|-------------|---------|
| `s2c_load_question` | Sends current question to all clients | Question data (different for teacher/student) |
| `s2c_timer_paused` | Notifies all clients timer is paused | `{}` |
| `s2c_timer_resumed` | Notifies all clients timer resumed | `{time_remaining}` |
| `s2c_question_timeout` | Notifies question time is up | `{question_id, correct_option}` |
| `s2c_quiz_finished` | Sends final results | `{results}` |

#### Student Interaction Events

**Client → Server Events:**

| Event | Description | Payload |
|-------|-------------|---------|
| `c2s_submit_answer` | Student submits answer | `{question_id, answer}` |

**Server → Client Events:**

| Event | Description | Payload |
|-------|-------------|---------|
| `s2c_update_student_status` | Updates teacher on student progress | `{students_status}` |

#### Error Handling

| Event | Description | Payload |
|-------|-------------|---------|
| `s2c_error` | Error message to specific client | `{message}` |

## Web Interfaces

### 🎓 Teacher Interface (`teacher.html`)

A comprehensive dashboard for quiz management with:

- **Class Creation**: Create quiz sessions with dummy questions (10-second timers)
- **Student Monitoring**: Real-time view of students joining and answering
- **Quiz Control**: Start, pause/resume timer, navigate questions, end quiz
- **Live Dashboard**: See student progress and participation status
- **Modern UI**: Responsive design with visual feedback and animations

**Features:**
- Pre-loaded with 5 sample questions covering Math, Geography, Science, and Programming
- Real-time student count and status updates
- Timer controls with visual countdown
- Question navigation with previous/next buttons
- Automatic class code generation (6-digit alphanumeric)

### 👨‍🎓 Student Interface (`student.html`)

A mobile-first, beautiful quiz interface with sky-blue/green gradients:

- **📱 Mobile-Optimized**: Touch-friendly design with large buttons and clear typography
- **⚡ Quick Join**: Auto-focus inputs, Enter key support, and streamlined form
- **🎨 Beautiful Design**: Sky-blue to green gradients with elegant rounded corners
- **⏱️ Subtle Timer**: Compact "Time Remaining" display that doesn't distract
- **✨ Smooth Interactions**: Gradient hover effects and gentle animations
- **📊 Elegant Results**: Beautiful gradient score display with comprehensive feedback
- **📄 Easy Download**: One-click PDF report generation
- **🔄 Vertical Options**: Questions display one by one for focused interaction

**Design Features:**
- Sky-blue (#0ea5e9) to green (#10b981) gradient backgrounds
- Rounded corners (12px-20px) throughout for modern feel
- Minimized timer with subtle styling and "Time Remaining" label
- Vertical option layout for better mobile focus
- Gradient hover effects and smooth transitions
- Glass-morphism inspired card designs with subtle shadows

### 🚀 Quick Demo

1. **Start the server**:
   ```bash
   python start_quiz_app.py
   ```

2. **Teacher Setup** (http://localhost:8000/teacher.html):
   - Enter teacher name (pre-filled: "Mr. Smith")
   - Click "Create Quiz Class"
   - Share the generated 6-digit code with students

3. **Student Join** (http://localhost:8000/student.html):
   - Enter the 6-digit code from teacher
   - Enter student name
   - Click "Join Quiz"

4. **Start Quiz**:
   - Teacher clicks "Start Quiz" when ready
   - Students automatically receive questions
   - Teacher can pause/resume timer and navigate questions

5. **Complete Quiz**:
   - Students see final results and can download PDF reports
   - Teacher can review student participation

## Usage Examples

### Creating a Quiz Class (Teacher)

```javascript
// Connect to Socket.IO
const socket = io('http://localhost:8000');

// Create a quiz class
socket.emit('c2s_create_class', {
  teacher_name: "Mr. Smith",
  quiz_data: {
    title: "Math Quiz",
    questions: [
      {
        id: "q1",
        text: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        correct_option: "4",
        timer: 30
      },
      {
        id: "q2", 
        text: "What is 5 × 3?",
        options: ["10", "15", "20", "25"],
        correct_option: "15",
        timer: 25
      }
    ]
  }
});

// Listen for class creation confirmation
socket.on('s2c_class_created', (data) => {
  console.log('Class created with code:', data.class_code);
});
```

### Joining a Quiz (Student)

```javascript
// Connect to Socket.IO
const socket = io('http://localhost:8000');

// Join a quiz class
socket.emit('c2s_join_class', {
  class_code: "ABC123",
  student_name: "Alice"
});

// Listen for join confirmation
socket.on('s2c_join_successful', (data) => {
  console.log(data.message); // "Waiting for teacher to start quiz"
});

// Listen for questions
socket.on('s2c_load_question', (question) => {
  console.log('New question:', question);
  // Display question to student
});
```

### Submitting Answers (Student)

```javascript
// Submit an answer
socket.emit('c2s_submit_answer', {
  question_id: "q1",
  answer: "4"
});

// Listen for quiz results
socket.on('s2c_quiz_finished', (data) => {
  console.log('Quiz completed! Score:', data.results.score);
  console.log('Details:', data.results.summary);
});
```

### Quiz Control (Teacher)

```javascript
// Start the quiz
socket.emit('c2s_start_quiz', {});

// Navigate questions
socket.emit('c2s_navigate_question', {direction: "next"});
socket.emit('c2s_navigate_question', {direction: "previous"});

// Pause/Resume timer
socket.emit('c2s_pause_timer', {});
socket.emit('c2s_resume_timer', {});

// End quiz
socket.emit('c2s_end_quiz', {});

// Listen for student status updates
socket.on('s2c_update_student_status', (data) => {
  console.log('Student status:', data.students_status);
});
```

## Data Structures

### Quiz Data Format

```json
{
  "title": "Quiz Title",
  "questions": [
    {
      "id": "unique_question_id",
      "text": "Question text",
      "options": ["Option 1", "Option 2", "Option 3"],
      "correct_option": "Option 2",
      "timer": 30
    }
  ]
}
```

### Student Results Format

```json
{
  "score": 2,
  "total_questions": 3,
  "summary": [
    {
      "question_id": "q1",
      "question_text": "What is 2 + 2?",
      "options": ["3", "4", "5"],
      "your_answer": "4",
      "correct_answer": "4"
    }
  ]
}
```

## Timer Synchronization

The application uses an efficient timer synchronization approach:

1. **Duration Sent Once**: Timer duration is sent with each question
2. **Client-Side Countdown**: Each client runs its own countdown timer
3. **Server Authority**: Server maintains authoritative timer
4. **Pause/Resume**: Server tracks exact remaining time during pauses
5. **Timeout Authority**: Server's timeout event is the single source of truth

## Error Handling

The server handles various error scenarios:

- Invalid class codes
- Duplicate student names
- Timer state conflicts
- Network disconnections
- Malformed requests

All errors are sent via the `s2c_error` event with descriptive messages.

## Development

### Project Structure

```
Quiz/
├── main.py                    # Main FastAPI application with Socket.IO
├── models.py                  # Pydantic models for data validation
├── quiz_manager.py            # Core quiz logic and state management
├── pdf_generator.py           # PDF report generation
├── teacher.html               # Teacher interface (complete HTML)
├── student.html               # Student interface (complete HTML)
├── start_quiz_app.py          # Enhanced startup script with instructions
├── run_server.py              # Basic server startup script
├── requirements.txt           # Python dependencies
├── README.md                  # This file
└── quiz_app_specification.md  # Detailed technical specification
```

### Running in Development

```bash
# With auto-reload
uvicorn main:socket_app --reload --host 0.0.0.0 --port 8000

# Or using the Python script
python main.py
```

### Testing

You can test the Socket.IO events using a browser console or tools like:
- [Socket.IO Client Tool](https://socket.io/docs/v4/client-api/)
- Browser developer console
- Postman (for REST endpoints)

## Production Deployment

### Environment Variables

Set these environment variables for production:

```bash
export QUIZ_HOST=0.0.0.0
export QUIZ_PORT=8000
export QUIZ_LOG_LEVEL=info
```

### CORS Configuration

Update CORS settings in `main.py` for production:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://yourdomain.com"],  # Specify your frontend domain
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
```

### Security Considerations

1. **CORS**: Configure appropriate origins for production
2. **Rate Limiting**: Consider adding rate limiting middleware
3. **Input Validation**: All inputs are validated using Pydantic models
4. **Session Management**: Quiz sessions are automatically cleaned up

## Troubleshooting

### Common Issues

1. **Connection Refused**: Check if server is running on correct port
2. **CORS Errors**: Update CORS configuration for your frontend domain
3. **Socket.IO Version**: Ensure client and server Socket.IO versions are compatible
4. **PDF Generation Errors**: Check FPDF2 installation and file permissions

### Logs

The server provides detailed logging. Check console output for:
- Connection events
- Quiz operations
- Error messages
- Cleanup operations

## License

This project is part of a technical specification implementation for a real-time quiz application system.

## Contributing

1. Follow the existing code structure and patterns
2. Add proper error handling and logging
3. Update documentation for new features
4. Ensure all Socket.IO events match the specification
5. Test thoroughly with multiple concurrent sessions 

## 🐛 Recent Bug Fixes

### Timer Pause/Resume Issue ✅
- **Problem**: When pausing and resuming, timer would resume from incorrect time
- **Solution**: Implemented proper remaining time calculation and separate timer duration handling
- **Files Modified**: `quiz_manager.py`

### Student Status Reset ✅
- **Problem**: Teacher interface showed cumulative student answers instead of per-question status
- **Solution**: Reset student status display when loading new questions
- **Files Modified**: `teacher.html`

### PDF Generation Unicode & Encoding Error ✅
- **Problem**: Unicode characters (✓, ✗) caused font errors and bytearray encoding issues
- **Solution**: Replaced with ASCII text ("CORRECT", "INCORRECT") and properly converted bytearray to bytes
- **Files Modified**: `pdf_generator.py`

## 📚 New Feature: Educational Reasoning

### Question Reasoning System ✨
- **Enhanced Learning**: Each question can now include detailed explanations for every answer option
- **Educational Value**: Students receive comprehensive feedback explaining why each option is correct or incorrect
- **Optional Implementation**: The reasoning field is completely optional - questions work with or without it
- **PDF Integration**: All reasoning explanations are included in downloadable PDF reports

### 📝 Question Structure with Reasoning
```json
{
  "id": "q1",
  "text": "What is 2 + 2?",
  "options": ["3", "4", "5", "6"],
  "correct_option": "4",
  "timer": 10,
  "reasoning": {
    "3": "This is incorrect. 2 + 2 equals 4, not 3. Basic addition shows us that 2 + 2 = 4.",
    "4": "This is correct! 2 + 2 = 4 is a fundamental arithmetic operation.",
    "5": "This is incorrect. 2 + 2 equals 4, not 5. You might be thinking of 2 + 3 = 5.",
    "6": "This is incorrect. 2 + 2 equals 4, not 6. You might be thinking of 2 × 3 = 6."
  }
}
```

### 🎯 Benefits
- **Better Learning Outcomes**: Students understand not just what's right, but why
- **Comprehensive Feedback**: Explanations help students learn from mistakes
- **Flexible Usage**: Teachers can choose to include reasoning or keep questions simple
- **Rich PDF Reports**: Complete explanations available for review and study 