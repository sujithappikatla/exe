


## Run below Commands to setup 
```
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python fastapi_server.py
```


### Before running Applications, Make sure to Create and Setup Google Cloud Account ADC(Application Default Credentials)
- Change Project Name to your GCP Project Name in STTHandler.py, LLMHandler.py
- Search "cloud-learning-443407" in whole folder and replace with your Project Name.




