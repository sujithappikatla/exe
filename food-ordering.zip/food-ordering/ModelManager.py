from models.STTHandler import STTHandler
from models.LLMHandler import LLMHandler
from models.TTSHandler import TTSHandler
import asyncio
import uuid
from datetime import datetime
import json
import base64
from asyncio import Queue
from fastapi import WebSocket
from storage.StorageManager import StorageManager

class ModelManager:
    def __init__(
        self,
        websocket: WebSocket = None,
    ):
        self.websocket = websocket

        self.stt_handler = STTHandler()
        self.llm_handler = LLMHandler()
        self.tts_handler = TTSHandler()
        self.storage_manager = StorageManager()

        self.session_id = None
        self.message_id = str(uuid.uuid4())
        
        self.input_type = None
        self.output_type = None

        self.input_queue = Queue()
        self.llm_output_queue = Queue()

        self.request_handler_task = None

    async def start_session(self):
        message = await self.websocket.receive_text()
        message = json.loads(message)
        if message.get("type") == "START_SESSION":
            self.output_type = message["data"]["output_type"]
        
        self.session_id = message["session_id"]

        self.storage_manager.init_session(self.session_id)
        self.llm_handler.set_storage_manager(self.storage_manager)

        await self.websocket.send_text(json.dumps({
            "message_id": message["message_id"],
            "session_id": message["session_id"],
            "timestamp": datetime.now().isoformat(),
            "type": "SESSION_STARTED",
            "data": {}
        }))

        await self.input_message_handler()


    
    async def input_message_handler(self):
        while True:
            try:
                msg = await self.websocket.receive_text()
                msg = json.loads(msg)

                if msg.get("type") == "AUDIO_STREAM_START":
                    if self.request_handler_task:
                        self.request_handler_task.cancel()
                    self.input_type = "audio"
                    self.request_handler_task = asyncio.create_task(self.handle_request())
                elif msg.get("type") == "AUDIO_STREAM_CHUNK":
                    data = base64.b64decode(msg.get("data").get("audio_content"))
                    self.input_queue.put_nowait(data)
                elif msg.get("type") == "AUDIO_STREAM_END":
                    self.input_queue.put_nowait(None)
                elif msg.get("type") == "TEXT_INPUT":
                    self.input_type = "text"
                    to_queue = {}

                    if self.request_handler_task:
                        self.request_handler_task.cancel()
                    if msg.get("data").get("text") != "":
                        to_queue["text"] = msg.get("data").get("text")
                    if msg.get("data").get("function_call_response") is not None:
                        to_queue["fn_response"] = msg.get("data").get("function_call_response")
                    self.input_queue.put_nowait(json.dumps(to_queue))
                    self.input_queue.put_nowait(None)
                    self.request_handler_task = asyncio.create_task(self.handle_request())
                elif msg.get("type") == "END_SESSION":
                    break
            except Exception as e:
                print(f"[ERROR][ModelManager][input_message_handler] {e}")
                break

    async def handle_request(
        self,
    ):
        try:
            # Step 1: Input handling
            if self.input_type == "audio":
                stt_output_text = await self.stt_handler.process(self.input_queue, self.send_status_to_client)
                stt_output_text = {
                    "text": stt_output_text,
                    "fn_response": None
                }
                stt_output_text = json.dumps(stt_output_text)
            else:
                stt_output_text = ""
                while True:
                    try:
                        chunk = self.input_queue.get_nowait()
                        if chunk is None:
                            break
                        stt_output_text += chunk
                    except asyncio.QueueEmpty:
                        await asyncio.sleep(0.01)
                        continue
                    except Exception as e:
                        print(f"[ERROR][ModelManager][handle_request] {e}")
                        break
                stt_output_text = stt_output_text.strip()

            # Step 2: LLM handler
            llm_task = asyncio.create_task(self.llm_handler.process(stt_output_text, self.send_status_to_client, self.llm_output_queue))

            # Step 3: Output handling
            tts_task = None
            if self.output_type == "audio":
                tts_task = asyncio.create_task(self.tts_handler.process(self.llm_output_queue, self.send_status_to_client))

            await asyncio.gather(llm_task, tts_task)

        except asyncio.CancelledError:
            print("[ERROR][ModelManager][handle_request] asyncio.CancelledError")
        except Exception as e:
            print(f"[ERROR][ModelManager][handle_request] {e}")
    

    async def send_status_to_client(self, status_type: str, status_msg:dict):

        try:
            response_to_client = {
                "message_id": self.message_id,
                "session_id": self.session_id,
                "timestamp": datetime.now().isoformat(),
            }

            if status_type == "STT:START":
                response_to_client["type"]="STT_TRANSCRIPT_START"
                response_to_client["data"] = {}
            elif status_type == "STT:PROGRESS":
                response_to_client["type"]="STT_TRANSCRIPT_CHUNK"
                response_to_client["data"] = {
                    "text": status_msg["text"],
                    "is_final": status_msg["is_final"],
                }
            elif status_type == "STT:DONE":
                response_to_client["type"]="STT_TRANSCRIPT_END"
                response_to_client["data"] = {
                    "final_transcript": status_msg["text"],
                }
            elif status_type == "LLM:START":
                response_to_client["type"]="LLM_RESPONSE_START"
                response_to_client["data"] = {}
            elif status_type == "LLM:CHUNK":
                response_to_client["type"]="LLM_TEXT_CHUNK"
                response_to_client["data"] = {
                    "text": status_msg["text"],
                }
            elif status_type == "LLM:FUNCTION_CALL":
                response_to_client["type"]="LLM_TEXT_CHUNK"
                response_to_client["data"] = {
                    "function_calls": status_msg["function_calls"]
                }
            elif status_type == "LLM:DONE":
                response_to_client["type"]="LLM_RESPONSE_END"
                response_to_client["data"] = {}
            elif status_type == "TTS:START":
                response_to_client["type"]="TTS_AUDIO_START"
                response_to_client["data"] = {}
            elif status_type == "TTS:CHUNK":
                response_to_client["type"]="TTS_AUDIO_CHUNK"
                response_to_client["data"] = {
                    "audio_content": base64.b64encode(status_msg["audio_content"]).decode("utf-8"),
                }
            elif status_type == "TTS:DONE":
                response_to_client["type"]="TTS_AUDIO_END"
                response_to_client["data"] = {}
            else:
                raise Exception(f"Invalid status type: {status_type}")

            # print("===========", json.dumps(response_to_client)[:400])
            if self.websocket:
                await self.websocket.send_text(json.dumps(response_to_client))
        except Exception as e:
            print(f"[ERROR][ModelManager][send_status_to_client] {e}")


    async def stop(self):
        if self.tts_handler:
            await self.tts_handler.stop()
        if self.stt_handler:
            await self.stt_handler.stop()
        if self.llm_handler:
            await self.llm_handler.stop()
        if self.request_handler_task:
            self.request_handler_task.cancel()