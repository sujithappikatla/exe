package com.example.netlib.networkClient

// Response model for GET https://reqres.in/api/users/2
data class UserResponse(
    val data: UserData,
    val support: Support
)

data class UserData(
    val id: Int,
    val email: String,
    val first_name: String,
    val last_name: String,
    val avatar: String
)

data class Support(
    val url: String,
    val text: String
)

// Request model for POST https://reqres.in/api/users
data class CreateUserRequest(
    val name: String,
    val job: String
)

// Response model for POST https://reqres.in/api/users
data class CreateUserResponse(
    val name: String,
    val job: String,
    val id: String,
    val createdAt: String
)

// Request model for PUT https://reqres.in/api/users/2
data class UpdateUserRequest(
    val name: String,
    val job: String
)

// Response model for PUT https://reqres.in/api/users/2
data class UpdateUserResponse(
    val name: String,
    val job: String,
    val updatedAt: String
)

// Model for SSE stream response
data class StreamResponse(
    val content: String = "",
    val rendered_content: String = "",
    val citations: List<Citation> = emptyList()
)

data class Citation(
    val title: String = "",
    val uri: String = ""
)

// Request for SSE stream
data class StreamRequest(
    val analysis: String
) 