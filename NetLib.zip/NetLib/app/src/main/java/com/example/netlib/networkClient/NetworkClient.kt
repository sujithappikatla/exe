package com.example.netlib.networkClient

import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import okio.BufferedSource
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * A Kotlin networking library built on OkHttp, providing easy-to-use APIs for making HTTP requests.
 * Supports coroutines, Flow, and Gson serialization.
 *
 * Features:
 * - Support for GET, POST, PUT, DELETE requests
 * - Configurable timeouts, headers, and interceptors
 * - Built-in logging
 * - Error handling with a sealed result class
 * - Gson serialization/deserialization
 * - HTTP chunked transfer support for streaming data
 */
class NetworkClient private constructor(val client: OkHttpClient) {
    private val gson: Gson = Gson()
    val TAG = "NetworkClient"

    /**
     * Builder for configuring the NetworkClient
     */
    class Builder {
        // Default timeouts (industry-standard defaults: 10s connect, 10s write, 30s read)
        private var connectTimeoutSec: Long = 10
        private var readTimeoutSec: Long = 30
        private var writeTimeoutSec: Long = 10

        private val interceptors = mutableListOf<okhttp3.Interceptor>()
        private var enableLogging: Boolean = true
        private var logLevel: HttpLoggingInterceptor.Level = HttpLoggingInterceptor.Level.BASIC

        /**
         * Set connection timeout in seconds
         */
        fun connectTimeout(seconds: Long) = apply { connectTimeoutSec = seconds }

        /**
         * Set read timeout in seconds
         */
        fun readTimeout(seconds: Long) = apply { readTimeoutSec = seconds }

        /**
         * Set write timeout in seconds
         */
        fun writeTimeout(seconds: Long) = apply { writeTimeoutSec = seconds }

        /**
         * Add a custom interceptor
         */
        fun addInterceptor(interceptor: okhttp3.Interceptor) = apply {
            interceptors.add(interceptor)
        }

        /**
         * Enable or disable logging with optional log level
         */
        fun enableLogging(
            enable: Boolean,
            level: HttpLoggingInterceptor.Level = HttpLoggingInterceptor.Level.BASIC
        ) = apply {
            enableLogging = enable
            logLevel = level
        }

        /**
         * Build the NetworkClient with the configured options
         */
        fun build(): NetworkClient {
            // Build OkHttpClient with configured options
            val builder = OkHttpClient.Builder()
                .connectTimeout(connectTimeoutSec, TimeUnit.SECONDS)
                .readTimeout(readTimeoutSec, TimeUnit.SECONDS)
                .writeTimeout(writeTimeoutSec, TimeUnit.SECONDS)
            
            // Add user-specified interceptors
            interceptors.forEach { builder.addInterceptor(it) }

            // Add a logging interceptor if enabled
            if (enableLogging) {
                val loggingInterceptor = HttpLoggingInterceptor()
                loggingInterceptor.level = logLevel
                builder.addInterceptor(loggingInterceptor)
            }

            return NetworkClient(builder.build())
        }
    }

    companion object {
        @Volatile private var INSTANCE: NetworkClient? = null

        /**
         * Initialize the NetworkClient singleton with the provided configuration
         */
        fun init(configure: Builder.() -> Unit): NetworkClient {
            synchronized(this) {
                val instance = Builder().apply(configure).build()
                INSTANCE = instance
                return instance
            }
        }

        /**
         * Get the NetworkClient instance, throws if not initialized
         */
        fun getInstance(): NetworkClient {
            return INSTANCE ?: throw IllegalStateException("NetworkClient must be initialized")
        }
    }

    /**
     * Perform a GET request
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the response or error information
     */
    suspend fun get(
        url: String,
        headers: Map<String, String>? = null
    ): NetworkResult<String> = executeRequest("GET", url, headers)

    /**
     * Perform a DELETE request
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the response or error information
     */
    suspend fun delete(
        url: String,
        headers: Map<String, String>? = null
    ): NetworkResult<String> = executeRequest("DELETE", url, headers)

    /**
     * Perform a POST request with a JSON body
     * @param url The URL to request
     * @param jsonBody The JSON body as a string
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the response or error information
     */
    suspend fun post(
        url: String,
        jsonBody: String,
        headers: Map<String, String>? = null
    ): NetworkResult<String> = executeRequest("POST", url, headers, jsonBody)

    /**
     * Perform a PUT request with a JSON body
     * @param url The URL to request
     * @param jsonBody The JSON body as a string
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the response or error information
     */
    suspend fun put(
        url: String,
        jsonBody: String,
        headers: Map<String, String>? = null
    ): NetworkResult<String> = executeRequest("PUT", url, headers, jsonBody)

    /**
     * Perform a GET request and deserialize the response to a Kotlin object
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the deserialized object or error information
     */
    public suspend inline fun <reified T> getObject(
        url: String,
        headers: Map<String, String>? = null
    ): NetworkResult<T> = parseResult(get(url, headers))

    /**
     * Perform a DELETE request and deserialize the response to a Kotlin object
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the deserialized object or error information
     */
    public suspend inline fun <reified T> deleteObject(
        url: String,
        headers: Map<String, String>? = null
    ): NetworkResult<T> = parseResult(delete(url, headers))

    /**
     * Perform a POST request with an object as the body and deserialize the response
     * @param url The URL to request
     * @param body The object to be serialized as the request body
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the deserialized response object or error information
     */
    public suspend inline fun <reified T, reified R> postObject(
        url: String,
        body: T,
        headers: Map<String, String>? = null
    ): NetworkResult<R> {
        val jsonBody = Gson().toJson(body)
        return parseResult(post(url, jsonBody, headers))
    }

    /**
     * Perform a PUT request with an object as the body and deserialize the response
     * @param url The URL to request
     * @param body The object to be serialized as the request body
     * @param headers Optional headers for the request
     * @return NetworkResult containing either the deserialized response object or error information
     */
    public suspend inline fun <reified T, reified R> putObject(
        url: String,
        body: T,
        headers: Map<String, String>? = null
    ): NetworkResult<R> {
        val jsonBody = Gson().toJson(body)
        return parseResult(put(url, jsonBody, headers))
    }

    /**
     * Transform a NetworkResult<String> to NetworkResult<T> using Gson deserialization
     */
    public inline fun <reified T> parseResult(result: NetworkResult<String>): NetworkResult<T> {
        return when (result) {
            is NetworkResult.Success -> {
                try {
                    val obj: T = Gson().fromJson(result.data, object : TypeToken<T>() {}.type)
                    NetworkResult.Success(obj)
                } catch (e: Exception) {
                    Log.e(TAG, "JSON parse error: ${e.message}", e)
                    NetworkResult.Error(error = "JSON parse error: ${e.message}", exception = e)
                }
            }
            is NetworkResult.Error -> NetworkResult.Error(
                code = result.code,
                error = result.error,
                exception = result.exception
            )
            is NetworkResult.Loading -> NetworkResult.Loading()
        }
    }

    /**
     * Get the response as a Flow that emits a loading state and then the result
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @return Flow emitting the loading state and then the response
     */
    fun getFlow(
        url: String,
        headers: Map<String, String>? = null
    ): Flow<NetworkResult<String>> = flow {
        emit(NetworkResult.Loading())
        emit(get(url, headers))
    }

    /**
     * Get the response as a Flow of deserialized objects
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @return Flow emitting the loading state and then the deserialized response
     */
    public inline fun <reified T> getObjectFlow(
        url: String,
        headers: Map<String, String>? = null
    ): Flow<NetworkResult<T>> = flow {
        emit(NetworkResult.Loading())
        emit(getObject<T>(url, headers))
    }

    /**
     * Stream data using HTTP chunked transfer encoding.
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @param requestBody Optional request body (for POST requests)
     * @return Flow emitting each chunk of data as it's received
     */
    fun streamChunkedData(
        url: String,
        headers: Map<String, String>? = null,
        requestBody: String? = null
    ): Flow<String> = callbackFlow {
        // Build the request with appropriate headers
        val requestBuilder = Request.Builder().url(url)
        
        headers?.forEach { (name, value) -> 
            requestBuilder.header(name, value) 
        }
        
        // If body provided, use POST method
        if (requestBody != null) {
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBody.toRequestBody(mediaType)
            requestBuilder.post(body)
        }
        
        val request = requestBuilder.build()
        
        // Create a client with longer timeouts for streaming
        val streamClient = client.newBuilder()
            .readTimeout(0, TimeUnit.SECONDS) // No timeout for streaming
            .build()
        
        // Create a call to manage the connection
        val call = streamClient.newCall(request)
        
        try {
            // Execute the request
            Log.d(TAG, "Opening chunked transfer connection to $url")
            val response = call.execute()
            
            if (!response.isSuccessful) {
                close(IOException("Unexpected response ${response.code}"))
                return@callbackFlow
            }
            
            // Get the response body source
            val source = response.body?.source()
            if (source == null) {
                close(IOException("No response body"))
                return@callbackFlow
            }
            
            // Read from the stream line by line
            while (!call.isCanceled() && !source.exhausted()) {
                try {
                    // Read a line from the stream
                    val line = source.readUtf8Line()
                    
                    if (line == null) {
                        // End of stream
                        Log.d(TAG, "Chunked stream ended")
                        break
                    }
                    
                    if (line.isNotEmpty()) {
                        Log.d(TAG, "Chunked data received: $line")
                        trySend(line).isSuccess
                    }
                } catch (e: IOException) {
                    if (!call.isCanceled()) {
                        Log.e(TAG, "Error reading chunked stream", e)
                        close(e)
                        break
                    }
                }
            }
            
            Log.d(TAG, "Chunked stream reading completed")
            
        } catch (e: Exception) {
            if (!call.isCanceled()) {
                Log.e(TAG, "Chunked connection error", e)
                close(e)
            }
        }
        
        // Clean up when flow is cancelled
        awaitClose {
            Log.d(TAG, "Closing chunked connection")
            call.cancel()
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Execute an HTTP request with the specified method, URL, headers, and optional body
     * @param method The HTTP method (GET, POST, PUT, DELETE)
     * @param url The URL to request
     * @param headers Optional headers for the request
     * @param jsonBody Optional JSON body for POST/PUT requests
     * @return NetworkResult containing either the response or error information
     */
    public suspend fun executeRequest(
        method: String,
        url: String,
        headers: Map<String, String>?,
        jsonBody: String? = null
    ): NetworkResult<String> {
        // Build the OkHttp Request
        val builder = Request.Builder().url(url)
        headers?.forEach { (name, value) -> builder.header(name, value) }
        
        when (method) {
            "GET", "DELETE" -> builder.method(method, null)
            "POST", "PUT" -> {
                // Set JSON media type and body
                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body: RequestBody = (jsonBody ?: "").toRequestBody(mediaType)
                builder.method(method, body)
            }
            else -> throw IllegalArgumentException("Unsupported method $method")
        }
        
        val request = builder.build()

        // Execute the request using OkHttp on a background thread
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "Executing $method request to $url")
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                
                if (response.isSuccessful) {
                    Log.d(TAG, "Request successful: ${response.code}")
                    NetworkResult.Success(responseBody ?: "")
                } else {
                    // HTTP error status (4xx or 5xx)
                    Log.e(TAG, "HTTP error: ${response.code}, ${response.message}")
                    NetworkResult.Error(
                        code = response.code,
                        error = responseBody ?: response.message
                    )
                }
            } catch (e: Exception) {
                // Network failure (timeout, no internet, etc.)
                Log.e(TAG, "Network exception: ${e.message}", e)
                NetworkResult.Error(exception = e)
            }
        }
    }
}

/**
 * Sealed class representing the result of a network operation
 */
sealed class NetworkResult<out T> {
    /**
     * Successful result containing the response data
     */
    data class Success<T>(val data: T) : NetworkResult<T>()
    
    /**
     * Error result containing error details
     * @param code HTTP status code (if available)
     * @param error Error message (if available)
     * @param exception Exception that occurred (if available)
     */
    data class Error(
        val code: Int? = null,
        val error: String? = null,
        val exception: Throwable? = null
    ) : NetworkResult<Nothing>()
    
    /**
     * Loading state for asynchronous operations
     */
    class Loading<T> : NetworkResult<T>()
} 