package com.example.netlib

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.netlib.networkClient.NetworkClient
import com.example.netlib.networkClient.NetworkResult
import com.example.netlib.ui.theme.NetLibTheme
import com.google.gson.GsonBuilder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize NetworkClient
        NetworkClient.init {
            connectTimeout(15)  // 15 seconds for connect timeout
            readTimeout(30)     // 30 seconds for read timeout
            enableLogging(true, okhttp3.logging.HttpLoggingInterceptor.Level.BODY) // Enable detailed logging
        }
        
        enableEdgeToEdge()
        setContent {
            NetLibTheme {
                NetworkDemoApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkDemoApp(viewModel: NetworkViewModel = viewModel()) {
    val gson = GsonBuilder().setPrettyPrinting().create()
    
    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = { Text("NetworkClient Demo") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            var name by remember { mutableStateOf("morpheus") }
            var job by remember { mutableStateOf("leader") }
            var analysisText by remember { mutableStateOf("vector addition physics force diagram") }
            
            // GET Request Section
            DemoSection(title = "GET Request") {
                val getUserResult by viewModel.getUserResult.collectAsState()
                
                Button(
                    onClick = { viewModel.getUser() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("GET User")
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                when (val result = getUserResult) {
                    is NetworkResult.Loading -> {
                        CircularProgressIndicator()
                    }
                    is NetworkResult.Success -> {
                        Text(
                            text = gson.toJson(result.data),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier
                                .background(
                                    color = Color(0xFFE0E0E0),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(8.dp)
                                .fillMaxWidth()
                        )
                    }
                    is NetworkResult.Error -> {
                        Text(
                            text = "Error: ${result.error ?: result.exception?.message}",
                            color = Color.Red
                        )
                    }
                }
            }
            
            // POST Request Section
            DemoSection(title = "POST Request") {
                val createUserResult by viewModel.createUserResult.collectAsState()
                
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                OutlinedTextField(
                    value = job,
                    onValueChange = { job = it },
                    label = { Text("Job") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Button(
                    onClick = { viewModel.createUser(name, job) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("POST Create User")
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                when (val result = createUserResult) {
                    is NetworkResult.Loading -> {
                        CircularProgressIndicator()
                    }
                    is NetworkResult.Success -> {
                        Text(
                            text = gson.toJson(result.data),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier
                                .background(
                                    color = Color(0xFFE0E0E0),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(8.dp)
                                .fillMaxWidth()
                        )
                    }
                    is NetworkResult.Error -> {
                        Text(
                            text = "Error: ${result.error ?: result.exception?.message}",
                            color = Color.Red
                        )
                    }
                }
            }
            
            // PUT Request Section
            DemoSection(title = "PUT Request") {
                val updateUserResult by viewModel.updateUserResult.collectAsState()
                
                Button(
                    onClick = { viewModel.updateUser(name = name, job = job) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("PUT Update User")
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                when (val result = updateUserResult) {
                    is NetworkResult.Loading -> {
                        CircularProgressIndicator()
                    }
                    is NetworkResult.Success -> {
                        Text(
                            text = gson.toJson(result.data),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier
                                .background(
                                    color = Color(0xFFE0E0E0),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(8.dp)
                                .fillMaxWidth()
                        )
                    }
                    is NetworkResult.Error -> {
                        Text(
                            text = "Error: ${result.error ?: result.exception?.message}",
                            color = Color.Red
                        )
                    }
                }
            }
            
            // DELETE Request Section
            DemoSection(title = "DELETE Request") {
                val deleteUserResult by viewModel.deleteUserResult.collectAsState()
                
                Button(
                    onClick = { viewModel.deleteUser() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("DELETE User")
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                when (val result = deleteUserResult) {
                    is NetworkResult.Loading -> {
                        CircularProgressIndicator()
                    }
                    is NetworkResult.Success -> {
                        Text(
                            text = "Successfully deleted (204 No Content)",
                            color = Color.Green
                        )
                    }
                    is NetworkResult.Error -> {
                        Text(
                            text = "Error: ${result.error ?: result.exception?.message}",
                            color = Color.Red
                        )
                    }
                }
            }
            
            // SSE Request Section
            DemoSection(title = "HTTP Chunked Transfer (Streaming)") {
                val streamMessages by viewModel.streamMessages.collectAsState()
                
                OutlinedTextField(
                    value = analysisText,
                    onValueChange = { analysisText = it },
                    label = { Text("Analysis Text") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Button(
                    onClick = { viewModel.startStreamingExplanation(analysisText) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start Chunked Streaming")
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                if (streamMessages.isEmpty()) {
                    Text("No messages received yet")
                } else {
                    Column {
                        Text(
                            "Latest Content:",
                            fontWeight = FontWeight.Bold
                        )
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Text(
                            text = streamMessages.last().content,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier
                                .background(
                                    color = Color(0xFFE0E0E0),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(8.dp)
                                .fillMaxWidth()
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text("Stream Updates: ${streamMessages.size}")
                    }
                }
            }
        }
    }
}

@Composable
fun DemoSection(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Divider(
                modifier = Modifier.padding(vertical = 8.dp)
            )
            
            content()
        }
    }
}