package com.example.netlib

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.netlib.networkClient.CreateUserRequest
import com.example.netlib.networkClient.CreateUserResponse
import com.example.netlib.networkClient.NetworkClient
import com.example.netlib.networkClient.NetworkResult
import com.example.netlib.networkClient.StreamRequest
import com.example.netlib.networkClient.StreamResponse
import com.example.netlib.networkClient.UpdateUserRequest
import com.example.netlib.networkClient.UpdateUserResponse
import com.example.netlib.networkClient.UserResponse
import com.google.gson.Gson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class NetworkViewModel : ViewModel() {
    private val networkClient = NetworkClient.getInstance()
    private val gson = Gson()
    
    private val _getUserResult = MutableStateFlow<NetworkResult<UserResponse>>(NetworkResult.Loading())
    val getUserResult: StateFlow<NetworkResult<UserResponse>> = _getUserResult.asStateFlow()
    
    private val _createUserResult = MutableStateFlow<NetworkResult<CreateUserResponse>>(NetworkResult.Loading())
    val createUserResult: StateFlow<NetworkResult<CreateUserResponse>> = _createUserResult.asStateFlow()
    
    private val _updateUserResult = MutableStateFlow<NetworkResult<UpdateUserResponse>>(NetworkResult.Loading())
    val updateUserResult: StateFlow<NetworkResult<UpdateUserResponse>> = _updateUserResult.asStateFlow()
    
    private val _deleteUserResult = MutableStateFlow<NetworkResult<String>>(NetworkResult.Loading())
    val deleteUserResult: StateFlow<NetworkResult<String>> = _deleteUserResult.asStateFlow()
    
    private val _streamMessages = MutableStateFlow<List<StreamResponse>>(emptyList())
    val streamMessages: StateFlow<List<StreamResponse>> = _streamMessages.asStateFlow()
    
    // GET request
    fun getUser(userId: Int = 2) {
        viewModelScope.launch {
            _getUserResult.value = NetworkResult.Loading()
            _getUserResult.value = networkClient.getObject<UserResponse>("https://reqres.in/api/users/$userId")
        }
    }
    
    // POST request
    fun createUser(name: String, job: String) {
        viewModelScope.launch {
            _createUserResult.value = NetworkResult.Loading()
            val request = CreateUserRequest(name, job)
            _createUserResult.value = networkClient.postObject<CreateUserRequest, CreateUserResponse>(
                "https://reqres.in/api/users", 
                request
            )
        }
    }
    
    // PUT request
    fun updateUser(userId: Int = 2, name: String, job: String) {
        viewModelScope.launch {
            _updateUserResult.value = NetworkResult.Loading()
            val request = UpdateUserRequest(name, job)
            _updateUserResult.value = networkClient.putObject<UpdateUserRequest, UpdateUserResponse>(
                "https://reqres.in/api/users/$userId", 
                request
            )
        }
    }
    
    // DELETE request
    fun deleteUser(userId: Int = 2) {
        viewModelScope.launch {
            _deleteUserResult.value = NetworkResult.Loading()
            _deleteUserResult.value = networkClient.delete("https://reqres.in/api/users/$userId")
        }
    }
    
    // Chunked transfer request
    fun startStreamingExplanation(analysisText: String) {
        viewModelScope.launch {
            // Clear previous messages
            _streamMessages.value = emptyList()
            
            // Create request body
            val requestBody = gson.toJson(StreamRequest(analysisText))
            
            // Start streaming using chunked transfer
            networkClient.streamChunkedData(
                url = "https://c2s-endpoint-server-305533803718.us-central1.run.app/api/gemini/explain-stream",
                requestBody = requestBody
            )
            .catch { e ->
                Log.e("NetworkViewModel", "Stream error: ${e.message}", e)
            }
                .buffer(10)
            .collect { jsonLine ->
                try {
                    val response = gson.fromJson(jsonLine, StreamResponse::class.java)
                    _streamMessages.value = _streamMessages.value + response
                } catch (e: Exception) {
                    Log.e("NetworkViewModel", "Error parsing stream data: ${e.message}", e)
                }
            }
        }
    }
} 