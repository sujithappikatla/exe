from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from dotenv import load_dotenv
import os
import time
from logger import logger
import random
import re
from typing import Optional, List, Dict, Union
from datetime import datetime, timedelta


class VideoSearchClient:
    """
    A client for searching videos using YouTube Data API v3.

    Documentation: https://developers.google.com/youtube/v3/docs/search/list
    
    This client provides comprehensive video search functionality with various filters
    including duration, upload date, video type, and more. It handles pagination,
    quota management, and provides detailed video metadata.
    """

    # Class constants
    MAX_RESULTS = 50  # YouTube API maximum results per request
    DEFAULT_RESULTS = 10

    # Video duration ranges in seconds
    DURATION_RANGES = {
        'short': ('', '4m'),           # < 4 minutes
        'medium': ('4m', '20m'),       # 4-20 minutes
        'long': ('20m', '')            # > 20 minutes
    }

    # Supported video qualities
    VIDEO_QUALITIES = ['any', 'high', 'standard']

    # Supported video types
    VIDEO_TYPES = ['any', 'episode', 'movie']

    # Supported order options
    ORDER_OPTIONS = {
        'date': 'Date',
        'rating': 'Rating',
        'relevance': 'Relevance',
        'title': 'Title',
        'viewCount': 'View Count',
    }

    # Supported caption options
    CAPTION_OPTIONS = ['any', 'closedCaption', 'none']

    # Supported video definitions
    VIDEO_DEFINITIONS = ['any', 'high', 'standard']

    # Supported video dimensions
    VIDEO_DIMENSIONS = ['any', '2d', '3d']

    # Supported languages (ISO 639-1 codes)
    SUPPORTED_LANGUAGES = {
        'ar': 'Arabic', 'bg': 'Bulgarian', 'ca': 'Catalan', 'cs': 'Czech',
        'da': 'Danish', 'de': 'German', 'el': 'Greek', 'en': 'English',
        'es': 'Spanish', 'et': 'Estonian', 'fi': 'Finnish', 'fr': 'French',
        'hr': 'Croatian', 'hu': 'Hungarian', 'id': 'Indonesian', 'is': 'Icelandic',
        'it': 'Italian', 'iw': 'Hebrew', 'ja': 'Japanese', 'ko': 'Korean',
        'lt': 'Lithuanian', 'lv': 'Latvian', 'nl': 'Dutch', 'no': 'Norwegian',
        'pl': 'Polish', 'pt': 'Portuguese', 'ro': 'Romanian', 'ru': 'Russian',
        'sk': 'Slovak', 'sl': 'Slovenian', 'sr': 'Serbian', 'sv': 'Swedish',
        'tr': 'Turkish', 'zh-CN': 'Chinese (Simplified)', 'zh-TW': 'Chinese (Traditional)'
    }

    def __init__(self, env_file_path: Optional[str] = None):
        """
        Initialize the VideoSearchClient.
        
        Args:
            env_file_path: Optional path to .env file. If not provided, looks in current directory.
        """
        # Load environment variables
        if env_file_path:
            load_dotenv(env_file_path)
        else:
            load_dotenv()

        # Initialize credentials
        self._api_key = os.getenv("PROJECT_API_KEY")

        if not self._api_key:
            raise self.SearchError("Missing required configuration")

    class SearchError(Exception):
        """Custom exception for search-related errors."""
        pass

    def _exponential_backoff(self, attempt: int, max_delay: float = 32.0) -> float:
        """
        Calculate delay with exponential backoff and jitter.
        
        Args:
            attempt: The current attempt number
            max_delay: Maximum delay in seconds
            
        Returns:
            The calculated delay in seconds
        """
        delay = min(max_delay, (2 ** attempt) + random.uniform(0, 1))
        return delay

    def _parse_duration(self, duration: str) -> str:
        """
        Convert duration string to YouTube API format.
        
        Args:
            duration: Duration string (e.g., '1h', '5m', '30s')
            
        Returns:
            Duration in PT format (e.g., 'PT1H', 'PT5M', 'PT30S')
        """
        if not duration:
            return ''

        units = {'h': 'H', 'm': 'M', 's': 'S'}
        value = int(duration[:-1])
        unit = duration[-1].lower()

        if unit not in units:
            raise ValueError(f"Invalid duration unit. Use 'h' for hours, 'm' for minutes, 's' for seconds")

        return f'PT{value}{units[unit]}'

    def _format_duration(self, duration: str) -> str:
        """
        Convert YouTube API's ISO 8601 duration format to HH:MM:SS format.
        
        Args:
            duration: Duration string in ISO 8601 format (e.g., 'PT1H2M10S')
            
        Returns:
            Duration in HH:MM:SS format (e.g., '01:02:10')
        """
        if not duration:
            return "00:00:00"

        # Extract hours, minutes, and seconds using regex
        hours = 0
        minutes = 0
        seconds = 0

        # Find hours
        hour_match = re.search(r'(\d+)H', duration)
        if hour_match:
            hours = int(hour_match.group(1))

        # Find minutes
        minute_match = re.search(r'(\d+)M', duration)
        if minute_match:
            minutes = int(minute_match.group(1))

        # Find seconds
        second_match = re.search(r'(\d+)S', duration)
        if second_match:
            seconds = int(second_match.group(1))

        # Format as HH:MM:SS
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def search(
        self,
        query: str,
        language: Optional[str] = None,
        region_code: Optional[str] = None,
        max_results: int = DEFAULT_RESULTS,
        order: str = 'relevance',
        published_after: Optional[Union[str, datetime]] = None,
        published_before: Optional[Union[str, datetime]] = None,
        duration: Optional[str] = None,
        caption: str = 'any',
        definition: str = 'any',
        dimension: str = 'any',
        video_type: str = 'any',
        safe_search: str = 'strict',
        max_retries: int = 3
    ) -> List[Dict[str, str]]:
        """
        Search for videos using YouTube Data API v3 with retry mechanism.
        
        Args:
            query: Search query string
            language: ISO 639-1 language code (e.g., 'en', 'es', 'fr')
            region_code: ISO 3166-1 alpha-2 country code (e.g., 'US', 'GB', 'IN')
            max_results: Number of results to return (1-50)
            order: Order of results ('date', 'rating', 'relevance', 'title', 'viewCount')
            published_after: Filter for videos published after this date/time
            published_before: Filter for videos published before this date/time
            duration: Filter by duration ('short', 'medium', 'long')
            caption: Caption filter ('any', 'closedCaption', 'none')
            definition: Video definition ('any', 'high', 'standard')
            dimension: Video dimension ('any', '2d', '3d')
            video_type: Type of video ('any', 'episode', 'movie')
            safe_search: Safe search level ('none', 'moderate', 'strict')
            max_retries: Maximum number of retry attempts
        
        Returns:
            List of dictionaries containing video results with keys:
            - video_id: YouTube video ID
            - title: Video title
            - description: Video description
            - thumbnail_url: URL of video thumbnail (high quality)
            - channel_id: YouTube channel ID
            - channel_title: Channel name
            - published_at: Publication date/time
            - view_count: Number of views (if available)
            - duration: Video duration (if available)
            - url: Full YouTube video URL
        
        Raises:
            SearchError: If the search fails after all retries
            ValueError: If input parameters are invalid
        """
        # Input validation
        if not query or not isinstance(query, str):
            raise self.SearchError("Invalid input format")

        if max_results < 1 or max_results > self.MAX_RESULTS:
            raise self.SearchError("Invalid input format")

        if order not in self.ORDER_OPTIONS:
            raise self.SearchError("Invalid input format")

        if duration and duration not in self.DURATION_RANGES:
            raise self.SearchError("Invalid input format")

        if caption not in self.CAPTION_OPTIONS:
            raise self.SearchError("Invalid input format")

        if definition not in self.VIDEO_DEFINITIONS:
            raise self.SearchError("Invalid input format")

        if dimension not in self.VIDEO_DIMENSIONS:
            raise self.SearchError("Invalid input format")

        if video_type not in self.VIDEO_TYPES:
            raise self.SearchError("Invalid input format")

        if language and language not in self.SUPPORTED_LANGUAGES:
            raise self.SearchError("Invalid input format")

        # Prepare search parameters
        search_params = {
            'q': query,
            'part': 'snippet',
            'maxResults': max_results,
            'type': 'video',
            'order': order,
            'safeSearch': safe_search,
            'videoCaption': caption if caption != 'any' else None,
            'videoDimension': dimension if dimension != 'any' else None,
            'videoDefinition': definition if definition != 'any' else None,
            'videoType': video_type if video_type != 'any' else None,
            'relevanceLanguage': language,
            'regionCode': region_code
        }

        # Handle date filters
        if published_after:
            if isinstance(published_after, str):
                published_after = datetime.fromisoformat(published_after.replace('Z', '+00:00'))
            search_params['publishedAfter'] = published_after.isoformat('T') + 'Z'

        if published_before:
            if isinstance(published_before, str):
                published_before = datetime.fromisoformat(published_before.replace('Z', '+00:00'))
            search_params['publishedBefore'] = published_before.isoformat('T') + 'Z'

        # Remove None values
        search_params = {k: v for k, v in search_params.items() if v is not None}

        for attempt in range(max_retries):
            try:
                logger.info(f"Attempting video search. Attempt {attempt + 1}/{max_retries}")
                youtube = build('youtube', 'v3', developerKey=self._api_key)
                
                # First request to get video IDs and basic info
                search_response = youtube.search().list(**search_params).execute()

                if not search_response.get('items'):
                    logger.warning("No video results found")
                    return []

                # Get video IDs
                video_ids = [item['id']['videoId'] for item in search_response['items']]

                # Second request to get detailed video information
                videos_response = youtube.videos().list(
                    part='snippet,contentDetails,statistics',
                    id=','.join(video_ids)
                ).execute()

                ret = []
                for item in videos_response['items']:
                    snippet = item['snippet']
                    statistics = item.get('statistics', {})
                    content_details = item.get('contentDetails', {})
                    
                    temp = {
                        # "video_id": item['id'],
                        "title": snippet.get('title', ''),
                        # "description": snippet.get('description', ''),
                        "thumbnail_url": snippet.get('thumbnails', {}).get('medium', {}).get('url', ''),
                        # "channel_id": snippet.get('channelId', ''),
                        "channel_title": snippet.get('channelTitle', ''),
                        # "published_at": snippet.get('publishedAt', ''),
                        # "view_count": statistics.get('viewCount', '0'),
                        "duration": self._format_duration(content_details.get('duration', '')),
                        "url": f"https://www.youtube.com/watch?v={item['id']}"
                    }
                    ret.append(temp)

                logger.info(f"Successfully retrieved {len(ret)} video results")
                return ret

            except HttpError as e:
                logger.error(f"HTTP error occurred: {str(e)}")
                if e.resp.status in [429, 500, 503]:  # Retry on rate limit or server errors
                    if attempt < max_retries - 1:
                        delay = self._exponential_backoff(attempt)
                        logger.info(f"Retrying in {delay:.2f} seconds...")
                        time.sleep(delay)
                        continue
                if e.resp.status == 429:
                    raise self.SearchError("API limit exceeded")
                elif e.resp.status in [401, 403]:
                    raise self.SearchError("API key invalid")
                else:
                    raise self.SearchError("API request failed")
                
            except Exception as e:
                logger.error(f"Unexpected error: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                raise self.SearchError("Video search operation failed")

if __name__ == "__main__":
    try:
        # Initialize the client
        client = VideoSearchClient()
        
        # Example video search with parameters
        results = client.search(
            query="python programming tutorial",
            # language="en",                # English content
            # region_code="US",             # US region
            # max_results=5,                # Get 5 results
            # order="viewCount",            # Sort by view count
            # duration="medium",            # Medium length videos
            # definition="high",            # HD videos
            # safe_search="moderate"        # Moderate safe search
        )
        
        print(f"Found {len(results)} videos")
        for result in results:
            print("\nVideo details:")
            for key, value in result.items():
                print(f"{key}: {value}")
    except (VideoSearchClient.SearchError, ValueError) as e:
        logger.error(f"Error during video search: {str(e)}")
