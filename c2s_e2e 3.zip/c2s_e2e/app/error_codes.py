"""
Error codes for the application.
Each code is prepended with 'ERR-' followed by three digits and a description.

First digit categories:
1xx - API and Rate Limit Errors
2xx - Data Processing Errors
3xx - Model and Generation Errors
4xx - Configuration Errors
5xx - Infrastructure Errors
"""

from typing import Dict, Optional

ERROR_CODES: Dict[str, str] = {
    # 1xx - API and Rate Limit Errors
    "ERR-101": "API Key Invalid",
    "ERR-102": "API Request Failed",
    "ERR-111": "API Limit Exceeded",
    "ERR-121": "Service Unavailable",
    "ERR-131": "Request Timeout",
    
    # 2xx - Data Processing Errors
    "ERR-201": "Invalid Input Format",
    "ERR-202": "Missing Required Fields",
    "ERR-211": "Data Validation Failed",
    "ERR-212": "Parsing Failed",
    "ERR-221": "Image Processing Failed",
    "ERR-222": "Video Processing Failed",
    
    # 3xx - Model and Generation Errors
    "ERR-301": "Model Initialization Failed",
    "ERR-302": "Model Not Found",
    "ERR-311": "Failed to Generate Response",
    "ERR-321": "Content Safety Violation",
    "ERR-331": "Context Processing Failed",
    
    # 4xx - Configuration Errors
    "ERR-401": "Missing Configuration",
    "ERR-402": "Invalid Configuration",
    "ERR-411": "Environment Setup Failed",
    "ERR-421": "Service Configuration Failed",
    
    # 5xx - Infrastructure Errors
    "ERR-501": "Service Connection Failed",
    "ERR-502": "Database Error",
    "ERR-511": "Network Error",
    "ERR-521": "Resource Not Available",
}

def get_error_message(code: str) -> str:
    """Get the error message for a given error code."""
    return f"{code} : {ERROR_CODES.get(code, 'Unknown Error')}"

def get_error_code(error_type: str) -> Optional[str]:
    """Get the appropriate error code based on the error type."""
    error_type_lower = error_type.lower()
    
    # API and Rate Limit Errors
    if "api key" in error_type_lower or "authentication" in error_type_lower:
        return "ERR-101"
    elif "rate limit" in error_type_lower or "quota" in error_type_lower:
        return "ERR-111"
    elif "timeout" in error_type_lower:
        return "ERR-131"
        
    # Data Processing Errors
    elif "invalid input" in error_type_lower or "validation" in error_type_lower:
        return "ERR-201"
    elif "missing" in error_type_lower and "field" in error_type_lower:
        return "ERR-202"
    elif "parse" in error_type_lower or "parsing" in error_type_lower:
        return "ERR-212"
    elif "image" in error_type_lower and "process" in error_type_lower:
        return "ERR-221"
    elif "video" in error_type_lower and "process" in error_type_lower:
        return "ERR-222"
        
    # Model and Generation Errors
    elif "model" in error_type_lower and "init" in error_type_lower:
        return "ERR-301"
    elif "model not found" in error_type_lower:
        return "ERR-302"
    elif "generate" in error_type_lower or "generation" in error_type_lower:
        return "ERR-311"
    elif "safety" in error_type_lower or "inappropriate" in error_type_lower:
        return "ERR-321"
        
    # Configuration Errors
    elif "configuration" in error_type_lower or "config" in error_type_lower:
        return "ERR-402"
    elif "environment" in error_type_lower or "env" in error_type_lower:
        return "ERR-411"
        
    # Infrastructure Errors
    elif "connection" in error_type_lower:
        return "ERR-501"
    elif "network" in error_type_lower:
        return "ERR-511"
    elif "resource" in error_type_lower or "not available" in error_type_lower:
        return "ERR-521"
    
    # Default error code for unknown errors
    return "ERR-102" 