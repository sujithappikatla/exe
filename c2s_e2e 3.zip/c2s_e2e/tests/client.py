import streamlit as st
import requests
import json
import base64
from typing import Dict, Any, Optional
from PIL import Image
import io
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
API_BASE_URL = "http://0.0.0.0:8080/api"
# API_BASE_URL = "https://c2s-endpoint-server-305533803718.us-central1.run.app/api"

class APIClient:
    """Client for interacting with the API endpoints."""
    
    @staticmethod
    def make_request(endpoint: str, data: Dict[str, Any]) -> Optional[Dict]:
        """
        Make a POST request to the API.
        
        Args:
            endpoint: API endpoint path
            data: Request data
            
        Returns:
            Optional[Dict]: Response data if successful, None if failed
        """
        try:
            url = f"{API_BASE_URL}/{endpoint}"
            response = requests.post(url, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            st.error(f"API Request Failed: {str(e)}")
            logger.error(f"API Request Failed: {str(e)}")
            return None

def encode_image(image_file) -> Optional[str]:
    """
    Encode image file to base64.
    
    Args:
        image_file: Uploaded image file
        
    Returns:
        Optional[str]: Base64 encoded image string if successful, None if failed
    """
    try:
        return base64.b64encode(image_file.getvalue()).decode('utf-8')
    except Exception as e:
        st.error(f"Failed to encode image: {str(e)}")
        logger.error(f"Image encoding failed: {str(e)}")
        return None

def render_search_results(results: Dict) -> None:
    """
    Render search results in a clean format.
    
    Args:
        results: Search results dictionary
    """
    if not results or not results.get('success'):
        st.error("No results found or API request failed")
        return

    data = results.get('data', [])
    if not data:
        st.info("No results found")
        return

    for item in data:
        with st.expander(item.get('title', 'No Title')):
            # Show snippet if available
            if 'snippet' in item:
                st.write(item['snippet'])
            
            # Handle YouTube video links
            if 'link' in item and 'youtube.com/watch?v=' in item['link']:
                video_id = item['link'].split('watch?v=')[-1].split('&')[0]
                st.video(f"https://www.youtube.com/watch?v={video_id}")
                st.write(f"[Open in YouTube]({item['link']})")
            # Handle other links
            elif 'link' in item:
                st.write(f"[Link]({item['link']})")
            
            # Show image for image search results
            if 'image_url' in item:
                st.image(item['image_url'], use_column_width=True)
            elif 'thumbnail' in item:
                st.image(item['thumbnail'], use_column_width=True)
            
            # Show duration for videos
            if 'duration' in item:
                st.write(f"Duration: {item['duration']}")
            
            # Display all other metadata
            for key, value in item.items():
                if key not in ['title', 'snippet', 'link', 'thumbnail', 'duration', 'image_url']:
                    st.write(f"{key}: {value}")

            # Add a separator between results
            st.markdown("---")

def render_gemini_results(results: Dict) -> None:
    """
    Render Gemini analysis results in a clean format.
    
    Args:
        results: Gemini results dictionary
    """
    if not results or not results.get('success'):
        st.error("No results found or API request failed")
        return

    data = results.get('data', {})
    
    # For search queries
    if 'search_query' in data:
        st.subheader("Generated Queries")
        st.write("Web Search:", data['search_query'])
        st.write("YouTube Search:", data['youtube_query'])
        st.write("Image Search:", data['image_query'])
        
        st.subheader("Follow-up Topics")
        for topic in data.get('followup', []):
            st.write(f"- {topic}")
            
        if 'context' in data:
            st.subheader("Context")
            st.write(data['context'])
    
    # For analysis results
    if 'analysis' in data:
        st.subheader("Analysis")
        analysis = data['analysis']
        st.write("Key Topic:", analysis.get('key_topic', ''))
        st.write("Full Image Description:", analysis.get('full_image_description', ''))
        st.write("Cropped Image Description:", analysis.get('cropped_image_description', ''))
        
        if 'explanation' in data:
            st.subheader("Educational Explanation")
            explanation = data['explanation']
            st.markdown(explanation.get('content', ''))
            
            if explanation.get('citations'):
                st.subheader("Citations")
                for citation in explanation['citations']:
                    st.write(f"- [{citation['title']}]({citation['uri']})")

def main():
    st.set_page_config(page_title="API Client", layout="wide")
    st.title("API Client")
    
    # Sidebar for API selection
    api_option = st.sidebar.selectbox(
        "Select API",
        ["Web Search", "Image Search", "Video Search", 
         "Discovery Engine - Add Sites", "Discovery Engine - Search",
         "Gemini - Analyze & Explain"]
    )
    
    # Main content area
    if api_option == "Web Search":
        st.header("Web Search")
        with st.form("web_search_form"):
            query = st.text_input("Search Query *")
            col1, col2 = st.columns(2)
            with col1:
                num = st.number_input("Number of Results", min_value=1, max_value=10, value=5)
                gl = st.text_input("Geolocation (e.g., us)")
            with col2:
                safe = st.checkbox("Safe Search")
                lr = st.text_input("Language (e.g., en)")
            
            if st.form_submit_button("Search"):
                if not query:
                    st.error("Search Query is required")
                else:
                    data = {"query": query, "num": num}
                    if gl: data["gl"] = gl
                    if lr: data["lr"] = lr
                    if safe: data["safe"] = safe
                    
                    results = APIClient.make_request("web-search", data)
                    if results:
                        render_search_results(results)
    
    elif api_option == "Image Search":
        st.header("Image Search")
        with st.form("image_search_form"):
            query = st.text_input("Search Query *")
            col1, col2 = st.columns(2)
            with col1:
                num = st.number_input("Number of Results", min_value=1, max_value=10, value=5)
                image_size = st.selectbox("Image Size", ["", "LARGE", "MEDIUM", "SMALL"])
            with col2:
                safe = st.checkbox("Safe Search")
                image_type = st.selectbox("Image Type", ["", "face", "photo", "clipart", "lineart"])
            
            if st.form_submit_button("Search"):
                if not query:
                    st.error("Search Query is required")
                else:
                    data = {"query": query, "num": num}
                    if image_size: data["image_size"] = image_size
                    if image_type: data["image_type"] = image_type
                    if safe: data["safe"] = safe
                    
                    results = APIClient.make_request("image-search", data)
                    if results:
                        render_search_results(results)
    
    elif api_option == "Video Search":
        st.header("Video Search")
        with st.form("video_search_form"):
            query = st.text_input("Search Query *")
            col1, col2 = st.columns(2)
            with col1:
                max_results = st.number_input("Number of Results", min_value=1, max_value=10, value=5)
                duration = st.selectbox("Duration", ["", "short", "medium", "long"])
            with col2:
                definition = st.selectbox("Definition", ["", "high", "standard"])
                safe_search = st.selectbox("Safe Search", ["", "moderate", "strict"])
            
            if st.form_submit_button("Search"):
                if not query:
                    st.error("Search Query is required")
                else:
                    data = {"query": query, "max_results": max_results}
                    if duration: data["duration"] = duration
                    if definition: data["definition"] = definition
                    if safe_search: data["safe_search"] = safe_search
                    
                    results = APIClient.make_request("video-search", data)
                    if results:
                        render_search_results(results)
    
    elif api_option == "Discovery Engine - Add Sites":
        st.header("Add Target Sites")
        with st.form("add_sites_form"):
            websites = st.text_area(
                "Enter websites (one per line) *",
                help="Example:\nwww.wikipedia.org\nwww.nasa.gov"
            )
            
            if st.form_submit_button("Add Sites"):
                if not websites:
                    st.error("At least one website is required")
                else:
                    sites_list = [site.strip() for site in websites.split('\n') if site.strip()]
                    if not sites_list:
                        st.error("Please enter valid websites")
                    else:
                        data = {"websites": sites_list}
                        results = APIClient.make_request("discovery-engine/add-sites", data)
                        if results and results.get('success'):
                            st.success("Sites added successfully")
                            st.write("Target Sites:")
                            for site in results['data']:
                                st.write(f"- {site}")
    
    elif api_option == "Discovery Engine - Search":
        st.header("Discovery Engine Search")
        with st.form("discovery_search_form"):
            query = st.text_input("Search Query *")
            websites = st.text_area(
                "Enter websites to search (one per line) *",
                help="Example:\nwww.wikipedia.org"
            )
            
            if st.form_submit_button("Search"):
                if not query:
                    st.error("Search Query is required")
                elif not websites:
                    st.error("At least one website is required")
                else:
                    sites_list = [site.strip() for site in websites.split('\n') if site.strip()]
                    if not sites_list:
                        st.error("Please enter valid websites")
                    else:
                        data = {"query": query, "websites": sites_list}
                        results = APIClient.make_request("discovery-engine/search", data)
                        if results:
                            render_search_results(results)
    
    elif api_option == "Gemini - Analyze & Explain":
        st.header("Analyze Images & Get Explanation")
        with st.form("gemini_analyze_explain_form"):
            col1, col2 = st.columns(2)
            with col1:
                image1 = st.file_uploader("Upload Full Image * (PNG, JPG)", type=['png', 'jpg', 'jpeg'])
                mime_type1 = st.selectbox("MIME Type (Image 1)", ["image/jpeg", "image/png"])
            with col2:
                image2 = st.file_uploader("Upload Cropped Image * (PNG, JPG)", type=['png', 'jpg', 'jpeg'])
                mime_type2 = st.selectbox("MIME Type (Image 2)", ["image/jpeg", "image/png"])
            
            # Add structured context inputs
            st.subheader("Context Information")
            col3, col4 = st.columns(2)
            with col3:
                grade = st.selectbox("Grade Level", ["", "6", "7", "8", "9", "10", "11", "12"])
                subject = st.selectbox("Subject", ["", "Math", "Science", "Physics", "Chemistry", "Biology", "Computer Science"])
            with col4:
                context = st.text_area("Additional Context (optional)", help="Any additional context about the topic")
            
            if st.form_submit_button("Analyze & Explain"):
                if not image1 or not image2:
                    st.error("Both images are required")
                else:
                    image1_b64 = encode_image(image1)
                    image2_b64 = encode_image(image2)
                    
                    if image1_b64 and image2_b64:
                        # Prepare extended context
                        extended_context = {}
                        if grade: extended_context["grade"] = grade
                        if subject: extended_context["subject"] = subject
                        if context: extended_context["context"] = context
                        
                        # First, send analyze request
                        analyze_data = {
                            "full_image": image1_b64,
                            "roi_image": image2_b64,
                            "full_image_mime_type": mime_type1,
                            "roi_image_mime_type": mime_type2
                        }
                        if extended_context:
                            analyze_data["extended_context"] = extended_context
                        
                        with st.spinner("Analyzing images..."):
                            analyze_results = APIClient.make_request("gemini/analyze", analyze_data)
                        
                        if analyze_results and analyze_results.get('success'):
                            st.subheader("Analysis Results")
                            analysis_data = analyze_results.get('data', {})
                            
                            # Display analysis results
                            if analysis_data.get('search_query'):
                                st.write("Main Search Query:", analysis_data['search_query'])
                            
                            if analysis_data.get('quick_followup_queries'):
                                st.write("Quick Follow-up Queries:")
                                for query in analysis_data['quick_followup_queries']:
                                    st.write(f"- {query}")
                            
                            if analysis_data.get('suggested_queries'):
                                st.write("Suggested Queries:")
                                for query in analysis_data['suggested_queries']:
                                    st.write(f"- {query}")
                            
                            # If we have a search query, get explanation
                            if analysis_data.get('search_query'):
                                with st.spinner("Generating explanation..."):
                                    explain_data = {
                                        "analysis": analysis_data['search_query']
                                    }
                                    explain_results = APIClient.make_request("gemini/explain", explain_data)
                                
                                if explain_results and explain_results.get('success'):
                                    explanation_data = explain_results.get('data', {})
                                    
                                    st.subheader("Educational Explanation")
                                    if explanation_data.get('content'):
                                        st.markdown(explanation_data['content'])
                                    
                                    if explanation_data.get('citations'):
                                        st.subheader("Citations")
                                        for citation in explanation_data['citations']:
                                            st.write(f"- [{citation['title']}]({citation['uri']})")
                                else:
                                    st.error("Failed to generate explanation")
                        else:
                            st.error("Failed to analyze images")

if __name__ == "__main__":
    main() 