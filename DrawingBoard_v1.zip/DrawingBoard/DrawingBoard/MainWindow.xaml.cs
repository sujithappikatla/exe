﻿using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace DrawingBoard
{
    public partial class MainWindow : Window
    {

        [DllImport("user32.dll")]
        public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TRANSPARENT = 0x20;

        private Polyline currentLine;
        private bool isDrawing;
        private bool isEraser = false;
        private SolidColorBrush brushColor = Brushes.Black;

        public MainWindow()
        {
            InitializeComponent();
            this.Show();
            OpenChildWindow_Click(null, null);
        }

        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
                isDrawing = true;

            if (isEraser)
            {
                Point eraserPosition = e.GetPosition(drawingCanvas);
                EraseAtPosition(eraserPosition, 10);
                
            }
            else
            {
                // Start a new polyline
                currentLine = new Polyline
                {
                    Stroke = brushColor,
                    StrokeThickness = 2,
                    StrokeLineJoin = PenLineJoin.Round,
                    StrokeEndLineCap = PenLineCap.Round,
                };

                drawingCanvas.Children.Add(currentLine);
                currentLine.Points.Add(e.GetPosition(drawingCanvas));
            }


           

            
        }

        private void EraseAtPosition(Point eraserCenter, double eraserRadius)
        {
            var toRemove = new List<UIElement>();
            var toAdd = new List<Polyline>();

            foreach (UIElement element in drawingCanvas.Children)
            {
                if (element is Polyline polyline)
                {
                    var newPolyline = new Polyline
                    {
                        Stroke = polyline.Stroke,
                        StrokeThickness = polyline.StrokeThickness
                    };

                    foreach (Point point in polyline.Points)
                    {
                        if (Math.Sqrt(Math.Pow(point.X - eraserCenter.X, 2) + Math.Pow(point.Y - eraserCenter.Y, 2)) > eraserRadius)
                        {
                            newPolyline.Points.Add(point);
                        }
                        else
                        {
                            // When encountering a point that should be erased, 
                            // add the current newPolyline to toAdd list if it has points,
                            // and start a new polyline for subsequent points.
                            if (newPolyline.Points.Count > 0)
                            {
                                toAdd.Add(newPolyline);
                                newPolyline = new Polyline
                                {
                                    Stroke = polyline.Stroke,
                                    StrokeThickness = polyline.StrokeThickness
                                };
                            }
                        }
                    }

                    if (newPolyline.Points.Count > 0)
                    {
                        toAdd.Add(newPolyline);
                    }
                    toRemove.Add(polyline);
                }
            }

            foreach (var item in toRemove)
            {
                drawingCanvas.Children.Remove(item);
            }

            foreach (var item in toAdd)
            {
                drawingCanvas.Children.Add(item);
            }
        }


        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && isDrawing)
            {

                if (isEraser)
                {
                    Point eraserPosition = e.GetPosition(drawingCanvas);
                    EraseAtPosition(eraserPosition, 10);
                   
                }
                else
                {
                    // Add the current point to the line
                    Point point = e.GetPosition(drawingCanvas);
                    currentLine.Points.Add(point);
                }

                
            }
        }

        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isDrawing = false;
        }

        public void Pen_Click(object sender, RoutedEventArgs e)
        {
            // Code to switch to pen tool
            isEraser = false;
        }

        public void Eraser_Click(object sender, RoutedEventArgs e)
        {
            // Code to switch to eraser tool
            isEraser = true;
        }

        public void RedColor_Click(object sender, RoutedEventArgs e)
        {
            // Code to switch to eraser tool
            brushColor = Brushes.Red;


        }

        private bool isClickThrough = false;

        public void ToggleClickThroughButton_Click(object sender, RoutedEventArgs e)
        {
            if (isClickThrough)
            {
                MakeWindowCaptureMouseEvents();
            }
            else
            {
                MakeWindowTransparentToMouseEvents();
            }
            isClickThrough = !isClickThrough;
        }


        private void MakeWindowTransparentToMouseEvents()
        {
            var windowInteropHelper = new WindowInteropHelper(this);
            int extendedStyle = GetWindowLong(windowInteropHelper.Handle, GWL_EXSTYLE);
            SetWindowLong(windowInteropHelper.Handle, GWL_EXSTYLE, extendedStyle | WS_EX_TRANSPARENT);
        }

        private void MakeWindowCaptureMouseEvents()
        {
            var windowInteropHelper = new WindowInteropHelper(this);
            int extendedStyle = GetWindowLong(windowInteropHelper.Handle, GWL_EXSTYLE);
            SetWindowLong(windowInteropHelper.Handle, GWL_EXSTYLE, extendedStyle & ~WS_EX_TRANSPARENT);
        }

        private void OpenChildWindow_Click(object sender, RoutedEventArgs e)
        {
            Controls childWindow = new Controls();
            // childWindow.Show(); // Use this to open non-modal
            childWindow.Owner = this;
            childWindow.Show(); // Use this to open as modal
        }



    }
}