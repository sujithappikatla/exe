﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DrawingBoard
{
    /// <summary>
    /// Interaction logic for Controls.xaml
    /// </summary>
    public partial class Controls : Window
    {
        private bool isDragging = false;
        private Point mouseStartPosition;

        public Controls()
        {
            InitializeComponent();
            this.LocationChanged += ChildWindow_LocationChanged;
            this.MouseDown += MainWindow_MouseDown;
            this.MouseMove += MainWindow_MouseMove;
            this.MouseUp += MainWindow_MouseUp;
        }

        private void MainWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Only start dragging on left mouse button press
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                isDragging = true;
                mouseStartPosition = e.GetPosition(this);
                // Capture the mouse to receive mouse move events even when the mouse leaves the window
                this.CaptureMouse();
            }
        }

        private void MainWindow_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging && e.LeftButton == MouseButtonState.Pressed)
            {
                Point mouseCurrentPosition = e.GetPosition(this);
                double offsetX = mouseCurrentPosition.X - mouseStartPosition.X;
                double offsetY = mouseCurrentPosition.Y - mouseStartPosition.Y;

                this.Left += offsetX;
                this.Top += offsetY;
            }
        }

        private void MainWindow_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (isDragging)
            {
                isDragging = false;
                this.ReleaseMouseCapture();
            }
        }

        private void ChildWindow_LocationChanged(object sender, EventArgs e)
        {
            var parent = this.Owner;

            if (parent != null)
            {
                // Get parent window bounds
                Rect parentBounds = new Rect(parent.Left, parent.Top, parent.Width, parent.Height);

                // Ensure child window is within the parent window bounds
                // Adjust these as necessary to account for window chrome
                double newLeft = Math.Max(parentBounds.Left, Math.Min(this.Left, parentBounds.Right - this.ActualWidth));
                double newTop = Math.Max(parentBounds.Top, Math.Min(this.Top, parentBounds.Bottom - this.ActualHeight));

                // Apply the constrained position
                this.Left = newLeft;
                this.Top = newTop;
            }
        }

        private void Pen_Click(object sender, RoutedEventArgs e)
        {
            if (this.Owner is MainWindow parentWindow)
            {
                parentWindow.Pen_Click(null, null);
            }
        }

        private void Eraser_Click(object sender, RoutedEventArgs e)
        {
            if (this.Owner is MainWindow parentWindow)
            {
                parentWindow.Eraser_Click(null, null);
            }
        }

        private void RedColor_Click(object sender, RoutedEventArgs e)
        {
            if (this.Owner is MainWindow parentWindow)
            {
                parentWindow.RedColor_Click(null, null);
            }
        }

        private void ToggleClickThroughButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.Owner is MainWindow parentWindow)
            {
                parentWindow.ToggleClickThroughButton_Click(null, null);
            }
        }
    }
}
