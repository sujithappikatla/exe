package com.example.glitch

import android.content.Intent
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.*
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.compose.ui.platform.ComposeView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.animation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.launch

class OverlayService : LifecycleService(), SavedStateRegistryOwner {
    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: ComposeView
    private var params: WindowManager.LayoutParams? = null
    
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        savedStateRegistryController.performRestore(null)
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupOverlay()
    }

    private fun setupOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        overlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
        }

        overlayView.setContent {
            OverlayContent(
                onPositionChange = { x, y ->
                    updateOverlayPosition(x.toInt(), y.toInt())
                }
            )
        }

        windowManager.addView(overlayView, params)
    }

    private fun updateOverlayPosition(x: Int, y: Int) {
        params?.let { layoutParams ->
            layoutParams.x = x
            layoutParams.y = y
            windowManager.updateViewLayout(overlayView, layoutParams)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}

@Composable
private fun OverlayContent(
    onPositionChange: (Int, Int) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    var isDragging by remember { mutableStateOf(false)}
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current

    // Store window position (Int to avoid rounding issues)
    var windowX by remember { mutableStateOf(0) }
    var windowY by remember { mutableStateOf(100) } // Initial Y position


    Box(
        modifier = Modifier
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = {
                        isDragging = true
                        // Collapse BEFORE position change to avoid conflicts
                        if (isExpanded) {
                            coroutineScope.launch { isExpanded = false }
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        windowX = (windowX + dragAmount.x).toInt()
                        windowY = (windowY + dragAmount.y).toInt()
                        onPositionChange(windowX, windowY)  // Immediately update WindowManager
                    },
                    onDragEnd = {
                        isDragging = false
                    },
                    onDragCancel = {
                        isDragging = false
                    }
                )
            }
    ) {
        Row(
        ) {  // No alpha modification needed

            Surface(
                modifier = Modifier
                    .size(50.dp)
                    .padding(4.dp),
                color = Color.Blue,
                onClick = {
                    if (!isDragging){  // Prevent clicks during drag to avoid flicker
                        isExpanded = !isExpanded
                    }
                }
            ) {}

            AnimatedVisibility(
                visible = isExpanded,
                enter = slideInHorizontally { with(density) { 50.dp.roundToPx() } },
                exit = slideOutHorizontally { with(density) { -50.dp.roundToPx() } }
            ) {
                Surface(
                    modifier = Modifier
                        .size(100.dp)
                        .padding(4.dp),
                    color = Color.Red
                ) {}
            }
        }
    }
}