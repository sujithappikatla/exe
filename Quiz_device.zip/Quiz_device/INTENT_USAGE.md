# Quiz App Intent Integration

This document explains how other Android apps can launch the Quiz app with pre-loaded question data, automatically opening the lobby screen.

## Overview

The Quiz app supports being launched from other apps with quiz data through Android Intents. This allows seamless integration where other educational apps can create quizzes and launch the Quiz app to conduct them.

## Supported Intent Methods

### 1. Direct Intent with Action

**Action:** `com.example.quiz.LAUNCH_QUIZ`  
**Package:** `com.example.quiz`  
**MIME Type:** `application/json`

**Intent Extras:**
- `quiz_data` (String): JSON representation of quiz data
- `teacher_name` (String): Name of the teacher (optional, defaults to "Teacher")

### 2. Deep Link Intent

**Scheme:** `quiz://launch`  
**Parameters:**
- `quiz_data`: URL-encoded JSON representation of quiz data
- `teacher_name`: Name of the teacher (optional)

## Quiz Data Format

The quiz data must be in the following JSON format:

```json
{
  "title": "Sample Math Quiz",
  "questions": [
    {
      "id": "q1",
      "text": "What is 2 + 2?",
      "options": ["3", "4", "5", "6"],
      "correct_option": "4",
      "timer": 30,
      "reasoning": {
        "3": "Incorrect. 2 + 2 equals 4.",
        "4": "Correct! 2 + 2 = 4.",
        "5": "Incorrect. 2 + 2 equals 4.",
        "6": "Incorrect. 2 + 2 equals 4."
      }
    }
  ]
}
```

### Required Fields
- `title`: Quiz title (String)
- `questions`: Array of question objects
  - `id`: Unique identifier for the question (String)
  - `text`: Question text (String)
  - `options`: Array of answer options (String[])
  - `correct_option`: The correct answer (String, must match one of the options)
  - `timer`: Time limit for the question in seconds (Integer, > 0)

### Optional Fields
- `reasoning`: Map of option explanations (Map<String, String>)

## Implementation Examples

### Method 1: Using IntentHelper (Recommended)

```kotlin
import com.example.quiz.IntentHelper
import com.example.quiz.data.QuizData
import com.example.quiz.data.Question

// Create quiz data
val quizData = QuizData(
    title = "My Math Quiz",
    questions = listOf(
        Question(
            id = "q1",
            text = "What is 5 + 3?",
            options = listOf("6", "7", "8", "9"),
            correctOption = "8",
            timer = 30
        )
    )
)

// Launch Quiz app
val intent = IntentHelper.createLaunchIntent(context, "Teacher Name", quizData)
context.startActivity(intent)
```

### Method 2: Manual Intent Creation

```kotlin
import android.content.Intent
import com.google.gson.Gson

val gson = Gson()
val quizDataJson = gson.toJson(quizData)

val intent = Intent().apply {
    action = "com.example.quiz.LAUNCH_QUIZ"
    setPackage("com.example.quiz")
    putExtra("teacher_name", "Teacher Name")
    putExtra("quiz_data", quizDataJson)
    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}

context.startActivity(intent)
```

### Method 3: Deep Link

```kotlin
import android.content.Intent
import android.net.Uri

val quizDataJson = gson.toJson(quizData)
val uri = Uri.parse("quiz://launch")
    .buildUpon()
    .appendQueryParameter("teacher_name", "Teacher Name")
    .appendQueryParameter("quiz_data", quizDataJson)
    .build()

val intent = Intent(Intent.ACTION_VIEW, uri)
context.startActivity(intent)
```

### Method 4: ADB Command (for testing)

```bash
# Direct intent
adb shell am start \
  -a "com.example.quiz.LAUNCH_QUIZ" \
  -n "com.example.quiz/.MainActivity" \
  --es "teacher_name" "Test Teacher" \
  --es "quiz_data" '{"title":"Test Quiz","questions":[{"id":"q1","text":"Test question?","options":["A","B","C","D"],"correct_option":"A","timer":30}]}'

# Deep link
adb shell am start \
  -a android.intent.action.VIEW \
  -d "quiz://launch?teacher_name=Test%20Teacher&quiz_data=%7B%22title%22%3A%22Test%20Quiz%22%2C%22questions%22%3A%5B%7B%22id%22%3A%22q1%22%2C%22text%22%3A%22Test%20question%3F%22%2C%22options%22%3A%5B%22A%22%2C%22B%22%2C%22C%22%2C%22D%22%5D%2C%22correct_option%22%3A%22A%22%2C%22timer%22%3A30%7D%5D%7D"
```

## App Behavior

When launched via intent:

1. **Connection**: App automatically connects to the Socket.IO server
2. **Class Creation**: Automatically creates a class with the provided quiz data
3. **Lobby Screen**: Directly opens the lobby screen showing the class code
4. **Ready to Start**: Teacher can immediately see joined students and start the quiz

## Error Handling

The app validates the provided quiz data and will show error messages for:

- Invalid JSON format
- Missing required fields
- Empty questions array
- Invalid timer values (≤ 0)
- Empty question text or options
- Missing correct option

## Dependencies

Make sure your app includes the Gson library for JSON serialization:

```gradle
implementation 'com.google.code.gson:gson:2.10.1'
```

## Troubleshooting

### App Not Opening
- Ensure the Quiz app is installed on the device
- Check that the package name is correct: `com.example.quiz`
- Verify the intent action: `com.example.quiz.LAUNCH_QUIZ`

### Data Not Loading
- Validate JSON format using a JSON validator
- Ensure all required fields are present
- Check logcat for detailed error messages

### Permission Issues
- The Quiz app requires INTERNET permission (already included)
- No additional permissions required for intent launching

## Testing

Use the provided `IntentHelper.launchQuizExample()` method for testing the integration. 