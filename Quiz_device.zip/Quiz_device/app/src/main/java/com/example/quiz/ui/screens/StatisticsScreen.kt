package com.example.quiz.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quiz.data.QuizStatistics
import kotlin.math.max

@Composable
fun StatisticsScreen(
    statistics: QuizStatistics?,
    onNewQuiz: () -> Unit
) {
    if (statistics == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Quiz Complete!",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = statistics.quizOverview.quizTitle,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
        
        // Key Metrics Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Students",
                    value = statistics.quizOverview.totalStudentsJoined.toString(),
                    subtitle = "joined",
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                
                MetricCard(
                    title = "Average",
                    value = "${statistics.performanceSummary.averagePercentage.toInt()}%",
                    subtitle = "score",
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )
                
                MetricCard(
                    title = "Completion",
                    value = "${statistics.quizOverview.completionRate.toInt()}%",
                    subtitle = "rate",
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        
        // Score Distribution
        item {
            StatisticsCard(
                title = "Score Distribution",
                icon = Icons.Default.BarChart,
                content = {
                    ScoreDistributionChart(
                        scoreDistribution = statistics.performanceSummary.scoreDistribution
                    )
                }
            )
        }
        
        // Performance Summary
        item {
            StatisticsCard(
                title = "Performance Summary",
                icon = Icons.Default.TrendingUp,
                content = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PerformanceBar(
                            label = "Average Score",
                            value = statistics.performanceSummary.averageScore.toFloat(),
                            maxValue = statistics.quizOverview.totalQuestions.toFloat(),
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        StatisticRow(
                            label = "Highest Score",
                            value = "${statistics.performanceSummary.highestScore}/${statistics.quizOverview.totalQuestions}"
                        )
                        StatisticRow(
                            label = "Lowest Score",
                            value = "${statistics.performanceSummary.lowestScore}/${statistics.quizOverview.totalQuestions}"
                        )
                    }
                }
            )
        }
        
        // Top Performers
        item {
            StatisticsCard(
                title = "🏆 Top Performers",
                icon = Icons.Default.EmojiEvents,
                content = {
                    if (statistics.topPerformers.isEmpty()) {
                        EmptyStateMessage("No top performers data available")
                    } else {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            statistics.topPerformers.forEach { performer ->
                                PerformerRow(
                                    rank = performer.rank,
                                    name = performer.name,
                                    score = performer.score,
                                    totalQuestions = statistics.quizOverview.totalQuestions,
                                    percentage = performer.percentage,
                                    isTopPerformer = true
                                )
                            }
                        }
                    }
                }
            )
        }
        
        // Bottom Performers
        if (statistics.bottomPerformers.isNotEmpty()) {
            item {
                StatisticsCard(
                    title = "Students Needing Support",
                    icon = Icons.Default.TrendingDown,
                    content = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            statistics.bottomPerformers.forEach { performer ->
                                PerformerRow(
                                    rank = null,
                                    name = performer.name,
                                    score = performer.score,
                                    totalQuestions = statistics.quizOverview.totalQuestions,
                                    percentage = performer.percentage,
                                    isTopPerformer = false
                                )
                            }
                        }
                    }
                )
            }
        }
        
        // Most Difficult Questions
        if (statistics.mostDifficultQuestions.isNotEmpty()) {
            item {
                StatisticsCard(
                    title = "Most Difficult Questions",
                    icon = Icons.Default.ThumbDown,
                    content = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            statistics.mostDifficultQuestions.forEach { question ->
                                DifficultyQuestionRow(
                                    questionText = question.questionText,
                                    successRate = question.successRate,
                                    difficultyLevel = question.difficultyLevel,
                                    isDifficult = true
                                )
                            }
                        }
                    }
                )
            }
        }
        
        // Least Difficult Questions
        if (statistics.leastDifficultQuestions.isNotEmpty()) {
            item {
                StatisticsCard(
                    title = "Easiest Questions",
                    icon = Icons.Default.ThumbUp,
                    content = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            statistics.leastDifficultQuestions.forEach { question ->
                                DifficultyQuestionRow(
                                    questionText = question.questionText,
                                    successRate = question.successRate,
                                    difficultyLevel = question.difficultyLevel,
                                    isDifficult = false
                                )
                            }
                        }
                    }
                )
            }
        }
        
        // Engagement Insights
        item {
            StatisticsCard(
                title = "Engagement Insights",
                icon = Icons.Default.Group,
                content = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Most Engaged Students
                        if (statistics.engagementInsights.mostEngagedStudents.isNotEmpty()) {
                            Column {
                                Text(
                                    text = "Most Engaged Students",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(statistics.engagementInsights.mostEngagedStudents) { student ->
                                        EngagementChip(
                                            studentName = student,
                                            isEngaged = true
                                        )
                                    }
                                }
                            }
                        }
                        
                        // Least Engaged Students
                        if (statistics.engagementInsights.leastEngagedStudents.isNotEmpty()) {
                            Column {
                                Text(
                                    text = "Students Needing Attention",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(statistics.engagementInsights.leastEngagedStudents) { student ->
                                        EngagementChip(
                                            studentName = student,
                                            isEngaged = false
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            )
        }
        
        // Question Analysis
        item {
            StatisticsCard(
                title = "Question Analysis",
                icon = Icons.Default.QuestionMark,
                content = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        statistics.questionAnalysis.forEach { question ->
                            EnhancedQuestionAnalysisRow(
                                questionText = question.questionText,
                                successRate = question.successRate,
                                responseRate = question.responseRate,
                                difficultyLevel = question.difficultyLevel,
                                correctAnswers = question.correctAnswers,
                                totalStudents = question.totalStudents,
                                optionDistribution = question.optionDistribution
                            )
                        }
                    }
                }
            )
        }
        
        // Participation Statistics
        item {
            StatisticsCard(
                title = "Participation Statistics",
                icon = Icons.Default.School,
                content = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ParticipationBar(
                            label = "Full Participation",
                            value = statistics.participationStats.fullParticipation,
                            total = statistics.quizOverview.totalStudentsJoined,
                            color = Color.Green
                        )
                        
                        ParticipationBar(
                            label = "Partial Participation",
                            value = statistics.participationStats.partialParticipation,
                            total = statistics.quizOverview.totalStudentsJoined,
                            color = Color.Yellow
                        )
                        
                        ParticipationBar(
                            label = "No Participation",
                            value = statistics.participationStats.noParticipation,
                            total = statistics.quizOverview.totalStudentsJoined,
                            color = Color.Red
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        StatisticRow(
                            label = "Average Response Rate",
                            value = "${statistics.participationStats.averageResponseRate.toInt()}%"
                        )
                    }
                }
            )
        }
        
        // New Quiz Button
        item {
            Button(
                onClick = onNewQuiz,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Start New Quiz",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = color
            )
            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = color.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun ScoreDistributionChart(
    scoreDistribution: Map<String, Int>
) {
    val maxValue = scoreDistribution.values.maxOrNull() ?: 1
    
    Column {
        Text(
            text = "Students by Score Range",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        
        scoreDistribution.forEach { (range, count) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = range,
                    fontSize = 12.sp,
                    modifier = Modifier.width(60.dp),
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(24.dp)
                        .padding(horizontal = 8.dp)
                ) {
                    // Background bar
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(4.dp)
                            )
                    )
                    
                    // Value bar
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(count.toFloat() / maxValue.toFloat())
                            .background(
                                MaterialTheme.colorScheme.primary,
                                RoundedCornerShape(4.dp)
                            )
                    )
                }
                
                Text(
                    text = count.toString(),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.width(30.dp),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}

@Composable
private fun PerformanceBar(
    label: String,
    value: Float,
    maxValue: Float,
    color: Color
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${value}/${maxValue}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        LinearProgressIndicator(
            progress = (value / maxValue).coerceIn(0f, 1f),
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

@Composable
private fun ParticipationBar(
    label: String,
    value: Int,
    total: Int,
    color: Color
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "$value students",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        LinearProgressIndicator(
            progress = if (total > 0) (value.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

@Composable
private fun DifficultyQuestionRow(
    questionText: String,
    successRate: Double,
    difficultyLevel: String,
    isDifficult: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isDifficult) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
            } else {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            }
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = questionText,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${successRate.toInt()}% success rate",
                    fontSize = 12.sp,
                    color = if (isDifficult) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.primary
                    }
                )
                
                DifficultyChip(difficultyLevel)
            }
        }
    }
}

@Composable
private fun EngagementChip(
    studentName: String,
    isEngaged: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isEngaged) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.errorContainer
            }
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(
            text = studentName,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = if (isEngaged) {
                MaterialTheme.colorScheme.onPrimaryContainer
            } else {
                MaterialTheme.colorScheme.onErrorContainer
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun EnhancedQuestionAnalysisRow(
    questionText: String,
    successRate: Double,
    responseRate: Double,
    difficultyLevel: String,
    correctAnswers: Int,
    totalStudents: Int,
    optionDistribution: Map<String, Int>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = questionText,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Success and Response Rates
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "✓ ${successRate.toInt()}% correct",
                    fontSize = 12.sp,
                    color = if (successRate >= 70) Color.Green else if (successRate >= 50) Color.Yellow else Color.Red
                )
                
                Text(
                    text = "📊 ${responseRate.toInt()}% responded",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                DifficultyChip(difficultyLevel)
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "$correctAnswers/$totalStudents students answered correctly",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            // Option Distribution (if available)
            if (optionDistribution.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Answer Distribution:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                LazyRow(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(optionDistribution.entries.toList()) { (option, count) ->
                        if (count > 0) {
                            OptionChip(option, count)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionChip(
    option: String,
    count: Int
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = "$option: $count",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun DifficultyChip(difficultyLevel: String) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = when (difficultyLevel) {
                "Easy" -> Color.Green.copy(alpha = 0.2f)
                "Medium" -> Color.Yellow.copy(alpha = 0.2f)
                "Hard" -> Color.Red.copy(alpha = 0.2f)
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
        ),
        shape = RoundedCornerShape(4.dp)
    ) {
        Text(
            text = difficultyLevel,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = when (difficultyLevel) {
                "Easy" -> Color.Green
                "Medium" -> Color.Yellow
                "Hard" -> Color.Red
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            },
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun EmptyStateMessage(message: String) {
    Text(
        text = message,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 14.sp,
        modifier = Modifier.padding(16.dp),
        textAlign = TextAlign.Center
    )
}

@Composable
private fun StatisticsCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            content()
        }
    }
}

@Composable
private fun StatisticRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun PerformerRow(
    rank: Int?,
    name: String,
    score: Int,
    totalQuestions: Int,
    percentage: Double,
    isTopPerformer: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isTopPerformer) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.errorContainer
            }
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (rank != null) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (rank) {
                            1 -> Color(0xFFFFD700) // Gold
                            2 -> Color(0xFFC0C0C0) // Silver
                            3 -> Color(0xFFCD7F32) // Bronze
                            else -> MaterialTheme.colorScheme.secondary
                        }
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "#$rank",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
            }
            
            Text(
                text = name,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            
            Text(
                text = "$score/$totalQuestions",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = "${percentage.toInt()}%",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
} 