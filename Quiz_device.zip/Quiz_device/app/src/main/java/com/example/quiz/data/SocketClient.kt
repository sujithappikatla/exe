package com.example.quiz.data

import android.util.Log
import com.google.gson.Gson
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import org.json.JSONObject
import java.net.URI

class SocketClient {
    private var socket: Socket? = null
    private val gson = Gson()
    
    companion object {
        private const val TAG = "SocketClient"
    }
    
    // State flows for various events
    private val _classCreated = MutableStateFlow<ClassCreatedResponse?>(null)
    val classCreated: StateFlow<ClassCreatedResponse?> = _classCreated
    
    private val _studentsJoined = MutableStateFlow<List<Student>>(emptyList())
    val studentsJoined: StateFlow<List<Student>> = _studentsJoined
    
    private val _currentQuestion = MutableStateFlow<LoadQuestionResponse?>(null)
    val currentQuestion: StateFlow<LoadQuestionResponse?> = _currentQuestion
    
    private val _studentStatusUpdate = MutableStateFlow<List<StudentStatus>>(emptyList())
    val studentStatusUpdate: StateFlow<List<StudentStatus>> = _studentStatusUpdate
    
    private val _questionTimeout = MutableStateFlow<QuestionTimeoutResponse?>(null)
    val questionTimeout: StateFlow<QuestionTimeoutResponse?> = _questionTimeout
    
    private val _timerPaused = MutableStateFlow(false)
    val timerPaused: StateFlow<Boolean> = _timerPaused
    
    private val _timerResumed = MutableStateFlow<TimerResumedResponse?>(null)
    val timerResumed: StateFlow<TimerResumedResponse?> = _timerResumed
    
    private val _quizFinished = MutableStateFlow(false)
    val quizFinished: StateFlow<Boolean> = _quizFinished
    
    private val _quizStatistics = MutableStateFlow<QuizStatistics?>(null)
    val quizStatistics: StateFlow<QuizStatistics?> = _quizStatistics
    
    private val _errors = Channel<String>()
    val errors: Flow<String> = _errors.receiveAsFlow()
    
    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected
    
    fun connect(serverUrl: String = "https://quiz-305533803718.us-central1.run.app") {
        Log.d(TAG, "🔌 Attempting to connect to Socket.IO server: $serverUrl")
        
        try {
            // Disconnect existing socket if any
            socket?.disconnect()
            
            Log.d(TAG, "🏗️ Creating new Socket.IO instance...")
            
            // Create socket with basic configuration
            socket = IO.socket(URI.create(serverUrl))
            Log.d(TAG, "✅ Socket.IO instance created successfully")
            
            socket?.on(Socket.EVENT_CONNECT) { args ->
                Log.d(TAG, "🎉 Socket connected successfully!")
                Log.d(TAG, "Connection args: ${args.contentToString()}")
                _isConnected.value = true
            }
            
            socket?.on(Socket.EVENT_DISCONNECT) { args ->
                Log.w(TAG, "❌ Socket disconnected")
                Log.w(TAG, "Disconnect reason: ${args.getOrNull(0)}")
                _isConnected.value = false
            }
            
            socket?.on(Socket.EVENT_CONNECT_ERROR) { args ->
                val error = args.getOrNull(0)
                Log.e(TAG, "🚨 Connection error occurred: $error")
                Log.e(TAG, "Error type: ${error?.javaClass?.simpleName}")
                if (error is Exception) {
                    Log.e(TAG, "Error stack trace:", error)
                }
                _errors.trySend("Connection error: $error")
            }
            

            
            // Note: Reconnection events may not be available in this Socket.IO client version
            // We'll rely on the basic connect/disconnect events for connection monitoring
            
            // Register event listeners
            Log.d(TAG, "📡 Setting up event listeners...")
            setupEventListeners()
            
            Log.d(TAG, "🚀 Initiating socket connection...")
            socket?.connect()
            
        } catch (e: Exception) {
            Log.e(TAG, "💥 Exception during socket creation/connection", e)
            _errors.trySend("Failed to connect: ${e.message}")
        }
    }
    
    private fun setupEventListeners() {
        Log.d(TAG, "📡 Setting up Socket.IO event listeners...")
        
        // Class creation response
        socket?.on("s2c_class_created") { args ->
            Log.d(TAG, "📨 Received s2c_class_created event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw data: $rawData")
                val response = gson.fromJson(rawData, ClassCreatedResponse::class.java)
                Log.d(TAG, "✅ Parsed class created response: $response")
                _classCreated.value = response
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing class created response", e)
                _errors.trySend("Error parsing class created response: ${e.message}")
            }
        }
        
        // Student joined
        socket?.on("s2c_student_joined") { args ->
            Log.d(TAG, "📨 Received s2c_student_joined event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw data: $rawData")
                val response = gson.fromJson(rawData, StudentJoinedResponse::class.java)
                Log.d(TAG, "✅ Parsed student joined response: $response")
                _studentsJoined.value = response.students
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing student joined response", e)
                _errors.trySend("Error parsing student joined response: ${e.message}")
            }
        }
        
        // Load question
        socket?.on("s2c_load_question") { args ->
            Log.d(TAG, "📨 Received s2c_load_question event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw data: $rawData")
                val response = gson.fromJson(rawData, LoadQuestionResponse::class.java)
                Log.d(TAG, "✅ Parsed load question response: $response")
                _currentQuestion.value = response
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing load question response", e)
                _errors.trySend("Error parsing load question response: ${e.message}")
            }
        }
        
        // Student status update
        socket?.on("s2c_update_student_status") { args ->
            Log.d(TAG, "📨 Received s2c_update_student_status event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw data: $rawData")
                val response = gson.fromJson(rawData, UpdateStudentStatusResponse::class.java)
                Log.d(TAG, "✅ Parsed student status update: $response")
                
                // Create a new list to ensure StateFlow emits the change
                val newStudentsList = response.studentsStatus.toList()
                Log.d(TAG, "🔄 Setting student status: $newStudentsList")
                _studentStatusUpdate.value = newStudentsList
                Log.d(TAG, "🔄 Student status set, current value: ${_studentStatusUpdate.value}")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing student status update", e)
                _errors.trySend("Error parsing student status update: ${e.message}")
            }
        }
        
        // Question timeout
        socket?.on("s2c_question_timeout") { args ->
            Log.d(TAG, "📨 Received s2c_question_timeout event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw data: $rawData")
                val response = gson.fromJson(rawData, QuestionTimeoutResponse::class.java)
                Log.d(TAG, "✅ Parsed question timeout response: $response")
                _questionTimeout.value = response
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing question timeout response", e)
                _errors.trySend("Error parsing question timeout response: ${e.message}")
            }
        }
        
        // Timer paused
        socket?.on("s2c_timer_paused") { args ->
            Log.d(TAG, "📨 Received s2c_timer_paused event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            _timerPaused.value = true
        }
        
        // Timer resumed
        socket?.on("s2c_timer_resumed") { args ->
            Log.d(TAG, "📨 Received s2c_timer_resumed event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw data: $rawData")
                val response = gson.fromJson(rawData, TimerResumedResponse::class.java)
                Log.d(TAG, "✅ Parsed timer resumed response: $response")
                _timerResumed.value = response
                _timerPaused.value = false
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing timer resumed response", e)
                _errors.trySend("Error parsing timer resumed response: ${e.message}")
            }
        }
        
        // Quiz finished
        socket?.on("s2c_quiz_finished") { args ->
            Log.d(TAG, "📨 Received s2c_quiz_finished event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            Log.d(TAG, "🏁 Setting quiz finished to true")
            _quizFinished.value = true
            Log.d(TAG, "🏁 Quiz finished value: ${_quizFinished.value}")
        }
        
        // Quiz statistics
        socket?.on("s2c_quiz_statistics") { args ->
            Log.d(TAG, "📨 Received s2c_quiz_statistics event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw data: $rawData")
                val response = gson.fromJson(rawData, QuizStatistics::class.java)
                Log.d(TAG, "✅ Parsed quiz statistics response: $response")
                _quizStatistics.value = response
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing quiz statistics response", e)
                _errors.trySend("Error parsing quiz statistics response: ${e.message}")
            }
        }
        
        // Error handling
        socket?.on("s2c_error") { args ->
            Log.d(TAG, "📨 Received s2c_error event")
            Log.d(TAG, "Raw args: ${args.contentToString()}")
            try {
                val rawData = args[0].toString()
                Log.d(TAG, "Raw error data: $rawData")
                val response = gson.fromJson(rawData, ErrorResponse::class.java)
                Log.w(TAG, "⚠️ Server error: ${response.message}")
                _errors.trySend(response.message)
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing server error response", e)
                val errorMsg = "Error: ${args[0]}"
                Log.w(TAG, "⚠️ Raw server error: $errorMsg")
                _errors.trySend(errorMsg)
            }
        }
        
        Log.d(TAG, "✅ All event listeners set up successfully")
    }
    
    fun createClass(teacherName: String, quizData: QuizData) {
        Log.d(TAG, "📤 Sending c2s_create_class event")
        val payload = CreateClassPayload(teacherName, quizData)
        val jsonPayload = gson.toJson(payload)
        Log.d(TAG, "📤 Payload: $jsonPayload")
        
        if (socket?.connected() == true) {
            // Convert JSON string to JSONObject for proper Socket.IO transmission
            try {
                val jsonObject = JSONObject(jsonPayload)
                socket?.emit("c2s_create_class", jsonObject)
                Log.d(TAG, "✅ c2s_create_class event sent successfully")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error creating JSONObject from payload", e)
                _errors.trySend("Error creating class payload: ${e.message}")
            }
        } else {
            Log.e(TAG, "❌ Socket not connected! Cannot send c2s_create_class")
            _errors.trySend("Socket not connected. Please check your connection.")
        }
    }
    
    fun startQuiz() {
        Log.d(TAG, "📤 Sending c2s_start_quiz event")
        
        if (socket?.connected() == true) {
            socket?.emit("c2s_start_quiz", JSONObject())
            Log.d(TAG, "✅ c2s_start_quiz event sent successfully")
        } else {
            Log.e(TAG, "❌ Socket not connected! Cannot send c2s_start_quiz")
            _errors.trySend("Socket not connected. Please check your connection.")
        }
    }
    
    fun navigateQuestion(direction: NavigationDirection) {
        Log.d(TAG, "📤 Sending c2s_navigate_question event")
        val payload = mapOf("direction" to direction.name.lowercase())
        val jsonPayload = gson.toJson(payload)
        Log.d(TAG, "📤 Payload: $jsonPayload")
        
        if (socket?.connected() == true) {
            try {
                val jsonObject = JSONObject(jsonPayload)
                socket?.emit("c2s_navigate_question", jsonObject)
                Log.d(TAG, "✅ c2s_navigate_question event sent successfully")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error creating JSONObject from payload", e)
                _errors.trySend("Error creating navigation payload: ${e.message}")
            }
        } else {
            Log.e(TAG, "❌ Socket not connected! Cannot send c2s_navigate_question")
            _errors.trySend("Socket not connected. Please check your connection.")
        }
    }
    
    fun pauseTimer() {
        Log.d(TAG, "📤 Sending c2s_pause_timer event")
        
        if (socket?.connected() == true) {
            socket?.emit("c2s_pause_timer", JSONObject())
            Log.d(TAG, "✅ c2s_pause_timer event sent successfully")
        } else {
            Log.e(TAG, "❌ Socket not connected! Cannot send c2s_pause_timer")
            _errors.trySend("Socket not connected. Please check your connection.")
        }
    }
    
    fun resumeTimer() {
        Log.d(TAG, "📤 Sending c2s_resume_timer event")
        
        if (socket?.connected() == true) {
            socket?.emit("c2s_resume_timer", JSONObject())
            Log.d(TAG, "✅ c2s_resume_timer event sent successfully")
        } else {
            Log.e(TAG, "❌ Socket not connected! Cannot send c2s_resume_timer")
            _errors.trySend("Socket not connected. Please check your connection.")
        }
    }
    
    fun endQuiz() {
        Log.d(TAG, "📤 Sending c2s_end_quiz event")
        
        if (socket?.connected() == true) {
            socket?.emit("c2s_end_quiz", JSONObject())
            Log.d(TAG, "✅ c2s_end_quiz event sent successfully")
        } else {
            Log.e(TAG, "❌ Socket not connected! Cannot send c2s_end_quiz")
            _errors.trySend("Socket not connected. Please check your connection.")
        }
    }
    
    fun disconnect() {
        Log.d(TAG, "🔌 Disconnecting socket...")
        
        if (socket?.connected() == true) {
            Log.d(TAG, "🔌 Socket was connected, disconnecting now...")
            socket?.disconnect()
        } else {
            Log.d(TAG, "🔌 Socket was already disconnected")
        }
        
        socket = null
        _isConnected.value = false
        Log.d(TAG, "✅ Socket disconnected and cleaned up")
    }
    
    fun clearStates() {
        Log.d(TAG, "🧹 Clearing all Socket.IO states...")
        _classCreated.value = null
        _studentsJoined.value = emptyList()
        _currentQuestion.value = null
        _studentStatusUpdate.value = emptyList()
        _questionTimeout.value = null
        _timerPaused.value = false
        _timerResumed.value = null
        _quizFinished.value = false
        _quizStatistics.value = null
        Log.d(TAG, "✅ All states cleared successfully")
    }
} 