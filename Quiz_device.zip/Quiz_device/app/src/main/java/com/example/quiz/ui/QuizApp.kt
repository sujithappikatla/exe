package com.example.quiz.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.quiz.data.NavigationDirection
import com.example.quiz.ui.screens.LobbyScreen
import com.example.quiz.ui.screens.QuestionScreen
import com.example.quiz.ui.screens.SetupScreen
import com.example.quiz.ui.screens.StatisticsScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizApp(
    viewModel: QuizViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val timerState by viewModel.timerState.collectAsState()
    val timeRemaining by viewModel.timeRemaining.collectAsState()
    val selectedAnswer by viewModel.selectedAnswer.collectAsState()
    val answerRevealed by viewModel.answerRevealed.collectAsState()
    
    // Error handling
    if (uiState.showError) {
        LaunchedEffect(uiState.errorMessage) {
            // Show error message
            kotlinx.coroutines.delay(3000)
            viewModel.clearError()
        }
    }
    
    Box(modifier = Modifier.fillMaxSize()) {
        when (uiState.currentScreen) {
            QuizScreen.SETUP -> {
                SetupScreen(
                    isConnected = uiState.isConnected,
                    onCreateClass = viewModel::createClass
                )
            }
            
            QuizScreen.LOBBY -> {
                LobbyScreen(
                    classCode = uiState.classCode,
                    teacherName = uiState.teacherName,
                    students = uiState.students,
                    onStartQuiz = viewModel::startQuiz
                )
            }
            
            QuizScreen.QUESTION -> {
                uiState.currentQuestion?.let { question ->
                    // Debug logging for UI state
                    android.util.Log.d("QuizApp", "🎯 Rendering QuestionScreen with ${uiState.studentsStatus.size} students")
                    android.util.Log.d("QuizApp", "🎯 Students: ${uiState.studentsStatus}")
                    
                    QuestionScreen(
                        classCode = uiState.classCode,
                        currentQuestion = question,
                        studentsStatus = uiState.studentsStatus,
                        timeRemaining = timeRemaining,
                        timerState = timerState,
                        selectedAnswer = selectedAnswer,
                        answerRevealed = answerRevealed,
                        onSelectAnswer = viewModel::selectAnswer,
                        onRevealAnswer = viewModel::revealAnswer,
                        onPauseTimer = viewModel::pauseTimer,
                        onResumeTimer = viewModel::resumeTimer,
                        onNavigateQuestion = viewModel::navigateQuestion,
                        onEndQuiz = viewModel::endQuiz
                    )
                }
            }
            
            QuizScreen.STATISTICS -> {
                StatisticsScreen(
                    statistics = uiState.quizStatistics,
                    onNewQuiz = viewModel::startNewQuiz
                )
            }
        }
        
        // Loading indicator
        if (uiState.isLoading) {
            Card(
                modifier = Modifier.align(Alignment.Center),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Box(
                    modifier = Modifier.padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        }
        
        // Error Snackbar
        if (uiState.showError && uiState.errorMessage != null) {
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Text(
                    text = uiState.errorMessage!!,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
} 