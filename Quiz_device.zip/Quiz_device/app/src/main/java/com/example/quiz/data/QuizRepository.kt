package com.example.quiz.data

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

class QuizRepository {
    private val socketClient = SocketClient()
    private val TAG = "QuizRepository"
    
    // Expose socket client flows
    val classCreated: StateFlow<ClassCreatedResponse?> = socketClient.classCreated
    val studentsJoined: StateFlow<List<Student>> = socketClient.studentsJoined
    val currentQuestion: StateFlow<LoadQuestionResponse?> = socketClient.currentQuestion
    val questionTimeout: StateFlow<QuestionTimeoutResponse?> = socketClient.questionTimeout
    val timerPaused: StateFlow<Boolean> = socketClient.timerPaused
    val timerResumed: StateFlow<TimerResumedResponse?> = socketClient.timerResumed
    val quizFinished: StateFlow<Boolean> = socketClient.quizFinished
    val quizStatistics: StateFlow<QuizStatistics?> = socketClient.quizStatistics
    val errors: Flow<String> = socketClient.errors
    val isConnected: StateFlow<Boolean> = socketClient.isConnected
    
    // Add debugging wrapper for student status updates
    val studentStatusUpdate: StateFlow<List<StudentStatus>> = socketClient.studentStatusUpdate.also {
        android.util.Log.d(TAG, "🏢 Repository: Student status flow exposed, current value: ${it.value}")
    }
    
    fun connect(serverUrl: String = "https://quiz-305533803718.us-central1.run.app") {
        Log.d(TAG, "🏢 Repository: Initiating connection to $serverUrl")
        socketClient.connect(serverUrl)
    }
    
    fun createClass(teacherName: String, quizData: QuizData = dummyQuizData) {
        Log.d(TAG, "🏢 Repository: Creating class for teacher '$teacherName' with ${quizData.questions.size} questions")
        socketClient.createClass(teacherName, quizData)
    }
    
    fun createClassFromIntent(teacherName: String, quizDataJson: String) {
        Log.d(TAG, "🏢 Repository: Creating class from intent for teacher '$teacherName'")
        try {
            val gson = Gson()
            val quizData = gson.fromJson(quizDataJson, QuizData::class.java)
            
            Log.d(TAG, "🏢 Repository: Parsed quiz data - Title: '${quizData.title}', Questions: ${quizData.questions.size}")
            
            // Validate quiz data
            if (quizData.questions.isEmpty()) {
                throw IllegalArgumentException("Quiz data must contain at least one question")
            }
            
            // Validate each question
            quizData.questions.forEach { question ->
                if (question.text.isBlank()) {
                    throw IllegalArgumentException("Question text cannot be empty")
                }
                if (question.options.isEmpty()) {
                    throw IllegalArgumentException("Question must have at least one option")
                }
                if (question.correctOption.isBlank()) {
                    throw IllegalArgumentException("Question must have a correct option")
                }
                if (question.timer <= 0) {
                    throw IllegalArgumentException("Question timer must be positive")
                }
            }
            
            Log.d(TAG, "🏢 Repository: Quiz data validation passed")
            socketClient.createClass(teacherName, quizData)
            
        } catch (e: JsonSyntaxException) {
            Log.e(TAG, "❌ Repository: Failed to parse quiz data JSON", e)
            throw IllegalArgumentException("Invalid quiz data format: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Repository: Error creating class from intent", e)
            throw e
        }
    }
    
    fun startQuiz() {
        socketClient.startQuiz()
    }
    
    fun navigateQuestion(direction: NavigationDirection) {
        socketClient.navigateQuestion(direction)
    }
    
    fun pauseTimer() {
        socketClient.pauseTimer()
    }
    
    fun resumeTimer() {
        socketClient.resumeTimer()
    }
    
    fun endQuiz() {
        socketClient.endQuiz()
    }
    
    fun disconnect() {
        socketClient.disconnect()
    }
    
    fun clearStates() {
        socketClient.clearStates()
    }
    
    companion object {
        @Volatile
        private var INSTANCE: QuizRepository? = null
        
        fun getInstance(): QuizRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: QuizRepository().also { INSTANCE = it }
            }
        }
    }
} 