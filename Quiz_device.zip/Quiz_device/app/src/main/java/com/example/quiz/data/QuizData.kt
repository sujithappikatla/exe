package com.example.quiz.data

import com.google.gson.annotations.SerializedName

data class Question(
    val id: String,
    val text: String,
    val options: List<String>,
    @SerializedName("correct_option")
    val correctOption: String,
    val timer: Int,
    val reasoning: Map<String, String>? = null
)

data class QuizData(
    val title: String,
    val questions: List<Question>
)

data class Student(
    val id: String,
    val name: String,
    val answered: Boolean = false
)

data class CreateClassPayload(
    @SerializedName("teacher_name")
    val teacherName: String,
    @SerializedName("quiz_data")
    val quizData: QuizData
)

data class ClassCreatedResponse(
    @SerializedName("class_code")
    val classCode: String
)

data class StudentJoinedResponse(
    val students: List<Student>
)

data class LoadQuestionResponse(
    val id: String,
    val text: String,
    val options: List<String>,
    @SerializedName("correct_option")
    val correctOption: String?,
    val timer: Int,
    @SerializedName("students_status")
    val studentsStatus: List<StudentStatus>?
)

data class StudentStatus(
    val name: String,
    val answered: Boolean
)

data class UpdateStudentStatusResponse(
    @SerializedName("students_status")
    val studentsStatus: List<StudentStatus>
)

data class QuestionTimeoutResponse(
    @SerializedName("question_id")
    val questionId: String,
    @SerializedName("correct_option")
    val correctOption: String
)

data class TimerResumedResponse(
    @SerializedName("time_remaining")
    val timeRemaining: Int
)

data class QuizStatistics(
    @SerializedName("quiz_overview")
    val quizOverview: QuizOverview,
    @SerializedName("performance_summary")
    val performanceSummary: PerformanceSummary,
    @SerializedName("top_performers")
    val topPerformers: List<StudentPerformance>,
    @SerializedName("bottom_performers")
    val bottomPerformers: List<StudentPerformance>,
    @SerializedName("question_analysis")
    val questionAnalysis: List<QuestionAnalysis>,
    @SerializedName("most_difficult_questions")
    val mostDifficultQuestions: List<DifficultyQuestion>,
    @SerializedName("least_difficult_questions")
    val leastDifficultQuestions: List<DifficultyQuestion>,
    @SerializedName("participation_stats")
    val participationStats: ParticipationStats,
    @SerializedName("engagement_insights")
    val engagementInsights: EngagementInsights
)

data class QuizOverview(
    @SerializedName("quiz_title")
    val quizTitle: String,
    @SerializedName("total_questions")
    val totalQuestions: Int,
    @SerializedName("total_students_joined")
    val totalStudentsJoined: Int,
    @SerializedName("students_participated")
    val studentsParticipated: Int,
    @SerializedName("completion_rate")
    val completionRate: Double
)

data class PerformanceSummary(
    @SerializedName("average_score")
    val averageScore: Double,
    @SerializedName("average_percentage")
    val averagePercentage: Double,
    @SerializedName("highest_score")
    val highestScore: Int,
    @SerializedName("lowest_score")
    val lowestScore: Int,
    @SerializedName("score_distribution")
    val scoreDistribution: Map<String, Int>
)

data class StudentPerformance(
    val rank: Int? = null,
    val name: String,
    val score: Int,
    val percentage: Double,
    @SerializedName("total_answered")
    val totalAnswered: Int
)

data class QuestionAnalysis(
    @SerializedName("question_id")
    val questionId: String,
    @SerializedName("question_text")
    val questionText: String,
    @SerializedName("total_students")
    val totalStudents: Int,
    @SerializedName("total_answered")
    val totalAnswered: Int,
    @SerializedName("correct_answers")
    val correctAnswers: Int,
    @SerializedName("wrong_answers")
    val wrongAnswers: Int,
    @SerializedName("success_rate")
    val successRate: Double,
    @SerializedName("response_rate")
    val responseRate: Double,
    @SerializedName("difficulty_level")
    val difficultyLevel: String,
    @SerializedName("option_distribution")
    val optionDistribution: Map<String, Int>,
    @SerializedName("most_popular_wrong_answer")
    val mostPopularWrongAnswer: MostPopularWrongAnswer
)

data class MostPopularWrongAnswer(
    val option: String,
    val count: Int
)

data class DifficultyQuestion(
    @SerializedName("question_id")
    val questionId: String,
    @SerializedName("question_text")
    val questionText: String,
    @SerializedName("success_rate")
    val successRate: Double,
    @SerializedName("difficulty_level")
    val difficultyLevel: String
)

data class ParticipationStats(
    @SerializedName("full_participation")
    val fullParticipation: Int,
    @SerializedName("partial_participation")
    val partialParticipation: Int,
    @SerializedName("no_participation")
    val noParticipation: Int,
    @SerializedName("average_response_rate")
    val averageResponseRate: Double
)

data class EngagementInsights(
    @SerializedName("students_answered_all")
    val studentsAnsweredAll: Int,
    @SerializedName("students_answered_none")
    val studentsAnsweredNone: Int,
    @SerializedName("students_answered_some")
    val studentsAnsweredSome: Int,
    @SerializedName("most_engaged_students")
    val mostEngagedStudents: List<String>,
    @SerializedName("least_engaged_students")
    val leastEngagedStudents: List<String>
)

data class ErrorResponse(
    val message: String
)

// Timer states
enum class TimerState {
    RUNNING,
    PAUSED,
    STOPPED
}

// Navigation directions
enum class NavigationDirection {
    NEXT,
    PREVIOUS
} 