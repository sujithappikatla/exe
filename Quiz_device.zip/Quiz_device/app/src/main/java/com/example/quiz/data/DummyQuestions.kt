package com.example.quiz.data

val dummyQuestions = listOf(
    Question(
        id = "q1",
        text = "What is 2 + 2?",
        options = listOf("3", "4", "5", "6"),
        correctOption = "4",
        timer = 30,
        reasoning = mapOf(
            "3" to "This is incorrect. 2 + 2 equals 4, not 3.",
            "4" to "This is correct. 2 + 2 = 4 is basic addition.",
            "5" to "This is incorrect. 2 + 2 equals 4, not 5.",
            "6" to "This is incorrect. 2 + 2 equals 4, not 6."
        )
    ),
    Question(
        id = "q2",
        text = "What is the capital of France?",
        options = listOf("London", "Berlin", "Paris", "Madrid"),
        correctOption = "Paris",
        timer = 25,
        reasoning = mapOf(
            "London" to "This is incorrect. London is the capital of the United Kingdom.",
            "Berlin" to "This is incorrect. Berlin is the capital of Germany.",
            "Paris" to "This is correct. Paris is the capital city of France.",
            "Madrid" to "This is incorrect. Madrid is the capital of Spain."
        )
    ),
    Question(
        id = "q3",
        text = "In Android development, which of the following is the correct way to create a composable function that displays a greeting message with a name parameter?",
        options = listOf(
            "@Composable\nfun Greeting(name: String) {\n    Text(\"Hello \$name!\")\n}",
            "fun Greeting(name: String) {\n    @Composable\n    Text(\"Hello \$name!\")\n}",
            "@Composable\nfun Greeting(): String {\n    return \"Hello World!\"\n}",
            "composable fun Greeting(name: String) {\n    Text(\"Hello \$name!\")\n}"
        ),
        correctOption = "@Composable\nfun Greeting(name: String) {\n    Text(\"Hello \$name!\")\n}",
        timer = 45,
        reasoning = mapOf(
            "@Composable\nfun Greeting(name: String) {\n    Text(\"Hello \$name!\")\n}" to "This is correct. The @Composable annotation should be placed before the function declaration, and the function should contain composable UI elements like Text.",
            "fun Greeting(name: String) {\n    @Composable\n    Text(\"Hello \$name!\")\n}" to "This is incorrect. The @Composable annotation should be on the function declaration, not inside the function body.",
            "@Composable\nfun Greeting(): String {\n    return \"Hello World!\"\n}" to "This is incorrect. Composable functions should not return values; they should compose UI elements.",
            "composable fun Greeting(name: String) {\n    Text(\"Hello \$name!\")\n}" to "This is incorrect. The correct annotation is @Composable, not 'composable' as a keyword."
        )
    ),
    Question(
        id = "q4",
        text = "Which planet is known as the Red Planet?",
        options = listOf("Venus", "Mars", "Jupiter", "Earth"),
        correctOption = "Mars",
        timer = 20,
        reasoning = mapOf(
            "Venus" to "This is incorrect. Venus is known as the hottest planet and is often called Earth's twin.",
            "Mars" to "This is correct. Mars is called the Red Planet due to its reddish appearance caused by iron oxide on its surface.",
            "Jupiter" to "This is incorrect. Jupiter is the largest planet in our solar system and is known for its Great Red Spot.",
            "Earth" to "This is incorrect. Earth is known as the Blue Planet due to its oceans, not the Red Planet."
        )
    ),
    Question(
        id = "q5",
        text = "In the context of software development and specifically mobile app development, what is the primary difference between declarative and imperative programming paradigms, and how does this apply to modern UI frameworks like Jetpack Compose versus traditional Android View system?",
        options = listOf(
            "Declarative programming focuses on 'what' the UI should look like, while imperative programming focuses on 'how' to achieve that state. Jetpack Compose is declarative, allowing developers to describe the UI state, while traditional Android Views are imperative, requiring step-by-step instructions.",
            "Imperative programming is faster and more efficient than declarative programming. Traditional Android Views use imperative approach which makes them superior to Jetpack Compose in terms of performance and memory usage.",
            "Declarative and imperative are the same concepts, just different naming conventions. Both Jetpack Compose and traditional Android Views use the same underlying principles and programming patterns.",
            "Declarative programming is only used for backend development, while imperative programming is used for frontend development. This distinction doesn't apply to mobile app development frameworks."
        ),
        correctOption = "Declarative programming focuses on 'what' the UI should look like, while imperative programming focuses on 'how' to achieve that state. Jetpack Compose is declarative, allowing developers to describe the UI state, while traditional Android Views are imperative, requiring step-by-step instructions.",
        timer = 60,
        reasoning = mapOf(
            "Declarative programming focuses on 'what' the UI should look like, while imperative programming focuses on 'how' to achieve that state. Jetpack Compose is declarative, allowing developers to describe the UI state, while traditional Android Views are imperative, requiring step-by-step instructions." to "This is correct. Declarative programming describes the desired end state, while imperative programming describes the steps to reach that state. Jetpack Compose exemplifies declarative UI development.",
            "Imperative programming is faster and more efficient than declarative programming. Traditional Android Views use imperative approach which makes them superior to Jetpack Compose in terms of performance and memory usage." to "This is incorrect. Performance depends on implementation, not paradigm. Modern declarative frameworks like Jetpack Compose are highly optimized and often perform better than traditional imperative approaches.",
            "Declarative and imperative are the same concepts, just different naming conventions. Both Jetpack Compose and traditional Android Views use the same underlying principles and programming patterns." to "This is incorrect. Declarative and imperative are fundamentally different programming paradigms with distinct approaches to problem-solving and code organization.",
            "Declarative programming is only used for backend development, while imperative programming is used for frontend development. This distinction doesn't apply to mobile app development frameworks." to "This is incorrect. Both paradigms are used in both frontend and backend development. The distinction is very relevant to mobile app development, especially in UI frameworks."
        )
    ),
    Question(
        id = "q6",
        text = "What is the largest mammal in the world?",
        options = listOf("Elephant", "Blue Whale", "Giraffe", "Hippopotamus"),
        correctOption = "Blue Whale",
        timer = 30,
        reasoning = mapOf(
            "Elephant" to "This is incorrect. While elephants are the largest land mammals, blue whales are much larger overall.",
            "Blue Whale" to "This is correct. Blue whales are the largest mammals and the largest animals ever known to have lived on Earth.",
            "Giraffe" to "This is incorrect. Giraffes are the tallest mammals but not the largest by weight or overall size.",
            "Hippopotamus" to "This is incorrect. Hippos are large mammals but much smaller than blue whales."
        )
    ),
    Question(
        id = "q7",
        text = "Which programming language is primarily used for Android app development?",
        options = listOf("Swift", "Kotlin", "C#", "Java"),
        correctOption = "Kotlin",
        timer = 25,
        reasoning = mapOf(
            "Swift" to "This is incorrect. Swift is primarily used for iOS app development, not Android.",
            "Kotlin" to "This is correct. Kotlin is Google's preferred language for Android development, alongside Java.",
            "C#" to "This is incorrect. C# is primarily used for Windows development and Xamarin cross-platform development.",
            "Java" to "This is partially correct but not the best answer. While Java was traditionally used for Android development, Kotlin is now Google's preferred language."
        )
    ),
    Question(
        id = "q8",
        text = "In the year 1969, which historic event captured the attention of the entire world as humanity achieved something that had been dreamed of for centuries?",
        options = listOf(
            "The first moon landing by Apollo 11",
            "The invention of the internet",
            "The first computer was built",
            "The first mobile phone was invented"
        ),
        correctOption = "The first moon landing by Apollo 11",
        timer = 35,
        reasoning = mapOf(
            "The first moon landing by Apollo 11" to "This is correct. On July 20, 1969, Neil Armstrong and Buzz Aldrin became the first humans to land on the moon during the Apollo 11 mission.",
            "The invention of the internet" to "This is incorrect. The internet's precursor ARPANET was developed in 1969, but the modern internet came much later.",
            "The first computer was built" to "This is incorrect. The first computers were built in the 1940s, not 1969.",
            "The first mobile phone was invented" to "This is incorrect. The first mobile phone was invented in 1973 by Martin Cooper at Motorola."
        )
    ),
    Question(
        id = "q9",
        text = "What is the chemical symbol for gold?",
        options = listOf("Go", "Gd", "Au", "Ag"),
        correctOption = "Au",
        timer = 20,
        reasoning = mapOf(
            "Go" to "This is incorrect. 'Go' is not a chemical symbol for any element.",
            "Gd" to "This is incorrect. 'Gd' is the chemical symbol for Gadolinium.",
            "Au" to "This is correct. 'Au' comes from the Latin word 'aurum' meaning gold.",
            "Ag" to "This is incorrect. 'Ag' is the chemical symbol for Silver (from Latin 'argentum')."
        )
    ),
    Question(
        id = "q10",
        text = "Which of the following best describes the Model-View-ViewModel (MVVM) architectural pattern in Android development?",
        options = listOf(
            "A pattern where the Model directly updates the View",
            "A pattern that separates UI logic from business logic using a ViewModel as an intermediary",
            "A pattern used only for database operations",
            "A pattern that combines all logic in a single component"
        ),
        correctOption = "A pattern that separates UI logic from business logic using a ViewModel as an intermediary",
        timer = 40,
        reasoning = mapOf(
            "A pattern where the Model directly updates the View" to "This is incorrect. In MVVM, the Model doesn't directly update the View; it goes through the ViewModel.",
            "A pattern that separates UI logic from business logic using a ViewModel as an intermediary" to "This is correct. MVVM separates concerns by having the ViewModel handle UI logic and serve as a bridge between the Model and View.",
            "A pattern used only for database operations" to "This is incorrect. MVVM is an architectural pattern for the entire application, not just database operations.",
            "A pattern that combines all logic in a single component" to "This is incorrect. MVVM is about separation of concerns, not combining all logic together."
        )
    )
)

val dummyQuizData = QuizData(
    title = "Android Development & General Knowledge Quiz",
    questions = dummyQuestions
) 