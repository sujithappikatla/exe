package com.example.quiz

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.quiz.data.QuizData
import com.google.gson.Gson

/**
 * Helper class for launching the Quiz app with question data from other apps
 */
object IntentHelper {
    
    /**
     * Creates an intent to launch the Quiz app with quiz data
     * @param context The calling context
     * @param teacherName The teacher's name
     * @param quizData The quiz data containing questions
     * @return Intent to launch the Quiz app
     */
    fun createLaunchIntent(
        context: Context,
        teacherName: String,
        quizData: QuizData
    ): Intent {
        val gson = Gson()
        val quizDataJson = gson.toJson(quizData)
        
        return Intent().apply {
            action = MainActivity.ACTION_LAUNCH_QUIZ
            setPackage("com.example.quiz")
            putExtra(MainActivity.EXTRA_TEACHER_NAME, teacherName)
            putExtra(MainActivity.EXTRA_QUIZ_DATA, quizDataJson)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    
    /**
     * Creates an intent to launch the Quiz app with quiz data using JSON string
     * @param context The calling context
     * @param teacherName The teacher's name
     * @param quizDataJson The quiz data as JSON string
     * @return Intent to launch the Quiz app
     */
    fun createLaunchIntentFromJson(
        context: Context,
        teacherName: String,
        quizDataJson: String
    ): Intent {
        return Intent().apply {
            action = MainActivity.ACTION_LAUNCH_QUIZ
            setPackage("com.example.quiz")
            putExtra(MainActivity.EXTRA_TEACHER_NAME, teacherName)
            putExtra(MainActivity.EXTRA_QUIZ_DATA, quizDataJson)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    
    /**
     * Creates a deep link URI to launch the Quiz app with quiz data
     * @param teacherName The teacher's name
     * @param quizDataJson The quiz data as JSON string (URL encoded)
     * @return URI for deep linking
     */
    fun createDeepLinkUri(
        teacherName: String,
        quizDataJson: String
    ): Uri {
        return Uri.parse("quiz://launch")
            .buildUpon()
            .appendQueryParameter("teacher_name", teacherName)
            .appendQueryParameter("quiz_data", quizDataJson)
            .build()
    }
    
    /**
     * Creates an intent to launch the Quiz app via deep link
     * @param context The calling context
     * @param teacherName The teacher's name
     * @param quizDataJson The quiz data as JSON string
     * @return Intent to launch the Quiz app via deep link
     */
    fun createDeepLinkIntent(
        context: Context,
        teacherName: String,
        quizDataJson: String
    ): Intent {
        val uri = createDeepLinkUri(teacherName, quizDataJson)
        return Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    
    /**
     * Example of how to launch the Quiz app from another app
     */
    fun launchQuizExample(context: Context) {
        // Example quiz data
        val sampleQuizData = QuizData(
            title = "Sample Math Quiz",
            questions = listOf(
                com.example.quiz.data.Question(
                    id = "q1",
                    text = "What is 2 + 2?",
                    options = listOf("3", "4", "5", "6"),
                    correctOption = "4",
                    timer = 30,
                    reasoning = mapOf(
                        "3" to "Incorrect. 2 + 2 equals 4.",
                        "4" to "Correct! 2 + 2 = 4.",
                        "5" to "Incorrect. 2 + 2 equals 4.",
                        "6" to "Incorrect. 2 + 2 equals 4."
                    )
                ),
                com.example.quiz.data.Question(
                    id = "q2",
                    text = "What is 3 × 3?",
                    options = listOf("6", "9", "12", "15"),
                    correctOption = "9",
                    timer = 25,
                    reasoning = mapOf(
                        "6" to "Incorrect. 3 × 3 equals 9.",
                        "9" to "Correct! 3 × 3 = 9.",
                        "12" to "Incorrect. 3 × 3 equals 9.",
                        "15" to "Incorrect. 3 × 3 equals 9."
                    )
                )
            )
        )
        
        // Launch using direct intent
        val intent = createLaunchIntent(context, "Sample Teacher", sampleQuizData)
        context.startActivity(intent)
    }
} 