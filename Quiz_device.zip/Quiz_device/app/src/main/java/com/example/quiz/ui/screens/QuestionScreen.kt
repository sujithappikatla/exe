package com.example.quiz.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import com.example.quiz.data.LoadQuestionResponse
import com.example.quiz.data.NavigationDirection
import com.example.quiz.data.StudentStatus
import com.example.quiz.data.TimerState
import com.example.quiz.data.dummyQuizData

@Composable
fun QuestionScreen(
    classCode: String,
    currentQuestion: LoadQuestionResponse,
    studentsStatus: List<StudentStatus>,
    timeRemaining: Int,
    timerState: TimerState,
    selectedAnswer: String?,
    answerRevealed: Boolean,
    onSelectAnswer: (String) -> Unit,
    onRevealAnswer: () -> Unit,
    onPauseTimer: () -> Unit,
    onResumeTimer: () -> Unit,
    onNavigateQuestion: (NavigationDirection) -> Unit,
    onEndQuiz: () -> Unit
) {
    val totalQuestions = dummyQuizData.questions.size
    val currentQuestionIndex = dummyQuizData.questions.indexOfFirst { it.id == currentQuestion.id } + 1
    
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Left Panel - 25% width
        LeftPanel(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.25f),
            classCode = classCode,
            studentsStatus = studentsStatus,
            timeRemaining = timeRemaining,
            timerState = timerState,
            timerDuration = currentQuestion.timer,
            onPauseTimer = onPauseTimer,
            onResumeTimer = onResumeTimer,
            onNavigateQuestion = onNavigateQuestion,
            onEndQuiz = onEndQuiz,
            currentQuestionIndex = currentQuestionIndex,
            totalQuestions = totalQuestions
        )
        
        // Main Content - 75% width
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Top Header - 10% of remaining height
            TopHeader(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.118f),
                classCode = classCode,
                questionNumber = currentQuestionIndex,
                totalQuestions = totalQuestions
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Question Text - 30% of remaining height
            QuestionContent(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.333f),
                questionText = currentQuestion.text
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Answer Options - 60% of remaining height
            AnswerOptions(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(),
                options = currentQuestion.options,
                correctAnswer = currentQuestion.correctOption,
                selectedAnswer = selectedAnswer,
                answerRevealed = answerRevealed,
                onSelectAnswer = onSelectAnswer,
                onRevealAnswer = onRevealAnswer
            )
        }
    }
}

@Composable
private fun LeftPanel(
    modifier: Modifier,
    classCode: String,
    studentsStatus: List<StudentStatus>,
    timeRemaining: Int,
    timerState: TimerState,
    timerDuration: Int,
    onPauseTimer: () -> Unit,
    onResumeTimer: () -> Unit,
    onNavigateQuestion: (NavigationDirection) -> Unit,
    onEndQuiz: () -> Unit,
    currentQuestionIndex: Int,
    totalQuestions: Int
) {
    Card(
        modifier = modifier.padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Timer Section
            CircularTimer(
                timeRemaining = timeRemaining,
                timerDuration = timerDuration,
                timerState = timerState,
                onPauseTimer = onPauseTimer,
                onResumeTimer = onResumeTimer
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Class Code Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF6366F1), // Indigo
                                Color(0xFF8B5CF6)  // Purple
                            )
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "CLASS CODE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White.copy(alpha = 0.8f),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = classCode,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = 2.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Students Status
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Students (${studentsStatus.count { it.answered }})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val answeredStudents = studentsStatus.filter { it.answered }
                    
                    // Debug logging
                    android.util.Log.d("QuestionScreen", "🎯 Total students: ${studentsStatus.size}, Answered: ${answeredStudents.size}")
                    android.util.Log.d("QuestionScreen", "🎯 Students list: $studentsStatus")
                    android.util.Log.d("QuestionScreen", "🎯 Answered students: $answeredStudents")
                    
                    if (answeredStudents.isEmpty()) {
                        Text(
                            text = "No submissions yet",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 200.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(answeredStudents) { student ->
                                StudentStatusItem(student)
                            }
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // Navigation Controls
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onNavigateQuestion(NavigationDirection.PREVIOUS) },
                    enabled = currentQuestionIndex > 1,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Prev", fontSize = 12.sp)
                }
                
                Button(
                    onClick = { onNavigateQuestion(NavigationDirection.NEXT) },
                    enabled = currentQuestionIndex < totalQuestions,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Text("Next", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
                
                Button(
                    onClick = onEndQuiz,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("End", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun StudentStatusItem(student: StudentStatus) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (student.answered) Icons.Default.Check else Icons.Default.Close,
            contentDescription = null,
            tint = if (student.answered) Color.Green else Color.Red,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = student.name,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun TopHeader(
    modifier: Modifier,
    classCode: String,
    questionNumber: Int,
    totalQuestions: Int
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Quiz Title
            Text(
                text = dummyQuizData.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            

            
            // Question Number
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "$questionNumber/$totalQuestions",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun QuestionContent(
    modifier: Modifier,
    questionText: String
) {
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = questionText,
                fontSize = 24.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                lineHeight = 32.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            )
        }
    }
}

@Composable
private fun AnswerOptions(
    modifier: Modifier,
    options: List<String>,
    correctAnswer: String?,
    selectedAnswer: String?,
    answerRevealed: Boolean,
    onSelectAnswer: (String) -> Unit,
    onRevealAnswer: () -> Unit
) {
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Answer Options",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                AnimatedVisibility(
                    visible = selectedAnswer != null && !answerRevealed,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Button(
                        onClick = onRevealAnswer,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reveal Answer")
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(options) { index, option ->
                    AnswerOptionCard(
                        option = option,
                        optionLabel = ('A' + index).toString(),
                        isSelected = selectedAnswer == option,
                        isCorrect = correctAnswer == option,
                        answerRevealed = answerRevealed,
                        onSelect = { onSelectAnswer(option) }
                    )
                }
            }
        }
    }
}

@Composable
private fun AnswerOptionCard(
    option: String,
    optionLabel: String,
    isSelected: Boolean,
    isCorrect: Boolean,
    answerRevealed: Boolean,
    onSelect: () -> Unit
) {
    val backgroundColor = when {
        answerRevealed && isCorrect -> Color.Green.copy(alpha = 0.3f)
        answerRevealed && isSelected && !isCorrect -> Color.Red.copy(alpha = 0.3f)
        isSelected && !answerRevealed -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    
    val borderColor = when {
        answerRevealed && isCorrect -> Color.Green
        answerRevealed && isSelected && !isCorrect -> Color.Red
        isSelected && !answerRevealed -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    }
    
    val borderWidth = when {
        answerRevealed && (isCorrect || (isSelected && !isCorrect)) -> 2.dp
        isSelected && !answerRevealed -> 2.dp
        else -> 1.dp
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .border(
                width = borderWidth,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = backgroundColor
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Option label (A, B, C, D)
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = optionLabel,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Text(
                text = option,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            
            if (answerRevealed && isCorrect) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.Green,
                    modifier = Modifier.size(24.dp)
                )
            } else if (answerRevealed && isSelected && !isCorrect) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = null,
                    tint = Color.Red,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
private fun CircularTimer(
    timeRemaining: Int,
    timerDuration: Int,
    timerState: TimerState,
    onPauseTimer: () -> Unit,
    onResumeTimer: () -> Unit
) {
    val progress = if (timerDuration > 0) {
        (timeRemaining.toFloat() / timerDuration.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    
    // Dynamic timer color based on time remaining
    val timerColor = when {
        timerState == TimerState.STOPPED -> MaterialTheme.colorScheme.error
        timerState == TimerState.PAUSED -> MaterialTheme.colorScheme.secondary
        progress > 0.5f -> MaterialTheme.colorScheme.primary
        progress > 0.25f -> MaterialTheme.colorScheme.tertiary
        else -> MaterialTheme.colorScheme.error
    }
    
    Box(
        modifier = Modifier
            .size(120.dp)
            .clickable { 
                if (timerState == TimerState.RUNNING) onPauseTimer() else onResumeTimer()
            },
        contentAlignment = Alignment.Center
    ) {
        // Background circle
        Canvas(
            modifier = Modifier.size(120.dp)
        ) {
            drawCircle(
                color = timerColor.copy(alpha = 0.3f),
                radius = size.minDimension / 2,
                style = Stroke(width = 8.dp.toPx())
            )
        }
        
        // Progress circle
        Canvas(
            modifier = Modifier.size(120.dp)
        ) {
            drawArc(
                color = timerColor,
                startAngle = -90f,
                sweepAngle = progress * 360f,
                useCenter = false,
                style = Stroke(width = 8.dp.toPx())
            )
        }
        
        // Timer content with pause/play controls
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = if (timerState == TimerState.RUNNING) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = timerColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${timeRemaining}s",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = timerColor
            )
        }
    }
} 