package com.example.quiz

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.quiz.ui.QuizApp
import com.example.quiz.ui.QuizViewModel
import com.example.quiz.ui.theme.QuizTheme

class MainActivity : ComponentActivity() {
    
    companion object {
        private const val TAG = "MainActivity"
        const val ACTION_LAUNCH_QUIZ = "com.example.quiz.LAUNCH_QUIZ"
        const val EXTRA_QUIZ_DATA = "quiz_data"
        const val EXTRA_TEACHER_NAME = "teacher_name"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            QuizTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewModel: QuizViewModel = viewModel()
                    
                    // Handle intent data
                    handleLaunchIntent(viewModel)
                    
                    QuizApp(viewModel = viewModel)
                }
            }
        }
    }
    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Handle new intent when app is already running
        // The viewModel will be recreated in setContent, so we don't need to handle it here
    }
    
    private fun handleLaunchIntent(viewModel: QuizViewModel) {
        val intent = intent
        Log.d(TAG, "🎯 Handling launch intent: ${intent.action}")
        
        when (intent.action) {
            ACTION_LAUNCH_QUIZ -> {
                Log.d(TAG, "🎯 Launch quiz intent detected")
                handleQuizLaunchIntent(intent, viewModel)
            }
            Intent.ACTION_VIEW -> {
                Log.d(TAG, "🎯 View intent detected")
                handleViewIntent(intent, viewModel)
            }
            else -> {
                Log.d(TAG, "🎯 Regular app launch")
            }
        }
    }
    
    private fun handleQuizLaunchIntent(intent: Intent, viewModel: QuizViewModel) {
        try {
            val quizDataJson = intent.getStringExtra(EXTRA_QUIZ_DATA)
            val teacherName = intent.getStringExtra(EXTRA_TEACHER_NAME) ?: "Teacher"
            
            if (quizDataJson != null) {
                Log.d(TAG, "🎯 Quiz data received via intent")
                Log.d(TAG, "🎯 Teacher name: $teacherName")
                Log.d(TAG, "🎯 Quiz data: $quizDataJson")
                
                viewModel.createClassFromIntent(teacherName, quizDataJson)
            } else {
                Log.w(TAG, "⚠️ No quiz data found in intent")
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error handling quiz launch intent", e)
        }
    }
    
    private fun handleViewIntent(intent: Intent, viewModel: QuizViewModel) {
        try {
            val uri: Uri? = intent.data
            uri?.let {
                Log.d(TAG, "🎯 URI received: $uri")
                
                // Handle URI-based quiz data
                val quizDataJson = uri.getQueryParameter("quiz_data")
                val teacherName = uri.getQueryParameter("teacher_name") ?: "Teacher"
                
                if (quizDataJson != null) {
                    Log.d(TAG, "🎯 Quiz data received via URI")
                    viewModel.createClassFromIntent(teacherName, quizDataJson)
                } else {
                    Log.w(TAG, "⚠️ No quiz data found in URI")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error handling view intent", e)
        }
    }
}