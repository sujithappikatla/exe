    package com.example.quiz.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quiz.data.QuizRepository
import com.example.quiz.data.NavigationDirection
import com.example.quiz.data.LoadQuestionResponse
import com.example.quiz.data.StudentStatus
import com.example.quiz.data.QuizStatistics
import com.example.quiz.data.TimerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job

class QuizViewModel(
    private val repository: QuizRepository = QuizRepository.getInstance()
) : ViewModel() {
    
    companion object {
        private const val TAG = "QuizViewModel"
    }
    
    // UI States
    private val _uiState = MutableStateFlow(QuizUiState())
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()
    
    // Timer state
    private val _timerState = MutableStateFlow(TimerState.STOPPED)
    val timerState: StateFlow<TimerState> = _timerState.asStateFlow()
    
    private val _timeRemaining = MutableStateFlow(0)
    val timeRemaining: StateFlow<Int> = _timeRemaining.asStateFlow()
    
    private var timerJob: Job? = null
    
    // Teacher's selected answer for revealing
    private val _selectedAnswer = MutableStateFlow<String?>(null)
    val selectedAnswer: StateFlow<String?> = _selectedAnswer.asStateFlow()
    
    // Whether answer is revealed
    private val _answerRevealed = MutableStateFlow(false)
    val answerRevealed: StateFlow<Boolean> = _answerRevealed.asStateFlow()
    
    init {
        Log.d(TAG, "🚀 QuizViewModel initializing...")
        
        // Connect to socket
        Log.d(TAG, "🔌 Connecting to Socket.IO server...")
        repository.connect()
        
        // Observe repository flows
        Log.d(TAG, "👁️ Setting up repository flow observers...")
        observeRepositoryFlows()
        
        Log.d(TAG, "✅ QuizViewModel initialization complete")
    }
    
    private fun observeRepositoryFlows() {
        viewModelScope.launch {
            // Connection status
            repository.isConnected.collect { isConnected ->
                _uiState.value = _uiState.value.copy(isConnected = isConnected)
            }
        }
        
        viewModelScope.launch {
            // Class created
            repository.classCreated.collect { classCreated ->
                classCreated?.let {
                    _uiState.value = _uiState.value.copy(
                        classCode = it.classCode,
                        currentScreen = QuizScreen.LOBBY,
                        isLoading = false
                    )
                }
            }
        }
        
        viewModelScope.launch {
            // Students joined
            repository.studentsJoined.collect { students ->
                _uiState.value = _uiState.value.copy(students = students)
            }
        }
        
        viewModelScope.launch {
            // Current question
            repository.currentQuestion.collect { question ->
                question?.let {
                    // Don't reset student status here - let the s2c_update_student_status handle it
                    _uiState.value = _uiState.value.copy(
                        currentQuestion = it,
                        currentScreen = QuizScreen.QUESTION
                    )
                    // Start timer
                    startTimer(it.timer)
                    // Reset answer revelation
                    _answerRevealed.value = false
                    _selectedAnswer.value = null
                }
            }
        }
        
        viewModelScope.launch {
            // Student status updates
            repository.studentStatusUpdate.collect { studentsStatus ->
                android.util.Log.d("QuizViewModel", "🎯 Student status update received: $studentsStatus")
                val currentState = _uiState.value
                android.util.Log.d("QuizViewModel", "🎯 Current question: ${currentState.currentQuestion?.id}")
                android.util.Log.d("QuizViewModel", "🎯 Current screen: ${currentState.currentScreen}")
                android.util.Log.d("QuizViewModel", "🎯 Previous students: ${currentState.studentsStatus}")
                
                // Always update student status - this should take precedence over any resets
                android.util.Log.d("QuizViewModel", "🎯 Updating student status with ${studentsStatus.size} students")
                _uiState.value = _uiState.value.copy(studentsStatus = studentsStatus)
                android.util.Log.d("QuizViewModel", "🎯 Updated UI state successfully")
                
                android.util.Log.d("QuizViewModel", "🎯 Final students in UI: ${_uiState.value.studentsStatus}")
            }
        }
        
                 viewModelScope.launch {
             // Question timeout
             repository.questionTimeout.collect { timeout ->
                 timeout?.let {
                     stopLocalTimer()
                     _answerRevealed.value = true
                 }
             }
         }
        
                 viewModelScope.launch {
             // Timer paused
             repository.timerPaused.collect { paused ->
                 if (paused) {
                     _timerState.value = TimerState.PAUSED
                     pauseLocalTimer()
                 }
             }
         }
        
                 viewModelScope.launch {
             // Timer resumed
             repository.timerResumed.collect { resumed ->
                 resumed?.let {
                     _timeRemaining.value = it.timeRemaining
                     resumeLocalTimer()
                 }
             }
         }
        
                 viewModelScope.launch {
             // Quiz finished
             repository.quizFinished.collect { finished ->
                 android.util.Log.d("QuizViewModel", "🏁 Quiz finished received: $finished")
                 if (finished) {
                     android.util.Log.d("QuizViewModel", "🏁 Quiz finished - waiting for statistics...")
                     // Don't switch to statistics here - wait for statistics data
                     stopLocalTimer()
                 }
             }
         }
        
        viewModelScope.launch {
            // Quiz statistics
            repository.quizStatistics.collect { statistics ->
                android.util.Log.d("QuizViewModel", "🎯 Quiz statistics received: ${statistics != null}")
                statistics?.let {
                    android.util.Log.d("QuizViewModel", "🎯 Switching to statistics screen")
                    _uiState.value = _uiState.value.copy(
                        quizStatistics = statistics,
                        currentScreen = QuizScreen.STATISTICS
                    )
                    // Stop timer when quiz ends
                    stopLocalTimer()
                }
            }
        }
        
        viewModelScope.launch {
            // Errors
            repository.errors.collect { error ->
                _uiState.value = _uiState.value.copy(
                    errorMessage = error,
                    showError = true,
                    isLoading = false
                )
            }
        }
    }
    
    fun createClass(teacherName: String) {
        if (teacherName.isNotBlank()) {
            repository.createClass(teacherName)
            _uiState.value = _uiState.value.copy(
                teacherName = teacherName,
                isLoading = true
            )
        }
    }
    
    fun createClassFromIntent(teacherName: String, quizDataJson: String) {
        Log.d(TAG, "🎯 Creating class from intent with teacher: $teacherName")
        try {
            // Parse the JSON data and create class
            repository.createClassFromIntent(teacherName, quizDataJson)
            _uiState.value = _uiState.value.copy(
                teacherName = teacherName,
                isLoading = true
            )
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error creating class from intent", e)
            _uiState.value = _uiState.value.copy(
                errorMessage = "Failed to parse quiz data: ${e.message}",
                showError = true,
                isLoading = false
            )
        }
    }
    
    fun startQuiz() {
        android.util.Log.d("QuizViewModel", "🎯 Starting quiz")
        // Reset student status when quiz first starts
        _uiState.value = _uiState.value.copy(studentsStatus = emptyList())
        repository.startQuiz()
    }
    
    fun navigateQuestion(direction: NavigationDirection) {
        android.util.Log.d("QuizViewModel", "🎯 Navigating question: $direction")
        android.util.Log.d("QuizViewModel", "🎯 Current students before navigation: ${_uiState.value.studentsStatus}")
        
        // Don't reset student status here - let s2c_update_student_status handle it
        repository.navigateQuestion(direction)
    }
    
    fun pauseTimer() {
        repository.pauseTimer()
    }
    
    fun resumeTimer() {
        repository.resumeTimer()
    }
    
    fun endQuiz() {
        repository.endQuiz()
    }
    
    fun selectAnswer(answer: String) {
        _selectedAnswer.value = answer
    }
    
    fun revealAnswer() {
        _answerRevealed.value = true
        pauseLocalTimer()
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(
            errorMessage = null,
            showError = false
        )
    }

    
    fun startNewQuiz() {
        // Reset all states and go back to setup
        stopLocalTimer()
        repository.clearStates()
        _uiState.value = QuizUiState()
        _selectedAnswer.value = null
        _answerRevealed.value = false
        _timerState.value = TimerState.STOPPED
        _timeRemaining.value = 0
        
        // Reconnect to socket
        repository.connect()
    }
    
    private fun startTimer(duration: Int) {
        stopLocalTimer()
        _timeRemaining.value = duration
        _timerState.value = TimerState.RUNNING
        
        timerJob = viewModelScope.launch {
            while (_timeRemaining.value > 0 && _timerState.value == TimerState.RUNNING) {
                delay(1000)
                if (_timerState.value == TimerState.RUNNING) {
                    _timeRemaining.value = _timeRemaining.value - 1
                }
            }
            
            if (_timeRemaining.value <= 0) {
                _timerState.value = TimerState.STOPPED
                _answerRevealed.value = true
            }
        }
    }
    
    private fun pauseLocalTimer() {
        timerJob?.cancel()
        _timerState.value = TimerState.PAUSED
    }
    
    private fun resumeLocalTimer() {
        if (_timeRemaining.value > 0) {
            _timerState.value = TimerState.RUNNING
            
            timerJob = viewModelScope.launch {
                while (_timeRemaining.value > 0 && _timerState.value == TimerState.RUNNING) {
                    delay(1000)
                    if (_timerState.value == TimerState.RUNNING) {
                        _timeRemaining.value = _timeRemaining.value - 1
                    }
                }
                
                if (_timeRemaining.value <= 0) {
                    _timerState.value = TimerState.STOPPED
                    _answerRevealed.value = true
                }
            }
        }
    }
    
    private fun stopLocalTimer() {
        timerJob?.cancel()
        _timerState.value = TimerState.STOPPED
    }
    
    override fun onCleared() {
        super.onCleared()
        stopLocalTimer()
        repository.disconnect()
    }
}

data class QuizUiState(
    val isConnected: Boolean = false,
    val isLoading: Boolean = false,
    val teacherName: String = "",
    val classCode: String = "",
    val students: List<com.example.quiz.data.Student> = emptyList(),
    val studentsStatus: List<StudentStatus> = emptyList(),
    val currentQuestion: LoadQuestionResponse? = null,
    val currentScreen: QuizScreen = QuizScreen.SETUP,
    val quizStatistics: QuizStatistics? = null,
    val errorMessage: String? = null,
    val showError: Boolean = false
)

enum class QuizScreen {
    SETUP,
    LOBBY,
    QUESTION,
    STATISTICS
} 