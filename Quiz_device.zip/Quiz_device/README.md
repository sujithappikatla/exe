# Quiz Master - Teacher App

A real-time quiz management application for teachers built with Android Jetpack Compose and Socket.IO.

## Overview

Quiz Master is a teacher-only Android application that allows educators to create and manage live quizzes for their students. The app connects to a Socket.IO server to provide real-time interaction between the teacher and students.

## Features

### ✅ Implemented Features

- **Real-time Socket.IO Integration**: Connects to `http://localhost:8000`
- **Teacher Class Management**: Create classes with unique 6-digit codes
- **Live Student Monitoring**: See students join the lobby in real-time
- **Interactive Quiz Interface**: 
  - Question display with customizable timer
  - Answer options with teacher selection capability
  - Real-time student response tracking
  - Answer revelation with visual feedback (green for correct, red for incorrect)
- **Timer Controls**: Pause/resume functionality
- **Question Navigation**: Previous/next question controls
- **Comprehensive Statistics**: Detailed post-quiz analytics and performance metrics
- **Modern UI Design**: Material Design 3 with smooth animations

### 📱 Screen Layout

#### Question Screen Layout (As Requested)
- **Top 10%**: Quiz title, class code, and question number
- **Left 15%**: Student response status, timer, and teacher controls
- **Main 40%**: Question text display
- **Bottom 50%**: Answer options with interactive selection

## Technical Architecture

### Data Layer
- **QuizData.kt**: Data models for questions, students, and responses
- **DummyQuestions.kt**: 10 sample questions with variable lengths for testing
- **SocketClient.kt**: Real-time communication with Socket.IO server
- **QuizRepository.kt**: Data management and state coordination

### UI Layer
- **QuizViewModel.kt**: Business logic and state management
- **SetupScreen.kt**: Teacher name input and class creation
- **LobbyScreen.kt**: Class code display and student waiting area
- **QuestionScreen.kt**: Main quiz interface with teacher controls
- **StatisticsScreen.kt**: Comprehensive quiz analytics

### Key Components
- **Timer Synchronization**: Client-side countdown with server authority
- **Real-time Updates**: Live student status and response tracking
- **Visual Feedback**: Color-coded answer selection and revelation
- **Responsive Design**: Optimized for various screen sizes

## Sample Questions

The app includes 10 diverse sample questions:
1. Basic math (2+2)
2. Geography (Capital of France)
3. Advanced Android development (Jetpack Compose)
4. Astronomy (Red Planet)
5. Programming paradigms (Declarative vs Imperative)
6. Biology (Largest mammal)
7. Mobile development (Android languages)
8. History (1969 moon landing)
9. Chemistry (Gold symbol)
10. Software architecture (MVVM pattern)

## Socket.IO Events

### Teacher → Server
- `c2s_create_class`: Create new quiz session
- `c2s_start_quiz`: Begin the quiz
- `c2s_navigate_question`: Move between questions
- `c2s_pause_timer`/`c2s_resume_timer`: Timer controls
- `c2s_end_quiz`: Finish the quiz

### Server → Teacher
- `s2c_class_created`: Class code response
- `s2c_student_joined`: Student join notifications
- `s2c_load_question`: Question data
- `s2c_update_student_status`: Real-time response tracking
- `s2c_quiz_statistics`: Post-quiz analytics

## Dependencies

```kotlin
// Socket.IO
implementation "io.socket:socket.io-client:2.1.0"

// Jetpack Compose
implementation "androidx.compose.ui:ui"
implementation "androidx.compose.material3:material3"
implementation "androidx.navigation:navigation-compose:2.7.7"
implementation "androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0"

// JSON Processing
implementation "com.google.code.gson:gson:2.10.1"

// Icons
implementation "androidx.compose.material:material-icons-extended"
```

## Setup Instructions

1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd Quiz
   ```

2. **Install Dependencies**
   - Ensure Android Studio is installed
   - Open the project in Android Studio
   - Sync Gradle dependencies

3. **Server Setup**
   - Set up a Socket.IO server running on `http://localhost:8000`
   - Implement the events specified in `quiz_app_specification.md`

4. **Run the App**
   - Connect an Android device or start an emulator
   - Build and run the application

## Usage

1. **Start**: Enter teacher name and create a class
2. **Lobby**: Share the generated class code with students
3. **Quiz**: 
   - Start the quiz when students join
   - Click on answer options to select them
   - Use "Reveal Answer" to show correct answers
   - Monitor student responses in real-time
   - Navigate between questions using Previous/Next
   - Pause/resume timer as needed
4. **Results**: View comprehensive statistics after quiz completion

## UI Features

- **Gradient Backgrounds**: Beautiful visual design
- **Animated Transitions**: Smooth screen changes
- **Loading States**: Clear feedback during operations
- **Error Handling**: User-friendly error messages
- **Responsive Layout**: Adapts to different screen sizes
- **Material Icons**: Consistent iconography throughout

## Future Enhancements

- PDF report generation for teachers
- Multiple quiz templates
- Advanced analytics with charts
- Custom question creation interface
- Student app companion
- Offline mode support

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is developed for educational purposes. Please ensure you have appropriate licenses for all dependencies. 