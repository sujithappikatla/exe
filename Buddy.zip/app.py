from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.requests import Request
from fastapi.responses import Response
from fastapi.responses import JSONResponse
from fastapi.responses import Response
from fastapi.responses import StreamingResponse
import uvicorn
from manager import MESSAGE, MESSAGE_TYPE, RunsManager
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

runs_manager = RunsManager()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.post("/run")
async def run(message: MESSAGE) -> MESSAGE:
    return await runs_manager.start_run(message)

@app.get("/run/{run_id}/{thread_id}/{start_from}")
async def get_run(run_id: str, thread_id: str, start_from: int = 0):

    async def generate_events():
        async for event in runs_manager.get_run_events(run_id, thread_id, start_from):
            yield f"data: {event.model_dump_json()}\n\n"

    return StreamingResponse(generate_events(), media_type="text/event-stream")

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
