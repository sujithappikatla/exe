from typing import Dict, Literal
from pydantic import BaseModel

class GraphState(BaseModel):
    question: str = ""
    answer: str = ""
    sources: list[Dict] = []
    sub_questions: list[str] = []
    agent_type: Literal["fast", "slow", "deep"] = "fast"





