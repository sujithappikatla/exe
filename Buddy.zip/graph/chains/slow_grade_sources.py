from langchain.prompts import ChatPromptTemplate
from langchain.chat_models import init_chat_model
from graph.constants import SLOW_SOURCE_GRADER_MODEL_PROVIDER, SLOW_SOURCE_GRADER_MODEL
from pydantic import BaseModel
from typing import List

GRADE_SOURCES_PROMPT = """
You are an AI assistant specializing in grading the source content based on the user's question. 
Your primary mission is to grade the source content based on the user's question.
Return true if the source content is any way relevant can help in answering to the user's question, otherwise return false.

- If source content contains any data that could help in answering the user's question, return true.

## Input Format:
<source_content>
</source_content>

<question>
</question>

## Output Format:
{{
    "result" : true or false // boolean value
}}

## Example:
Input:
<source_content>
LangGraph agents are a way to create agents that can use LangGraph to interact with the world.
</source_content>

<question>
What is the difference between LangGraph and LangChain?
</question>

Output:
{{
    "result": true
}}

## Here is the user's QUESTION and the source content that you should grade:
<source_content>
{source_content}
</source_content>

<question>
{question}
</question>

## Your final ANSWER:


"""

class Result(BaseModel):
    result: bool


model = init_chat_model(
    SLOW_SOURCE_GRADER_MODEL,
    provider=SLOW_SOURCE_GRADER_MODEL_PROVIDER
)
structured_model = model.with_structured_output(Result)


prompt = ChatPromptTemplate.from_template(GRADE_SOURCES_PROMPT)

grade_sources_chain = prompt | structured_model



if __name__ == "__main__":
    result = grade_sources_chain.invoke({"question": "What is the difference between LangGraph and LangChain?", "source_content": "LangGraph agents are a way to create agents that can use LangGraph to interact with the world."})
    print(result)

