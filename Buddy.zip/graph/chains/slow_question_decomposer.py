from langchain.prompts import ChatPromptTemplate
from langchain.chat_models import init_chat_model
from graph.constants import SLOW_DECOMPOSER_MODEL_PROVIDER, SLOW_DECOMPOSER_MODEL
from pydantic import BaseModel
from typing import List

DECOMPOSER_PROMPT = """
You are an AI assistant specializing in Question Decomposition tasks within a Retrieval-Augmented Generation (RAG) system. 
Your primary mission is to decompose the question into a list of sub-questions.

## Input Format:
<question>

## Output Format:
{{
    "sub_questions": [
        <sub_question_1>,
        <sub_question_2>,
        ...
    ]
}}

## Example:
Input:
What is the difference between LangGraph and LangChain?

Output:
{{
    "sub_questions": [
        "What is LangGraph?",
        "What is LangChain?",
        "What is the difference between LangGraph and LangChain?",
    ]
}}

## Here is the user's QUESTION that you should decompose:
<question>
{question}
</question>

## Your final ANSWER to the user's QUESTION:


"""

class SubQuestions(BaseModel):
    sub_questions: List[str]


model = init_chat_model(
    SLOW_DECOMPOSER_MODEL,
    provider=SLOW_DECOMPOSER_MODEL_PROVIDER
)
structured_model = model.with_structured_output(SubQuestions)


prompt = ChatPromptTemplate.from_template(DECOMPOSER_PROMPT)

slow_decomposer_chain = prompt | structured_model




