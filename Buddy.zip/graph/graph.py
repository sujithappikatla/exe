from graph.nodes import fast_retriever_node, fast_generator_node, agent_type_selector_node
from graph.nodes import slow_retreiver_node, slow_decomposer_node, slow_source_grader_node, slow_answer_generator_node
from graph.state import GraphState
from langgraph.graph import StateGraph, END, START
from graph.constants import FAST_RETREIVER, FAST_GENERATOR, AGENT_TYPE_SELECTOR
from graph.constants import SLOW_DECOMPOSER, SLOW_RETREIVER, SLOW_SOURCE_GRADER, SLOW_ANSWER_GENERATOR


entry_condition_mappings = {
    FAST_RETREIVER:FAST_RETREIVER,
    SLOW_DECOMPOSER:SLOW_DECOMPOSER
}


def build_graph():
    graph = StateGraph(GraphState)
    graph.add_node(AGENT_TYPE_SELECTOR, agent_type_selector_node)
    graph.add_node(FAST_RETREIVER, fast_retriever_node)
    graph.add_node(FAST_GENERATOR, fast_generator_node)
    graph.add_node(SLOW_DECOMPOSER, slow_decomposer_node)
    graph.add_node(SLOW_RETREIVER, slow_retreiver_node)
    graph.add_node(SLOW_SOURCE_GRADER, slow_source_grader_node)
    graph.add_node(SLOW_ANSWER_GENERATOR, slow_answer_generator_node)

    graph.set_conditional_entry_point(agent_type_selector_node, entry_condition_mappings)
    graph.add_edge(FAST_RETREIVER, FAST_GENERATOR)
    graph.add_edge(FAST_GENERATOR, END)

    graph.add_edge(SLOW_DECOMPOSER, SLOW_RETREIVER)
    graph.add_edge(SLOW_RETREIVER, SLOW_SOURCE_GRADER)
    graph.add_edge(SLOW_SOURCE_GRADER, SLOW_ANSWER_GENERATOR)
    graph.add_edge(SLOW_ANSWER_GENERATOR, END)

    return graph.compile()

graph = build_graph()






