from graph.state import GraphState
from ingestion import retriever
from langgraph.config import get_stream_writer
import asyncio


async def slow_retreiver_node(state: GraphState):
    """
    This node is responsible for retrieving the most relevant documents from the vector database.
    """
    writer = get_stream_writer()
    writer({"type": "updates", "update": "Retrieving source documents..."})

    async def retrieve_docs(question: str):
        docs = await retriever.ainvoke(question)
        return [{"url": doc.metadata["source"], "name": doc.metadata["source_name"], "content": doc.page_content} for doc in docs]

    sub_questions = state.sub_questions
    tasks = [retrieve_docs(question) for question in sub_questions]
    sources = await asyncio.gather(*tasks)
    sources = [doc for sublist in sources for doc in sublist]
    unique_dicts = []
    seen_dicts = set()

    for d in sources:
        val = d["content"]       # Use the field you want uniqueness by
        if val not in seen_dicts:
            seen_dicts.add(val)
            unique_dicts.append(d)
    
    
    return {"sources": unique_dicts}


