from langchain.chat_models import init_chat_model
from graph.state import GraphState
from ingestion import retriever
from langgraph.config import get_stream_writer



async def fast_retriever_node(state: GraphState):
    """
    This node is responsible for retrieving the most relevant documents from the vector database.
    """
    writer = get_stream_writer()
    writer({"type": "updates", "update": "Retrieving source documents..."})

    question = state.question
    docs = await retriever.ainvoke(question)
    sources = [{"url": doc.metadata["source"], "name": doc.metadata["source_name"], "content": doc.page_content} for doc in docs]
    
    unique_dicts = []
    seen_dicts = set()

    for d in sources:
        val = d["content"]       # Use the field you want uniqueness by
        if val not in seen_dicts:
            seen_dicts.add(val)
            unique_dicts.append(d)

    sources = unique_dicts

    writer({"type": "sources", "sources": [{"url": src["url"], "name": src["name"], "content": src["content"]} for src in sources]})
    return {"sources": sources}


