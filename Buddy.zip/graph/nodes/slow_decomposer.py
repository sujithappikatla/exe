from langchain.chat_models import init_chat_model
from graph.state import GraphState
from ingestion import retriever
from langgraph.config import get_stream_writer
from graph.chains import slow_decomposer_chain


async def slow_decomposer_node(state: GraphState):
    """
    This node is responsible for decomposing the question into a list of sub-questions.
    """
    writer = get_stream_writer()
    writer({"type": "updates", "update": "Decomposing user query..."})

    question = state.question
    sub_questions = await slow_decomposer_chain.ainvoke({"question": question})
    return {"sub_questions": sub_questions.sub_questions}


