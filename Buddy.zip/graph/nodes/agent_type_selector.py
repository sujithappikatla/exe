from graph.state import GraphState
from langgraph.config import get_stream_writer
from graph.constants import FAST_RETREIVER, SLOW_DECOMPOSER


async def agent_type_selector_node(state: GraphState):
    """
    This node is responsible for generating the answer to the question.
    """
    writer = get_stream_writer()
    agent_type = state.agent_type
    if agent_type == "fast":
        writer({"type": "updates", "update": "Generating a quick answer..."})
        return FAST_RETREIVER
    elif agent_type == "slow":
        writer({"type": "updates", "update": "Generating a better answer. May take some time..."})
        return SLOW_DECOMPOSER
    elif agent_type == "deep":
        writer({"type": "updates", "update": "Doing indepth analysis to generate answer. This will take some time..."})
        return FAST_RETREIVER

    return FAST_RETREIVER