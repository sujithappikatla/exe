from graph.state import GraphState
from graph.chains import fast_generate_chain
from langgraph.config import get_stream_writer


async def fast_generator_node(state: GraphState):
    """
    This node is responsible for generating the answer to the question.
    """
    writer = get_stream_writer()
    writer({"type": "updates", "update": "Generating answer..."})

    context = "\n".join([f"Source: {source['name']}\nURL: {source['url']}\nContent: {source['content']}" for source in state.sources])
    answer = ""
    async for chunk in fast_generate_chain.astream({"context": context, "question": state.question}):
        writer({"type": "messages", "delta": chunk.content})
        answer += chunk.content
    return {"answer": answer}