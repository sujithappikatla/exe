from graph.state import GraphState
from langgraph.config import get_stream_writer
from graph.chains import grade_sources_chain
import asyncio


async def slow_source_grader_node(state: GraphState):
    """
    This node is responsible for grading the source content based on the user's question.
    """
    writer = get_stream_writer()
    writer({"type": "updates", "update": "Grading source content..."})

    question = state.question
    sources = state.sources

    async def grade_source(source: dict):
        result = await grade_sources_chain.ainvoke({"question": question, "source_content": source["content"]})
        return {"url": source["url"], "name": source["name"], "content": source["content"], "result": result.result}

    tasks = [grade_source(source) for source in sources]
    results = await asyncio.gather(*tasks)
    results = [result for result in results] 

    filtered_sources = [{"url": source["url"], "name": source["name"], "content": source["content"]} for source in results if source["result"]]

    writer({"type": "sources", "sources": [{"url": src["url"], "name": src["name"], "content": src["content"]} for src in filtered_sources]})

    return {"sources": filtered_sources}


