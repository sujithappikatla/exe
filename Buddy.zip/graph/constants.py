
# model settings
# ollama:qwen2.5:latest
# gemini-2.0-flash, google_vertexai

# GENERATOR_MODEL = "gemini-2.0-flash"
# GENERATOR_MODEL_PROVIDER = "google_vertexai"
FAST_GENERATOR_MODEL = "gemini-2.0-flash"
FAST_GENERATOR_MODEL_PROVIDER = "google_vertexai"
SLOW_DECOMPOSER_MODEL = "gemini-2.0-flash"
SLOW_DECOMPOSER_MODEL_PROVIDER = "google_vertexai"
SLOW_SOURCE_GRADER_MODEL = "gemini-2.0-flash"
SLOW_SOURCE_GRADER_MODEL_PROVIDER = "google_vertexai"
SLOW_ANSWER_GENERATOR_MODEL = "gemini-2.0-flash"
SLOW_ANSWER_GENERATOR_MODEL_PROVIDER = "google_vertexai"


# node names
AGENT_TYPE_SELECTOR = "agent_type_selector"
FAST_RETREIVER = "fast_retreiver_node"
FAST_GENERATOR = "fast_generator_node"

SLOW_DECOMPOSER = "slow_decomposer_node"
SLOW_RETREIVER = "slow_retreiver_node"
SLOW_SOURCE_GRADER = "slow_source_grader_node"
SLOW_ANSWER_GENERATOR = "slow_answer_generator_node"