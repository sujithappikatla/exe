from enum import Enum
from pydantic import BaseModel
from typing import Dict, Any, Optional, List
import time


class MESSAGE_TYPE(Enum):
    RUN_START = "run_start"
    RUN_STARTED = "run_started"
    RUN_COMPLETED = "run_completed"
    RUN_FAILED = "run_failed"
    MESSAGE_STREAM = "message_stream"
    NODE_UPDATE = "node_update"
    SOURCE_UPDATE = "source_update"
    CUSTOM = "custom"
    TOOL_CALL = "tool_call"
    TOOL_PROGRESS = "tool_progress"
    TOOL_RESULT = "tool_result"


class MESSAGE(BaseModel):
    type: MESSAGE_TYPE
    thread_id: Optional[str] = None
    run_id: Optional[str] = None
    payload: Dict[str, Any]
