from typing import Dict, List, Any
import asyncio
import uuid
from .InputOutputModels import MESSAGE, MESSAGE_TYPE
from graph import graph
from langchain_core.messages import HumanMessage

class RunsManager:
    def __init__(self):
        self.RUN_TASK: Dict[str, asyncio.Task] = {}
        self.RUN_EVENTS: Dict[str, Dict[int, Any]] = {}

    async def start_run(self, message: MESSAGE) -> MESSAGE:
        if message.type != MESSAGE_TYPE.RUN_START:
            raise ValueError(f"Invalid message type: {message.type}")

        if message.thread_id == None or message.thread_id == "":
            thread_id = str(uuid.uuid4())
        else:
            thread_id = message.thread_id

        if message.run_id == None or message.run_id == "":
            run_id = str(uuid.uuid4())
        else:
            run_id = message.run_id
        
        run_key = f"{thread_id}-{run_id}"
        message.thread_id = thread_id
        message.run_id = run_id

        self.RUN_TASK[run_key] = asyncio.create_task(self.run_task(message))
        self.RUN_EVENTS[run_key] = {}
        return MESSAGE(type=MESSAGE_TYPE.RUN_STARTED, thread_id=thread_id, run_id=run_id, payload={})


    async def run_task(self, message: MESSAGE):
        
        sources_content = "Photosynthesis is the process by which plants convert light energy into chemical energy. Photosynthesis is a complex process that involves many steps. The first step is the absorption of light by chlorophyll. The second step is the conversion of light energy into chemical energy. The third step is the release of oxygen. The fourth step is the release of carbon dioxide. The fifth step is the release of water."
        steps_counter = 0
        run_key = f"{message.thread_id}-{message.run_id}"
        await asyncio.sleep(3)
        node_updates = ["I need to check for why photosynthesis is important and chemical energy is important", "Making Tool call", "Photosynthesis is the process by which plants convert light energy into chemical energy. Photosynthesis is a complex process that involves many steps. The first step is the absorption of light by chlorophyll. The second step is the conversion of light energy into chemical energy. The third step is the release of oxygen. The fourth step is the release of carbon dioxide. The fifth step is the release of water", "Saving response", "Generating response"]
        sources = [{"name": "Markdown", "url": "", "content": sources_content}, {"name": "Markdown", "url": "", "content": sources_content},
                    {"name": "Markdown", "url": "", "content": sources_content}, {"name": "Markdown", "url": "", "content": sources_content},
                    {"name": "Markdown", "url": "https://github.com/karthik/markdown_science", "content": sources_content}, {"name": "Markdown", "url": "https://github.com/karthik/markdown_science", "content": sources_content}]
        try:
            # for idx in range(15):
            #     await asyncio.sleep(0.5)
            #     self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.NODE_UPDATE, thread_id=message.thread_id, run_id=message.run_id, payload={"content":node_updates[idx%5]})
            #     steps_counter += 1

            # for source in sources:
            #     await asyncio.sleep(0.5)
            #     self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.SOURCE_UPDATE, thread_id=message.thread_id, run_id=message.run_id, payload={"sources": [source]})
            #     steps_counter += 1

            # for chunk in dummy_output.split(" "):
            #     chunk = chunk + " "
            #     # print(f"key: {run_key}, steps_counter: {steps_counter} chunk: {chunk}")
            #     await asyncio.sleep(0.0005)
            #     self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.MESSAGE_STREAM, thread_id=message.thread_id, run_id=message.run_id, payload={"delta": chunk})
            #     steps_counter += 1
            # print(f"message: {message.payload}")
            # answer = graph.invoke({"question": message.payload["message"]})

            # self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.MESSAGE_STREAM, thread_id=message.thread_id, run_id=message.run_id, payload={"delta": answer["answer"]})
            # steps_counter += 1

            config = {"configurable": {"thread_id": message.thread_id}}
            async for mode, chunk in graph.astream({"question": message.payload["message"], "agent_type":message.payload["agent_type"]}, stream_mode=["messages", "updates", "custom"], config=config):
                # print(mode)
                if mode == "messages":
                    pass
                elif mode == "updates":
                    pass
                elif mode == "custom":
                    if chunk["type"] == "messages":
                        self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.MESSAGE_STREAM, thread_id=message.thread_id, run_id=message.run_id, payload={"delta": chunk["delta"]})
                        steps_counter += 1
                    elif chunk["type"] == "sources":
                        self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.SOURCE_UPDATE, thread_id=message.thread_id, run_id=message.run_id, payload={"sources": chunk["sources"]})
                        steps_counter += 1
                    elif chunk["type"] == "updates":
                        self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.NODE_UPDATE, thread_id=message.thread_id, run_id=message.run_id, payload={"content": chunk["update"]})
                        steps_counter += 1




            self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.RUN_COMPLETED, thread_id=message.thread_id, run_id=message.run_id, payload={})
        except Exception as e:
            print(f"Error: {e}")
            self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.RUN_FAILED, thread_id=message.thread_id, run_id=message.run_id, payload={"error": "Internal error"})
        




#     async def run_task(self, message: MESSAGE):
#         dummy_output = """
# # Markdown for scientific writing

# [Markdown](http://inundata.org/2012/06/01/markdown-and-the-future-of-collaborative-manuscript-writing/) is a fantastic and minimalist tool for authoring scientific documents. This repository is a collection of tools, resources, and tutorials to simplfy your workflow. If you spend a little time going through the tutorials you'll be able to [stop using Microsoft Word entirely](http://inundata.org/2012/12/04/how-to-ditch-word/) and write clean, lightweight markdown files that can easily be version controlled by git. Collaboration with your coauthors would also become way more powerful and simpler.


# ## Copying this repo

# If you have git installed, simply clone this repo and you'll have a full set of examples to work with. Otherwise just hit the `zip` button at the top to download a copy.

# ```coffee
# git clone https://github.com/karthik/markdown_science.git
# ```

# # Documentation

# A full set of documentation is slowly coming together in the [wiki](https://github.com/karthik/markdown_science/wiki). Feel free to contribute. If you have ideas for examples, add them to the repo and send in a pull request.
 
#         """
#         sources_content = "Photosynthesis is the process by which plants convert light energy into chemical energy. Photosynthesis is a complex process that involves many steps. The first step is the absorption of light by chlorophyll. The second step is the conversion of light energy into chemical energy. The third step is the release of oxygen. The fourth step is the release of carbon dioxide. The fifth step is the release of water."
#         steps_counter = 0
#         run_key = f"{message.thread_id}-{message.run_id}"
#         await asyncio.sleep(3)
#         node_updates = ["I need to check for why photosynthesis is important and chemical energy is important", "Making Tool call", "Photosynthesis is the process by which plants convert light energy into chemical energy. Photosynthesis is a complex process that involves many steps. The first step is the absorption of light by chlorophyll. The second step is the conversion of light energy into chemical energy. The third step is the release of oxygen. The fourth step is the release of carbon dioxide. The fifth step is the release of water", "Saving response", "Generating response"]
#         sources = [{"name": "Markdown", "url": "", "content": sources_content}, {"name": "Markdown", "url": "", "content": sources_content},
#                     {"name": "Markdown", "url": "", "content": sources_content}, {"name": "Markdown", "url": "", "content": sources_content},
#                     {"name": "Markdown", "url": "https://github.com/karthik/markdown_science", "content": sources_content}, {"name": "Markdown", "url": "https://github.com/karthik/markdown_science", "content": sources_content}]
#         try:
#             for idx in range(15):
#                 await asyncio.sleep(0.5)
#                 self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.NODE_UPDATE, thread_id=message.thread_id, run_id=message.run_id, payload={"content":node_updates[idx%5]})
#                 steps_counter += 1

#             for source in sources:
#                 await asyncio.sleep(0.5)
#                 self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.SOURCE_UPDATE, thread_id=message.thread_id, run_id=message.run_id, payload={"sources": [source]})
#                 steps_counter += 1

#             for chunk in dummy_output.split(" "):
#                 chunk = chunk + " "
#                 # print(f"key: {run_key}, steps_counter: {steps_counter} chunk: {chunk}")
#                 await asyncio.sleep(0.0005)
#                 self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.MESSAGE_STREAM, thread_id=message.thread_id, run_id=message.run_id, payload={"delta": chunk})
#                 steps_counter += 1
            
#             self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.RUN_COMPLETED, thread_id=message.thread_id, run_id=message.run_id, payload={})
#         except Exception as e:
#             print(f"Error: {e}")
#             self.RUN_EVENTS[run_key][steps_counter] = MESSAGE(type=MESSAGE_TYPE.RUN_FAILED, thread_id=message.thread_id, run_id=message.run_id, payload={"error": "Internal error"})
        
        
    async def get_run_events(self, run_id: str, thread_id: str, start_from: int = 0):
        run_key = f"{thread_id}-{run_id}"
        if run_key in self.RUN_EVENTS:
            while True:
                # print(f"key: {run_key}, start_from: {start_from}")
                # print(f"events: {self.RUN_EVENTS[run_key]}")
                if start_from in self.RUN_EVENTS[run_key]:
                    yield self.RUN_EVENTS[run_key][start_from]
                    if self.RUN_EVENTS[run_key][start_from].type == MESSAGE_TYPE.RUN_COMPLETED:
                        break
                    start_from += 1
                    await asyncio.sleep(0.01)
                else:
                    await asyncio.sleep(1)
        else:
            yield MESSAGE(type=MESSAGE_TYPE.RUN_FAILED, thread_id=run_key, run_id=run_key, payload={"error": "Run not found"})
