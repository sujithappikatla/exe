

from graph import graph
import asyncio


async def main():
    async for mode, chunk in graph.astream({"question": "Explain get_stream_writer in langgraph", "agent_type": "slow"}, stream_mode=["messages", "updates", "custom"]):
        if mode == "custom":
            if chunk["type"] == "messages":
                print(chunk["delta"])
        elif mode == "updates":
            print(chunk)
                

asyncio.run(main())