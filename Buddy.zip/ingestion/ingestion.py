from langchain.embeddings import init_embeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_community.document_loaders import WebBaseLoader
from ingestion.constants import INGESTION_MODEL, INGESTION_MODEL_PROVIDER
# Universal initializer for VertexAI embeddings
embeddings = init_embeddings(
    INGESTION_MODEL,
    provider=INGESTION_MODEL_PROVIDER
)




LANGGRAPH_LLMS_TXT_URL = "https://langchain-ai.github.io/langgraph/llms-full.txt"
CHROMA_PERSIST_DIR = "chroma_db"

# document = WebBaseLoader(LANGGRAPH_LLMS_TXT_URL).load()

# text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

# docs = text_splitter.split_documents(document)
# for doc in docs:
#     doc.metadata["source_name"] = "llms-full.txt"   
#     doc.metadata["source"] = ""

# # run once when needed to create the chroma db
# chroma_db = Chroma.from_documents(
#     documents=docs,
#     embedding=embeddings,
#     persist_directory=CHROMA_PERSIST_DIR
# )



retriever = Chroma(
    persist_directory=CHROMA_PERSIST_DIR,
    embedding_function=embeddings
).as_retriever(
    search_kwargs={"k": 5, "score_threshold": 0.5},
    search_type="similarity_score_threshold"
)

# print(retriever.invoke("What is the difference between LangGraph and LangChain?"))



