
# ingestion settings
# INGESTION_MODEL = "text-embedding-004"
# INGESTION_MODEL_PROVIDER = "google_vertexai"
INGESTION_MODEL = "nomic-embed-text:latest"
INGESTION_MODEL_PROVIDER = "ollama"
