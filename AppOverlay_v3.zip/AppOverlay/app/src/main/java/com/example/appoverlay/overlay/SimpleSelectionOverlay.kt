package com.example.appoverlay.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import com.example.appoverlay.R
import com.example.appoverlay.util.LOGTAG

class SimpleSelectionOverlay(
    cxt: Context,
    windowManager: WindowManager,
    drawingCanvasOverlay: DrawingCanvasOverlay,
    val stopService: () -> Unit
) {
    private var selectionBarView: View? = null
    private var CXT: Context? = null
    private var WM:WindowManager? = null
    private var layoutParams:WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )
    private val CANVAS = drawingCanvasOverlay

    private var isColorSliderVisible = false
    private var isWidthSliderVisible = false
    private var mode = 0

    init {
        CXT = cxt
        WM = windowManager
    }

    public fun create()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView create ")

        val inflater = CXT!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        selectionBarView = inflater.inflate(R.layout.simple_selection_layout, null)

        layoutParams.gravity = Gravity.LEFT
        WM!!.addView(selectionBarView, layoutParams)

        addColorSelectionLogic()
        addEraserLogic()
        addModeLogic()
        addCloseLogic()

    }

    fun addColorSelectionLogic()
    {
        val color1: View = selectionBarView!!.findViewById(R.id.color1)
        color1.setOnClickListener {
            CANVAS.setToPen()
            onColorSelect(Color.BLUE);
        }

        val color2: View = selectionBarView!!.findViewById(R.id.color2)
        color2.setOnClickListener {
            CANVAS.setToPen()
            onColorSelect(Color.BLACK);
        }

    }


    fun addEraserLogic()
    {
        val eraser: View = selectionBarView!!.findViewById(R.id.earserIcon)
        eraser.setOnClickListener {
            onEraserSelect()
        }
    }

    fun addModeLogic()
    {
        val modeL : View = selectionBarView!!.findViewById(R.id.modeLayout)

        modeL.setOnClickListener {
            val annotate = selectionBarView!!.findViewById<View>(R.id.modeAnnotate)
            val control = selectionBarView!!.findViewById<View>(R.id.modeControl)
            val control_annotate = selectionBarView!!.findViewById<View>(R.id.modeControlAndAnnotate)

            mode = (mode +1 ) % 3
            if(mode==0)
            {
                control_annotate.visibility = View.VISIBLE
                annotate.visibility = View.GONE
                control.visibility = View.GONE

            }
            else if(mode ==1)
            {
                control_annotate.visibility = View.GONE
                annotate.visibility = View.VISIBLE
                control.visibility = View.GONE

            }
            else if(mode==2)
            {
                control_annotate.visibility = View.GONE
                annotate.visibility = View.GONE
                control.visibility = View.VISIBLE
            }
            CANVAS.SetMode(mode)
        }

    }

    fun addCloseLogic()
    {
        val closeL: View = selectionBarView!!.findViewById(R.id.closeIcon)
        closeL.setOnClickListener {
            stopService()
        }

    }

    private fun onColorSelect(_color:Int)
    {
        Log.i(LOGTAG, "Selecting Color : $_color")
        CANVAS.setPenColor(_color)
    }

    private fun onEraserSelect()
    {
        Log.i(LOGTAG, "Selecting Eraser")

        CANVAS.setToEraser()
    }

    public fun destroy()
    {
        Log.i(LOGTAG, "--- DrawingCanvasView destroy ")
        if (WM != null && selectionBarView != null) {
            WM!!.removeView(selectionBarView)
        }
    }

}