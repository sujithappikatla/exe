package com.example.appoverlay.util

const val LOGTAG = "_AppOverlay"