package com.ska.imagegallery.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.util.Log
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Collections

@OptIn(UnstableApi::class)
object AudioCache {
    private var cache: SimpleCache? = null
    private const val CACHE_SIZE = 100 * 1024 * 1024L // 100MB
    private const val TOKEN_SERVER_URL = "https://tokenserver-305533803718.us-central1.run.app/gcp/presign"
    private val okHttpClient = OkHttpClient()
    
    // Track URLs that need renewal due to 401/403 errors
    private val urlsNeedingRenewal = Collections.synchronizedSet(mutableSetOf<String>())

    @Synchronized
    fun getCache(context: Context): SimpleCache {
        if (cache == null) {
            val cacheDir = File(context.cacheDir, "audio_cache")
            val evictor = LeastRecentlyUsedCacheEvictor(CACHE_SIZE)
            val databaseProvider = StandaloneDatabaseProvider(context)
            cache = SimpleCache(cacheDir, evictor, databaseProvider)
        }
        return cache!!
    }

    private fun fetchNewPresignedUrl(): Uri {
        val request = Request.Builder()
            .url(TOKEN_SERVER_URL)
            .build()

        try {
            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Unexpected code $response")
                val responseData = response.body?.string() ?: throw IOException("Empty body")
                val json = JSONObject(responseData)
                val newUrl = json.getString("url")
                Log.i("AudioCache", "Fetched new presigned URL: $newUrl")
                return Uri.parse(newUrl)
            }
        } catch (e: Exception) {
            Log.e("AudioCache", "Error fetching new presigned URL", e)
            throw e
        }
    }

    private fun getNormalizedUrl(uri: Uri): String {
        val path = uri.path ?: ""
        val scheme = uri.scheme ?: ""
        val host = uri.host ?: ""
        return if (scheme.isNotEmpty() && host.isNotEmpty()) {
            "$scheme://$host$path"
        } else {
            uri.toString()
        }
    }

    fun markUrlForRenewal(uri: Uri) {
        val normalizedUrl = getNormalizedUrl(uri)
        urlsNeedingRenewal.add(normalizedUrl)
        Log.w("AudioCache", "URL marked for renewal due to 401/403 error: $normalizedUrl")
    }

    fun getCacheDataSourceFactory(context: Context): CacheDataSource.Factory {
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
        
        val resolvingDataSourceFactory = ResolvingDataSource.Factory(httpDataSourceFactory) { dataSpec ->
            val uri = dataSpec.uri
            val normalizedUrl = getNormalizedUrl(uri)
            
            // Only fetch new URL if this URL was marked for renewal due to 401/403
            if (urlsNeedingRenewal.contains(normalizedUrl)) {
                urlsNeedingRenewal.remove(normalizedUrl)
                Log.i("AudioCache", "Renewing URL due to previous 401/403 error: $normalizedUrl")
                val newUri = fetchNewPresignedUrl()
                dataSpec.withUri(newUri)
            } else {
                // Use original URL
                dataSpec
            }
        }
        
        val defaultDataSourceFactory = DefaultDataSource.Factory(context, resolvingDataSourceFactory)
        
        return CacheDataSource.Factory()
            .setCache(getCache(context))
            .setUpstreamDataSourceFactory(defaultDataSourceFactory)
            .setCacheKeyFactory { dataSpec ->
                // Use URL without query parameters as the cache key to handle expiring signed URLs
                getNormalizedUrl(dataSpec.uri)
            }
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }
}

