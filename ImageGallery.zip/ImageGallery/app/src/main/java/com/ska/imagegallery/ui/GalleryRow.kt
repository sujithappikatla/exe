package com.ska.imagegallery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.ska.imagegallery.ui.theme.ImageGalleryTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DynamicGalleryRow(
    imageUrls: List<String>,
    modifier: Modifier = Modifier,
    rowHeight: Dp = 240.dp,
    spacing: Dp = 8.dp
) {
    val context = LocalContext.current
    val imageLoader = context.imageLoader
    val successfulUrls = remember(imageUrls) { mutableStateListOf<String>() }

    LaunchedEffect(imageUrls) {
        successfulUrls.clear()
        coroutineScope {
            imageUrls.forEachIndexed { index, url ->
                launch(Dispatchers.IO) {
                    val request = ImageRequest.Builder(context)
                        .data(url)
                        .allowHardware(false)
                        .build()
                    val result = imageLoader.execute(request)
                    if (result is SuccessResult) {
                        // insert in original order
                        withContext(Dispatchers.Main) {
                            // ensure list is large enough and ordered
                            val tmp = successfulUrls.toMutableList()
                            if (index >= tmp.size) {
                                // pad if needed
                                while (tmp.size < index) tmp.add("")
                                tmp.add(url)
                            } else {
                                tmp.add(index, url)
                            }
                            successfulUrls.clear()
                            successfulUrls.addAll(tmp.filter { it.isNotEmpty() })
                        }
                    }
                }
            }
        }
    }

    if (successfulUrls.isEmpty()) {
        Box(
            modifier = modifier
                .height(rowHeight)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "No images available")
        }
        return
    }

    val lastImageUrl = successfulUrls.last()
    val tileHeight = rowHeight / 2
    val tileWidth = tileHeight * (4f / 3f)

    // Build columns: first image full height, the rest in pairs; if odd, last one fills column.
    val columns: List<List<String>> = buildList {
        add(listOf(successfulUrls.first()))
        val remaining = successfulUrls.drop(1)
        var idx = 0
        while (idx < remaining.size) {
            if (idx + 1 < remaining.size) {
                add(listOf(remaining[idx], remaining[idx + 1]))
                idx += 2
            } else {
                add(listOf(remaining[idx]))
                idx += 1
            }
        }
    }

    LazyRow(
        modifier = modifier.height(rowHeight),
        horizontalArrangement = Arrangement.spacedBy(spacing),
        contentPadding = PaddingValues(horizontal = spacing)
    ) {
        itemsIndexed(columns) { columnIndex, columnItems ->
            val isFirstColumn = columnIndex == 0
            val columnWidth = if (isFirstColumn) rowHeight * (4f / 3f) else tileWidth

            Box(
                modifier = Modifier
                    .height(rowHeight)
                    .width(columnWidth)
            ) {
                if (isFirstColumn) {
                    val url = columnItems.first()
                    GalleryTile(
                        url = url,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(width = columnWidth, height = rowHeight),
                        showOverlay = url == lastImageUrl
                    )
                } else if (columnItems.size == 2) {
                    val topUrl = columnItems[0]
                    val bottomUrl = columnItems[1]

                    GalleryTile(
                        url = topUrl,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .size(width = tileWidth, height = tileHeight),
                        showOverlay = topUrl == lastImageUrl
                    )
                    GalleryTile(
                        url = bottomUrl,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .size(width = tileWidth, height = tileHeight),
                        showOverlay = bottomUrl == lastImageUrl
                    )
                } else {
                    val url = columnItems.first()
                    GalleryTile(
                        url = url,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(width = tileWidth, height = rowHeight),
                        showOverlay = url == lastImageUrl
                    )
                }
            }
        }
    }
}

@Composable
private fun GalleryTile(
    url: String,
    modifier: Modifier,
    showOverlay: Boolean
) {
    val context = LocalContext.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(url)
                .crossfade(true)
                .build(),
            contentDescription = "Gallery image",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        if (showOverlay) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.35f))
            )
            Text(
                text = "+more",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun DynamicGalleryRowPreview() {
    ImageGalleryTheme {
        DynamicGalleryRow(
            imageUrls = listOf(
                "https://picsum.photos/id/1001/600/900",
                "https://picsum.photos/id/1002/600/900",
                "https://picsum.photos/id/1003/600/900",
                "https://picsum.photos/id/1004/600/900",
                "https://picsum.photos/id/1005/600/900"
            ),
            rowHeight = 240.dp,
            spacing = 8.dp
        )
    }
}

