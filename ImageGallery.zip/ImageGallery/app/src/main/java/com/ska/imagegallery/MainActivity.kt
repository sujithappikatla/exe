package com.ska.imagegallery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.ska.imagegallery.ui.DynamicGalleryRow
import com.ska.imagegallery.ui.theme.ImageGalleryTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ImageGalleryTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)) {
                        DynamicGalleryRow(
                            imageUrls = sampleGalleryUrls()
                        )
                    }
                }
            }
        }
    }
}

private fun sampleGalleryUrls(): List<String> = listOf(
    "https://picsum.photos/id/1001/600/900",
    "https://picsum.photos/id/1002/600/900",
    "https://www.amazon.in/stores/Microsoft/page/80DAC8F6-AD23-4B56-86D2-8DEF35BEA566",
    "https://picsum.photos/id/1003/600/900",
    "https://picsum.photos/id/1004/600/900",
    "https://picsum.photos/id/1005/600/900",
    "https://picsum.photos/id/1006/600/900",
    "https://picsum.photos/id/1007/600/900",
    "https://picsum.photos/id/1008/600/900",
    "https://picsum.photos/id/1009/600/900",
)

@Composable
fun GalleryPreview() {
    ImageGalleryTheme {
        DynamicGalleryRow(imageUrls = sampleGalleryUrls())
    }
}