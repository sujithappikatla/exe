package com.ska.imagegallery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.ska.imagegallery.player.AudioPlayer
import com.ska.imagegallery.ui.DynamicGalleryRow
import com.ska.imagegallery.ui.theme.ImageGalleryTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ImageGalleryTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        DynamicGalleryRow(
                            imageUrls = sampleGalleryUrls()
                        )
                        
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        AudioPlayer(
                            url = "https://storage.googleapis.com/ska-test-bucket/exotest.mp3?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=305533803718-compute%40developer.gserviceaccount.com%2F20251229%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20251229T171703Z&X-Goog-Expires=180&X-Goog-SignedHeaders=host&X-Goog-Signature=332ae29e094d4f8fcf53e1338205d733575d1945755ef2f7f8f553c71dabe6032e9b34027a56ce0b7190fbda3f34e456b24d1f4bd62c85a3237fb1668476b71bf2a99a5be2ff8d3b802d62db20673d3b71438fc755f62102ed6530fd96012e4eda66e0753649528b64f7fd2d3c6ca3594553c5d13c04038b027579051809ebf5a58bfe253edf7a2c84623bf96cb4bc1c49c4f35dca25ce7e189e00a6e32c1e5bebe5fc0164e6c23c2c8af4820f5fd94f188a67dadf3d5a0a19076113e9a7123c5a00bb027b771788bd9896b19200ee595eea95803808542ee75c8c8511b84353b270cb6c20020d3a33ee76b404ed5741982d38ee9c17a7df3e6e600a493191ab",
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun sampleGalleryUrls(): List<String> = listOf(
    "https://picsum.photos/id/1001/600/900",
    "https://picsum.photos/id/1002/600/900",
    "https://www.amazon.in/stores/Microsoft/page/80DAC8F6-AD23-4B56-86D2-8DEF35BEA566",
    "https://picsum.photos/id/1003/600/900",
    "https://picsum.photos/id/1004/600/900",
    "https://picsum.photos/id/1005/600/900",
    "https://picsum.photos/id/1006/600/900",
    "https://picsum.photos/id/1007/600/900",
    "https://picsum.photos/id/1008/600/900",
    "https://picsum.photos/id/1009/600/900",
)

@Composable
fun GalleryPreview() {
    ImageGalleryTheme {
        DynamicGalleryRow(imageUrls = sampleGalleryUrls())
    }
}