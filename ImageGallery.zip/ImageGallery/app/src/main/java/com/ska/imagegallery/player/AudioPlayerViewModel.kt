package com.ska.imagegallery.player

import android.app.Application
import androidx.annotation.OptIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.Log
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class AudioPlayerViewModel(application: Application) : AndroidViewModel(application) {
    
    var player: ExoPlayer? by mutableStateOf(null)
        private set

    var isPlaying by mutableStateOf(false)
        private set

    var currentPosition by mutableLongStateOf(0L)
        private set

    var duration by mutableLongStateOf(0L)
        private set

    var playbackSpeed by mutableFloatStateOf(1.0f)
        private set

    private var currentUrl: String? = null

    init {
        val cacheFactory = AudioCache.getCacheDataSourceFactory(application)
        val mediaSourceFactory = DefaultMediaSourceFactory(application)
            .setDataSourceFactory(cacheFactory)

        player = ExoPlayer.Builder(application)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .apply {
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        this@AudioPlayerViewModel.isPlaying = isPlaying
                    }

                    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                        playbackSpeed = playbackParameters.speed
                    }

                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_READY) {
                            this@AudioPlayerViewModel.duration = duration.coerceAtLeast(0L)
                        }
                    }

                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        Log.e("AudioPlayerViewModel", "Player error: ${error.message}", error)
                        
                        // Check if this is a 401/403 error (URL expired)
                        val cause = error.cause
                        val isAuthError = when {
                            cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException -> {
                                val responseCode = cause.responseCode
                                responseCode == 401 || responseCode == 403
                            }
                            error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> true
                            else -> false
                        }
                        
                        if (isAuthError) {
                            Log.w("AudioPlayerViewModel", "Detected 401/403 error - marking URL for renewal")
                            // Mark the URL for renewal
                            player?.currentMediaItem?.localConfiguration?.uri?.let { uri ->
                                AudioCache.markUrlForRenewal(uri)
                            }
                            
                            // Attempt to recover by re-preparing
                            val currentPos = currentPosition
                            player?.let {
                                it.prepare()
                                it.seekTo(currentPos)
                                it.play()
                            }
                        }
                    }

                    override fun onEvents(player: Player, events: Player.Events) {
                        if (events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED) || 
                            events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) {
                            this@AudioPlayerViewModel.duration = player.duration.coerceAtLeast(0L)
                        }
                    }
                })
            }

        startProgressUpdate()
    }

    private fun startProgressUpdate() {
        viewModelScope.launch {
            while (isActive) {
                player?.let {
                    currentPosition = it.currentPosition
                    if (it.duration > 0) {
                        duration = it.duration
                    }
                }
                delay(500)
            }
        }
    }

    fun playAudio(url: String) {
        if (currentUrl == url) return
        
        currentUrl = url
        player?.let {
            val mediaItem = MediaItem.fromUri(url)
            it.setMediaItem(mediaItem)
            it.prepare()
            it.playWhenReady = true
        }
    }

    fun togglePlayPause() {
        player?.let {
            if (it.isPlaying) {
                it.pause()
            } else {
                it.play()
            }
        }
    }

    fun seekTo(position: Long) {
        player?.seekTo(position)
        currentPosition = position
    }

    fun setSpeed(speed: Float) {
        player?.playbackParameters = PlaybackParameters(speed)
    }

    override fun onCleared() {
        super.onCleared()
        player?.release()
        player = null
    }
}

