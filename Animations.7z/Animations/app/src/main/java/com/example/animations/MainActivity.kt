package com.example.animations

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import kotlin.math.max
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BackgroundWithAnimation()
                }
            }
        }
    }
}

@Composable
fun BackgroundWithAnimation() {
    Box(modifier = Modifier.fillMaxSize()) {
        // Background Image
        Image(
            painter = painterResource(id = R.drawable.image2),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Expanding Circle Animation
        ExpandingCircleAnimation()
    }
}

@Composable
fun ExpandingCircleAnimation() {
    var animationPlayed by remember { mutableStateOf(false) }
    val animationSpec = tween<Float>(500, easing = LinearOutSlowInEasing)

    val animationProgress by animateFloatAsState(
        targetValue = if (animationPlayed) 1f else 0f,
        animationSpec = animationSpec,
        finishedListener = { animationPlayed = true }
    )

    val infiniteTransition = rememberInfiniteTransition()
    val colorRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    LaunchedEffect(key1 = true) {
        animationPlayed = true
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val maxRadius = sqrt(size.width * size.width + size.height * size.height)
        val currentRadius = max(0.1f, animationProgress * maxRadius)
        val center = Offset(size.width, size.height)

        drawExpandingCircle(center, currentRadius, animationProgress, colorRotation)
    }
}

fun DrawScope.drawExpandingCircle(center: Offset, radius: Float, progress: Float, rotation: Float) {
    val gradient = Brush.sweepGradient(
        colors = listOf(
            Color(0xFF00BCD4),  // Cyan
            Color(0xFF3F51B5),  // Indigo
            Color(0xFF9C27B0),  // Purple
            Color(0xFF00BCD4)   // Cyan again to complete the circle
        ),
        center = center
    )

    rotate(rotation, pivot = center) {
        drawCircle(
            brush = gradient,
            center = center,
            radius = radius,
            alpha = progress * 0.4f // Alpha transition from 0 to 0.4f
        )
    }
}