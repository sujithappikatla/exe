from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from dotenv import load_dotenv
import os
import time
from logger import logger
import random
from typing import Optional, List, Dict, Union


class ImageSearchClient:
    """
    A client for performing image searches using Google Custom Search API.

    Documentation: https://developers.google.com/custom-search/v1/reference/rest/v1/cse/list
    
    This client specifically searches for images using the Google Custom Search API.
    It returns image metadata including URLs, dimensions, and contextual information.
    """

    # Class constants
    MAX_RESULTS = 10
    SUPPORTED_LANGUAGES = {
        'ar': 'Arabic', 'bg': 'Bulgarian', 'ca': 'Catalan', 'cs': 'Czech',
        'da': 'Danish', 'de': 'German', 'el': 'Greek', 'en': 'English',
        'es': 'Spanish', 'et': 'Estonian', 'fi': 'Finnish', 'fr': 'French',
        'hr': 'Croatian', 'hu': 'Hungarian', 'id': 'Indonesian', 'is': 'Icelandic',
        'it': 'Italian', 'iw': 'Hebrew', 'ja': 'Japanese', 'ko': 'Korean',
        'lt': 'Lithuanian', 'lv': 'Latvian', 'nl': 'Dutch', 'no': 'Norwegian',
        'pl': 'Polish', 'pt': 'Portuguese', 'ro': 'Romanian', 'ru': 'Russian',
        'sk': 'Slovak', 'sl': 'Slovenian', 'sr': 'Serbian', 'sv': 'Swedish',
        'tr': 'Turkish', 'zh-CN': 'Chinese (Simplified)', 'zh-TW': 'Chinese (Traditional)'
    }

    # Image-specific constants
    SUPPORTED_IMAGE_SIZES = ['HUGE', 'ICON', 'LARGE', 'MEDIUM', 'SMALL', 'XLARGE', 'XXLARGE']
    SUPPORTED_IMAGE_TYPES = ['clipart', 'face', 'lineart', 'stock', 'photo', 'animated']
    SUPPORTED_IMAGE_COLORS = ['color', 'gray', 'mono', 'trans']

    def __init__(self, env_file_path: Optional[str] = None):
        """
        Initialize the ImageSearchClient.
        
        Args:
            env_file_path: Optional path to .env file. If not provided, looks in current directory.
        """
        # Load environment variables
        if env_file_path:
            load_dotenv(env_file_path)
        else:
            load_dotenv()

        # Initialize credentials
        self._api_key = os.getenv("PROJECT_API_KEY")
        self._search_engine_id = os.getenv("SEARCH_ENGINE_ID")

        if not self._api_key or not self._search_engine_id:
            raise self.SearchError("Missing API credentials. Please check PROJECT_API_KEY and SEARCH_ENGINE_ID in .env file")

    class SearchError(Exception):
        """Custom exception for search-related errors."""
        pass

    def _exponential_backoff(self, attempt: int, max_delay: float = 32.0) -> float:
        """
        Calculate delay with exponential backoff and jitter.
        
        Args:
            attempt: The current attempt number
            max_delay: Maximum delay in seconds
            
        Returns:
            The calculated delay in seconds
        """
        delay = min(max_delay, (2 ** attempt) + random.uniform(0, 1))
        return delay

    def search(
        self,
        query: str,
        gl: Optional[str] = None,
        lr: Optional[str] = None,
        num: int = 10,
        safe: bool = True,
        start: int = 1,
        image_size: Optional[str] = None,
        image_type: Optional[str] = None,
        image_color: Optional[str] = None,
        max_retries: int = 3
    ) -> List[Dict[str, str]]:
        """
        Search for images using Google Custom Search API with retry mechanism.
        
        Args:
            query: Search query string
            gl: Geolocation of end user (e.g., 'us', 'uk', 'in'). See https://developers.google.com/custom-search/docs/xml_results#countryCodes
            lr: Language restriction. Format: 'lang_{two-letter code}' (e.g., 'lang_en' for English). See SUPPORTED_LANGUAGES for valid codes.
            num: Number of search results to return (1-10)
            safe: Whether to enable safe search (True for 'active', False for 'off')
            start: Index of first result to return (1-based indexing)
            image_size: Filter by image size (see SUPPORTED_IMAGE_SIZES)
            image_type: Filter by image type (see SUPPORTED_IMAGE_TYPES)
            image_color: Filter by color properties (see SUPPORTED_IMAGE_COLORS)
            max_retries: Maximum number of retry attempts
        
        Returns:
            List of dictionaries containing image results with keys:
            - title: Image title
            - link: Direct link to the image
            - image_url: URL of the full-size image
            - thumbnail_url: URL of the thumbnail
            - context_url: URL of the page containing the image
            - height: Image height in pixels
            - width: Image width in pixels
            - thumbnail_height: Thumbnail height in pixels
            - thumbnail_width: Thumbnail width in pixels
            - snippet: Text snippet describing the image
        
        Raises:
            SearchError: If the search fails after all retries
            ValueError: If input parameters are invalid
        """
        # Input validation
        if not query or not isinstance(query, str):
            raise ValueError("Query must be a non-empty string")

        if num < 1 or num > self.MAX_RESULTS:
            raise ValueError(f"Number of results must be between 1 and {self.MAX_RESULTS}")

        if start < 1:
            raise ValueError("Start index must be greater than 0")

        if lr and not lr.startswith('lang_'):
            lr = f'lang_{lr}'
        
        if lr and lr[5:] not in self.SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported language code. Supported codes: {', '.join(self.SUPPORTED_LANGUAGES.keys())}")

        if image_size and image_size not in self.SUPPORTED_IMAGE_SIZES:
            raise ValueError(f"Unsupported image size. Supported sizes: {', '.join(self.SUPPORTED_IMAGE_SIZES)}")

        if image_type and image_type not in self.SUPPORTED_IMAGE_TYPES:
            raise ValueError(f"Unsupported image type. Supported types: {', '.join(self.SUPPORTED_IMAGE_TYPES)}")

        if image_color and image_color not in self.SUPPORTED_IMAGE_COLORS:
            raise ValueError(f"Unsupported image color. Supported colors: {', '.join(self.SUPPORTED_IMAGE_COLORS)}")

        # Prepare search parameters
        search_params = {
            'q': query,
            'cx': self._search_engine_id,
            'num': num,
            'start': start,
            'safe': 'active' if safe else 'off',
            'searchType': 'image'  # Specify image search
        }

        # Add optional parameters if provided
        if gl:
            search_params['gl'] = gl
        if lr:
            search_params['lr'] = lr
        if image_size:
            search_params['imgSize'] = image_size
        if image_type:
            search_params['imgType'] = image_type
        if image_color:
            search_params['imgColorType'] = image_color

        search_params['imgSize'] = "MEDIUM"

        for attempt in range(max_retries):
            try:
                logger.info(f"Attempting image search. Attempt {attempt + 1}/{max_retries}")
                service = build("customsearch", "v1", developerKey=self._api_key)
                result = service.cse().list(**search_params).execute()

                if 'items' not in result:
                    logger.warning("No image results found")
                    return []

                ret = []
                for item in result['items']:
                    image = item.get('image', {})
                    temp = {
                        "title": item.get('title', ''),
                        # "link": item.get('link', ''),
                        "image_url": item.get('link', ''),
                        # "thumbnail_url": image.get('thumbnailLink', ''),
                        "context_url": item.get('image', {}).get('contextLink', ''),
                        "height": image.get('height', 0),
                        "width": image.get('width', 0),
                        # "thumbnail_height": image.get('thumbnailHeight', 0),
                        # "thumbnail_width": image.get('thumbnailWidth', 0),
                        # "snippet": item.get('snippet', '')
                    }
                    ret.append(temp)
                
                logger.info(f"Successfully retrieved {len(ret)} image results")
                return ret

            except HttpError as e:
                logger.error(f"HTTP error occurred: {str(e)}")
                if e.resp.status in [429, 500, 503]:  # Retry on rate limit or server errors
                    if attempt < max_retries - 1:
                        delay = self._exponential_backoff(attempt)
                        logger.info(f"Retrying in {delay:.2f} seconds...")
                        time.sleep(delay)
                        continue
                raise self.SearchError(f"Image search failed: {str(e)}")
                
            except Exception as e:
                logger.error(f"Unexpected error: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                raise self.SearchError(f"Image search failed: {str(e)}")


if __name__ == "__main__":
    try:
        # Initialize the client
        client = ImageSearchClient()
        
        # Example image search with parameters
        results = client.search(
            query="cute puppies",
            # gl="us",                # Search from US perspective
            # lr="en",                # English results only
            # num=5,                  # Get 5 results
            # safe=True,              # Safe search on
            # start=1,                # Start from first result
            # image_size="LARGE",     # Large images only
            # image_type="face",     # Photos only
            # image_color="gray"     # Color images only
        )
        
        print(f"Found {len(results)} images")
        for result in results:
            print("\nImage details:")
            for key, value in result.items():
                print(f"{key}: {value}")
    except (ImageSearchClient.SearchError, ValueError) as e:
        logger.error(f"Error during image search: {str(e)}")
