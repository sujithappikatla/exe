import vertexai
from vertexai.generative_models import GenerativeModel, Part, SafetySetting, GenerationResponse
from vertexai.preview.generative_models import Tool, grounding
from typing import List, Dict, Optional, Union, Tuple, Any
from dotenv import load_dotenv
from PIL import Image
import io
import json
import os
import time
import random
from logger import logger


class GeminiClient:
    """
    A client for performing image analysis and educational content generation using Google's Gemini AI.
    
    This client provides functionality to:
    - Analyze pairs of images (full and cropped versions)
    - Generate educational explanations based on image analysis
    - Ground explanations using Google Search
    - Handle safety settings and content filtering
    
    Documentation: https://cloud.google.com/vertex-ai/docs/generative-ai/model-reference/gemini
    """

    def __init__(self, env_file_path: Optional[str] = None):
        """
        Initialize the GeminiClient.
        
        Args:
            env_file_path: Optional path to .env file. If not provided, looks in current directory.
        """
        # Load environment variables
        if env_file_path:
            load_dotenv(env_file_path)
        else:
            load_dotenv()

        # Initialize configuration from environment variables
        self._project_id = os.getenv("PROJECT_ID")
        self._location = os.getenv("GEMINI_MODEL_LOCATION", "us-central1")
        self._model_name_for_image_analysis = os.getenv("GEMINI_MODEL_NAME_FOR_IMAGE_ANALYSIS", "gemini-1.5-flash-002")
        self._model_name_for_grounding = os.getenv("GEMINI_MODEL_NAME_FOR_GROUNDING", "gemini-1.5-flash-002")

        # Load prompts from environment variables
        self._analysis_system_instructions = [os.getenv("ANALYSIS_SYSTEM_INSTRUCTIONS", "")]
        self._analysis_prompt = os.getenv("ANALYSIS_PROMPT", "")
        self._grounding_system_instruction = os.getenv("GROUNDING_SYSTEM_INSTRUCTION", "")
        self._search_query_system_instructions = [os.getenv("SEARCH_QUERY_SYSTEM_INSTRUCTIONS", "")]
        self._search_query_prompt = os.getenv("SEARCH_QUERY_PROMPT", "")

        # Retry configuration
        self._max_retries = 3
        self._initial_retry_delay = 1  # seconds
        self._max_retry_delay = 32  # seconds
        self._jitter_factor = 0.1

        # Validate required configuration
        if not self._project_id:
            raise self.ConfigurationError(
                "Missing required environment variables. Please check PROJECT_ID in .env file"
            )

        # Initialize Vertex AI
        vertexai.init(project=self._project_id, location=self._location)

        # Initialize models and configurations
        self._init_models()

    class ConfigurationError(Exception):
        """Exception raised for configuration-related errors."""
        pass

    class AnalysisError(Exception):
        """Exception raised for image analysis errors."""
        pass

    def _exponential_backoff(self, attempt: int) -> float:
        """
        Calculate the exponential backoff delay with jitter.
        
        Args:
            attempt: Current retry attempt number (0-based)
            
        Returns:
            float: Delay in seconds before next retry
        """
        delay = min(
            self._max_retry_delay,
            self._initial_retry_delay * (2 ** attempt)
        )
        jitter = delay * self._jitter_factor * random.uniform(-1, 1)
        return max(0, delay + jitter)

    def _retry_with_backoff(self, func, *args, **kwargs):
        """
        Execute a function with exponential backoff retry logic.
        
        Args:
            func: Function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function
            
        Returns:
            Any: Result of the function execution
            
        Raises:
            Exception: Last encountered exception after all retries
        """
        last_exception = None
        
        for attempt in range(self._max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                if attempt < self._max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.warning(f"Attempt {attempt + 1} failed: {str(e)}. Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                else:
                    logger.error(f"All {self._max_retries} attempts failed. Last error: {str(e)}")
                    raise last_exception

    def _init_models(self) -> None:
        """
        Initialize Gemini models and configurations.
        
        Sets up:
        - Image analysis model
        - Generation configuration
        - Safety settings
        """
        # Create model instance for image analysis
        self._analysis_model = GenerativeModel(
            self._model_name_for_image_analysis,
            system_instruction=self._analysis_system_instructions
        )

        # Configure generation parameters
        self._generation_config = {
            "max_output_tokens": 8192,
            "temperature": 0.2,
            "top_p": 0.95,
            "response_mime_type": "application/json",
            "response_schema": {
                "type": "OBJECT",
                "properties": {
                    "key_topic": {"type": "STRING"},
                    "full_image_description": {"type": "STRING"},
                    "cropped_image_description": {"type": "STRING"}
                }
            },
        }

        # Set up safety filters
        self._safety_settings = [
            SafetySetting(
                category=cat,
                threshold=SafetySetting.HarmBlockThreshold.BLOCK_LOW_AND_ABOVE
            )
            for cat in [
                SafetySetting.HarmCategory.HARM_CATEGORY_HATE_SPEECH,
                SafetySetting.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
                SafetySetting.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
                SafetySetting.HarmCategory.HARM_CATEGORY_HARASSMENT,
            ]
        ]

    def _compress_image(self, image_bytes: bytes, max_dimension: int = 1024) -> bytes:
        """
        Compress image while maintaining aspect ratio.
        
        Args:
            image_bytes: Raw image data
            max_dimension: Maximum allowed dimension (width or height)
            
        Returns:
            bytes: Compressed image data
            
        Raises:
            AnalysisError: If image compression fails
        """
        try:
            # Open image from bytes
            image = Image.open(io.BytesIO(image_bytes))
            
            # Get current dimensions
            width, height = image.size
            
            # Check if compression is needed
            if width <= max_dimension and height <= max_dimension:
                return image_bytes
                
            # Calculate new dimensions maintaining aspect ratio
            if width > height:
                new_width = max_dimension
                new_height = int(height * (max_dimension / width))
            else:
                new_height = max_dimension
                new_width = int(width * (max_dimension / height))
                
            # Resize image
            resized_image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # Convert back to bytes
            output_buffer = io.BytesIO()
            resized_image.save(output_buffer, format=image.format if image.format else 'JPEG')
            return output_buffer.getvalue()
            
        except Exception as e:
            raise self.AnalysisError(f"Failed to compress image: {str(e)}")

    def _create_image_part(self, image_bytes: bytes, mime_type: str) -> Part:
        """
        Create a Gemini Part object from image bytes.
        
        Args:
            image_bytes: Raw image data
            mime_type: MIME type of the image (e.g., 'image/jpeg')
            
        Returns:
            Part: Gemini Part object containing the image
            
        Raises:
            AnalysisError: If image processing fails
        """
        try:
            # Compress image if needed
            compressed_bytes = self._compress_image(image_bytes)
            
            # Create Part from compressed image
            return Part.from_data(
                mime_type=mime_type,
                data=compressed_bytes
            )
        except Exception as e:
            raise self.AnalysisError(f"Failed to process image: {str(e)}")

    def _analyze_images(self, image_parts: List[Part], extended_context: Optional[str] = None) -> Dict[str, str]:
        """
        Generate analysis for the provided images using Gemini.
        
        Args:
            image_parts: List of image Parts to analyze
            extended_context: Optional additional context or questions from the user
            
        Returns:
            Dict[str, str]: Analysis results containing key_topic, descriptions
            
        Raises:
            AnalysisError: If analysis fails
        """
        def _perform_analysis():
            # Prepare prompt with extended context if provided
            prompt = self._analysis_prompt
            if extended_context:
                prompt = f"""{prompt}\nUser Specifically looking for: "{extended_context}" of the information in the images."""


            responses = self._analysis_model.generate_content(
                [prompt] + image_parts,
                generation_config=self._generation_config,
                safety_settings=self._safety_settings,
                stream=True,
            )

            result = ""
            for response in responses:
                result += response.text

            try:
                return json.loads(result)
            except json.JSONDecodeError as e:
                raise self.AnalysisError(f"Failed to parse analysis response: {str(e)}")

        try:
            return self._retry_with_backoff(_perform_analysis)
        except Exception as e:
            raise self.AnalysisError(f"Image analysis failed after retries: {str(e)}")

    def _generate_explanation(self, analysis: Dict[str, str]) -> Dict[str, Any]:
        """
        Generate educational explanation based on image analysis.
        
        Args:
            analysis: Dictionary containing image analysis results
            
        Returns:
            Dict[str, Any] containing:
            - content: Main explanation text
            - rendered_content: Rendered version of the content (if available)
            - citations: List of citation dictionaries with title and uri
            
        Raises:
            AnalysisError: If explanation generation fails
        """
        def _perform_explanation():
            tools = [Tool.from_google_search_retrieval(
                google_search_retrieval=grounding.GoogleSearchRetrieval()
            )]

            model = GenerativeModel(
                self._model_name_for_grounding,
                tools=tools,
                system_instruction=[self._grounding_system_instruction]
            )

            generation_config = {
                "max_output_tokens": 8192,
                "temperature": 0,
                "top_p": 0.95,
            }

            responses = model.generate_content(
                [json.dumps(analysis) + "Provide a markdown format response."],
                generation_config=generation_config,
                safety_settings=self._safety_settings,
                stream=False,
            )

            result = GenerationResponse.to_dict(responses)
            
            # Initialize return dictionary with default empty values
            ret = {
                "content": "",
                "rendered_content": "",
                "citations": []
            }
            
            try:
                # Safely extract content
                if (result.get('candidates') and 
                    result['candidates'][0].get('content') and 
                    result['candidates'][0]['content'].get('parts')):
                    ret["content"] = result['candidates'][0]['content']['parts'][0].get('text', '')
                
                # Safely extract rendered content
                if (result.get('candidates') and 
                    result['candidates'][0].get('grounding_metadata') and 
                    result['candidates'][0]['grounding_metadata'].get('search_entry_point')):
                    ret["rendered_content"] = result['candidates'][0]['grounding_metadata']['search_entry_point'].get('rendered_content', '')
                
                # Safely extract citations
                if (result.get('candidates') and 
                    result['candidates'][0].get('grounding_metadata') and 
                    result['candidates'][0]['grounding_metadata'].get('grounding_chunks')):
                    
                    grounding_chunks_array = result['candidates'][0]['grounding_metadata']['grounding_chunks']
                    for chunk in grounding_chunks_array:
                        if chunk.get('web'):
                            citation = {
                                "title": chunk['web'].get('title', ''),
                                "uri": chunk['web'].get('uri', '')
                            }
                            # Only add citation if at least one field is non-empty
                            if citation["title"] or citation["uri"]:
                                ret['citations'].append(citation)
            
            except Exception as e:
                logger.warning(f"Error parsing explanation response: {str(e)}")
                # Return the initialized ret dictionary with empty values
            
            logger.info(f"Generated explanation with {len(ret['citations'])} citations")
            return ret

        try:
            return self._retry_with_backoff(_perform_explanation)
        except Exception as e:
            raise self.AnalysisError(f"Failed to generate explanation after retries: {str(e)}")

    def _generate_search_queries(self, image_parts: List[Part], extended_context: Optional[str] = None) -> Dict[str, Union[str, List[str]]]:
        """
        Generate search queries and follow-up questions based on the analyzed images.
        
        Args:
            image_parts: List of image Parts to analyze
            extended_context: Optional additional context or questions from the user
            
        Returns:
            Dict containing:
            - search_query: str
            - youtube_query: str
            - image_query: str
            - followup: List[str]
            - context: str
            
        Raises:
            AnalysisError: If query generation fails
        """
        def _perform_query_generation():
            # Initialize model for search query generation
            model = GenerativeModel(
                self._model_name_for_image_analysis,
                system_instruction=self._search_query_system_instructions
            )

            # Prepare prompt with extended context if provided
            prompt = self._search_query_prompt
            if extended_context:
                prompt = f"""{prompt}\nUser Specifically looking for: "{extended_context}" of the information in the images."""

            # Configure generation parameters for concise output
            generation_config = {
                "max_output_tokens": 1024,
                "temperature": 0.2,
                "top_p": 0.95,
                "response_mime_type": "application/json",
                "response_schema": {
                    "type": "OBJECT",
                    "properties": {
                        "search_query": {"type": "STRING"},
                        "youtube_query": {"type": "STRING"},
                        "image_query": {"type": "STRING"},
                        "followup": {
                            "type": "ARRAY",
                            "items": {"type": "STRING"}
                        },
                        "context": {"type": "STRING"}
                    },
                    "required": ["search_query", "youtube_query", "image_query", "followup", "context"]
                },
            }

            # Generate queries
            responses = model.generate_content(
                [prompt] + image_parts,
                generation_config=generation_config,
                safety_settings=self._safety_settings,
                stream=True,
            )

            result = ""
            for response in responses:
                result += response.text

            try:
                return json.loads(result)
            except json.JSONDecodeError as e:
                raise self.AnalysisError(f"Failed to parse query generation response: {str(e)}")

        try:
            return self._retry_with_backoff(_perform_query_generation)
        except Exception as e:
            raise self.AnalysisError(f"Search query generation failed after retries: {str(e)}")

    def generate_search_queries(
        self,
        image1_bytes: bytes,
        image2_bytes: bytes,
        mime_type1: str = "image/jpeg",
        mime_type2: str = "image/jpeg",
        extended_context: Optional[str] = None
    ) -> Dict[str, Union[str, List[str]]]:
        """
        Generate optimized search queries and follow-up questions based on a pair of images.
        
        This method analyzes the images (focusing primarily on the cropped image) and generates:
        1. Targeted search queries for different platforms
        2. Ultra-concise follow-up questions for further exploration
        The full image is used only for supporting context.
        
        Args:
            image1_bytes: Raw bytes of the first (full) image
            image2_bytes: Raw bytes of the second (cropped) image
            mime_type1: MIME type of the first image
            mime_type2: MIME type of the second image
            extended_context: Optional additional context or questions from the user
            
        Returns:
            Dict containing:
            - search_query: Optimized query for web search (max 10 words)
            - youtube_query: Optimized query for YouTube search (max 10 words)
            - image_query: Optimized query for finding similar educational images (max 10 words)
            - followup: List of 5 ultra-concise follow-up topics (1-2 words each)
            - context: Brief explanation of the generated queries
            
        Raises:
            ConfigurationError: If client is not properly configured
            AnalysisError: If query generation fails
        """
        try:
            # Process images
            image_parts = [
                self._create_image_part(image1_bytes, mime_type1),
                self._create_image_part(image2_bytes, mime_type2)
            ]

            # Generate search queries
            logger.info("Generating search queries and follow-up questions...")
            queries = self._generate_search_queries(image_parts, extended_context)
            logger.info("Search query generation complete")

            return queries

        except Exception as e:
            logger.error(f"Error in generate_search_queries: {str(e)}")
            raise

    def analyze_and_explain(
        self,
        image1_bytes: bytes,
        image2_bytes: bytes,
        mime_type1: str = "image/jpeg",
        mime_type2: str = "image/jpeg",
        extended_context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Analyze a pair of images and generate educational explanation.
        
        This method:
        1. Processes both images into Gemini-compatible format
        2. Performs detailed image analysis
        3. Generates educational explanation based on analysis
        
        Args:
            image1_bytes: Raw bytes of the first (full) image
            image2_bytes: Raw bytes of the second (cropped) image
            mime_type1: MIME type of the first image
            mime_type2: MIME type of the second image
            extended_context: Optional additional context or questions from the user
            
        Returns:
            Dict[str, Any] containing:
            - analysis: Raw analysis results
            - explanation: Generated educational content
            
        Raises:
            ConfigurationError: If client is not properly configured
            AnalysisError: If analysis or explanation generation fails
        """
        try:
            # Process images
            image_parts = [
                self._create_image_part(image1_bytes, mime_type1),
                self._create_image_part(image2_bytes, mime_type2)
            ]

            # Generate analysis
            logger.info("Analyzing images...")
            analysis = self._analyze_images(image_parts, extended_context)
            logger.info("Image analysis complete")

            # Generate explanation
            logger.info("Generating educational explanation...")
            explanation = self._generate_explanation(analysis)
            logger.info("Explanation generation complete")

            return {
                "analysis": analysis,
                "explanation": explanation
            }

        except Exception as e:
            logger.error(f"Error in analyze_and_explain: {str(e)}")
            raise


if __name__ == "__main__":
    try:
        # Example usage
        client = GeminiClient()
        
        # Load test images
        with open("./full2.png", "rb") as f:
            image1_bytes = f.read()
        with open("./roi2.png", "rb") as f:
            image2_bytes = f.read()

        extended_context = "Vectors"
        # Generate search queries
        queries = client.generate_search_queries(image1_bytes, image2_bytes, mime_type1="image/png", mime_type2="image/png", extended_context=extended_context)
        logger.info(json.dumps(queries, indent=2))
            
        # Analyze images and get explanation
        result = client.analyze_and_explain(image1_bytes, image2_bytes, mime_type1="image/png", mime_type2="image/png", extended_context=extended_context)
        
        # Print results
        print("\nAnalysis Results:")
        print(json.dumps(result["analysis"], indent=2))
        
        print("\nEducational Explanation:")
        print(result["explanation"]["content"])
        
    except (GeminiClient.ConfigurationError, GeminiClient.AnalysisError) as e:
        logger.error(f"Error: {str(e)}")
