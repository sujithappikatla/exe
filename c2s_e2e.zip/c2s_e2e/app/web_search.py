from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from dotenv import load_dotenv
import os
import time
import random
from typing import Optional, List, Dict, Union

from logger import logger

class WebSearchClient:
    """
    A client for performing web searches using Google Custom Search API.

    Documentation: https://developers.google.com/custom-search/v1/reference/rest/v1/cse/list
    
    """

    # Class constants
    MAX_RESULTS = 10
    SUPPORTED_LANGUAGES = {
        'ar': 'Arabic', 'bg': 'Bulgarian', 'ca': 'Catalan', 'cs': 'Czech',
        'da': 'Danish', 'de': 'German', 'el': 'Greek', 'en': 'English',
        'es': 'Spanish', 'et': 'Estonian', 'fi': 'Finnish', 'fr': 'French',
        'hr': 'Croatian', 'hu': 'Hungarian', 'id': 'Indonesian', 'is': 'Icelandic',
        'it': 'Italian', 'iw': 'Hebrew', 'ja': 'Japanese', 'ko': 'Korean',
        'lt': 'Lithuanian', 'lv': 'Latvian', 'nl': 'Dutch', 'no': 'Norwegian',
        'pl': 'Polish', 'pt': 'Portuguese', 'ro': 'Romanian', 'ru': 'Russian',
        'sk': 'Slovak', 'sl': 'Slovenian', 'sr': 'Serbian', 'sv': 'Swedish',
        'tr': 'Turkish', 'zh-CN': 'Chinese (Simplified)', 'zh-TW': 'Chinese (Traditional)'
    }

    def __init__(self, env_file_path: Optional[str] = None):
        """
        Initialize the WebSearchClient.
        
        Args:
            env_file_path: Optional path to .env file. If not provided, looks in current directory.
        """
        # Load environment variables
        if env_file_path:
            load_dotenv(env_file_path)
        else:
            load_dotenv()

        # Initialize credentials
        self._api_key = os.getenv("PROJECT_API_KEY")
        self._search_engine_id = os.getenv("SEARCH_ENGINE_ID")

        if not self._api_key or not self._search_engine_id:
            raise self.SearchError("Missing API credentials. Please check PROJECT_API_KEY and SEARCH_ENGINE_ID in .env file")

    class SearchError(Exception):
        """Custom exception for search-related errors."""
        pass

    def _exponential_backoff(self, attempt: int, max_delay: float = 32.0) -> float:
        """
        Calculate delay with exponential backoff and jitter.
        
        Args:
            attempt: The current attempt number
            max_delay: Maximum delay in seconds
            
        Returns:
            The calculated delay in seconds
        """
        delay = min(max_delay, (2 ** attempt) + random.uniform(0, 1))
        return delay

    def search(
        self,
        query: str,
        gl: Optional[str] = None,
        lr: Optional[str] = None,
        num: int = 10,
        safe: bool = True,
        start: int = 1,
        max_retries: int = 3
    ) -> List[Dict[str, str]]:
        """
        Search the web using Google Custom Search API with retry mechanism.
        
        Args:
            query: Search query string
            gl: Geolocation of end user (e.g., 'us', 'uk', 'in'). See https://developers.google.com/custom-search/docs/xml_results#countryCodes
            lr: Language restriction. Format: 'lang_{two-letter code}' (e.g., 'lang_en' for English). See SUPPORTED_LANGUAGES for valid codes.
            num: Number of search results to return (1-10)
            safe: Whether to enable safe search (True for 'active', False for 'off')
            start: Index of first result to return (1-based indexing)
            max_retries: Maximum number of retry attempts
        
        Returns:
            List of dictionaries containing search results with 'title', 'link', and 'snippet' keys
        
        Raises:
            SearchError: If the search fails after all retries
            ValueError: If input parameters are invalid
        """
        # Input validation
        if not query or not isinstance(query, str):
            raise ValueError("Query must be a non-empty string")

        if num < 1 or num > self.MAX_RESULTS:
            raise ValueError(f"Number of results must be between 1 and {self.MAX_RESULTS}")

        if start < 1:
            raise ValueError("Start index must be greater than 0")

        if lr and not lr.startswith('lang_'):
            lr = f'lang_{lr}'
        
        if lr and lr[5:] not in self.SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported language code. Supported codes: {', '.join(self.SUPPORTED_LANGUAGES.keys())}")

        # Prepare search parameters
        search_params = {
            'q': query,
            'cx': self._search_engine_id,
            'num': num,
            'start': start,
            'safe': 'active' if safe else 'off'
        }

        # Add optional parameters if provided
        if gl:
            search_params['gl'] = gl
        if lr:
            search_params['lr'] = lr

        for attempt in range(max_retries):
            try:
                logger.info(f"Attempting search. Attempt {attempt + 1}/{max_retries}")
                service = build("customsearch", "v1", developerKey=self._api_key)
                result = service.cse().list(**search_params).execute()

                if 'items' not in result:
                    logger.warning("No search results found")
                    return []

                ret = []
                for item in result['items']:
                    temp = {
                        "title": item.get('title', ''),
                        "link": item.get('link', ''),
                        "snippet": item.get('snippet', '')
                    }
                    ret.append(temp)
                
                logger.info(f"Successfully retrieved {len(ret)} search results")
                return ret

            except HttpError as e:
                logger.error(f"HTTP error occurred: {str(e)}")
                if e.resp.status in [429, 500, 503]:  # Retry on rate limit or server errors
                    if attempt < max_retries - 1:
                        delay = self._exponential_backoff(attempt)
                        logger.info(f"Retrying in {delay:.2f} seconds...")
                        time.sleep(delay)
                        continue
                raise self.SearchError(f"Search failed: {str(e)}")
                
            except Exception as e:
                logger.error(f"Unexpected error: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                raise self.SearchError(f"Search failed: {str(e)}")

if __name__ == "__main__":
    try:
        # Initialize the client
        client = WebSearchClient()
        
        # Example search with parameters
        results = client.search(
            query="what are solar flares",
            # gl="us",              # Search from US perspective
            # lr="en",              # English results only
            # num=5,                # Get 5 results
            # safe=True,            # Safe search on
            # start=1               # Start from first result
        )
        
        print(f"Found {len(results)} results")
        for result in results:
            print("\nWeb details:")
            for key, value in result.items():
                print(f"{key}: {value}")
    except (WebSearchClient.SearchError, ValueError) as e:
        logger.error(f"Error during search: {str(e)}")
