import os
from google.api_core.client_options import ClientOptions
from google.cloud import discoveryengine
from google.protobuf.json_format import MessageToDict
from dotenv import load_dotenv
import time
import random
from logger import logger
from typing import List, Dict, Optional, Union
from urllib.parse import urlparse
import asyncio


class DiscoveryEngineClient:
    """
    A client for managing and searching with Google Cloud Discovery Engine.
    
    This client provides functionality to:
    - Create and manage data stores
    - Create and manage search engines
    - Add and manage target sites
    - Perform searches with advanced filtering and ranking
    
    Documentation: https://cloud.google.com/python/docs/reference/discoveryengine/latest
    """

    def __init__(self, env_file_path: Optional[str] = None):
        """
        Initialize the DiscoveryEngineClient.
        
        Args:
            env_file_path: Optional path to .env file. If not provided, looks in current directory.
        """
        # Load environment variables
        if env_file_path:
            load_dotenv(env_file_path)
        else:
            load_dotenv()

        # Initialize configuration from environment variables
        self._project_id = os.getenv("PROJECT_ID")
        self._location = os.getenv("DISCOVERY_ENGINE_LOCATION", "global")
        self._engine_id = os.getenv("DISCOVERY_ENGINE_ID")
        self._datastore_id = os.getenv("DISCOVERY_DATASTORE_ID")
        # self._credentials_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")

        # Validate required configuration
        if not all([self._project_id, self._engine_id, self._datastore_id]):
            raise self.ConfigurationError(
                "Missing required environment variables. Please check PROJECT_ID, "
                "DISCOVERY_ENGINE_ID, DISCOVERY_DATASTORE_ID in .env file"
            )

        # Set credentials
        # os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = self._credentials_path

    class ConfigurationError(Exception):
        """Exception raised for configuration-related errors."""
        pass

    def _exponential_backoff(self, attempt: int, max_delay: float = 32.0) -> float:
        """
        Calculate delay with exponential backoff and jitter.
        
        Args:
            attempt: The current attempt number
            max_delay: Maximum delay in seconds
            
        Returns:
            The calculated delay in seconds
        """
        delay = min(max_delay, (2 ** attempt) + random.uniform(0, 1))
        return delay

    def _get_client_options(self) -> Optional[ClientOptions]:
        """
        Get client options for non-global locations.
        
        Returns:
            ClientOptions if location is not global, None otherwise
        """
        return (
            ClientOptions(api_endpoint=f"{self._location}-discoveryengine.googleapis.com")
            if self._location != "global"
            else None
        )

    def _normalize_domain(self, url: str) -> str:
        """
        Extract and normalize domain URI from a URL string.
        
        Args:
            url: URL string (e.g., 'www.samsung.com' or 'https://www.samsung.com/us')
            
        Returns:
            str: Clean domain URI (e.g., 'samsung.com')
            
        Raises:
            ValueError: If URL is invalid or cannot be parsed
        """
        try:
            # Add protocol if not present
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            
            # Parse the URL
            parsed = urlparse(url)
            
            # Get domain, removing 'www.' if present
            domain = parsed.netloc.lower()
            if domain.startswith('www.'):
                domain = domain.replace('www.', '', 1)
                
            return domain
        except Exception as e:
            raise ValueError(f"Invalid URL format: {url}. Error: {str(e)}")

    def check_datastore_exists(self, max_retries: int = 3) -> bool:
        """
        Check if the configured Discovery Engine data store exists.

        Args:
            max_retries: Maximum number of retry attempts

        Returns:
            bool: True if datastore exists, False otherwise
            
        Raises:
            ConfigurationError: If there's an error checking datastore existence
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.DataStoreServiceClient(
                    client_options=self._get_client_options()
                )
                
                name = client.data_store_path(
                    project=self._project_id,
                    location=self._location,
                    data_store=self._datastore_id
                )

                client.get_data_store(name=name)
                return True

            except Exception as e:
                if "not found" in str(e):
                    return False
                    
                logger.error(f"Error checking datastore existence: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error checking datastore existence: {str(e)}")

    def create_datastore(self, max_retries: int = 3) -> str:
        """
        Create a new Discovery Engine data store.

        This method creates a new data store with the following configuration:
        - Display name based on the datastore ID
        - Generic industry vertical
        - Search solution type
        - Public website content configuration

        Args:
            max_retries: Maximum number of retry attempts

        Returns:
            str: The full resource name of the created datastore
            
        Raises:
            ConfigurationError: If there's an error creating the datastore
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.DataStoreServiceClient(
                    client_options=self._get_client_options()
                )

                parent = client.collection_path(
                    project=self._project_id,
                    location=self._location,
                    collection="default_collection",
                )

                data_store = discoveryengine.DataStore(
                    display_name=f"{self._datastore_id}",
                    industry_vertical=discoveryengine.IndustryVertical.GENERIC,
                    solution_types=[discoveryengine.SolutionType.SOLUTION_TYPE_SEARCH],
                    content_config=discoveryengine.DataStore.ContentConfig.PUBLIC_WEBSITE,
                )

                request = discoveryengine.CreateDataStoreRequest(
                    parent=parent,
                    data_store_id=self._datastore_id,
                    data_store=data_store,
                )

                operation = client.create_data_store(request=request)
                logger.info("Creating datastore...")
                
                response = operation.result()
                logger.info(f"Created datastore: {response.name}")
                return response.name

            except Exception as e:
                logger.error(f"Error creating datastore: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error creating datastore: {str(e)}")

    def get_target_sites(self, max_retries: int = 3) -> List[str]:
        """
        Get list of all target sites in the data store.

        Args:
            max_retries: Maximum number of retry attempts

        Returns:
            List[str]: List of target site domain URIs
            
        Raises:
            ConfigurationError: If there's an error retrieving target sites
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.SiteSearchEngineServiceClient()

                site_search_engine = client.site_search_engine_path(
                    project=self._project_id,
                    location=self._location,
                    data_store=self._datastore_id
                )

                request = discoveryengine.ListTargetSitesRequest(
                    parent=site_search_engine
                )

                target_sites = []
                page_result = client.list_target_sites(request=request)

                for target_site in page_result:
                    target_sites.append(target_site.root_domain_uri)

                logger.info(f"Found {len(target_sites)} total sites in Data Store")
                return target_sites

            except Exception as e:
                logger.error(f"Error getting target sites: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error getting target sites: {str(e)}")

    def add_target_sites(self, domains: List[str], max_retries: int = 3) -> None:
        """
        Add new target sites to the data store.

        Args:
            domains: List of domain URIs to add
            max_retries: Maximum number of retry attempts
            
        Raises:
            ConfigurationError: If there's an error adding target sites
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.SiteSearchEngineServiceClient()

                site_search_engine = client.site_search_engine_path(
                    project=self._project_id,
                    location=self._location,
                    data_store=self._datastore_id
                )

                batch_requests = []
                for domain in domains:
                    target_site = discoveryengine.TargetSite(
                        provided_uri_pattern=domain,
                        type_=discoveryengine.TargetSite.Type.INCLUDE,
                        exact_match=False
                    )

                    batch_requests.append(
                        discoveryengine.CreateTargetSiteRequest(
                            parent=site_search_engine,
                            target_site=target_site
                        )
                    )

                if batch_requests:
                    batch_request = discoveryengine.BatchCreateTargetSitesRequest(
                        parent=site_search_engine,
                        requests=batch_requests
                    )

                    operation = client.batch_create_target_sites(batch_request)
                    logger.info(f"Adding {len(batch_requests)} target sites...")
                    
                    response = operation.result()
                    logger.info(f"Successfully added {len(batch_requests)} target sites")
                    return

            except Exception as e:
                logger.error(f"Error adding target sites: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error adding target sites: {str(e)}")

    def check_search_engine_exists(self, max_retries: int = 3) -> bool:
        """
        Check if the configured search engine exists.

        Args:
            max_retries: Maximum number of retry attempts

        Returns:
            bool: True if search engine exists, False otherwise
            
        Raises:
            ConfigurationError: If there's an error checking search engine existence
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.EngineServiceClient(
                    client_options=self._get_client_options()
                )
                
                name = client.engine_path(
                    project=self._project_id,
                    location=self._location,
                    collection="default_collection",
                    engine=self._engine_id
                )

                client.get_engine(name=name)
                return True

            except Exception as e:
                if "does not exist" in str(e):
                    return False
                    
                logger.error(f"Error checking search engine existence: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error checking search engine existence: {str(e)}")

    def create_search_engine(self, max_retries: int = 3) -> str:
        """
        Create a new search engine with enterprise features.

        Creates a search engine with:
        - Enterprise tier capabilities
        - LLM features enabled
        - Generic industry vertical
        - Search solution type

        Args:
            max_retries: Maximum number of retry attempts

        Returns:
            str: The operation name for the create engine request
            
        Raises:
            ConfigurationError: If there's an error creating the search engine
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.EngineServiceClient(
                    client_options=self._get_client_options()
                )

                parent = client.collection_path(
                    project=self._project_id,
                    location=self._location,
                    collection="default_collection",
                )

                engine = discoveryengine.Engine(
                    display_name=self._engine_id,
                    industry_vertical=discoveryengine.IndustryVertical.GENERIC,
                    solution_type=discoveryengine.SolutionType.SOLUTION_TYPE_SEARCH,
                    search_engine_config=discoveryengine.Engine.SearchEngineConfig(
                        search_tier=discoveryengine.SearchTier.SEARCH_TIER_ENTERPRISE,
                        search_add_ons=[
                            discoveryengine.SearchAddOn.SEARCH_ADD_ON_LLM,
                        ],
                    ),
                    data_store_ids=[self._datastore_id],
                )

                request = discoveryengine.CreateEngineRequest(
                    parent=parent,
                    engine=engine,
                    engine_id=self._engine_id,
                )

                operation = client.create_engine(request=request)
                logger.info(f"Creating search engine: {self._engine_id}")
                
                response = operation.result()
                logger.info("Search engine creation complete")
                return operation.operation.name

            except Exception as e:
                logger.error(f"Error creating search engine: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error creating search engine: {str(e)}")

    def search(self, query: str, max_retries: int = 3) -> List[Dict[str, str]]:
        """
        Execute a search query against the Discovery Engine.

        Args:
            query: Search query string
            max_retries: Maximum number of retry attempts

        Returns:
            List[Dict[str, str]]: List of search results with title, link, and snippet
            
        Raises:
            ConfigurationError: If there's an error executing the search
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.SearchServiceClient(
                    client_options=self._get_client_options()
                )

                serving_config = (
                    f"projects/{self._project_id}/locations/{self._location}/"
                    f"collections/default_collection/engines/{self._engine_id}/servingConfigs/default_config"
                )

                request = discoveryengine.SearchRequest(
                    serving_config=serving_config,
                    query=query,
                    page_size=10,
                    query_expansion_spec=discoveryengine.SearchRequest.QueryExpansionSpec(
                        condition=discoveryengine.SearchRequest.QueryExpansionSpec.Condition.AUTO,
                    ),
                    spell_correction_spec=discoveryengine.SearchRequest.SpellCorrectionSpec(
                        mode=discoveryengine.SearchRequest.SpellCorrectionSpec.Mode.AUTO
                    ),
                )

                response = client.search(request)
                search_results = []
                
                for result in response.results:
                    search_results.append({
                        'title': result.document.derived_struct_data.get('title'),
                        'link': result.document.derived_struct_data.get('link'),
                        'snippet': MessageToDict(
                            result.document.derived_struct_data.get('snippets')._pb[0]
                        ).get('snippet')
                    })
                    
                logger.info(f"Found {len(search_results)} search results")
                return search_results

            except Exception as e:
                logger.error(f"Error executing search: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error executing search: {str(e)}")

    async def search_async(self, query: str, max_retries: int = 3) -> List[Dict[str, str]]:
        """
        Asynchronously execute a search query against the Discovery Engine.

        Args:
            query: Search query string
            max_retries: Maximum number of retry attempts

        Returns:
            List[Dict[str, str]]: List of search results with title, link, and snippet
            
        Raises:
            ConfigurationError: If there's an error executing the search
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.SearchServiceClient(
                    client_options=self._get_client_options()
                )

                serving_config = (
                    f"projects/{self._project_id}/locations/{self._location}/"
                    f"collections/default_collection/engines/{self._engine_id}/servingConfigs/default_config"
                )

                request = discoveryengine.SearchRequest(
                    serving_config=serving_config,
                    query=query,
                    page_size=10,
                    query_expansion_spec=discoveryengine.SearchRequest.QueryExpansionSpec(
                        condition=discoveryengine.SearchRequest.QueryExpansionSpec.Condition.AUTO,
                    ),
                    spell_correction_spec=discoveryengine.SearchRequest.SpellCorrectionSpec(
                        mode=discoveryengine.SearchRequest.SpellCorrectionSpec.Mode.AUTO
                    ),
                )

                response = await asyncio.get_event_loop().run_in_executor(
                    None, client.search, request
                )
                
                search_results = []
                for result in response.results:
                    search_results.append({
                        'title': result.document.derived_struct_data.get('title'),
                        'link': result.document.derived_struct_data.get('link'),
                        'snippet': MessageToDict(
                            result.document.derived_struct_data.get('snippets')._pb[0]
                        ).get('snippet')
                    })
                    
                logger.info(f"Found {len(search_results)} search results")
                return search_results

            except Exception as e:
                logger.error(f"Error executing async search: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error executing async search: {str(e)}")

    def rerank_results(
        self, 
        results: List[Dict[str, str]], 
        query: str, 
        top_n: int = 10,
        max_retries: int = 3
    ) -> List[Dict[str, str]]:
        """
        Rerank search results using the Discovery Engine Reranker.

        Args:
            results: List of search results to rerank
            query: Original search query
            top_n: Number of top results to return
            max_retries: Maximum number of retry attempts

        Returns:
            List[Dict[str, str]]: Reranked search results
            
        Raises:
            ConfigurationError: If there's an error reranking the results
        """
        for attempt in range(max_retries):
            try:
                client = discoveryengine.RankServiceClient()

                ranking_config = client.ranking_config_path(
                    project=self._project_id,
                    location=self._location,
                    ranking_config="default_ranking_config"
                )

                records = []
                for i, result in enumerate(results):
                    records.append(
                        discoveryengine.RankingRecord(
                            id=str(i),
                            title=result['title'],
                            content=result['snippet']
                        )
                    )

                request = discoveryengine.RankRequest(
                    ranking_config=ranking_config,
                    model="semantic-ranker-512@latest",
                    top_n=top_n,
                    query=query,
                    records=records
                )

                reranked_results = client.rank(request=request)
                result_ids = [int(result.id) for result in reranked_results.records]
                
                logger.info(f"Successfully reranked {len(result_ids)} results")
                return [results[id] for id in result_ids]

            except Exception as e:
                logger.error(f"Error reranking results: {str(e)}")
                if attempt < max_retries - 1:
                    delay = self._exponential_backoff(attempt)
                    logger.info(f"Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    continue
                    
                raise self.ConfigurationError(f"Error reranking results: {str(e)}")

    def setup_and_search(
        self, 
        query: str, 
        websites: List[str],
        max_retries: int = 3
    ) -> List[Dict[str, str]]:
        """
        Set up the search infrastructure and perform a search across specified websites.

        This method:
        1. Creates datastore if it doesn't exist
        2. Creates search engine if it doesn't exist
        3. Adds new target sites
        4. Performs parallel searches across all sites
        5. Reranks the combined results

        Args:
            query: Search query string
            websites: List of websites to search
            max_retries: Maximum number of retry attempts

        Returns:
            List[Dict[str, str]]: Ranked search results
            
        Raises:
            ConfigurationError: If there's an error in the setup or search process
        """
        try:
            # Setup infrastructure
            if not self.check_datastore_exists():
                self.create_datastore()
            else:
                logger.info(f"Using existing datastore: {self._datastore_id}")

            if not self.check_search_engine_exists():
                self.create_search_engine()
            else:
                logger.info(f"Using existing search engine: {self._engine_id}")
            
            # Process and add new target sites
            normalized_domains = [self._normalize_domain(website) for website in websites]
            existing_sites = self.get_target_sites()
            new_sites = set(normalized_domains) - set(existing_sites)
            
            if new_sites:
                logger.info(f"Adding {len(new_sites)} new target sites")
                self.add_target_sites(list(new_sites))
            else:
                logger.info("No new target sites to add")

            # Perform parallel searches
            async def run_parallel_searches():
                tasks = []
                for domain in normalized_domains:
                    site_query = f"site:{domain} {query}"
                    tasks.append(self.search_async(site_query))
                
                results = await asyncio.gather(*tasks)
                return [item for sublist in results for item in sublist]

            # Execute searches and rerank results
            search_results = asyncio.run(run_parallel_searches())
            return self.rerank_results(search_results, query)

        except Exception as e:
            logger.error(f"Error in setup and search process: {str(e)}")
            raise self.ConfigurationError(f"Error in setup and search process: {str(e)}")

    def setup_and_add_target_sites(
        self, 
        websites: List[str],
        max_retries: int = 3
    ) -> List[str]:
        """
        Set up the search infrastructure and add new target sites.

        This method:
        1. Creates datastore if it doesn't exist
        2. Creates search engine if it doesn't exist
        3. Gets existing target sites
        4. Adds new target sites that don't exist
        5. Returns list of all target sites after addition

        Args:
            websites: List of websites to add as target sites
            max_retries: Maximum number of retry attempts

        Returns:
            List[str]: List of all target sites after addition (both existing and new)
            
        Raises:
            ConfigurationError: If there's an error in the setup or addition process
        """
        try:
            # Setup infrastructure
            if not self.check_datastore_exists():
                self.create_datastore()
                logger.info(f"Created new datastore: {self._datastore_id}")
            else:
                logger.info(f"Using existing datastore: {self._datastore_id}")

            if not self.check_search_engine_exists():
                self.create_search_engine()
                logger.info(f"Created new search engine: {self._engine_id}")
            else:
                logger.info(f"Using existing search engine: {self._engine_id}")
            
            # Process and add new target sites
            normalized_domains = [self._normalize_domain(website) for website in websites]
            existing_sites = self.get_target_sites()
            new_sites = set(normalized_domains) - set(existing_sites)
            
            if new_sites:
                logger.info(f"Adding {len(new_sites)} new target sites")
                self.add_target_sites(list(new_sites))
                logger.info("Successfully added new target sites")
                
                # Get updated list of all sites
                all_sites = self.get_target_sites()
                logger.info(f"Total target sites after addition: {len(all_sites)}")
                return all_sites
            else:
                logger.info("No new target sites to add")
                return existing_sites

        except Exception as e:
            logger.error(f"Error in setup and add target sites process: {str(e)}")
            raise self.ConfigurationError(f"Error in setup and add target sites process: {str(e)}")


if __name__ == "__main__":
    try:
        # Initialize client
        client = DiscoveryEngineClient()
        
        # Example 1: Add target sites
        websites_to_add = ["www.wikipedia.org", "www.nasa.gov", "www.science.org"]
        all_sites = client.setup_and_add_target_sites(websites=websites_to_add)
        print(f"\nTotal target sites: {len(all_sites)}")
        print("Target sites:")
        for site in all_sites:
            print(f"- {site}")
        
        # Example 2: Search across the added websites
        results = client.setup_and_search(
            query="What are solar flares?",
            websites=websites_to_add
        )
        
        # Print search results
        print(f"\nFound {len(results)} results:")
        for result in results:
            print("\nResult details:")
            for key, value in result.items():
                print(f"{key}: {value}")
                
    except DiscoveryEngineClient.ConfigurationError as e:
        logger.error(f"Error: {str(e)}")
