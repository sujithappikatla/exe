package com.example.fs_feasibility

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

class TransparentActivity : ComponentActivity() {
    private val pipParams by lazy {
        PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        window.setBackgroundDrawableResource(android.R.color.transparent)
        
        setContent {
            TransparentBackground {
                SampleText()
            }
        }
    }

    override fun onUserLeaveHint() {
        enterPictureInPictureMode(pipParams)
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    }
}

@Composable
private fun TransparentBackground(
    content: @Composable () -> Unit
) {
    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp
    val screenHeight = configuration.screenHeightDp.dp

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        repeat(3) { index ->
            FloatingElement(
                screenWidth = screenWidth,
                screenHeight = screenHeight,
                initialDelay = index * 500
            )
        }

        content()
    }
}

@Composable
private fun FloatingElement(
    screenWidth: androidx.compose.ui.unit.Dp,
    screenHeight: androidx.compose.ui.unit.Dp,
    initialDelay: Int
) {
    val density = LocalDensity.current
    val maxWidth = with(density) { screenWidth.toPx() }
    val maxHeight = with(density) { screenHeight.toPx() }
    
    val baseSize = 900.dp
    val xPos = remember { Animatable(maxWidth / (2 + Random.nextInt() % 5)) }
    val yPos = remember { Animatable(maxHeight /  (2 + Random.nextInt() % 5)) }
//    val xPos = remember { Animatable(100f) }
//    val yPos = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        delay(initialDelay.toLong())
        opacity.animateTo(1f, tween(1000))

        val _w = (Random.nextInt() / 10 ) / 10F
        val _h = (Random.nextInt() / 10 ) / 10F

        while (true) {
            val targetX = (maxWidth * 0.3f) + (Random.nextFloat() * maxWidth * 0.4f)
            val targetY = (maxHeight * 0.3f) + (Random.nextFloat() * maxHeight * 0.4f)
//            val targetX = 400f
//            val targetY =500f

            launch {
                xPos.animateTo(
                    targetValue = targetX,
                    animationSpec = tween(
                        durationMillis = Random.nextInt(4000, 6000),
                        easing = FastOutSlowInEasing
                    )
                )
            }
            
            launch {
                yPos.animateTo(
                    targetValue = targetY,
                    animationSpec = tween(
                        durationMillis = Random.nextInt(4000, 6000),
                        easing = FastOutSlowInEasing
                    )
                )
            }
            
            delay(Random.nextLong(2000, 3000))
        }
    }

    Box(
        modifier = Modifier
            .offset(
                x = (xPos.value / density.density).dp,
                y = (yPos.value / density.density).dp
            )
            .size(baseSize)
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x44556EA1),  // Very transparent light blue
                        Color(0x33A891F5),  // Very transparent light purple
                        Color(0x00556EA1)   // Fully transparent
                    )
                )
            )
    )
}

@Composable
private fun SampleText() {

    Box(modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center

    )
    {
        Text(
            text = "Sample Text",
            style = TextStyle(
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        )
    }


} 