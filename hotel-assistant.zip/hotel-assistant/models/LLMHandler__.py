from models.ModelBase import ModelBase, SendToClientCallable
from google import genai
from google.genai.types import GenerateContentConfig, HttpOptions, FunctionDeclaration, Schema, Tool, ToolConfig, FunctionCall, Part, FunctionResponse
import asyncio
from storage.StorageManager import StorageManager
from asyncio import Queue
import json 

SYSTEM_INSTRUCTION = """
You are Voice Assistant - EVA.
Always answer user query with few words and keep the response short and concise.
Your response is used to generate audio using TTS Model for the user, so dont use any emojis or special characters.
keep your response under 200-250 words at max.
"""





class LLMHandler():
    def __init__(self):
        self.client = genai.Client(
            vertexai=True,
            project="cloud-learning-443407",
            location="us-central1",
            http_options=HttpOptions(api_version="v1")
        )
        self.model_id = "gemini-2.0-flash-lite"  # Or your chosen model
        self.storage_manager = None
        self.history = []
        self.conversation_history_json = []
        # weather_function = FunctionDeclaration(
        #     name="get_current_weather",
        #     description="Get current weather in a given location",
        #     parameters=Schema(
        #         type="object",
        #         properties={
        #             "location": Schema(type="string", description="City name"),
        #             "unit": Schema(type="string", enum=["celsius", "fahrenheit"])
        #         },
        #         required=["location"]
        #     )
        # )
        # self.tools = [Tool(function_declarations=[weather_function])]
        self.tools = [
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="add_item_to_cart",
                    description="Add a pizza item to the cart with base toppings. If item already exists in cart, returns error message. Only adds new items, does not increase quantity.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to add. Must be exact match from available menu items."
                            ),
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="remove_item_from_cart",
                    description="Remove a specific pizza item completely from the cart based on name.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to remove from cart"
                            ),
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="increase_quantity",
                    description="Increase the quantity of a pizza in the cart by specified amount. If pizza not in cart, adds it with base toppings and specified quantity.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to increase quantity for"
                            ),
                            "quantity": Schema(
                                type="integer", 
                                minimum=1,
                                description="Number to increase quantity by. Must be positive integer. Default is 1 if not specified."
                            )
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="decrease_quantity",
                    description="Decrease the quantity of a pizza in the cart by specified amount. If quantity becomes 0 or negative, item is removed from cart.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to decrease quantity for"
                            ),
                            "quantity": Schema(
                                type="integer", 
                                minimum=1,
                                description="Number to decrease quantity by. Must be positive integer. Default is 1 if not specified."
                            )
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="add_toppings",
                    description="Add toppings to a pizza item. If item not in cart, adds it with base toppings plus specified toppings. If item in cart, adds new toppings to existing ones (no duplicates).",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to add toppings to"
                            ),
                            "toppings": Schema(
                                type="string", 
                                description="Comma-separated list of toppings to add. Available toppings: Extra Cheese, Pepperoni, Mushrooms, Bell Peppers, Onions, Olives, Tomatoes, Fresh Basil, Oregano, Ham, Bacon, Sausage, Pineapple, Jalapeños, Hot Peppers, Spinach, Sun-dried Tomatoes, Feta Cheese, Red Onions, Grilled Chicken"
                            )
                        },
                        required=["item_name", "toppings"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="remove_toppings",
                    description="Remove specified toppings from a pizza item in the cart. If topping doesn't exist, it's ignored. If all toppings removed, base toppings are restored.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to remove toppings from"
                            ),
                            "toppings": Schema(
                                type="string", 
                                description="Comma-separated list of toppings to remove. Case-insensitive matching."
                            )
                        },
                        required=["item_name", "toppings"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="get_cart_contents",
                    description="Get current cart contents with detailed breakdown including items, quantities, prices, GST, delivery fee, and total amount.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="clear_cart",
                    description="Remove all items from the cart completely. This action cannot be undone.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="get_menu_items",
                    description="Get list of all available pizza items with prices and base toppings information.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="checkout",
                    description="Process the order and complete checkout. Calculates final total with GST (18%) and delivery fee (₹40). Clears cart after successful checkout.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ])
        ]
       

    def set_storage_manager(self, storage_manager: StorageManager):
        self.storage_manager = storage_manager
        self.conversation_history_json = self.storage_manager.get_conversation_history()
        for message in self.conversation_history_json:
            self.history.append(genai.types.Content(
                role=message["role"],
                parts=[genai.types.Part(text=message["content"])]
            ))

    async def process(
            self, 
            input_text: str, 
            send_to_client: SendToClientCallable,
            llm_output_queue: Queue
        ):

        
        try:
            self.streaming_cancel_event = asyncio.Event()
            await send_to_client("LLM:START", {
                "text": "Starting LLM"
            })
            print(f"Input Text: {input_text}")
            input_text_json = json.loads(input_text) 
            if input_text_json.get("text") != "":
                input_text = input_text_json.get("text")
            if input_text_json.get("fn_response") is not None:
                function_call_response = input_text_json.get("fn_response")
                function_response_parts = []
                for function_call in function_call_response:

                    function_response_parts.append(genai.types.Part(
                        function_response=FunctionResponse(
                            name=function_call.get("fn_name"),
                            response={"result":function_call.get("fn_response")}
                        )
                    ))
                    
                    self.conversation_history_json.append({
                        "role": "function_response",
                        "name": function_call.get("fn_name"),
                        "content": function_call.get("fn_response")
                    })
                print(f"Function Response Parts: {function_response_parts}")
                if len(function_response_parts) > 0:
                    self.history.append(genai.types.Content(
                        role="function",
                        parts=function_response_parts
                    ))
            else:
                self.conversation_history_json.append({
                    "role": "user",
                    "content": input_text
                })
                

                self.history.append(genai.types.Content(
                    role="user",
                    parts=[genai.types.Part(text=input_text)]
                ))
            print(f"History: {self.history}")
            self.storage_manager.set_conversation_history(self.conversation_history_json)

            self.streaming_responses = await self.client.aio.models.generate_content_stream(
                model=self.model_id,
                contents=self.history,
                config=GenerateContentConfig(
                    response_modalities=["TEXT"],
                    system_instruction=SYSTEM_INSTRUCTION,
                    tools=self.tools,
                ),
                
            )

            full_llm_response = ""
            function_call_response = []
            async for chunk in self.streaming_responses:
                if chunk.candidates:
                    for candidate in chunk.candidates:
                        if candidate.content and candidate.content.parts:
                            print(f"Candidate: {candidate.content.parts}")
                            for part in candidate.content.parts:

                                if isinstance(part, Part):
                                    if part.text:
                                        if self.streaming_cancel_event.is_set():
                                            break
                                        await send_to_client("LLM:CHUNK", {
                                            "text": chunk.text
                                        })
                                        full_llm_response += chunk.text
                                        llm_output_queue.put_nowait(chunk.text)
                                    elif part.function_call:
                                        print(f"Function Call: {part.function_call}")
                                        # await send_to_client("LLM:FUNCTION_CALL", {
                                        #     "function_name": part.function_call.name,
                                        #     "arguments": part.function_call.args,
                                        #     "call_id":part.function_call.id
                                        # })
                                        function_call_response.append({
                                            "function_name": part.function_call.name,
                                            "arguments": part.function_call.args,
                                            "call_id":part.function_call.id
                                        })
    
                # if chunk.text:
                #     print(chunk.text)
                #     # print(chunk.text, end="", flush=True)
                #     if self.streaming_cancel_event.is_set():
                #         break
                #     await send_to_client("LLM:CHUNK", {
                #         "text": chunk.text
                #     })
                #     full_llm_response += chunk.text
                #     llm_output_queue.put_nowait(chunk.text)
            
            if len(function_call_response) > 0:
                await send_to_client("LLM:FUNCTION_CALL", {
                    "function_calls": function_call_response
                })
            llm_output_queue.put_nowait(None)

            if not self.streaming_cancel_event.is_set():
                if full_llm_response!= "":
                    self.conversation_history_json.append({
                        "role": "model",
                        "content": full_llm_response
                    })
                    self.history.append(genai.types.Content(
                        role="model",
                        parts=[genai.types.Part(text=full_llm_response)]
                    ))
                function_call_parts = []
                for function_call in function_call_response:
                    self.conversation_history_json.append({
                        "role": "function",
                        "name": function_call.get("function_name"),
                        "content": json.dumps(function_call.get("arguments"))
                    })
                    function_call_parts.append(genai.types.Part(function_call=FunctionCall(
                            name=function_call.get("function_name"),
                            args=function_call.get("arguments"),
                            id=function_call.get("call_id")
                        ))
                    )
                print(f"Function Call Parts: {function_call_parts}")
                if len(function_call_parts) > 0:
                    self.history.append(genai.types.Content(
                        role="function",
                        parts=function_call_parts
                    ))
                self.storage_manager.set_conversation_history(self.conversation_history_json)

                await send_to_client("LLM:DONE", {
                    "text": "LLM Done"
                })
        except Exception as e:
            print(f"[ERROR][LLMHandler][process] {e}")



    async def stop(self):
        try:
            self.streaming_cancel_event.set()
        except Exception as e:
            print(f"[ERROR][LLMHandler][stop] {e}")