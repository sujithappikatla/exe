from models.ModelBase import ModelBase, SendToClientCallable
from typing import AsyncGenerator, Union
from google.cloud import texttospeech
import asyncio
import wave
from asyncio import Queue

class TTSHandler():
    def __init__(self):
        self.language = "en-US"
        self.voice = "en-US-Chirp3-HD-Leda"

        self.client = texttospeech.TextToSpeechAsyncClient()
        self.streaming_config = texttospeech.StreamingSynthesizeConfig(
            voice=texttospeech.VoiceSelectionParams(
                name=f"{self.voice}",
                language_code=self.language,
            ),
            streaming_audio_config=texttospeech.StreamingAudioConfig(
                audio_encoding=texttospeech.AudioEncoding.PCM,
                sample_rate_hertz=16000
            )
        )

        self.config_request = texttospeech.StreamingSynthesizeRequest(
            streaming_config=self.streaming_config
        )

    async def process(
            self, 
            input_stream: Queue, 
            send_to_client: SendToClientCallable
    ) -> str:
        try:
            await send_to_client("TTS:START", {
                "text": "Starting TTS"
            })

            async def _request_async_generator():
                yield self.config_request
                while True:
                    try:
                        text = input_stream.get_nowait()
                        if text is None:
                            break
                        yield texttospeech.StreamingSynthesizeRequest(
                            input=texttospeech.StreamingSynthesisInput(text=text)
                        )
                    except asyncio.QueueEmpty:
                        await asyncio.sleep(0.01)
                        continue
                    except Exception as e:
                        print(f"[ERROR][TTSHandler][process] {e}")
                        break
                    

            # audio_buffer = b""

            self.streaming_responses = await self.client.streaming_synthesize(_request_async_generator())

            async for response in self.streaming_responses:
                if not response.audio_content:
                    continue
                await send_to_client("TTS:CHUNK", {
                    "audio_content": response.audio_content
                })
                # audio_buffer += response.audio_content
            
            # with wave.open("tts_response.wav", "wb") as f:
            #     f.setnchannels(1)
            #     f.setsampwidth(2)
            #     f.setframerate(16000)
            #     f.writeframes(audio_buffer)

            await send_to_client("TTS:DONE", {
                "text": "TTS Done"
            })
        except Exception as e:
            print(f"[ERROR][TTSHandler][process] {e}")

    async def stop(self):
        try:
            if self.streaming_responses:
                self.streaming_responses.cancel()
        except Exception as e:
            print(f"[ERROR][TTSHandler][stop] {e}")