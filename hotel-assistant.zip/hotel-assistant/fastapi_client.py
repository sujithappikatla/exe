import asyncio
import websockets
import pyaudio
from datetime import datetime
import uuid
import base64
import json
import time

baseline_time = time.time()

async def record_audio():
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=1024)
    while True:
        await asyncio.sleep(0.01)
        data = stream.read(1024)
        yield data

async def read_websocket(websocket: websockets.WebSocketClientProtocol):
    while True:
        msg = await websocket.recv()
        msg = json.loads(msg)
        print(f"[{time.time() - baseline_time:.2f}] {msg['type']}")



async def main():
    async with websockets.connect("ws://localhost:8000/service") as websocket:
        task = asyncio.create_task(read_websocket(websocket))
        print(f"[{time.time() - baseline_time:.2f}] START_SESSION")
        await websocket.send(json.dumps({
            "message_id": str(uuid.uuid4()),
            "session_id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "type": "START_SESSION",
            "data": {
                "input_type": "audio",
                "output_type": "audio"
            }
        }))
        print(f"[{time.time() - baseline_time:.2f}] AUDIO_STREAM_START")
        await websocket.send(json.dumps(
            {
                "message_id": str(uuid.uuid4()),
                "session_id": str(uuid.uuid4()),
                "timestamp": datetime.now().isoformat(),
                "type": "AUDIO_STREAM_START",
                "data": {}
            }
        ))

        start_time = datetime.now()
        async for chunk in record_audio():
            if (datetime.now() - start_time).total_seconds() > 10:
                break
            await websocket.send(json.dumps(
                {
                    "message_id": str(uuid.uuid4()),
                    "session_id": str(uuid.uuid4()),
                    "timestamp": datetime.now().isoformat(),
                    "type": "AUDIO_STREAM_CHUNK",
                    "data": {
                        "audio_content": base64.b64encode(chunk).decode("utf-8")
                    }
                }
            ))  
        print(f"[{time.time() - baseline_time:.2f}] AUDIO_STREAM_CHUNK")
        await websocket.send(json.dumps(
            {
                "message_id": str(uuid.uuid4()),
                "session_id": str(uuid.uuid4()),
                "timestamp": datetime.now().isoformat(),
                "type": "AUDIO_STREAM_END",
                "data": {}
            }
        ))
        print(f"[{time.time() - baseline_time:.2f}] AUDIO_STREAM_END")
        await task

asyncio.run(main())