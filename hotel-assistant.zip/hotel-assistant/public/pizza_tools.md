
```
self.tools = [
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="add_item_to_cart",
                    description="Add a pizza item to the cart with base toppings. If item already exists in cart, returns error message. Only adds new items, does not increase quantity.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to add. Must be exact match from available menu items."
                            ),
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="remove_item_from_cart",
                    description="Remove a specific pizza item completely from the cart based on name.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to remove from cart"
                            ),
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="increase_quantity",
                    description="Increase the quantity of a pizza in the cart by specified amount. If pizza not in cart, adds it with base toppings and specified quantity.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to increase quantity for"
                            ),
                            "quantity": Schema(
                                type="integer", 
                                minimum=1,
                                description="Number to increase quantity by. Must be positive integer. Default is 1 if not specified."
                            )
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="decrease_quantity",
                    description="Decrease the quantity of a pizza in the cart by specified amount. If quantity becomes 0 or negative, item is removed from cart.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to decrease quantity for"
                            ),
                            "quantity": Schema(
                                type="integer", 
                                minimum=1,
                                description="Number to decrease quantity by. Must be positive integer. Default is 1 if not specified."
                            )
                        },
                        required=["item_name"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="add_toppings",
                    description="Add toppings to a pizza item. If item not in cart, adds it with base toppings plus specified toppings. If item in cart, adds new toppings to existing ones (no duplicates).",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to add toppings to"
                            ),
                            "toppings": Schema(
                                type="string", 
                                description="Comma-separated list of toppings to add. Available toppings: Extra Cheese, Pepperoni, Mushrooms, Bell Peppers, Onions, Olives, Tomatoes, Fresh Basil, Oregano, Ham, Bacon, Sausage, Pineapple, Jalapeños, Hot Peppers, Spinach, Sun-dried Tomatoes, Feta Cheese, Red Onions, Grilled Chicken"
                            )
                        },
                        required=["item_name", "toppings"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="remove_toppings",
                    description="Remove specified toppings from a pizza item in the cart. If topping doesn't exist, it's ignored. If all toppings removed, base toppings are restored.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "item_name": Schema(
                                type="string", 
                                enum=["Margherita Classic", "Pepperoni Supreme", "BBQ Chicken", "Veggie Delight"],
                                description="Name of the pizza to remove toppings from"
                            ),
                            "toppings": Schema(
                                type="string", 
                                description="Comma-separated list of toppings to remove. Case-insensitive matching."
                            )
                        },
                        required=["item_name", "toppings"]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="get_cart_contents",
                    description="Get current cart contents with detailed breakdown including items, quantities, prices, GST, delivery fee, and total amount.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="clear_cart",
                    description="Remove all items from the cart completely. This action cannot be undone.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="get_menu_items",
                    description="Get list of all available pizza items with prices and base toppings information.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ]),

            Tool(function_declarations=[
                FunctionDeclaration(
                    name="checkout",
                    description="Process the order and complete checkout. Calculates final total with GST (18%) and delivery fee (₹40). Clears cart after successful checkout.",
                    parameters=Schema(
                        type="object",
                        properties={},
                        required=[]
                    )
                )
            ])
        ]


```