import json
from storage.StorageBase import StorageBase

class JSONStorage(StorageBase):
    def __init__(self, session_id: str):
        self.file_path = "jsondb.json"
        self.session_id = session_id

    def get_conversation_history(self):
        try:
            with open(self.file_path, 'r') as f:
                data = json.load(f)
                if self.session_id in data:
                    return data[self.session_id]
                else:
                    return []
        except FileNotFoundError:
            return []
        except json.JSONDecodeError:
            return []

    def set_conversation_history(self, history: list):
        try:
            with open(self.file_path, 'r') as f:
                data = json.load(f)
            data[self.session_id] = history
            with open(self.file_path, 'w') as f:
                json.dump(data, f, indent=4)
        except FileNotFoundError:
            with open(self.file_path, 'w') as f:
                json.dump({self.session_id: history}, f, indent=4)