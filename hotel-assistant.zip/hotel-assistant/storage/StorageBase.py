from abc import ABC, abstractmethod

class StorageBase(ABC):
    @abstractmethod
    def __init__(self, session_id: str):
        self.session_id = session_id

    @abstractmethod
    def get_conversation_history(self):
        pass

    @abstractmethod
    def set_conversation_history(self, history: list):
        pass

