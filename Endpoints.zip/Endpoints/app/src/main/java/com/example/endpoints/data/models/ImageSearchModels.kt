package com.example.endpoints.data.models

data class ImageSearchRequest(
    val query: String,
    val gl: String? = null,
    val lr: String? = null,
    val num: Int? = null,
    val safe: Boolean = true,
    val start: Int? = null,
    val image_size: ImageSize? = null,
    val image_type: ImageType? = null,
    val image_color: ImageColor? = null
)

data class ImageSearchResult(
    val title: String,
    val image_url: String,
    val context_url: String,
    val height: Int,
    val width: Int
)

data class ImageSearchResponse(
    val success: Boolean,
    val data: List<ImageSearchResult>? = null,
    val error: String? = null,
    val status_code: Int
)

enum class ImageSize {
    HUGE, ICON, LARGE, MEDIUM, SMALL, XLARGE, XXLARGE
}

enum class ImageType {
    CLIPART, FACE, LINEART, STOCK, PHOTO, ANIMATED
}

enum class ImageColor {
    COLOR, GRAY, MONO, TRANS
} 