package com.example.endpoints

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.endpoints.data.models.ImageSearchResult
import com.example.endpoints.data.models.VideoSearchResult
import com.example.endpoints.data.repository.SearchRepository
import com.example.endpoints.di.NetworkModule
import com.example.endpoints.ui.theme.EndpointsTheme
import com.example.endpoints.ui.viewmodel.SearchResult
import com.example.endpoints.ui.viewmodel.SearchViewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.util.Base64
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val repository = SearchRepository(NetworkModule.apiService)
        
        setContent {
            EndpointsTheme {
                SearchScreen(repository)
            }
        }
    }
}

enum class SearchType {
    WEB, IMAGE, VIDEO, DISCOVERY, GEMINI
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(repository: SearchRepository) {
    val viewModel = viewModel { SearchViewModel(repository) }
    val uiState by viewModel.uiState.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedSearchType by remember { mutableStateOf(SearchType.WEB) }
    var showAddWebsitesDialog by remember { mutableStateOf(false) }
    var websiteInput by remember { mutableStateOf("") }
    val managedWebsites by viewModel.managedWebsites.collectAsState()
    var selectedWebsites by remember { mutableStateOf(emptySet<String>()) }
    var fullImage by remember { mutableStateOf<Uri?>(null) }
    var roiImage by remember { mutableStateOf<Uri?>(null) }
    var grade by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var contextInfo by remember { mutableStateOf("") }

    val context = LocalContext.current

    val fullImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        fullImage = uri
    }

    val roiImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        roiImage = uri
    }

    if (showAddWebsitesDialog) {
        AlertDialog(
            onDismissRequest = { showAddWebsitesDialog = false },
            title = { Text("Add Websites") },
            text = {
                TextField(
                    value = websiteInput,
                    onValueChange = { websiteInput = it },
                    label = { Text("Enter websites (comma-separated)") }
                )
            },
            confirmButton = {
                Button(onClick = {
                    val websites = websiteInput.split(",").map { it.trim() }
                    viewModel.addWebsites(websites)
                    showAddWebsitesDialog = false
                    websiteInput = ""
                }) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddWebsitesDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Search Type Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SearchType.values().forEach { searchType ->
                        FilterChip(
                            selected = selectedSearchType == searchType,
                            onClick = { 
                                selectedSearchType = searchType
                                if (searchType != SearchType.DISCOVERY) {
                                    selectedWebsites = emptySet()
                                }
                            },
                            label = { Text(searchType.name) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Gemini Input Fields
                if (selectedSearchType == SearchType.GEMINI) {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Image Selection
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(100.dp)
                                    .padding(4.dp)
                                    .border(1.dp, Color.Gray)
                                    .clickable { fullImageLauncher.launch("image/*") },
                                contentAlignment = Alignment.Center
                            ) {
                                if (fullImage != null) {
                                    AsyncImage(
                                        model = fullImage,
                                        contentDescription = "Full Image",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(Icons.Default.Add, "Select Full Image")
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(100.dp)
                                    .padding(4.dp)
                                    .border(1.dp, Color.Gray)
                                    .clickable { roiImageLauncher.launch("image/*") },
                                contentAlignment = Alignment.Center
                            ) {
                                if (roiImage != null) {
                                    AsyncImage(
                                        model = roiImage,
                                        contentDescription = "ROI Image",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(Icons.Default.Add, "Select ROI Image")
                                }
                            }
                        }

                        // Optional Fields
                        TextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("Subject (Optional)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )

                        TextField(
                            value = grade,
                            onValueChange = { grade = it },
                            label = { Text("Grade (Optional)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )

                        TextField(
                            value = contextInfo,
                            onValueChange = { contextInfo = it },
                            label = { Text("Context (Optional)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )

                        // Analyze Button
                        Button(
                            onClick = {
                                fullImage?.let { full ->
                                    roiImage?.let { roi ->
                                        val fullImageBase64 = context.contentResolver
                                            .openInputStream(full)?.use { 
                                                Base64.encodeToString(it.readBytes(), Base64.DEFAULT)
                                            } ?: ""
                                        val roiImageBase64 = context.contentResolver
                                            .openInputStream(roi)?.use {
                                                Base64.encodeToString(it.readBytes(), Base64.DEFAULT)
                                            } ?: ""
                                        
                                        viewModel.analyzeWithGemini(
                                            fullImageBase64,
                                            roiImageBase64,
                                            grade,
                                            subject,
                                            contextInfo
                                        )
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            enabled = fullImage != null && roiImage != null
                        ) {
                            Text("Analyze Images")
                        }
                    }
                }

                // Website Selection for Discovery Search
                if (selectedSearchType == SearchType.DISCOVERY) {
                    Text(
                        text = "Select websites to search from:",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        maxItemsInEachRow = 3
                    ) {
                        managedWebsites.forEach { website ->
                            FilterChip(
                                selected = website in selectedWebsites,
                                onClick = {
                                    selectedWebsites = if (website in selectedWebsites) {
                                        selectedWebsites - website
                                    } else {
                                        selectedWebsites + website
                                    }
                                },
                                label = { Text(website) },
                                modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search Bar
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Search") },
                    trailingIcon = {
                        Button(
                            onClick = {
                                when (selectedSearchType) {
                                    SearchType.WEB -> viewModel.performWebSearch(searchQuery)
                                    SearchType.IMAGE -> viewModel.performImageSearch(searchQuery)
                                    SearchType.VIDEO -> viewModel.performVideoSearch(searchQuery)
                                    SearchType.DISCOVERY -> {
                                        if (selectedWebsites.isNotEmpty()) {
                                            viewModel.performDiscoverySearch(
                                                searchQuery,
                                                selectedWebsites.toList()
                                            )
                                        }
                                    }
                                    SearchType.GEMINI -> { } // Remove this case as we handle it separately
                                }
                            },
                            enabled = when (selectedSearchType) {
                                SearchType.DISCOVERY -> selectedWebsites.isNotEmpty()
                                SearchType.GEMINI -> false // Hide button for GEMINI
                                else -> true
                            }
                        ) {
                            Text("Search")
                        }
                    },
                    enabled = selectedSearchType != SearchType.GEMINI // Disable search field for GEMINI
                )
            }
        },
        floatingActionButton = {
            if (selectedSearchType == SearchType.DISCOVERY) {
                FloatingActionButton(onClick = { showAddWebsitesDialog = true }) {
                    Icon(Icons.Default.Add, "Add websites")
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            when {
                uiState.isLoading -> CircularProgressIndicator()
                uiState.error != null -> Text("Error: ${uiState.error}")
                else -> {
                    LazyColumn {
                        uiState.searchResults?.let { searchResults ->
                            item {
                                when (searchResults) {
                                    is SearchResult.Web -> WebSearchResults(searchResults)
                                    is SearchResult.Image -> ImageSearchResults(searchResults)
                                    is SearchResult.Video -> VideoSearchResults(searchResults)
                                    is SearchResult.Discovery -> WebSearchResults(SearchResult.Web(searchResults.results))
                                    is SearchResult.GeminiAnalysis -> GeminiAnalysisResults(searchResults)
                                    is SearchResult.GeminiExplanation -> {} // Handle in next section
                                }
                            }
                        }
                        
                        uiState.explanationResults?.let { explanation ->
                            item {
                                GeminiExplanationResults(explanation)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WebSearchResults(results: SearchResult.Web) {
    Column {
        results.results.forEach { result ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(text = result.title, style = MaterialTheme.typography.titleMedium)
                    Text(text = result.snippet, style = MaterialTheme.typography.bodyMedium)
                    Text(text = result.link, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun ImageSearchResults(results: SearchResult.Image) {
    Column {
        results.results.forEach { result ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(result.image_url)
                            .crossfade(true)
                            .build(),
                        contentDescription = result.title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentScale = ContentScale.Crop
                    )
                    Text(text = result.title, style = MaterialTheme.typography.titleSmall)
                }
            }
        }
    }
}

@Composable
fun VideoSearchResults(results: SearchResult.Video) {
    Column {
        results.results.forEach { result ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(result.thumbnail_url)
                            .crossfade(true)
                            .build(),
                        contentDescription = result.title,
                        modifier = Modifier
                            .width(120.dp)
                            .height(90.dp),
                        contentScale = ContentScale.Crop
                    )
                    Column(
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .weight(1f)
                    ) {
                        Text(text = result.title, style = MaterialTheme.typography.titleSmall)
                        Text(text = result.channel_title, style = MaterialTheme.typography.bodySmall)
                        Text(text = result.duration, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GeminiAnalysisResults(results: SearchResult.GeminiAnalysis) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Analysis Results",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            // Search Query Section
            Text(
                text = "Generated Search Query:",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Text(
                    text = results.searchQuery,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(16.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Quick Follow-up Queries Section
            Text(
                text = "Quick Follow-up Queries:",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                maxItemsInEachRow = 3
            ) {
                results.quickFollowups.forEach { query ->
                    AssistChip(
                        onClick = { /* Handle click if needed */ },
                        label = { Text(query) },
                        modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Suggested Queries Section
            Text(
                text = "Suggested Queries:",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                maxItemsInEachRow = 3
            ) {
                results.suggestedQueries.forEach { query ->
                    SuggestionChip(
                        onClick = { /* Handle click if needed */ },
                        label = { Text(query) },
                        modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun GeminiExplanationResults(results: SearchResult.GeminiExplanation) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Explanation",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            Text(
                text = results.content,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            if (results.citations.isNotEmpty()) {
                Text(
                    text = "Citations:",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                results.citations.forEach { citation ->
                    Text(
                        text = "• ${citation.title}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = citation.uri,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}