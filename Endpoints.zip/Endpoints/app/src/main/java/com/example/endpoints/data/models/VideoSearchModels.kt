package com.example.endpoints.data.models

data class VideoSearchRequest(
    val query: String,
    val language: String? = null,
    val region_code: String? = null,
    val max_results: Int? = null,
    val order: VideoOrder? = null,
    val duration: VideoDuration? = null,
    val definition: VideoDefinition? = null,
    val safe_search: SafeSearch? = null
)

data class VideoSearchResult(
    val title: String,
    val thumbnail_url: String,
    val channel_title: String,
    val duration: String,
    val url: String
)

data class VideoSearchResponse(
    val success: Boolean,
    val data: List<VideoSearchResult>? = null,
    val error: String? = null,
    val status_code: Int
)

enum class VideoOrder {
    DATE, RATING, RELEVANCE, TITLE, VIEW_COUNT
}

enum class VideoDuration {
    SHORT, MEDIUM, LONG
}

enum class VideoDefinition {
    HIGH, STANDARD
}

enum class SafeSearch {
    NONE, MODERATE, STRICT
} 