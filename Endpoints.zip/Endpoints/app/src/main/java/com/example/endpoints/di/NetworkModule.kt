package com.example.endpoints.di

import com.example.endpoints.data.api.ApiService
import com.example.endpoints.data.api.MockApiService
import com.example.endpoints.data.api.SearchApi
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {
    private const val BASE_URL = "https://c2s-endpoint-server-305533803718.us-central1.run.app"
    private const val USE_MOCK = false  // Toggle this to switch between mock and real implementation

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val apiService: ApiService = if (USE_MOCK) {
        MockApiService()
    } else {
        retrofit.create(SearchApi::class.java)
    }
} 