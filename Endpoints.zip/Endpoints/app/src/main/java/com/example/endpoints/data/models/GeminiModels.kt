package com.example.endpoints.data.models

data class ExtendedContext(
    val grade: String,
    val subject: String,
    val context: String
)

data class GeminiAnalyzeRequest(
    val full_image: String,
    val roi_image: String,
    val mime_type1: String,
    val mime_type2: String,
    val extended_context: ExtendedContext
)

data class GeminiAnalyzeResponse(
    val success: Boolean,
    val data: AnalysisData? = null,
    val error: String? = null,
    val status_code: Int
)

data class AnalysisData(
    val search_query: String,
    val quick_followup_queries: List<String>,
    val suggested_queries: List<String>,
    val for_next_step: String
)

data class GeminiExplainRequest(
    val analysis: String
)

data class GeminiExplainResponse(
    val success: Boolean,
    val data: ExplanationData? = null,
    val error: String? = null,
    val status_code: Int
)

data class ExplanationData(
    val content: String,
    val rendered_content: String,
    val citations: List<Citation>
)

data class Citation(
    val title: String,
    val uri: String
) 