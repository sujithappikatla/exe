package com.example.endpoints.data.repository

import com.example.endpoints.data.api.ApiService
import com.example.endpoints.data.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.IOException
import kotlinx.coroutines.flow.FlowCollector
import retrofit2.Response

sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val exception: Exception) : Result<Nothing>()
    object Loading : Result<Nothing>()
}

class SearchRepository(
    private val api: ApiService,
    private val apiToken: String = "YOUR_API_TOKEN"
) {
    fun performWebSearch(query: String, gl: String? = null, lr: String? = null, num: Int? = null): Flow<Result<WebSearchResponse>> = flow {
        emit(Result.Loading)
        try {
            val request = WebSearchRequest(query, gl, lr, num)
            val response = api.performWebSearch("Bearer $apiToken", request)
            handleResponse<WebSearchResponse>(response)
        } catch (e: Exception) {
            handleException<WebSearchResponse>(e)
        }
    }

    fun performImageSearch(
        query: String,
        imageSize: ImageSize? = null,
        imageType: ImageType? = null,
        imageColor: ImageColor? = null,
        num: Int? = null
    ): Flow<Result<ImageSearchResponse>> = flow {
        emit(Result.Loading)
        try {
            val request = ImageSearchRequest(
                query = query,
                image_size = imageSize,
                image_type = imageType,
                image_color = imageColor,
                num = num
            )
            val response = api.performImageSearch("Bearer $apiToken", request)
            handleResponse<ImageSearchResponse>(response)
        } catch (e: Exception) {
            handleException<ImageSearchResponse>(e)
        }
    }

    fun performVideoSearch(
        query: String,
        language: String? = null,
        regionCode: String? = null,
        maxResults: Int? = null,
        order: VideoOrder? = null,
        duration: VideoDuration? = null,
        definition: VideoDefinition? = null
    ): Flow<Result<VideoSearchResponse>> = flow {
        emit(Result.Loading)
        try {
            val request = VideoSearchRequest(
                query = query,
                language = language,
                region_code = regionCode,
                max_results = maxResults,
                order = order,
                duration = duration,
                definition = definition
            )
            val response = api.performVideoSearch("Bearer $apiToken", request)
            handleResponse<VideoSearchResponse>(response)
        } catch (e: Exception) {
            handleException<VideoSearchResponse>(e)
        }
    }

    fun addDiscoverySites(websites: List<String>): Flow<Result<AddSitesResponse>> = flow {
        emit(Result.Loading)
        try {
            val request = AddSitesRequest(websites)
            val response = api.addDiscoverySites("Bearer $apiToken", request)
            handleResponse<AddSitesResponse>(response)
        } catch (e: Exception) {
            handleException<AddSitesResponse>(e)
        }
    }

    fun performDiscoverySearch(
        query: String,
        websites: List<String>
    ): Flow<Result<DiscoverySearchResponse>> = flow {
        emit(Result.Loading)
        try {
            val request = DiscoverySearchRequest(query, websites)
            val response = api.performDiscoverySearch("Bearer $apiToken", request)
            handleResponse<DiscoverySearchResponse>(response)
        } catch (e: Exception) {
            handleException<DiscoverySearchResponse>(e)
        }
    }

    fun analyzeWithGemini(
        fullImage: String,
        roiImage: String,
        mimeType1: String = "image/jpeg",
        mimeType2: String = "image/jpeg",
        context: ExtendedContext
    ): Flow<Result<GeminiAnalyzeResponse>> = flow {
        emit(Result.Loading)
        try {
            val request = GeminiAnalyzeRequest(
                full_image = fullImage,
                roi_image = roiImage,
                mime_type1 = mimeType1,
                mime_type2 = mimeType2,
                extended_context = context
            )
            val response = api.analyzeWithGemini("Bearer $apiToken", request)
            handleResponse<GeminiAnalyzeResponse>(response)
        } catch (e: Exception) {
            handleException<GeminiAnalyzeResponse>(e)
        }
    }

    fun explainWithGemini(analysis: String): Flow<Result<GeminiExplainResponse>> = flow {
        emit(Result.Loading)
        try {
            val request = GeminiExplainRequest(analysis)
            val response = api.explainWithGemini("Bearer $apiToken", request)
            handleResponse<GeminiExplainResponse>(response)
        } catch (e: Exception) {
            handleException<GeminiExplainResponse>(e)
        }
    }

    private suspend fun <T> FlowCollector<Result<T>>.handleResponse(response: Response<T>) {
        if (response.isSuccessful) {
            response.body()?.let {
                emit(Result.Success(it))
            } ?: emit(Result.Error(Exception("Empty response")))
        } else {
            emit(Result.Error(Exception("Error: ${response.code()} ${response.message()}")))
        }
    }

    private suspend fun <T> FlowCollector<Result<T>>.handleException(e: Exception) {
        when (e) {
            is IOException -> emit(Result.Error(Exception("Network error: ${e.message}")))
            else -> emit(Result.Error(e))
        }
    }
} 