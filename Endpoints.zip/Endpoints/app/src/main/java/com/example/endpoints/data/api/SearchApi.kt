package com.example.endpoints.data.api

import com.example.endpoints.data.models.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface SearchApi : ApiService {
    @POST("/api/web-search")
    override suspend fun performWebSearch(
        @Header("Authorization") authToken: String,
        @Body request: WebSearchRequest
    ): Response<WebSearchResponse>

    @POST("/api/image-search")
    override suspend fun performImageSearch(
        @Header("Authorization") authToken: String,
        @Body request: ImageSearchRequest
    ): Response<ImageSearchResponse>

    @POST("/api/video-search")
    override suspend fun performVideoSearch(
        @Header("Authorization") authToken: String,
        @Body request: VideoSearchRequest
    ): Response<VideoSearchResponse>

    @POST("/api/discovery-engine/add-sites")
    override suspend fun addDiscoverySites(
        @Header("Authorization") authToken: String,
        @Body request: AddSitesRequest
    ): Response<AddSitesResponse>

    @POST("/api/discovery-engine/search")
    override suspend fun performDiscoverySearch(
        @Header("Authorization") authToken: String,
        @Body request: DiscoverySearchRequest
    ): Response<DiscoverySearchResponse>

    @POST("/api/gemini/analyze")
    override suspend fun analyzeWithGemini(
        @Header("Authorization") authToken: String,
        @Body request: GeminiAnalyzeRequest
    ): Response<GeminiAnalyzeResponse>

    @POST("/api/gemini/explain")
    override suspend fun explainWithGemini(
        @Header("Authorization") authToken: String,
        @Body request: GeminiExplainRequest
    ): Response<GeminiExplainResponse>
} 