package com.example.endpoints.data.models

data class WebSearchRequest(
    val query: String,
    val gl: String? = null,
    val lr: String? = null,
    val num: Int? = null,
    val safe: Boolean = true,
    val start: Int? = null
)

data class SearchResult(
    val title: String,
    val link: String,
    val snippet: String
)

data class WebSearchResponse(
    val success: Boolean,
    val data: List<SearchResult>? = null,
    val error: String? = null,
    val status_code: Int
) 