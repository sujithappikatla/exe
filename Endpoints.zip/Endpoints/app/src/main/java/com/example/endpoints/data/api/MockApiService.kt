package com.example.endpoints.data.api

import com.example.endpoints.data.models.*
import retrofit2.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import retrofit2.Response.success

class MockApiService : ApiService {
    override suspend fun performWebSearch(
        authToken: String,
        request: WebSearchRequest
    ): Response<WebSearchResponse> {
        return success(
            WebSearchResponse(
                success = true,
                data = listOf(
                    SearchResult(
                        title = "Mock Search Result 1",
                        link = "https://example.com/1",
                        snippet = "This is a mock search result snippet 1"
                    ),
                    SearchResult(
                        title = "Mock Search Result 2",
                        link = "https://example.com/2",
                        snippet = "This is a mock search result snippet 2"
                    )
                ),
                status_code = 200
            )
        )
    }

    override suspend fun performImageSearch(
        authToken: String,
        request: ImageSearchRequest
    ): Response<ImageSearchResponse> {
        return success(
            ImageSearchResponse(
                success = true,
                data = listOf(
                    ImageSearchResult(
                        title = "Mock Image 1",
                        image_url = "https://picsum.photos/200/300",
                        context_url = "https://example.com/image1",
                        height = 300,
                        width = 200
                    ),
                    ImageSearchResult(
                        title = "Mock Image 2",
                        image_url = "https://picsum.photos/300/200",
                        context_url = "https://example.com/image2",
                        height = 200,
                        width = 300
                    )
                ),
                status_code = 200
            )
        )
    }

    override suspend fun performVideoSearch(
        authToken: String,
        request: VideoSearchRequest
    ): Response<VideoSearchResponse> {
        return success(
            VideoSearchResponse(
                success = true,
                data = listOf(
                    VideoSearchResult(
                        title = "Mock Video 1",
                        thumbnail_url = "https://picsum.photos/200/100",
                        channel_title = "Mock Channel 1",
                        duration = "10:30",
                        url = "https://example.com/video1"
                    ),
                    VideoSearchResult(
                        title = "Mock Video 2",
                        thumbnail_url = "https://picsum.photos/200/100",
                        channel_title = "Mock Channel 2",
                        duration = "5:45",
                        url = "https://example.com/video2"
                    )
                ),
                status_code = 200
            )
        )
    }

    override suspend fun addDiscoverySites(
        authToken: String,
        request: AddSitesRequest
    ): Response<AddSitesResponse> {
        return success(
            AddSitesResponse(
                success = true,
                data = request.websites,
                status_code = 200
            )
        )
    }

    override suspend fun performDiscoverySearch(
        authToken: String,
        request: DiscoverySearchRequest
    ): Response<DiscoverySearchResponse> {
        return success(
            DiscoverySearchResponse(
                success = true,
                data = listOf(
                    SearchResult(
                        title = "Mock Discovery Result 1",
                        link = "https://example.com/discovery1",
                        snippet = "This is a mock discovery result from ${request.websites.firstOrNull()}"
                    )
                ),
                status_code = 200
            )
        )
    }

    override suspend fun analyzeWithGemini(
        authToken: String,
        request: GeminiAnalyzeRequest
    ): Response<GeminiAnalyzeResponse> {
        return success(
            GeminiAnalyzeResponse(
                success = true,
                data = AnalysisData(
                    search_query = "Mock analysis for ${request.extended_context.subject}",
                    quick_followup_queries = listOf(
                        "Mock followup 1",
                        "Mock followup 2",
                        "Mock followup 3"
                    ),
                    suggested_queries = listOf(
                        "Mock suggestion 1",
                        "Mock suggestion 2",
                        "Mock suggestion 3"
                    ),
                    for_next_step = "Mock analysis for explanation"
                ),
                status_code = 200
            )
        )
    }

    override suspend fun explainWithGemini(
        authToken: String,
        request: GeminiExplainRequest
    ): Response<GeminiExplainResponse> {
        return success(
            GeminiExplainResponse(
                success = true,
                data = ExplanationData(
                    content = "This is a mock explanation for: ${request.analysis}",
                    rendered_content = "<p>This is a mock explanation for: ${request.analysis}</p>",
                    citations = listOf(
                        Citation(
                            title = "Mock Citation 1",
                            uri = "https://example.com/citation1"
                        ),
                        Citation(
                            title = "Mock Citation 2",
                            uri = "https://example.com/citation2"
                        )
                    )
                ),
                status_code = 200
            )
        )
    }
} 