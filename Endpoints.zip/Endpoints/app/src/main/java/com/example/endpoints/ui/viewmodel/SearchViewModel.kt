package com.example.endpoints.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.endpoints.data.models.*
import com.example.endpoints.data.repository.Result
import com.example.endpoints.data.repository.SearchRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class SearchResult {
    data class Web(val results: List<com.example.endpoints.data.models.SearchResult>) : SearchResult()
    data class Image(val results: List<ImageSearchResult>) : SearchResult()
    data class Video(val results: List<VideoSearchResult>) : SearchResult()
    data class Discovery(val results: List<com.example.endpoints.data.models.SearchResult>) : SearchResult()
    data class GeminiAnalysis(
        val searchQuery: String,
        val quickFollowups: List<String>,
        val suggestedQueries: List<String>
    ) : SearchResult()
    
    data class GeminiExplanation(
        val content: String,
        val renderedContent: String,
        val citations: List<Citation>
    ) : SearchResult()
}

data class SearchUiState(
    val isLoading: Boolean = false,
    val searchResults: SearchResult? = null,
    val explanationResults: SearchResult.GeminiExplanation? = null,
    val error: String? = null
)

class SearchViewModel(
    private val repository: SearchRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState

    private val _managedWebsites = MutableStateFlow<List<String>>(emptyList())
    val managedWebsites: StateFlow<List<String>> = _managedWebsites

    fun performWebSearch(query: String) {
        viewModelScope.launch {
            repository.performWebSearch(query).collect { result ->
                handleSearchResult(result) { SearchResult.Web(it.data ?: emptyList()) }
            }
        }
    }

    fun performImageSearch(query: String, imageSize: ImageSize? = null) {
        viewModelScope.launch {
            repository.performImageSearch(query, imageSize).collect { result ->
                handleSearchResult(result) { SearchResult.Image(it.data ?: emptyList()) }
            }
        }
    }

    fun performVideoSearch(query: String, duration: VideoDuration? = null) {
        viewModelScope.launch {
            repository.performVideoSearch(query, duration = duration).collect { result ->
                handleSearchResult(result) { SearchResult.Video(it.data ?: emptyList()) }
            }
        }
    }

    fun addWebsites(websites: List<String>) {
        viewModelScope.launch {
            repository.addDiscoverySites(websites).collect { result ->
                when (result) {
                    is Result.Success -> {
                        result.data.data?.let { sites ->
                            _managedWebsites.value = sites
                            _uiState.value = SearchUiState()
                        }
                    }
                    is Result.Error -> {
                        _uiState.value = SearchUiState(error = result.exception.message)
                    }
                    is Result.Loading -> {
                        _uiState.value = SearchUiState(isLoading = true)
                    }
                }
            }
        }
    }

    fun performDiscoverySearch(query: String, websites: List<String>) {
        viewModelScope.launch {
            repository.performDiscoverySearch(query, websites).collect { result ->
                handleSearchResult(result) { SearchResult.Discovery(it.data ?: emptyList()) }
            }
        }
    }

    fun analyzeWithGemini(
        fullImage: String,
        roiImage: String,
        grade: String,
        subject: String,
        context: String
    ) {
        viewModelScope.launch {
            val extendedContext = ExtendedContext(
                grade = grade.takeIf { it.isNotBlank() } ?: "N/A",
                subject = subject,
                context = context.takeIf { it.isNotBlank() } ?: "N/A"
            )
            repository.analyzeWithGemini(
                fullImage = fullImage,
                roiImage = roiImage,
                context = extendedContext
            ).collect { result ->
                when (result) {
                    is Result.Success -> {
                        result.data.data?.let { analysisData ->
                            _uiState.value = SearchUiState(
                                searchResults = SearchResult.GeminiAnalysis(
                                    searchQuery = analysisData.search_query,
                                    quickFollowups = analysisData.quick_followup_queries,
                                    suggestedQueries = analysisData.suggested_queries
                                )
                            )
                            explainWithGemini(analysisData.for_next_step)
                        }
                    }
                    is Result.Error -> {
                        _uiState.value = SearchUiState(error = result.exception.message)
                    }
                    is Result.Loading -> {
                        _uiState.value = SearchUiState(isLoading = true)
                    }
                }
            }
        }
    }

    private fun explainWithGemini(analysis: String) {
        viewModelScope.launch {
            repository.explainWithGemini(analysis).collect { result ->
                when (result) {
                    is Result.Success -> {
                        result.data.data?.let { explanationData ->
                            _uiState.value = SearchUiState(
                                searchResults = _uiState.value.searchResults,
                                explanationResults = SearchResult.GeminiExplanation(
                                    content = explanationData.content,
                                    renderedContent = explanationData.rendered_content,
                                    citations = explanationData.citations
                                )
                            )
                        }
                    }
                    is Result.Error -> {
                        _uiState.value = SearchUiState(error = result.exception.message)
                    }
                    is Result.Loading -> {
                        // Don't update loading state here to keep analysis results visible
                    }
                }
            }
        }
    }

    private fun <T> handleSearchResult(
        result: Result<T>,
        mapSuccess: (T) -> SearchResult
    ) {
        _uiState.value = when (result) {
            is Result.Loading -> SearchUiState(isLoading = true)
            is Result.Success -> SearchUiState(searchResults = mapSuccess(result.data))
            is Result.Error -> SearchUiState(error = result.exception.message ?: "Unknown error occurred")
        }
    }
} 