package com.example.endpoints.data.api

import com.example.endpoints.data.models.*
import retrofit2.Response

interface ApiService {
    suspend fun performWebSearch(
        authToken: String,
        request: WebSearchRequest
    ): Response<WebSearchResponse>

    suspend fun performImageSearch(
        authToken: String,
        request: ImageSearchRequest
    ): Response<ImageSearchResponse>

    suspend fun performVideoSearch(
        authToken: String,
        request: VideoSearchRequest
    ): Response<VideoSearchResponse>

    suspend fun addDiscoverySites(
        authToken: String,
        request: AddSitesRequest
    ): Response<AddSitesResponse>

    suspend fun performDiscoverySearch(
        authToken: String,
        request: DiscoverySearchRequest
    ): Response<DiscoverySearchResponse>

    suspend fun analyzeWithGemini(
        authToken: String,
        request: GeminiAnalyzeRequest
    ): Response<GeminiAnalyzeResponse>

    suspend fun explainWithGemini(
        authToken: String,
        request: GeminiExplainRequest
    ): Response<GeminiExplainResponse>
} 