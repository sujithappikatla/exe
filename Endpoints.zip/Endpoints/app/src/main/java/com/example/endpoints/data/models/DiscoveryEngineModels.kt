package com.example.endpoints.data.models

data class AddSitesRequest(
    val websites: List<String>
)

data class AddSitesResponse(
    val success: Boolean,
    val data: List<String>? = null,
    val error: String? = null,
    val status_code: Int
)

data class DiscoverySearchRequest(
    val query: String,
    val websites: List<String>
)

data class DiscoverySearchResponse(
    val success: Boolean,
    val data: List<SearchResult>? = null,
    val error: String? = null,
    val status_code: Int
) 