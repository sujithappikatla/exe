import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
from flask import Flask, request, jsonify, send_from_directory

import docx
import pandas as pd
import faiss
import numpy as np
import json
from uuid import uuid4
# from huggingface_hub import InferenceClient
import requests
import base64
import logging
# from transformers import AutoTokenizer, AutoModel
# import torch
import fitz  # PyMuPDF for local PDF text extraction
from gemini import generate_response, generate_embeddings


app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Disable multiprocessing in transformers and torch to avoid semaphore leaks
os.environ["TOKENIZERS_PARALLELISM"] = "false"
# torch.set_num_threads(1)  # Limit torch to single-threaded execution

# Load API keys from config.json
CONFIG_FILE = 'config.json'
try:
    with open(CONFIG_FILE, 'r') as f:
        config = json.load(f)
    HF_API_KEY = config.get('HF_API_KEY', '')
    OCR_SPACE_API_KEY = config.get('OCR_SPACE_API_KEY', '')
except FileNotFoundError:
    raise Exception(f"Config file {CONFIG_FILE} not found. Please create it with HF_API_KEY and OCR_SPACE_API_KEY.")
except json.JSONDecodeError:
    raise Exception(f"Invalid JSON in {CONFIG_FILE}. Ensure it contains valid JSON with HF_API_KEY and OCR_SPACE_API_KEY.")

# Initialize APIs
# hf_client = InferenceClient(api_key=HF_API_KEY)

# Initialize FAISS index dimension
# dimension = 384  # Dimension of sentence-transformers model
dimension = 3072

# Initialize the tokenizer and model for local embedding generation
# try:
#     tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
#     model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
# except Exception as e:
#     logger.error(f"Failed to load model: {str(e)}")
#     raise

# JSON file for document storage
JSON_FILE = 'knowledge_base.json'

# Uploads folder
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Initialize JSON file if it doesn't exist or is invalid
if not os.path.exists(JSON_FILE):
    with open(JSON_FILE, 'w') as f:
        json.dump([], f)
else:
    try:
        with open(JSON_FILE, 'r') as f:
            json.load(f)
    except json.JSONDecodeError:
        logger.warning(f"Invalid JSON in {JSON_FILE}. Resetting to empty list.")
        with open(JSON_FILE, 'w') as f:
            json.dump([], f)

# Store document embeddings and metadata
embeddings = []
doc_metadata = []

# Custom prompt for LLM
CHAT_PROMPT = """
You are a professional hotel concierge. You can take food orders and response that it will be delivered in 20 min. Provide accurate, friendly, and concise answers (approx 50 words) based on the hotel's knowledge base, including services, dining options, and FAQs. Use a warm tone and offer assistance if needed. If the context lacks relevant information, respond: "I'm sorry, I don't have that information. Please contact our staff for assistance."
Context: {context}
User Query: {query}
Answer:
"""

def extract_text_from_docx(file_path):
    doc = docx.Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs if para.text.strip()])

def extract_text_from_excel(file_path):
    df = pd.read_excel(file_path)
    return df.to_string()

def extract_text_from_pdf_local(file_path):
    """Extract text from a PDF using PyMuPDF (fitz) as a fallback."""
    try:
        doc = fitz.open(file_path)
        text = ""
        for page in doc:
            text += page.get_text("text")
        doc.close()
        if not text.strip():
            logger.warning(f"No text extracted from {file_path} using PyMuPDF")
            return "Error: No text could be extracted from the PDF using PyMuPDF"
        logger.debug(f"Extracted text from {file_path} using PyMuPDF, length: {len(text)}")
        return text
    except Exception as e:
        logger.error(f"Failed to extract text from PDF {file_path} using PyMuPDF: {str(e)}")
        return f"Error: Failed to extract text from PDF using PyMuPDF ({str(e)})"

def extract_text_from_pdf(file_path):
    """Extract text from a PDF using OCR Space API, with a fallback to PyMuPDF."""
    try:
        with open(file_path, 'rb') as file:
            file_content = file.read()
            encoded_file = base64.b64encode(file_content).decode('utf-8')
            
            payload = {
                'apikey': OCR_SPACE_API_KEY,
                'base64Image': f"data:application/pdf;base64,{encoded_file}",
                'isOverlayRequired': True,
                'filetype': 'PDF',
                'language': 'eng'
            }
            
            logger.debug(f"Sending request to OCR Space API for {file_path}")
            response = requests.post('https://api.ocr.space/parse/image', data=payload)
            logger.debug(f"OCR Space API response status: {response.status_code}")
            logger.debug(f"OCR Space API response: {response.text}")

            result = response.json()
            
            if result.get('IsErroredOnProcessing', True):
                error_message = result.get('ErrorMessage', ['Unknown error'])[0]
                logger.error(f"OCR Space API failed for {file_path}: {error_message}")
                # Fallback to PyMuPDF
                logger.debug(f"Falling back to PyMuPDF for {file_path}")
                return extract_text_from_pdf_local(file_path)
            
            text = ""
            for parsed_result in result.get('ParsedResults', []):
                text += parsed_result.get('ParsedText', '')
            
            if not text.strip():
                logger.warning(f"No text extracted from {file_path} by OCR Space API")
                # Fallback to PyMuPDF
                logger.debug(f"Falling back to PyMuPDF for {file_path}")
                return extract_text_from_pdf_local(file_path)
            
            logger.debug(f"Extracted text from {file_path} using OCR Space API, length: {len(text)}")
            return text
    except Exception as e:
        logger.error(f"Failed to extract text from PDF {file_path} using OCR Space API: {str(e)}")
        # Fallback to PyMuPDF
        logger.debug(f"Falling back to PyMuPDF for {file_path}")
        return extract_text_from_pdf_local(file_path)

# def chunk_text(text, max_tokens=256):
#     """Split text into chunks that fit within the model's max token length."""
#     sentences = text.split('\n')
#     chunks = []
#     current_chunk = ""
#     current_token_count = 0

#     for sentence in sentences:
#         sentence = sentence.strip()
#         if not sentence:
#             continue
#         tokens = tokenizer.tokenize(sentence)
#         token_count = len(tokens)

#         if current_token_count + token_count > max_tokens:
#             if current_chunk:
#                 chunks.append(current_chunk.strip())
#             current_chunk = sentence
#             current_token_count = token_count
#         else:
#             current_chunk += " " + sentence if current_chunk else sentence
#             current_token_count += token_count

#     if current_chunk:
#         chunks.append(current_chunk.strip())

#     return chunks

def get_text_embedding(text):
    embedding = generate_embeddings(text)
    return np.array(embedding)

    # try:
    #     logger.debug(f"Generating embedding for text: {text[:100]}...")
    #     if text.startswith("Error:"):
    #         logger.warning(f"Skipping embedding generation due to extraction error: {text}")
    #         return None

    #     chunks = chunk_text(text, max_tokens=256)
    #     logger.debug(f"Text split into {len(chunks)} chunks")
    #     chunk_embeddings = []

    #     for i, chunk in enumerate(chunks):
    #         logger.debug(f"Processing chunk {i+1}/{len(chunks)}, length: {len(chunk)}")
    #         inputs = tokenizer(chunk, return_tensors="pt", truncation=True, padding=True, max_length=256)
    #         with torch.no_grad():
    #             outputs = model(**inputs)
    #         embedding = outputs.last_hidden_state.mean(dim=1).squeeze().numpy()
    #         chunk_embeddings.append(embedding)
    #         # Free memory
    #         del inputs, outputs
    #         torch.cuda.empty_cache() if torch.cuda.is_available() else None

    #     if not chunk_embeddings:
    #         raise ValueError("No embeddings generated for the text")
    #     embedding = np.mean(chunk_embeddings, axis=0)
        
    #     if embedding.shape[-1] != dimension:
    #         raise ValueError(f"Embedding dimension mismatch: expected {dimension}, got {embedding.shape[-1]}")
    #     logger.debug(f"Embedding generated: {embedding.shape}")
    #     return embedding
    # except Exception as e:
    #     logger.error(f"Failed to generate embedding: {str(e)}")
    #     raise Exception(f"Failed to generate embedding: {str(e)}")
    # finally:
    #     torch.cuda.empty_cache() if torch.cuda.is_available() else None

def load_json():
    try:
        with open(JSON_FILE, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse {JSON_FILE}: {str(e)}")
        raise

def save_json(data):
    with open(JSON_FILE, 'w') as f:
        json.dump(data, f, indent=4)

@app.route('/')
def index():
    return send_from_directory('templates', 'index.html')

@app.route('/eva')
def eva_index():
    return send_from_directory('templates', 'index.html')

@app.route('/eva/ingestion')
def ingestion():
    return send_from_directory('templates', 'ingestion.html')

@app.route('/eva/guidelines')
def guidelines():
    return send_from_directory('templates', 'guidelines.html')


@app.route('/eva/chat')
def chat():
    return send_from_directory('templates', 'chat.html')

@app.route('/eva/voice_chat')
def voice_chat():
    return send_from_directory('templates', 'voice_chat.html')

@app.route('/eva/menu_ingestion')
def menu_ingestion():
    return send_from_directory('templates', 'menu_ingestion.html')

@app.route('/eva/hotel_onboarding')
def hotel_onboarding():
    return send_from_directory('templates', 'hotel_onboarding.html')

@app.route('/eva/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

@app.route('/eva/list_files', methods=['GET'])
def list_files():
    try:
        files = os.listdir(UPLOAD_FOLDER)
        return jsonify(files)
    except Exception as e:
        logger.error(f"Failed to list files: {str(e)}")
        return jsonify({'error': f'Failed to list files: {str(e)}'}), 500

@app.route('/eva/upload_files', methods=['POST'])
def upload_files():
    try:
        files = request.files.getlist('files')
        if not files or all(file.filename == '' for file in files):
            return jsonify({'error': 'No files selected'}), 400

        uploaded_files = []
        for file in files:
            if file and file.filename:
                file_path = os.path.join(UPLOAD_FOLDER, file.filename)
                file.save(file_path)
                uploaded_files.append(file.filename)

        if not uploaded_files:
            return jsonify({'error': 'No valid files uploaded'}), 400

        return jsonify({'message': 'Files uploaded successfully', 'files': uploaded_files})
    except Exception as e:
        logger.error(f"Upload failed: {str(e)}")
        return jsonify({'error': f'Upload failed: {str(e)}'}), 500

@app.route('/eva/ingest_files', methods=['POST'])
def ingest_files():
    global embeddings, doc_metadata
    # Initialize FAISS index within the endpoint to avoid global issues
    index = faiss.IndexFlatL2(dimension)
    logger.debug(f"FAISS index initialized with dimension {dimension} in ingest_files")

    try:
        data = request.get_json()
        files = data.get('files', [])
        if not files:
            return jsonify({'error': 'No files provided for ingestion'}), 400

        documents = load_json()
        failed_files = []
        
        for filename in files:
            file_path = os.path.join(UPLOAD_FOLDER, filename)
            if not os.path.exists(file_path):
                logger.warning(f"File not found: {file_path}")
                failed_files.append(f"{filename}: File not found")
                continue
                
            doc_id = str(uuid4())
            content = ""

            if filename.endswith('.docx'):
                content = extract_text_from_docx(file_path)
            elif filename.endswith('.xlsx'):
                content = extract_text_from_excel(file_path)
            elif filename.endswith('.pdf'):
                content = extract_text_from_pdf(file_path)
            else:
                logger.warning(f"Unsupported file type: {filename}")
                failed_files.append(f"{filename}: Unsupported file type")
                continue

            if content.strip():
                if content.startswith("Error:"):
                    logger.warning(f"Failed to extract content from {filename}: {content}")
                    failed_files.append(f"{filename}: {content}")
                    continue

                logger.debug(f"Processing file: {filename}, content length: {len(content)}")
                documents.append({
                    'id': doc_id,
                    'content': content,
                    'source': filename
                })
                save_json(documents)

                embedding = get_text_embedding(content)
                if embedding is not None:
                    embeddings.append(embedding)
                    doc_metadata.append({'id': doc_id, 'filename': filename})
                else:
                    failed_files.append(f"{filename}: Failed to generate embedding")
            else:
                logger.warning(f"No content extracted from file: {filename}")
                failed_files.append(f"{filename}: No content extracted")

        if embeddings:
            embeddings_array = np.vstack(embeddings)
            logger.debug(f"FAISS index updated with {len(embeddings)} embeddings, shape: {embeddings_array.shape}")
            index.reset()
            index.add(embeddings_array)
        else:
            logger.warning("No embeddings generated during ingestion")

        if failed_files:
            return jsonify({'message': 'Ingestion completed with errors', 'failed_files': failed_files}), 206
        return jsonify({'message': 'Documents ingested successfully'})
    except Exception as e:
        logger.error(f"Ingestion failed: {str(e)}")
        return jsonify({'error': f'Ingestion failed: {str(e)}'}), 500

@app.route('/eva/query', methods=['POST'])
def query():
    # Initialize FAISS index within the endpoint to avoid global issues
    index = faiss.IndexFlatL2(dimension)
    logger.debug(f"FAISS index initialized with dimension {dimension} in query")

    # Rebuild the index with existing embeddings
    if embeddings:
        embeddings_array = np.vstack(embeddings)
        logger.debug(f"Rebuilding FAISS index with {len(embeddings)} embeddings, shape: {embeddings_array.shape}")
        index.reset()
        index.add(embeddings_array)
    else:
        logger.warning("FAISS index is empty; no embeddings available")

    try:
        data = request.get_json()
        query = data['query']
        logger.debug(f"Received query: {query}")

        # Get query embedding
        query_embedding = get_text_embedding(query)
        if query_embedding is None:
            raise ValueError("Failed to generate embedding for the query")
        logger.debug(f"Query embedding shape: {query_embedding.shape}")

        # Search FAISS index
        k = 3  # Top 3 documents
        logger.debug(f"Searching FAISS index with {k} nearest neighbors")
        if not hasattr(index, 'search'):
            logger.error(f"Index object does not have a search method: {type(index)}")
            raise AttributeError("FAISS index does not have a search method")
        distances, indices = index.search(np.array([query_embedding]), k)
        logger.debug(f"Search results - distances: {distances}, indices: {indices}")

        # Retrieve relevant documents from JSON
        documents = load_json()
        context = ""
        for idx in indices[0]:
            if idx < len(doc_metadata):
                doc_id = doc_metadata[idx]['id']
                for doc in documents:
                    if doc['id'] == doc_id:
                        context += doc['content'] + "\n"
                        logger.debug(f"Found document for doc_id {doc_id}: {doc['source']}")
                        break

        if not context.strip():
            logger.warning("No relevant context found for the query")
            return jsonify({'answer': "I'm sorry, I don't have that information. Please contact our staff for assistance."})

        # Use LLM for response
        prompt = CHAT_PROMPT.format(context=context, query=query)
        logger.debug(f"Generated prompt: {prompt[:200]}...")
        # response = hf_client.text_generation(
        #     model="mistralai/Mixtral-8x7B-Instruct-v0.1",
        #     prompt=prompt,
        #     max_new_tokens=200
        # )
        response = generate_response(prompt)
        answer = response.strip()
        logger.debug(f"LLM response: {answer[:100]}...")

        return jsonify({'answer': answer})
    except Exception as e:
        logger.error(f"Query failed: {str(e)}")
        return jsonify({'error': f'Query failed: {str(e)}'}), 500
    finally:
        # torch.cuda.empty_cache() if torch.cuda.is_available() else None
        pass

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=8080)
    finally:
        # torch.cuda.empty_cache() if torch.cuda.is_available() else None
        pass