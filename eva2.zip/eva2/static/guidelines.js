async function loadPrompt() {
    try {
        const response = await fetch('/eva/load_prompt', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await response.json();

        if (response.ok) {
            document.getElementById('prompt-textarea').value = data.prompt || '';
        } else {
            document.getElementById('prompt-error').textContent = data.error || 'Failed to load prompt.';
        }
    } catch (error) {
        console.error('Error loading prompt:', error);
        document.getElementById('prompt-error').textContent = 'Error: ' + error.message;
    }
}

async function savePrompt() {
    const promptText = document.getElementById('prompt-textarea').value.trim();
    const errorDisplay = document.getElementById('prompt-error');

    if (!promptText) {
        errorDisplay.textContent = 'Prompt cannot be empty.';
        return;
    }

    try {
        const response = await fetch('/eva/save_prompt', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: promptText })
        });
        const data = await response.json();

        if (response.ok) {
            errorDisplay.textContent = 'Prompt saved successfully!';
            errorDisplay.style.color = '#28a745'; // Green for success
        } else {
            errorDisplay.textContent = data.error || 'Failed to save prompt.';
            errorDisplay.style.color = '#ff6f61'; // Red for error
        }
    } catch (error) {
        console.error('Error saving prompt:', error);
        errorDisplay.textContent = 'Error: ' + error.message;
        errorDisplay.style.color = '#ff6f61';
    }
}

// Load the prompt when the page loads
document.addEventListener('DOMContentLoaded', loadPrompt);