async function uploadFiles() {
    const fileInput = document.getElementById('file-input');
    const uploadError = document.getElementById('upload-error');
    const modal = document.getElementById('upload-modal');
    const files = fileInput.files;

    if (files.length === 0) {
        uploadError.textContent = 'Please select at least one file.';
        return;
    }

    const formData = new FormData();
    for (let file of files) {
        formData.append('files', file);
    }

    modal.style.display = 'flex';
    try {
        const response = await fetch('/eva/upload_files', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();

        if (response.ok) {
            uploadError.textContent = '';
            await listFiles(); // Refresh the file list
        } else {
            uploadError.textContent = data.error || 'Failed to upload files.';
        }
    } catch (error) {
        uploadError.textContent = 'Error: ' + error.message;
    } finally {
        modal.style.display = 'none';
    }
}

async function listFiles() {
    const fileTableBody = document.getElementById('file-table-body');
    const ingestBtn = document.getElementById('ingest-btn');
    try {
        const response = await fetch('/eva/list_files');
        const files = await response.json();

        fileTableBody.innerHTML = '';
        if (files.length === 0) {
            fileTableBody.innerHTML = '<tr><td colspan="3">No files uploaded.</td></tr>';
            ingestBtn.disabled = true;
            return;
        }

        files.forEach(file => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><input type="checkbox" class="file-checkbox" data-filename="${file}"></td>
                <td>${file}</td>
                <td>Not ingested</td>
            `;
            fileTableBody.appendChild(row);
        });

        const checkboxes = document.querySelectorAll('.file-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const anyChecked = Array.from(checkboxes).some(cb => cb.checked);
                ingestBtn.disabled = !anyChecked;
            });
        });
    } catch (error) {
        fileTableBody.innerHTML = `<tr><td colspan="3">Error: ${error.message}</td></tr>`;
        ingestBtn.disabled = true;
    }
}

async function ingestFiles() {
    const checkboxes = document.querySelectorAll('.file-checkbox:checked');
    const statusDisplay = document.getElementById('ingestion-status');
    const progressBar = document.getElementById('ingestion-progress');
    const filesToIngest = Array.from(checkboxes).map(cb => cb.dataset.filename);

    if (filesToIngest.length === 0) {
        statusDisplay.textContent = 'No files selected for ingestion.';
        return;
    }

    statusDisplay.textContent = 'Ingesting files...';
    progressBar.style.width = '0%'; // Reset progress bar

    try {
        // Simulate progress for each file
        for (let i = 0; i < filesToIngest.length; i++) {
            const file = filesToIngest[i];
            const progress = ((i + 1) / filesToIngest.length) * 100;
            progressBar.style.width = `${progress}%`; // Update progress bar

            // Simulate ingestion delay for each file
            await new Promise(resolve => setTimeout(resolve, 500));

            const response = await fetch('/eva/ingest_files', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ files: [file] })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Failed to ingest files.');
            }

            // Update file status in table
            const row = checkboxes[i].parentElement.parentElement;
            row.cells[2].textContent = 'Ingested';
        }

        statusDisplay.textContent = 'Ingestion completed successfully.';
    } catch (error) {
        statusDisplay.textContent = 'Error: ' + error.message;
        progressBar.style.width = '0%'; // Reset on error
    }
}

// Load the file list when the page loads
document.addEventListener('DOMContentLoaded', listFiles);