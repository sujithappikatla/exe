//package com.example.cloudrunstt.viewmodel
//
//import android.util.Log
//import androidx.lifecycle.ViewModel
//import androidx.lifecycle.viewModelScope
//import com.example.cloudrunstt.audio.AudioRecorder
//import com.example.cloudrunstt.network.TranscriptionWebSocket
//import kotlinx.coroutines.flow.MutableStateFlow
//import kotlinx.coroutines.flow.StateFlow
//import kotlinx.coroutines.flow.catch
//import kotlinx.coroutines.flow.launchIn
//import kotlinx.coroutines.flow.onEach
//import kotlinx.coroutines.launch
//
///**
// * ViewModel to manage real-time audio transcription state and coordinate components
// */
//class TranscriptionViewModel : ViewModel() {
//    companion object {
//        private const val TAG = "TranscriptionViewModel"
//    }
//
//    private val audioRecorder = AudioRecorder()
//    private var webSocket: TranscriptionWebSocket? = null
//
//    private val _transcriptionText = MutableStateFlow("")
//    val transcriptionText: StateFlow<String> = _transcriptionText
//
//    private val _isRecording = MutableStateFlow(false)
//    val isRecording: StateFlow<Boolean> = _isRecording
//
//    private val _error = MutableStateFlow<String?>(null)
//    val error: StateFlow<String?> = _error
//
//    /**
//     * Starts the transcription process
//     * @param serverUrl WebSocket server URL
//     */
//    fun startTranscription(serverUrl: String) {
//        if (_isRecording.value) {
//            Log.w(TAG, "Transcription already in progress")
//            return
//        }
//
//        viewModelScope.launch {
//            try {
//                webSocket = TranscriptionWebSocket(, serverUrl)
//
//                // Start WebSocket connection and collect transcriptions
//                webSocket?.connect()
//                    ?.catch { e ->
//                        Log.e(TAG, "WebSocket error: ${e.message}", e)
//                        _error.value = "Connection error: ${e.message}"
//                        stopTranscription()
//                    }
//                    ?.onEach { transcription ->
//                        _transcriptionText.value += "$transcription "
//                    }
//                    ?.launchIn(viewModelScope)
//
//                // Start audio recording and send chunks to WebSocket
//                audioRecorder.startRecording()
//                    .catch { e ->
//                        Log.e(TAG, "Audio recording error: ${e.message}", e)
//                        _error.value = "Recording error: ${e.message}"
//                        stopTranscription()
//                    }
//                    .onEach { audioData ->
//                        webSocket?.sendAudioData(audioData)
//                    }
//                    .launchIn(viewModelScope)
//
//                _isRecording.value = true
//                _error.value = null
//            } catch (e: Exception) {
//                Log.e(TAG, "Failed to start transcription: ${e.message}", e)
//                _error.value = "Failed to start: ${e.message}"
//                stopTranscription()
//            }
//        }
//    }
//
//    fun stopTranscription() {
//        audioRecorder.stopRecording()
//        webSocket?.disconnect()
//        webSocket = null
//        _isRecording.value = false
//    }
//
//    override fun onCleared() {
//        super.onCleared()
//        stopTranscription()
//    }
//}