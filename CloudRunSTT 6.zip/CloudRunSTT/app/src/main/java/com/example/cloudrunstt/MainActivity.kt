package com.example.cloudrunstt

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.cloudrunstt.service.TranscriptionService
import com.example.cloudrunstt.ui.theme.CloudRunSTTTheme

class MainActivity : ComponentActivity() {
    private var isRecording = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        val notificationGranted = permissions[Manifest.permission.POST_NOTIFICATIONS] == true

        if (micGranted && notificationGranted) {
            checkOverlayPermission()
        } else {
            Toast.makeText(
                this,
                "Microphone and notification permissions are required",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request required permissions
        requestPermissions()

        setContent {
            CloudRunSTTTheme {
                TranscriptionScreen(
                    isRecording = isRecording,
                    onStartRecording = {
                        url -> startBackgroundService(url)
                        finish()
                                       },
                    onStopRecording = { stopBackgroundService() }
                )
            }
        }
    }

    private fun requestPermissions() {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )
    }

    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun startBackgroundService(websocketUrl: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Overlay permission is required",
                Toast.LENGTH_LONG
            ).show()
            checkOverlayPermission()
            return
        }

        TranscriptionService.startService(this, websocketUrl)
        isRecording = true
    }

    private fun stopBackgroundService() {
        TranscriptionService.stopService(this)
        isRecording = false
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranscriptionScreen(
    isRecording: Boolean,
    onStartRecording: (String) -> Unit,
    onStopRecording: () -> Unit
) {
    var serverUrl by remember {
        mutableStateOf("wss://chirpv2-305533803718.us-central1.run.app/")
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Real-time Transcription") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Server URL input
            TextField(
                value = serverUrl,
                onValueChange = { serverUrl = it },
                label = { Text("WebSocket Server URL") },
                modifier = Modifier.fillMaxWidth()
            )

            // Info text
            Text(
                text = if (isRecording) {
                    "Recording in background. Check notification shade for controls."
                } else {
                    "Press start to begin recording and showing overlay"
                },
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // Control button
            Button(
                onClick = {
                    if (isRecording) {
                        onStopRecording()
                    } else {
                        onStartRecording(serverUrl)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(if (isRecording) "Stop Recording" else "Start Recording")
            }
        }
    }
}
