package com.example.cloudrunstt.network

import android.content.Context
import android.util.Log
import com.example.cloudrunstt.auth.CloudRunAuthenticator
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI
import java.nio.ByteBuffer

/**
 * Handles WebSocket connection to Cloud Run instance for real-time audio transcription
 */
class TranscriptionWebSocket(
    private val context: Context,
    private val serverUrl: String
) {
    companion object {
        private const val TAG = "TranscriptionWebSocket"
    }

    private var webSocketClient: WebSocketClient? = null
    private val authenticator by lazy {
        // Extract the host from the WebSocket URL for the target audience
        val audience = serverUrl.replace("wss://", "https://")
        Log.d(TAG, "Target audience: $audience")
        CloudRunAuthenticator(context, audience)
    }

    private var isConnected = false

    /**
     * Connects to the WebSocket server with authentication
     * @return Flow of transcription results
     */
    suspend fun connect(): Flow<String> = callbackFlow {
        try {
            // Get authentication token
            val token = authenticator.getAccessToken()
            Log.d(TAG, "Got ID token: ${token}...")
            if (token == null) {
                throw IllegalStateException("Failed to obtain authentication token")
            }

            val headers = mapOf("Authorization" to "Bearer $token")
            val uri = URI(serverUrl)

            webSocketClient = object : WebSocketClient(uri, headers) {
                override fun onOpen(handshakedata: ServerHandshake?) {
                    Log.d(TAG, "WebSocket opened successfully")
                    isConnected = true
                }

                override fun onMessage(message: String) {
                    Log.d(TAG, "Received transcription: $message")
                    trySend(message)
                }

                override fun onClose(code: Int, reason: String, remote: Boolean) {
                    Log.d(TAG, "WebSocket closed with code: $code, reason: $reason")
                    isConnected = false
                    close()
                }

                override fun onError(ex: Exception?) {
                    val errorMessage = "WebSocket error: ${ex?.message}"
                    Log.e(TAG, errorMessage, ex)
                    isConnected = false
                    close(ex)
                }
            }

            webSocketClient?.connect()
            Log.d(TAG, "WebSocket connection initiated")

        } catch (e: Exception) {
            Log.e(TAG, "WebSocket connection error: ${e.message}", e)
            throw e
        }

        // Clean up when the flow collection is cancelled
        awaitClose {
            disconnect()
        }
    }

    /**
     * Sends audio data to the WebSocket server
     * @param audioData ByteArray of audio chunk
     */
    fun sendAudioData(audioData: ByteArray) {
        if (!isConnected) {
            Log.w(TAG, "Cannot send audio data: WebSocket not connected")
            return
        }
        try {
            webSocketClient?.send(ByteBuffer.wrap(audioData))
        } catch (e: Exception) {
            Log.e(TAG, "Error sending audio data: ${e.message}", e)
        }
    }

    fun disconnect() {
        webSocketClient?.close()
        webSocketClient = null
        isConnected = false
        Log.d(TAG, "WebSocket disconnected")
    }
} 