package com.example.cloudrunstt.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.example.cloudrunstt.R
import com.example.cloudrunstt.audio.AudioRecorder
import com.example.cloudrunstt.network.TranscriptionWebSocket
import com.example.cloudrunstt.overlay.OverlayWindowManager
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class TranscriptionService : LifecycleService() {
    companion object {
        private const val TAG = "TranscriptionService"
        private const val NOTIFICATION_CHANNEL_ID = "TranscriptionService"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_START = "ACTION_START"
        private const val ACTION_STOP = "ACTION_STOP"
        private const val EXTRA_WEBSOCKET_URL = "EXTRA_WEBSOCKET_URL"

        fun startService(context: Context, websocketUrl: String) {
            val intent = Intent(context, TranscriptionService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_WEBSOCKET_URL, websocketUrl)
            }
            context.startForegroundService(intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, TranscriptionService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private lateinit var overlayManager: OverlayWindowManager
    private val audioRecorder = AudioRecorder()
    private var webSocket: TranscriptionWebSocket? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        overlayManager = OverlayWindowManager(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_START -> {
                val websocketUrl = intent.getStringExtra(EXTRA_WEBSOCKET_URL)
                    ?: throw IllegalArgumentException("WebSocket URL is required")
                startTranscription(websocketUrl)
            }
            ACTION_STOP -> stopTranscription()
        }

        return Service.START_NOT_STICKY
    }

    private fun startTranscription(websocketUrl: String) {
        try {
            startForeground(NOTIFICATION_ID, createNotification())
            
            webSocket = TranscriptionWebSocket(this, websocketUrl)
            
            // Show overlay window
            overlayManager.show {}  // Empty content as it's handled internally now

            lifecycleScope.launch {
                // Start WebSocket connection and collect transcriptions
                webSocket?.connect()
                    ?.catch { e ->
                        Log.e(TAG, "WebSocket error: ${e.message}", e)
                    }
                    ?.let { flow ->
                        // Start updating the transcription text
                        overlayManager.updateTranscriptionFlow(flow)
                    }

                // Start audio recording and send chunks to WebSocket
                audioRecorder.startRecording()
                    .catch { e ->
                        Log.e(TAG, "Audio recording error: ${e.message}", e)
                    }
                    .onEach { audioData ->
                        webSocket?.sendAudioData(audioData)
                    }
                    .launchIn(lifecycleScope)
            }

            Log.d(TAG, "Transcription service started")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting transcription: ${e.message}", e)
            stopSelf()
        }
    }

    private fun stopTranscription() {
        audioRecorder.stopRecording()
        webSocket?.disconnect()
        webSocket = null
        overlayManager.hide()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.d(TAG, "Transcription service stopped")
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            "Transcription Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Running transcription service"
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun createNotification() = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
        .setContentTitle("Transcription Active")
        .setContentText("Recording and transcribing audio...")
        .setSmallIcon(R.drawable.ic_launcher_foreground)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    override fun onDestroy() {
        super.onDestroy()
        stopTranscription()
    }
}