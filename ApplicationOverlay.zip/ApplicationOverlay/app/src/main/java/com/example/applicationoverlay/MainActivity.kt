package com.example.applicationoverlay

import android.R
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {

    var TAG = "AppOverlay"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //setContentView(R.layout.activity_main)

        // Start the overlay service

        // Start the overlay service
        startService(Intent(this, OverlayService::class.java))
        startService(Intent(this, MyAccessibilityService::class.java))

        //setContentView(R.layout.activity_main)

        finish()


    }


}