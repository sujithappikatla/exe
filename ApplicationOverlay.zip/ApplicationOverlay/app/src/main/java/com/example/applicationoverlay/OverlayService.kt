package com.example.applicationoverlay

import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener
import android.view.WindowManager
import android.widget.GridLayout
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService


class OverlayService : Service() {
    var TAG = "AppOverlay"
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var selectionView: View? = null
    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        showOverlay()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            // Handle the case where the permission is not granted
            Log.e(TAG, "Returning ....");
            return
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, // or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ) /* w  w w  . jav a  2  s.co m*/

        val SelectionParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, // or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        SelectionParams.gravity = Gravity.TOP or Gravity.RIGHT


        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        overlayView = inflater.inflate(R.layout.overlay_layout, null)
        selectionView = inflater.inflate(R.layout.color_selection_layout, null)

        // Customize overlayView here if needed
        windowManager!!.addView(overlayView, params)
        windowManager!!.addView(selectionView, SelectionParams)

        // Set up touch event detection
        // Set up touch event detection
        overlayView!!.setOnTouchListener(OnTouchListener { v, event ->
            // Handle touch events here
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {}
                MotionEvent.ACTION_MOVE -> {}
                MotionEvent.ACTION_UP -> {}
            }

            Log.i(TAG, "Touch Event Occured "+event.size*10000)

            if(shouldBlockTouchEvent(event) == false)
            {
                Log.i(TAG, "Blocking evenet")
                //dispatchTouchEventToUnderlyingApp(event);
                val newParams = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                windowManager?.updateViewLayout(overlayView, newParams)

            }

            false
             // Consume the event
        })

        val colorSelectionGrid: GridLayout = selectionView!!.findViewById(R.id.colorSelectionGrid)
        // Array of colors you want to display
        val colors = intArrayOf(
            Color.BLACK,
            Color.WHITE,
            Color.RED,
            Color.GREEN,
            Color.BLUE
            // Add more colors as needed
        )

                // Inflate and add small circles to the GridLayout
                for (colorResId in colors) {
                    val circleView = View(this)
                    val circleDrawable = ContextCompat.getDrawable(this, R.drawable.circle) as GradientDrawable
                    //circleDrawable.setColor(ContextCompat.getColor(this, colorResId))
                    circleDrawable.setColor(colorResId)
                    circleView.background = circleDrawable

                    circleView.setOnClickListener {
                        Log.i(TAG, "Click event AHppend "+colorResId)

                        if(colorResId == Color.BLACK)
                        {
                            Log.i(TAG, "Blocking evenet")
                            //dispatchTouchEventToUnderlyingApp(event);
                            val newParams = WindowManager.LayoutParams(
                                WindowManager.LayoutParams.MATCH_PARENT,
                                WindowManager.LayoutParams.MATCH_PARENT,
                                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                                PixelFormat.TRANSLUCENT
                            )
                            windowManager?.updateViewLayout(overlayView, newParams)

                        }else
                        {
                            val dw: DrawingView = overlayView!!.findViewById(R.id.drawingView)
                            dw.setPenColor(colorResId)
                        }


                    }

                    val layoutParams = GridLayout.LayoutParams().apply {
                        width = 100
                        height = 100
                        rightMargin = 30

                        //margin = resources.getDimensionPixelSize(R.dimen.circle_margin)
                    }

                    colorSelectionGrid.addView(circleView, layoutParams)



                }

        val circleView = View(this)
        val circleDrawable = ContextCompat.getDrawable(this, R.drawable.circle) as GradientDrawable
        //circleDrawable.setColor(ContextCompat.getColor(this, colorResId))
        circleDrawable.setColor(Color.MAGENTA)
        circleView.background = circleDrawable

        circleView.setOnClickListener {
            stopSelf()
        }
        val layoutParams = GridLayout.LayoutParams().apply {
            width = 100
            height = 100
            rightMargin = 30

            //margin = resources.getDimensionPixelSize(R.dimen.circle_margin)
        }

        colorSelectionGrid.addView(circleView, layoutParams)

    }

    private fun shouldBlockTouchEvent(event: MotionEvent): Boolean {
        if((event.size*10000) > 300.0)
            return false
        // Add your condition to determine if the touch event should be blocked
        // For example, you may check specific coordinates or other conditions
        return true /* your condition */
    }
/*
    private fun dispatchTouchEventToUnderlyingApp(event: MotionEvent): Boolean {
        // Get the root view of the entire screen
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val defaultDisplay = getSystemService<DisplayManager>()?.getDisplay(Display.DEFAULT_DISPLAY)
        val rootView = windowManager.defaultDisplay.rootview

        // Create a MotionEvent for the root view
        val rootViewEvent = MotionEvent.obtain(event)
        rootViewEvent.setLocation(event.rawX, event.rawY)

        // Dispatch the MotionEvent to the root view
        val eventConsumed = rootView.dispatchTouchEvent(rootViewEvent)

        // Recycle the MotionEvent
        rootViewEvent.recycle()

        return eventConsumed
    }
*/
    private fun removeOverlay() {
        if (windowManager != null && overlayView != null) {
            windowManager!!.removeView(overlayView)
            windowManager!!.removeView(selectionView)
        }
    }
}
