package com.example.applicationoverlay

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MyAccessibilityService : AccessibilityService() {

    var TAG = "AppOverlay"

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val rootNodeInfo: AccessibilityNodeInfo? = rootInActiveWindow
            val packageName = event.packageName?.toString()
            val className = event.className?.toString()
            Log.i(TAG, "PackageName : "+packageName+ " className : "+className)
            rootNodeInfo?.let {
                val windowRect = Rect()
                it.getBoundsInScreen(windowRect)

                // Now, windowRect contains the coordinates of the top-left and bottom-right corners
                // of the window in screen coordinates.
                val windowWidth = windowRect.width()
                val windowHeight = windowRect.height()

                Log.i(TAG, " width : "+ windowWidth+"  height : "+windowHeight)

                // Handle or log the window size as needed
            }
        }
    }

    override fun onInterrupt() {
        // Handle service interruption
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Accessibility Create")
    }

    override fun onStart(intent: Intent?, startId: Int) {
        super.onStart(intent, startId)
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
