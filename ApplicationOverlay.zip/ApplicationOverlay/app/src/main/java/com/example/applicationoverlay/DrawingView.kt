package com.example.applicationoverlay

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View

class DrawingView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    var TAG = "AppOverlay"
    private var path = 0
    private var paint = 0
    private var pathMap:MutableMap<Int, Path> = mutableMapOf()
    private var paintMap:MutableMap<Int, Paint> = mutableMapOf()

    init {


       // val typedArray = context.obtainStyledAttributes(attrs, R.styleable.DrawingView)

        // Retrieve specific attributes
        //val customAttribute = typedArray.getString(R.styleable.DrawingView_penColor)

        // Don't forget to recycle the TypedArray to avoid memory leaks
        //typedArray.recycle()
       // Log.i(TAG, "ATT : "+customAttribute.toString());
        path = Color.WHITE
        paint = Color.WHITE
        //pathMap.set(path, Path())
        pathMap[path] = Path()
        paintMap[paint] = Paint()

        paintMap[paint]!!.apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 5f
            isAntiAlias = true
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for ((key, value) in pathMap) {
            canvas.drawPath(value, paintMap[key]!!)
        }
        //pathMap[path]?.let { canvas.drawPath(it, paint) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                pathMap[path]!!.moveTo(x, y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                pathMap[path]!!.lineTo(x, y)
                //invalidate()
            }
            MotionEvent.ACTION_UP -> {
                // Nothing to do here for now
            }
        }

        return false
    }

    fun setPenColor(c:Int)
    {
        Log.i(TAG,"Setting PenColor "+ c)



        path = c
        paint = c
        if(pathMap.containsKey(path) == false)
        {
            pathMap[path] = Path()
        }
        if(paintMap.containsKey(paint) == false)
        {
            paintMap[paint] = Paint()
        }
       // paint = Paint()
        paintMap[paint]!!.apply {
            color = c
            style = Paint.Style.STROKE
            strokeWidth = 5f
            isAntiAlias = true
        }

        if(c==Color.GREEN)
        {
                paintMap[paint]!!.color = Color.WHITE // Set color to match the background or underlying content
                paintMap[paint]!!.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            paintMap[paint]!!.strokeWidth = 20f
        }
    }
}
