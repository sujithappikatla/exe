from google.cloud import storage
from google.cloud import firestore
import datetime
from google.oauth2 import service_account

# Replace with the path to your downloaded JSON key file
key_path = "./service-account.json"

credentials = service_account.Credentials.from_service_account_file(
    key_path,
    scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

lesson_bucket_name = 'lesson-bucket8'
firestore_collection_name = 'users_data'



# {
#     "lesson_list": [
#         {
#             "id": "lesson_id",
#             "name": "lesson_name",
#             "created_at": "2021-01-01",
#         },
#         {
#             "id": "lesson_id",
#             "name": "lesson_name",
#             "created_at": "2021-01-01",
#         }
#     ]
# }



def generate_signed_url(bucket_name, blob_name, expiration=300):
    """
    Generate a signed URL for downloading a blob from GCS.
    
    Args:
        bucket_name (str): The name of the GCS bucket.
        blob_name (str): The name of the blob within the bucket.
        expiration (int): URL expiration time in seconds, default is 1 hour.
        
    Returns:
        str: The signed URL for downloading the blob.
    """
    # Initialize the storage client
    storage_client = storage.Client(credentials=credentials)
    
    # Get the bucket
    bucket = storage_client.bucket(bucket_name)
    
    # Get the blob
    blob = bucket.blob(blob_name)
    
    # Generate signed URL
    url = blob.generate_signed_url(
        version="v4",
        expiration=datetime.timedelta(seconds=expiration),
        method="GET",
    )
    
    return url


def get_user_data(user_id):
    """
    Get the user data from the Firestore database.
    Args:
        user_id (str): The user ID to get the data for.
    Returns:
        dict: The user data.
    """
    db = firestore.Client()
    doc_ref = db.collection(firestore_collection_name).document(user_id)
    doc = doc_ref.get()
    
    if doc.exists:
        return doc.to_dict()
    return None

def set_user_data(user_id, data):
    """
    Set the user data in the Firestore database.
    Args:
        user_id (str): The user ID to set the data for.
        data (dict): The data to set.
    """
    db = firestore.Client()
    doc_ref = db.collection(firestore_collection_name).document(user_id)
    doc_ref.set(data)


def add_new_lesson(user_id, lesson_id, lesson_name):
    """
    Add a new lesson to the user's lesson list.
    """
    user_data = get_user_data(user_id)
    if user_data:
        user_data['lesson_list'].append({
            'id': lesson_id,
            'name': lesson_name,
            'created_at': datetime.datetime.now().isoformat()
        })
        set_user_data(user_id, user_data)
    return None

def get_lesson_list(user_id):
    """
    Get the lesson list from the Firestore database.
    """
    user_data = get_user_data(user_id)
    if user_data:
        lesson_list = user_data['lesson_list']
        ret = []
        for lesson in lesson_list:
            lesson_id = lesson['id']
            lesson_name = lesson['name']
            ret.append( {
                'id': lesson_id,
                'name': lesson_name,
            })
        return {
            'lessons': ret
        }
    return None

def get_download_url_for_lesson_audio(user_id, lesson_id):
    """
    Get the download URL for the lesson audio.
    """
    user_data = get_user_data(user_id)
    if user_data:
        lesson_list = user_data['lesson_list']
        for lesson in lesson_list:
            if lesson['id'] == lesson_id:
                return generate_signed_url(lesson_bucket_name, lesson['id']+"/audio.mp4")
    return None

def get_download_url_for_lesson_transcript(user_id, lesson_id):
    """
    Get the download URL for the lesson transcript.
    """
    user_data = get_user_data(user_id)
    if user_data:
        lesson_list = user_data['lesson_list']
        for lesson in lesson_list:
            if lesson['id'] == lesson_id:
                return generate_signed_url(lesson_bucket_name, lesson['id']+"/transcript.txt")
    return None


def get_download_url_for_lesson_summary(user_id, lesson_id):
    """
    Get the download URL for the lesson summary.
    """
    user_data = get_user_data(user_id)
    if user_data:
        lesson_list = user_data['lesson_list']
        for lesson in lesson_list:
            if lesson['id'] == lesson_id:
                return generate_signed_url(lesson_bucket_name, lesson['id']+"/summary.txt")
    return None


# user1_data = {
#     "lesson_list": [
#         {
#             "id": "USER1-LESSON1",
#             "name": "User 1 Lesson 1",
#             "created_at": "2021-01-01",
#         }
#     ]
# }

# set_user_data('USER1', user1_data)

# print(get_lesson_list('USER1'))

# print(get_download_url_for_lesson_summary('USER1', 'USER1-LESSON1'))


