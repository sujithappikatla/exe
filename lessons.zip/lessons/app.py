from flask import Flask, request, jsonify
from google.cloud import storage
import datetime
import os
from lesson_data import (
    get_download_url_for_lesson_summary,
    get_download_url_for_lesson_transcript,
    get_download_url_for_lesson_audio,
    get_lesson_list,
    add_new_lesson
)
app = Flask(__name__)

@app.route('/health', methods=['GET'])
def health_check():
    """Simple health check endpoint"""
    return jsonify({'status': 'healthy'})

@app.route('/lesson/list', methods=['POST'])
def get_lessons():
    """Get the list of lessons for a user"""
    data = request.json
    user_id = data.get('user_id')
    if not user_id:
        return jsonify({'error': 'Missing user_id parameter'}), 400
    
    lessons = get_lesson_list(user_id)
    return jsonify({'lessons': lessons})

@app.route('/lesson/add', methods=['POST'])
def add_lesson():
    """Add a new lesson for a user"""
    data = request.json
    user_id = data.get('user_id')
    lesson_id = data.get('lesson_id')
    lesson_name = data.get('lesson_name')
    
    if not all([user_id, lesson_id, lesson_name]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    add_new_lesson(user_id, lesson_id, lesson_name)
    return jsonify({'status': 'success'})

@app.route('/lesson/audio/download', methods=['POST'])
def download_audio():
    """Get download URL for lesson audio"""
    data = request.json
    user_id = data.get('user_id')
    lesson_id = data.get('lesson_id')
    
    if not all([user_id, lesson_id]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    download_url = get_download_url_for_lesson_audio(user_id, lesson_id)
    return jsonify({'download_url': download_url})

@app.route('/lesson/transcript/download', methods=['POST'])
def download_transcript():
    """Get download URL for lesson transcript"""
    data = request.json
    user_id = data.get('user_id')
    lesson_id = data.get('lesson_id')
    
    if not all([user_id, lesson_id]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    download_url = get_download_url_for_lesson_transcript(user_id, lesson_id)
    return jsonify({'download_url': download_url})

@app.route('/lesson/summary/download', methods=['POST'])
def download_summary():
    """Get download URL for lesson summary"""
    data = request.json
    user_id = data.get('user_id')
    lesson_id = data.get('lesson_id')
    
    if not all([user_id, lesson_id]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    download_url = get_download_url_for_lesson_summary(user_id, lesson_id)
    return jsonify({'download_url': download_url})

if __name__ == '__main__':

    # Set the port for the Flask app
    port = int(os.environ.get('PORT', 8080))
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=port, debug=False)

