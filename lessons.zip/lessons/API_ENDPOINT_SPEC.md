# Downloader Service API Specification

This document specifies the endpoints available in the Downloader Service API, which provides functionality for managing lessons and retrieving associated resources from Google Cloud Storage.

## Base URL
```
https://<host>:<port>
```

## Authentication
Currently, the API does not implement authentication. User identification is done through the `user_id` parameter in the request body.

## Data Formats
All endpoints accept and return JSON data.

## Endpoints

### Health Check
**Endpoint:** `/health`  
**Method:** GET  
**Description:** Simple health check to verify the service is running.

**Response:**
```json
{
  "status": "healthy"
}
```

### List Lessons
**Endpoint:** `/lesson/list`  
**Method:** POST  
**Description:** Retrieves a list of lessons associated with a specific user.

**Request Body:**
```json
{
  "user_id": "string" // Required: Unique identifier for the user
}
```

**Success Response (200 OK):**
```json
{
  "lessons": [
    {
      "id": "string", // Unique lesson identifier
      "name": "string" // Display name of the lesson
    }
  ]
}
```

**Error Response (400 Bad Request):**
```json
{
  "error": "Missing user_id parameter"
}
```

### Add Lesson
**Endpoint:** `/lesson/add`  
**Method:** POST  
**Description:** Adds a new lesson for a specific user.

**Request Body:**
```json
{
  "user_id": "string",    // Required: Unique identifier for the user
  "lesson_id": "string",  // Required: Unique identifier for the lesson
  "lesson_name": "string" // Required: Display name of the lesson
}
```

**Success Response (200 OK):**
```json
{
  "status": "success"
}
```

**Error Response (400 Bad Request):**
```json
{
  "error": "Missing required parameters"
}
```

### Download Lesson Audio
**Endpoint:** `/lesson/audio/download`  
**Method:** POST  
**Description:** Generates a signed URL for downloading the audio file of a specific lesson.

**Request Body:**
```json
{
  "user_id": "string",   // Required: Unique identifier for the user
  "lesson_id": "string"  // Required: Unique identifier for the lesson
}
```

**Success Response (200 OK):**
```json
{
  "download_url": "string" // Signed URL for downloading the audio file
}
```

**Error Response (400 Bad Request):**
```json
{
  "error": "Missing required parameters"
}
```

### Download Lesson Transcript
**Endpoint:** `/lesson/transcript/download`  
**Method:** POST  
**Description:** Generates a signed URL for downloading the transcript of a specific lesson.

**Request Body:**
```json
{
  "user_id": "string",   // Required: Unique identifier for the user
  "lesson_id": "string"  // Required: Unique identifier for the lesson
}
```

**Success Response (200 OK):**
```json
{
  "download_url": "string" // Signed URL for downloading the transcript file
}
```

**Error Response (400 Bad Request):**
```json
{
  "error": "Missing required parameters"
}
```

### Download Lesson Summary
**Endpoint:** `/lesson/summary/download`  
**Method:** POST  
**Description:** Generates a signed URL for downloading the summary of a specific lesson.

**Request Body:**
```json
{
  "user_id": "string",   // Required: Unique identifier for the user
  "lesson_id": "string"  // Required: Unique identifier for the lesson
}
```

**Success Response (200 OK):**
```json
{
  "download_url": "string" // Signed URL for downloading the summary file
}
```

**Error Response (400 Bad Request):**
```json
{
  "error": "Missing required parameters"
}
```

## Technical Details

### Storage Details
- Lessons are stored in Google Cloud Storage bucket named `lesson-bucket8`
- User data is stored in Firestore collection named `users_data`
- Files associated with lessons follow this naming pattern:
  - Audio: `<lesson_id>/audio.mp4`
  - Transcript: `<lesson_id>/transcript.txt`
  - Summary: `<lesson_id>/summary.txt`

### Signed URLs
- Download URLs are generated as GCS signed URLs
- Default expiration time for signed URLs is 300 seconds (5 minutes)

## Data Structure
User data in Firestore follows this structure:
```json
{
  "lesson_list": [
    {
      "id": "lesson_id",
      "name": "lesson_name",
      "created_at": "2021-01-01T00:00:00"
    }
  ]
}
``` 