# AMS Launcher - Android Custom Launcher

A modern, customizable Android launcher built with Kotlin and Jetpack Compose, featuring custom wallpapers, icon customization, and home screen personalization.

## Features

### 🏠 **Home Screen Launcher**
- Complete replacement for your default Android launcher
- Clean, modern Material Design 3 interface
- Smooth animations and transitions
- Edge-to-edge display support

### 🔍 **App Management**
- Search functionality to quickly find apps
- Grid-based app layout with customizable columns and rows
- Support for both system and user-installed apps
- App launching with proper intent handling

### 🎨 **Customization Options**
- **Wallpapers**: Choose from built-in gradients or set custom wallpapers
- **Icon Size**: Adjustable icon sizes (0.5x to 2.0x)
- **Grid Layout**: Customizable grid (3-6 columns, 4-8 rows)
- **App Labels**: Toggle app name display
- **Haptic Feedback**: Vibration feedback on interactions

### 🖼️ **Wallpaper System**
- Built-in gradient wallpapers (Ocean, Sunset, Forest, Purple themes)
- Custom wallpaper support from gallery
- Wallpaper preview and selection
- Automatic wallpaper management

### ⚙️ **Settings & Configuration**
- Comprehensive settings screen
- Real-time preview of changes
- Persistent settings using DataStore
- Easy default launcher setup

## Installation & Setup

### Prerequisites
- Android Studio Arctic Fox or later
- Android SDK 30 or higher
- Kotlin 1.8+

### Building the App
1. Clone the repository
2. Open in Android Studio
3. Sync Gradle dependencies
4. Build and run on device/emulator

### Setting as Default Launcher
1. Install the app on your device
2. Open the app and go to Settings
3. Tap "Set as Default Launcher"
4. Choose "AMS Launcher" from the system dialog
5. Set as default for home screen

## Architecture

### Tech Stack
- **Kotlin** - Primary programming language
- **Jetpack Compose** - Modern UI toolkit
- **Material Design 3** - Design system
- **DataStore** - Settings persistence
- **Coroutines** - Asynchronous programming
- **ViewModel** - UI state management
- **Repository Pattern** - Data management

### Project Structure
```
app/src/main/java/com/example/amstest/
├── data/                    # Data models
│   ├── AppInfo.kt          # App information model
│   └── LauncherSettings.kt # Settings data classes
├── repository/             # Data layer
│   └── AppRepository.kt    # App and settings management
├── viewmodel/              # Presentation layer
│   └── LauncherViewModel.kt # UI state management
├── ui/
│   ├── components/         # Reusable UI components
│   │   ├── AppIcon.kt      # App icon display
│   │   ├── SearchBar.kt    # Search functionality
│   │   └── WallpaperBackground.kt # Wallpaper display
│   ├── screens/            # Screen composables
│   │   ├── LauncherScreen.kt # Main home screen
│   │   └── WallpaperPickerScreen.kt # Wallpaper selection
│   └── settings/           # Settings screens
│       └── SettingsActivity.kt # Settings configuration
├── wallpaper/              # Wallpaper management
│   └── WallpaperService.kt # Wallpaper operations
└── utils/                  # Utility classes
    └── PermissionUtils.kt  # Permission handling
```

## Permissions

The app requires the following permissions:
- `QUERY_ALL_PACKAGES` - To list installed apps
- `SET_WALLPAPER` - To change wallpapers
- `SET_WALLPAPER_HINTS` - Wallpaper optimization
- `WRITE_SETTINGS` - System settings access
- `WRITE_EXTERNAL_STORAGE` - File access (Android < 10)
- `READ_EXTERNAL_STORAGE` - File reading
- `VIBRATE` - Haptic feedback

## Usage

### Basic Navigation
- **Home Screen**: Displays all installed apps in a customizable grid
- **Search**: Tap the search bar to find apps quickly
- **Settings**: Tap the settings icon (top-right) to customize

### Customization
1. **Change Wallpaper**:
   - Go to Settings → Appearance → Change Wallpaper
   - Choose from built-in gradients or select custom image

2. **Adjust Icon Size**:
   - Settings → Appearance → Icon Size
   - Use slider to adjust from 0.5x to 2.0x

3. **Modify Grid Layout**:
   - Settings → Grid Layout
   - Adjust columns (3-6) and rows (4-8)

4. **Toggle Features**:
   - App Labels: Show/hide app names
   - Haptic Feedback: Enable/disable vibrations

### Setting as Default
1. Open Settings in the launcher
2. Tap "Set as Default Launcher"
3. Select AMS Launcher from system options
4. Choose "Always" to set as default

## Development

### Adding New Features
1. **New Settings**: Add to `LauncherSettings` data class and update repository
2. **UI Components**: Create in `ui/components/` following Material Design
3. **Screens**: Add to `ui/screens/` with proper navigation
4. **Wallpapers**: Extend `WallpaperService` for new wallpaper types

### Testing
- Unit tests for ViewModels and Repository
- UI tests for Compose screens
- Integration tests for launcher functionality

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Troubleshooting

### Common Issues
1. **App not showing as launcher option**:
   - Ensure proper intent filters in AndroidManifest.xml
   - Check that HOME category is included

2. **Wallpaper not changing**:
   - Verify SET_WALLPAPER permission is granted
   - Check file access permissions

3. **Apps not loading**:
   - Ensure QUERY_ALL_PACKAGES permission (Android 11+)
   - Check package manager queries

### Support
For issues and feature requests, please create an issue in the repository.

---

**AMS Launcher** - Making Android home screens beautiful and functional! 🚀 