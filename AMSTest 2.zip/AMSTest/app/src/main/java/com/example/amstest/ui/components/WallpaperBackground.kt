package com.example.amstest.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File

@Composable
fun WallpaperBackground(
    wallpaperPath: String?,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    
    Box(modifier = modifier.fillMaxSize()) {
        // Background
        when {
            wallpaperPath != null && File(wallpaperPath).exists() -> {
                // Custom wallpaper from file
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(wallpaperPath)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            wallpaperPath != null -> {
                // Built-in gradient wallpapers
                when (wallpaperPath) {
                    "gradient_1" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFF667eea),
                                            Color(0xFF764ba2)
                                        )
                                    )
                                )
                        )
                    }
                    "gradient_2" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFFf093fb),
                                            Color(0xFFf5576c)
                                        )
                                    )
                                )
                        )
                    }
                    "gradient_3" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFF4facfe),
                                            Color(0xFF00f2fe)
                                        )
                                    )
                                )
                        )
                    }
                    "gradient_4" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFF43e97b),
                                            Color(0xFF38f9d7)
                                        )
                                    )
                                )
                        )
                    }
                    "solid_dark" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF121212))
                        )
                    }
                    "solid_light" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFFF5F5F5))
                        )
                    }
                    else -> {
                        // Default gradient background
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFF1A1A2E),
                                            Color(0xFF16213E),
                                            Color(0xFF0F3460)
                                        )
                                    )
                                )
                        )
                    }
                }
            }
            else -> {
                // Default gradient background
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF1A1A2E),
                                    Color(0xFF16213E),
                                    Color(0xFF0F3460)
                                )
                            )
                        )
                )
            }
        }
        
        // Overlay for better text readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.2f))
        )
        
        // Content
        content()
    }
}

@Composable
fun BlurredWallpaperBackground(
    wallpaperPath: String?,
    blurRadius: Float = 10f,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    
    Box(modifier = modifier.fillMaxSize()) {
        // Blurred background
        if (wallpaperPath != null && File(wallpaperPath).exists()) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(wallpaperPath)
                    .crossfade(true)
                    .build(),
                contentDescription = "Blurred Wallpaper",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .blur(blurRadius.dp)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF2D1B69),
                                Color(0xFF11998E),
                                Color(0xFF38EF7D)
                            )
                        )
                    )
                    .blur(blurRadius.dp)
            )
        }
        
        // Dark overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.4f))
        )
        
        // Content
        content()
    }
} 