package com.example.amstest.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.example.amstest.data.AppInfo
import com.example.amstest.data.HomeScreenShortcut

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    shortcuts: List<HomeScreenShortcut>,
    favoriteApps: List<AppInfo>,
    columns: Int = 4,
    rows: Int = 5,
    iconSize: Float = 1.0f,
    showLabels: Boolean = true,
    isEditMode: Boolean = false,
    onAppClick: (String) -> Unit,
    onAppLongClick: (AppInfo) -> Unit,
    onAddShortcut: () -> Unit,
    onSwipeUp: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val totalSlots = columns * rows
    val density = LocalDensity.current
    
    Box(modifier = modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 8.dp,
                bottom = 80.dp // Space for swipe indicator
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Display shortcuts first
            items(shortcuts) { shortcut ->
                HomeScreenShortcutItem(
                    shortcut = shortcut,
                    iconSize = iconSize,
                    showLabel = showLabels,
                    isEditMode = isEditMode,
                    onClick = { onAppClick(shortcut.packageName) },
                    onLongClick = { /* Handle shortcut long click */ }
                )
            }
            
            // Fill remaining slots with favorite apps (up to available space)
            val remainingSlots = totalSlots - shortcuts.size
            val availableFavorites = favoriteApps.take(remainingSlots.coerceAtLeast(0))
            
            items(availableFavorites) { app ->
                HomeScreenAppItem(
                    appInfo = app,
                    iconSize = iconSize,
                    showLabel = showLabels,
                    isEditMode = isEditMode,
                    onClick = { onAppClick(app.packageName) },
                    onLongClick = { onAppLongClick(app) }
                )
            }
            
            // Add shortcut button if in edit mode and there's space
            if (isEditMode && (shortcuts.size + availableFavorites.size) < totalSlots) {
                item {
                    AddShortcutButton(
                        iconSize = iconSize,
                        onClick = onAddShortcut
                    )
                }
            }
        }
        
        // Enhanced swipe detection overlay for better responsiveness
        if (onSwipeUp != null && !isEditMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragStart = { },
                            onDragEnd = { },
                            onVerticalDrag = { _, dragAmount ->
                                // Detect upward swipe anywhere on screen
                                val swipeThreshold = with(density) { 15.dp.toPx() }
                                if (dragAmount < -swipeThreshold) {
                                    onSwipeUp()
                                }
                            }
                        )
                    }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreenShortcutItem(
    shortcut: HomeScreenShortcut,
    iconSize: Float = 1.0f,
    showLabel: Boolean = true,
    isEditMode: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val iconSizeDp = (64 * iconSize).dp
    val textSizeSp = (12 * iconSize).sp
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(iconSizeDp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (isEditMode) Color.White.copy(alpha = 0.2f) 
                    else Color.White.copy(alpha = 0.1f),
                    RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            // Use the same icon rendering logic as AppIcon
            val iconBitmap = remember(shortcut.icon, iconSizeDp) {
                try {
                    shortcut.icon.toBitmap(
                        width = (iconSizeDp.value * 0.8f).toInt(),
                        height = (iconSizeDp.value * 0.8f).toInt()
                    )
                } catch (e: Exception) {
                    null
                }
            }
            
            if (iconBitmap != null) {
                androidx.compose.foundation.Image(
                    bitmap = iconBitmap.asImageBitmap(),
                    contentDescription = shortcut.appName,
                    modifier = Modifier
                        .size((iconSizeDp.value * 0.8).dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            } else {
                // Fallback
                Box(
                    modifier = Modifier
                        .size((iconSizeDp.value * 0.8).dp)
                        .background(
                            MaterialTheme.colorScheme.primary,
                            RoundedCornerShape(12.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = shortcut.appName.take(1).uppercase(),
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = (textSizeSp.value * 1.5).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        
        if (showLabel) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = shortcut.appName,
                color = Color.White,
                fontSize = textSizeSp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier = Modifier.width(iconSizeDp + 16.dp)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreenAppItem(
    appInfo: AppInfo,
    iconSize: Float = 1.0f,
    showLabel: Boolean = true,
    isEditMode: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    AppIcon(
        appInfo = appInfo,
        iconSize = iconSize,
        showLabel = showLabel,
        onClick = onClick,
        modifier = Modifier.combinedClickable(
            onClick = onClick,
            onLongClick = onLongClick
        )
    )
}

@Composable
fun AddShortcutButton(
    iconSize: Float = 1.0f,
    onClick: () -> Unit
) {
    val iconSizeDp = (64 * iconSize).dp
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .padding(8.dp)
    ) {
        Card(
            onClick = onClick,
            modifier = Modifier.size(iconSizeDp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White.copy(alpha = 0.1f)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Shortcut",
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size((iconSizeDp.value * 0.5).dp)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Add",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = (12 * iconSize).sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
} 