package com.example.amstest.data

import android.graphics.drawable.Drawable

data class AppInfo(
    val packageName: String,
    val appName: String,
    val icon: Drawable,
    val isSystemApp: Boolean = false,
    val isHidden: Boolean = false,
    val customIconPath: String? = null,
    val position: Int = -1,
    val isFavorite: Boolean = false
)

data class HomeScreenShortcut(
    val id: String,
    val packageName: String,
    val appName: String,
    val icon: Drawable,
    val position: HomeScreenPosition,
    val customIconPath: String? = null
)

data class HomeScreenPosition(
    val row: Int,
    val column: Int
)

data class LauncherSettings(
    val wallpaperPath: String? = null,
    val iconSize: Float = 1.0f,
    val gridColumns: Int = 4,
    val gridRows: Int = 6,
    val showAppLabels: Boolean = true,
    val enableHapticFeedback: Boolean = true,
    val theme: LauncherTheme = LauncherTheme.SYSTEM,
    val homeScreenColumns: Int = 4,
    val homeScreenRows: Int = 5,
    val showHomeScreenLabels: Boolean = true
)

enum class LauncherTheme {
    LIGHT, DARK, SYSTEM
}

data class WallpaperInfo(
    val id: String,
    val name: String,
    val path: String,
    val isBuiltIn: Boolean = false,
    val thumbnail: String? = null
)

/**
 * Represents a user profile in the multi-user system
 */
data class UserProfile(
    val id: Int,
    val name: String,
    val isCurrentUser: Boolean = false,
    val isSystemUser: Boolean = false,
    val isGuest: Boolean = false,
    val creationTime: Long = System.currentTimeMillis(),
    val lastActiveTime: Long = System.currentTimeMillis()
) 