package com.example.amstest.repository

import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.UserHandle
import android.os.UserManager
import android.util.Log
import com.example.amstest.data.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserProfileManager(private val context: Context) {
    
    private val userManager = context.getSystemService(Context.USER_SERVICE) as UserManager
    private val devicePolicyManager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    
    private val _userProfiles = MutableStateFlow<List<UserProfile>>(emptyList())
    val userProfiles: StateFlow<List<UserProfile>> = _userProfiles.asStateFlow()
    
    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()
    
    companion object {
        private const val TAG = "UserProfileManager"
        private const val GUEST_USER_NAME = "Guest"
    }
    
    init {
        refreshUserProfiles()
    }
    
    /**
     * Refresh the list of user profiles
     */
    fun refreshUserProfiles() {
        try {
            // Since UserInfo is a hidden API, we'll create a fallback approach
            // that works with the current user and any additional users we can detect
            createFallbackProfile()
            
            Log.d(TAG, "Refreshed user profiles using fallback method")
        } catch (e: SecurityException) {
            Log.e(TAG, "Security exception when accessing user profiles", e)
            createFallbackProfile()
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing user profiles", e)
            createFallbackProfile()
        }
    }
    
    /**
     * Create a fallback profile when user enumeration fails
     */
    private fun createFallbackProfile() {
        try {
            val currentUserId = android.os.Process.myUserHandle().hashCode()
            val fallbackProfile = UserProfile(
                id = currentUserId,
                name = "Current User",
                isCurrentUser = true,
                isSystemUser = currentUserId == 0,
                isGuest = false
            )
            
            _userProfiles.value = listOf(fallbackProfile)
            _currentUser.value = fallbackProfile
            
            Log.d(TAG, "Created fallback user profile")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating fallback profile", e)
        }
    }
    
    /**
     * Create a new user profile
     */
    fun createUserProfile(name: String, skipSetupWizard: Boolean = true): Boolean {
        return try {
            Log.d(TAG, "Attempting to create user profile: $name")
            
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
                Log.w(TAG, "Multi-user not supported on this Android version")
                return false
            }
            
            if (!canCreateUsers()) {
                Log.w(TAG, "Cannot create users - insufficient permissions or restrictions")
                return false
            }
            
            Log.d(TAG, "Permissions check passed, attempting to create user...")
            
            // Try to create user using reflection since createUser is not in public API
            val success = try {
                val createUserMethod = userManager.javaClass.getMethod("createUser", String::class.java, Int::class.javaPrimitiveType)
                val userInfo = createUserMethod.invoke(userManager, name, 0) // 0 = no special flags
                
                if (userInfo != null) {
                    Log.d(TAG, "User created successfully: $userInfo")
                    
                    if (skipSetupWizard) {
                        Log.d(TAG, "Attempting to skip setup wizard...")
                        // Try to skip setup wizard using reflection
                        try {
                            val setUserSetupCompleteMethod = android.provider.Settings.Secure::class.java.getMethod(
                                "putIntForUser", 
                                android.content.ContentResolver::class.java,
                                String::class.java,
                                Int::class.javaPrimitiveType,
                                Int::class.javaPrimitiveType
                            )
                            setUserSetupCompleteMethod.invoke(
                                null,
                                context.contentResolver,
                                "user_setup_complete",
                                1,
                                (userInfo as Any).javaClass.getField("id").getInt(userInfo)
                            )
                            Log.d(TAG, "Setup wizard skipped successfully")
                        } catch (e: Exception) {
                            Log.w(TAG, "Could not skip setup wizard", e)
                        }
                    }
                    
                    refreshUserProfiles()
                    true
                } else {
                    Log.e(TAG, "User creation returned null")
                    false
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create user via reflection", e)
                false
            }
            
            success
        } catch (e: Exception) {
            Log.e(TAG, "Error creating user profile", e)
            false
        }
    }
    
    /**
     * Create a guest user profile
     */
    fun createGuestProfile(): Boolean {
        return try {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.LOLLIPOP) {
                Log.w(TAG, "Guest users not supported on this Android version")
                return false
            }
            
            if (!canCreateUsers()) {
                Log.w(TAG, "Cannot create guest user - insufficient permissions")
                return false
            }
            
            // Try to create guest user using reflection
            try {
                val guestUser = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                    val createGuestMethod = userManager.javaClass.getMethod("createGuest", Context::class.java, String::class.java)
                    createGuestMethod.invoke(userManager, context, GUEST_USER_NAME)
                } else {
                    // Fallback for older versions using createUser with guest flag
                    val createUserMethod = userManager.javaClass.getMethod("createUser", String::class.java, Int::class.javaPrimitiveType)
                    createUserMethod.invoke(userManager, GUEST_USER_NAME, 0x00000004) // FLAG_GUEST
                }
                
                if (guestUser != null) {
                    // Get user ID using reflection
                    val idField = guestUser.javaClass.getField("id")
                    val userId = idField.getInt(guestUser)
                    
                    Log.d(TAG, "Successfully created guest user with ID: $userId")
                    refreshUserProfiles()
                    true
                } else {
                    Log.e(TAG, "Failed to create guest user")
                    false
                }
            } catch (e: Exception) {
                Log.e(TAG, "Could not create guest user via reflection", e)
                false
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Security exception when creating guest user", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Error creating guest user", e)
            false
        }
    }
    
    /**
     * Switch to a different user profile
     */
    fun switchToUser(userId: Int): Boolean {
        return try {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
                Log.w(TAG, "User switching not supported on this Android version")
                return false
            }
            
            if (!canSwitchUsers()) {
                Log.w(TAG, "Cannot switch users - insufficient permissions")
                return false
            }
            
            // Try to switch user using reflection since switchUser is not in public API
            val success = try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                    // Try UserManager.switchUser via reflection
                    val switchUserMethod = userManager.javaClass.getMethod("switchUser", Int::class.javaPrimitiveType)
                    switchUserMethod.invoke(userManager, userId) as? Boolean ?: false
                } else {
                    // For older versions, try using ActivityManager via reflection
                    try {
                        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                        val switchUserMethod = activityManager.javaClass.getMethod("switchUser", Int::class.javaPrimitiveType)
                        switchUserMethod.invoke(activityManager, userId) as? Boolean ?: false
                    } catch (e: Exception) {
                        Log.w(TAG, "ActivityManager.switchUser not available via reflection", e)
                        false
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not switch user via reflection", e)
                false
            }
            
            if (success) {
                Log.d(TAG, "Successfully initiated switch to user: $userId")
            } else {
                Log.e(TAG, "Failed to switch to user: $userId")
            }
            success
        } catch (e: SecurityException) {
            Log.e(TAG, "Security exception when switching to user: $userId", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Error switching to user: $userId", e)
            false
        }
    }
    
    /**
     * Remove a user profile
     */
    fun removeUserProfile(userId: Int): Boolean {
        return try {
            if (userId == 0) { // System user ID is 0
                Log.w(TAG, "Cannot remove system user")
                return false
            }
            
            if (!canRemoveUsers()) {
                Log.w(TAG, "Cannot remove users - insufficient permissions")
                return false
            }
            
            // Try to remove user using reflection since removeUser is not in public API
            val success = try {
                val removeUserMethod = userManager.javaClass.getMethod("removeUser", Int::class.javaPrimitiveType)
                removeUserMethod.invoke(userManager, userId) as? Boolean ?: false
            } catch (e: Exception) {
                Log.w(TAG, "Could not remove user via reflection", e)
                false
            }
            
            if (success) {
                Log.d(TAG, "Successfully removed user: $userId")
                refreshUserProfiles()
            } else {
                Log.e(TAG, "Failed to remove user: $userId")
            }
            success
        } catch (e: SecurityException) {
            Log.e(TAG, "Security exception when removing user: $userId", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Error removing user: $userId", e)
            false
        }
    }
    
    /**
     * Check if the app can create users
     */
    fun canCreateUsers(): Boolean {
        return try {
            Log.d(TAG, "Checking if can create users...")
            
            // Try to check if can add more users using reflection since canAddMoreUsers is not in public API
            val canAddMore = try {
                val canAddMoreUsersMethod = userManager.javaClass.getMethod("canAddMoreUsers")
                val result = canAddMoreUsersMethod.invoke(userManager) as? Boolean ?: false
                Log.d(TAG, "canAddMoreUsers result: $result")
                result
            } catch (e: Exception) {
                Log.w(TAG, "Could not check canAddMoreUsers via reflection, assuming false", e)
                false
            }
            
            val hasRestriction = userManager.hasUserRestriction(UserManager.DISALLOW_ADD_USER)
            Log.d(TAG, "hasUserRestriction(DISALLOW_ADD_USER): $hasRestriction")
            
            val finalResult = canAddMore && !hasRestriction
            Log.d(TAG, "Final canCreateUsers result: $finalResult")
            
            finalResult
        } catch (e: Exception) {
            Log.e(TAG, "Error checking if can create users", e)
            false
        }
    }
    
    /**
     * Check if the app can switch users
     */
    fun canSwitchUsers(): Boolean {
        return try {
            !userManager.hasUserRestriction(UserManager.DISALLOW_USER_SWITCH)
        } catch (e: Exception) {
            Log.e(TAG, "Error checking if can switch users", e)
            false
        }
    }
    
    /**
     * Check if the app can remove users
     */
    fun canRemoveUsers(): Boolean {
        return try {
            !userManager.hasUserRestriction(UserManager.DISALLOW_REMOVE_USER)
        } catch (e: Exception) {
            Log.e(TAG, "Error checking if can remove users", e)
            false
        }
    }
    
    /**
     * Skip setup wizard for a specific user
     */
    private fun skipSetupWizardForUser(userId: Int) {
        try {
            // This requires system-level permissions and may not work on all devices
            val intent = Intent("android.intent.action.USER_INITIALIZE")
            intent.putExtra("android.intent.extra.USER_HANDLE", userId)
            context.sendBroadcast(intent)
            
            Log.d(TAG, "Attempted to skip setup wizard for user: $userId")
        } catch (e: Exception) {
            Log.w(TAG, "Could not skip setup wizard for user: $userId", e)
        }
    }
    
    /**
     * Get the maximum number of users that can be created
     */
    fun getMaxUsers(): Int {
        return try {
            // Try to get max supported users using reflection since getMaxSupportedUsers is not in public API
            try {
                val getMaxSupportedUsersMethod = UserManager::class.java.getMethod("getMaxSupportedUsers")
                getMaxSupportedUsersMethod.invoke(null) as? Int ?: 4 // Default fallback
            } catch (e: Exception) {
                Log.w(TAG, "Could not get max supported users via reflection, using default", e)
                4 // Default fallback
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting max users", e)
            4 // Default fallback
        }
    }
    
    /**
     * Check if multi-user is supported on this device
     */
    fun isMultiUserSupported(): Boolean {
        return try {
            UserManager.supportsMultipleUsers()
        } catch (e: Exception) {
            Log.e(TAG, "Error checking multi-user support", e)
            false
        }
    }
} 