package com.example.amstest.wallpaper

import android.app.Service
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class WallpaperService : Service() {
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    companion object {
        fun setWallpaper(context: Context, uri: Uri) {
            val intent = Intent(context, WallpaperService::class.java).apply {
                data = uri
                action = "SET_WALLPAPER"
            }
            context.startService(intent)
        }
        
        fun setWallpaperFromPath(context: Context, path: String) {
            val intent = Intent(context, WallpaperService::class.java).apply {
                putExtra("wallpaper_path", path)
                action = "SET_WALLPAPER_FROM_PATH"
            }
            context.startService(intent)
        }
        
        fun getBuiltInWallpapers(context: Context): List<String> {
            // Return list of built-in wallpaper paths
            // In a real app, you'd have wallpapers in assets or drawable
            return listOf(
                "android.resource://${context.packageName}/drawable/wallpaper_1",
                "android.resource://${context.packageName}/drawable/wallpaper_2",
                "android.resource://${context.packageName}/drawable/wallpaper_3"
            )
        }
        
        fun saveWallpaperToInternalStorage(context: Context, uri: Uri): String? {
            return try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                
                val filename = "wallpaper_${System.currentTimeMillis()}.jpg"
                val file = File(context.filesDir, filename)
                val outputStream = FileOutputStream(file)
                
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
                outputStream.close()
                
                file.absolutePath
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let { serviceIntent ->
            when (serviceIntent.action) {
                "SET_WALLPAPER" -> {
                    serviceIntent.data?.let { uri ->
                        setWallpaperFromUri(uri)
                    }
                }
                "SET_WALLPAPER_FROM_PATH" -> {
                    serviceIntent.getStringExtra("wallpaper_path")?.let { path ->
                        setWallpaperFromFilePath(path)
                    }
                }
            }
        }
        return START_NOT_STICKY
    }
    
    private fun setWallpaperFromUri(uri: Uri) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val wallpaperManager = WallpaperManager.getInstance(this@WallpaperService)
                val inputStream = contentResolver.openInputStream(uri)
                wallpaperManager.setStream(inputStream)
                inputStream?.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    private fun setWallpaperFromFilePath(path: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val wallpaperManager = WallpaperManager.getInstance(this@WallpaperService)
                val bitmap = BitmapFactory.decodeFile(path)
                wallpaperManager.setBitmap(bitmap)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
} 