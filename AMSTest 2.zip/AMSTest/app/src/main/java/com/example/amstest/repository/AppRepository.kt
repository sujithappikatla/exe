package com.example.amstest.repository

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.amstest.data.AppInfo
import com.example.amstest.data.HomeScreenShortcut
import com.example.amstest.data.HomeScreenPosition
import com.example.amstest.data.LauncherSettings
import com.example.amstest.data.LauncherTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "launcher_settings")

class AppRepository(private val context: Context) {
    
    private val packageManager = context.packageManager
    
    // DataStore keys
    private val WALLPAPER_PATH = stringPreferencesKey("wallpaper_path")
    private val ICON_SIZE = floatPreferencesKey("icon_size")
    private val GRID_COLUMNS = intPreferencesKey("grid_columns")
    private val GRID_ROWS = intPreferencesKey("grid_rows")
    private val SHOW_APP_LABELS = booleanPreferencesKey("show_app_labels")
    private val ENABLE_HAPTIC_FEEDBACK = booleanPreferencesKey("enable_haptic_feedback")
    private val THEME = stringPreferencesKey("theme")
    private val HOME_SCREEN_COLUMNS = intPreferencesKey("home_screen_columns")
    private val HOME_SCREEN_ROWS = intPreferencesKey("home_screen_rows")
    private val SHOW_HOME_SCREEN_LABELS = booleanPreferencesKey("show_home_screen_labels")
    private val FAVORITE_APPS = stringSetPreferencesKey("favorite_apps")
    private val HOME_SHORTCUTS = stringPreferencesKey("home_shortcuts")
    
    fun getInstalledApps(): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        
        val resolveInfoList: List<ResolveInfo> = packageManager.queryIntentActivities(intent, 0)
        
        return resolveInfoList.map { resolveInfo ->
            val packageName = resolveInfo.activityInfo.packageName
            val appName = resolveInfo.loadLabel(packageManager).toString()
            val icon = resolveInfo.loadIcon(packageManager)
            val isSystemApp = isSystemApp(packageName)
            
            AppInfo(
                packageName = packageName,
                appName = appName,
                icon = icon,
                isSystemApp = isSystemApp
            )
        }.sortedBy { it.appName }
    }
    
    private fun isSystemApp(packageName: String): Boolean {
        return try {
            val packageInfo = packageManager.getPackageInfo(packageName, 0)
            (packageInfo.applicationInfo?.flags?.and(android.content.pm.ApplicationInfo.FLAG_SYSTEM) ?: 0) != 0
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }
    
    fun launchApp(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        launchIntent?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(it)
        }
    }
    
    // Settings management
    val launcherSettings: Flow<LauncherSettings> = context.dataStore.data.map { preferences ->
        LauncherSettings(
            wallpaperPath = preferences[WALLPAPER_PATH],
            iconSize = preferences[ICON_SIZE] ?: 1.0f,
            gridColumns = preferences[GRID_COLUMNS] ?: 4,
            gridRows = preferences[GRID_ROWS] ?: 6,
            showAppLabels = preferences[SHOW_APP_LABELS] ?: true,
            enableHapticFeedback = preferences[ENABLE_HAPTIC_FEEDBACK] ?: true,
            theme = LauncherTheme.valueOf(preferences[THEME] ?: LauncherTheme.SYSTEM.name),
            homeScreenColumns = preferences[HOME_SCREEN_COLUMNS] ?: 4,
            homeScreenRows = preferences[HOME_SCREEN_ROWS] ?: 5,
            showHomeScreenLabels = preferences[SHOW_HOME_SCREEN_LABELS] ?: true
        )
    }
    
    // Home screen shortcuts management
    suspend fun addToHomeScreen(appInfo: AppInfo, position: HomeScreenPosition) {
        // Implementation for adding shortcuts to home screen
        // This would typically involve serializing the shortcut data
    }
    
    suspend fun removeFromHomeScreen(shortcutId: String) {
        // Implementation for removing shortcuts from home screen
    }
    
    suspend fun getHomeScreenShortcuts(): List<HomeScreenShortcut> {
        // Implementation for retrieving home screen shortcuts
        // For now, return empty list - this would be implemented with proper serialization
        return emptyList()
    }
    
    suspend fun addToFavorites(packageName: String) {
        context.dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_APPS] ?: emptySet()
            preferences[FAVORITE_APPS] = currentFavorites + packageName
        }
    }
    
    suspend fun removeFromFavorites(packageName: String) {
        context.dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_APPS] ?: emptySet()
            preferences[FAVORITE_APPS] = currentFavorites - packageName
        }
    }
    
    val favoriteApps: Flow<Set<String>> = context.dataStore.data.map { preferences ->
        preferences[FAVORITE_APPS] ?: emptySet()
    }
    
    suspend fun updateWallpaper(path: String?) {
        context.dataStore.edit { preferences ->
            if (path != null) {
                preferences[WALLPAPER_PATH] = path
            } else {
                preferences.remove(WALLPAPER_PATH)
            }
        }
    }
    
    suspend fun updateIconSize(size: Float) {
        context.dataStore.edit { preferences ->
            preferences[ICON_SIZE] = size
        }
    }
    
    suspend fun updateGridSize(columns: Int, rows: Int) {
        context.dataStore.edit { preferences ->
            preferences[GRID_COLUMNS] = columns
            preferences[GRID_ROWS] = rows
        }
    }
    
    suspend fun updateHomeScreenGridSize(columns: Int, rows: Int) {
        context.dataStore.edit { preferences ->
            preferences[HOME_SCREEN_COLUMNS] = columns
            preferences[HOME_SCREEN_ROWS] = rows
        }
    }
    
    suspend fun updateShowAppLabels(show: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SHOW_APP_LABELS] = show
        }
    }
    
    suspend fun updateShowHomeScreenLabels(show: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SHOW_HOME_SCREEN_LABELS] = show
        }
    }
    
    suspend fun updateHapticFeedback(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[ENABLE_HAPTIC_FEEDBACK] = enabled
        }
    }
    
    suspend fun updateTheme(theme: LauncherTheme) {
        context.dataStore.edit { preferences ->
            preferences[THEME] = theme.name
        }
    }
} 