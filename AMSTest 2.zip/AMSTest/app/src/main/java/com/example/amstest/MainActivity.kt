package com.example.amstest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.amstest.ui.screens.LauncherHomeScreen
import com.example.amstest.ui.theme.AMSTestTheme
import com.google.accompanist.systemuicontroller.rememberSystemUiController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Configure window for full-screen launcher
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        setContent {
            AMSTestTheme {
                SetupSystemUI()
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Transparent // Make surface transparent
                ) {
                    LauncherHomeScreen()
                }
            }
        }
    }
    
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Prevent back button from closing the launcher
        // Do nothing or minimize to show home screen
    }
}

@Composable
fun SetupSystemUI() {
    val systemUiController = rememberSystemUiController()
    val view = LocalView.current
    
    SideEffect {
        // Make status bar completely transparent
        systemUiController.setStatusBarColor(
            color = Color.Transparent,
            darkIcons = false
        )
        
        // Make navigation bar completely transparent
        systemUiController.setNavigationBarColor(
            color = Color.Transparent,
            darkIcons = false
        )
        
        // Hide system bars for immersive experience
        systemUiController.isStatusBarVisible = true
        systemUiController.isNavigationBarVisible = true
        
        // Set system bars behavior for immersive mode
        val windowInsetsController = WindowInsetsControllerCompat(
            (view.context as ComponentActivity).window,
            view
        )
        windowInsetsController.systemBarsBehavior = 
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}