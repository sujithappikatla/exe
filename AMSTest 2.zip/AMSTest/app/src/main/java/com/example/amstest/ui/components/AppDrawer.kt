package com.example.amstest.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.amstest.data.AppInfo
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDrawer(
    isOpen: Boolean,
    apps: List<AppInfo>,
    searchQuery: String,
    isSearchActive: Boolean,
    columns: Int = 4,
    iconSize: Float = 1.0f,
    showLabels: Boolean = true,
    isEditMode: Boolean = false,
    onSearchQueryChange: (String) -> Unit,
    onSearchActiveChange: (Boolean) -> Unit,
    onAppClick: (AppInfo) -> Unit,
    onAppLongClick: ((AppInfo) -> Unit)? = null,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val configuration = LocalConfiguration.current
    val screenHeight = configuration.screenHeightDp.dp
    val density = LocalDensity.current
    
    // Improved animation for sliding up/down
    val offsetY by animateFloatAsState(
        targetValue = if (isOpen) 0f else 1f,
        animationSpec = tween(durationMillis = 250), // Faster animation
        label = "drawer_offset"
    )
    
    // Background overlay
    if (isOpen) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.3f))
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        // Allow closing by swiping down on background
                        val swipeThreshold = with(density) { 30.dp.toPx() }
                        if (dragAmount > swipeThreshold) {
                            onClose()
                        }
                    }
                }
        )
    }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                translationY = offsetY * with(density) { screenHeight.toPx() * 0.85f }
            }
    ) {
        Card(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { },
                        onDragEnd = { },
                        onVerticalDrag = { _, dragAmount ->
                            // More responsive drag to close
                            val swipeThreshold = with(density) { 20.dp.toPx() }
                            if (dragAmount > swipeThreshold) {
                                onClose()
                            }
                        }
                    )
                },
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isEditMode) 
                    Color.Gray.copy(alpha = 0.2f).copy(alpha = 0.95f) // Changed to gray
                else 
                    Color.Black.copy(alpha = 0.95f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding() // Add status bar padding to drawer content
            ) {
                // Drag Handle
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier
                            .width(50.dp)
                            .height(4.dp),
                        shape = RoundedCornerShape(2.dp),
                        color = Color.White.copy(alpha = 0.4f)
                    ) {}
                }
                
                // Header with close button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isEditMode) "Select Apps to Add" else "All Apps",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (isEditMode) {
                            Text(
                                text = "Tap apps to add to home screen",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 14.sp
                            )
                        }
                    }
                    
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                
                // Search Bar (hide in edit mode for simplicity)
                if (!isEditMode) {
                    LauncherSearchBar(
                        query = searchQuery,
                        onQueryChange = onSearchQueryChange,
                        isActive = isSearchActive,
                        onActiveChange = onSearchActiveChange,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                }
                
                // Apps Grid
                AppIconGrid(
                    apps = apps,
                    columns = columns,
                    iconSize = iconSize,
                    showLabels = showLabels,
                    onAppClick = onAppClick,
                    onAppLongClick = onAppLongClick,
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .navigationBarsPadding() // Add navigation bar padding to grid
                )
            }
        }
    }
}

@Composable
fun SwipeUpIndicator(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp), // Reduced padding
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            modifier = Modifier
                .width(80.dp) // Wider indicator
                .height(4.dp),
            shape = RoundedCornerShape(2.dp),
            color = Color.White.copy(alpha = 0.6f) // More visible
        ) {}
    }
} 