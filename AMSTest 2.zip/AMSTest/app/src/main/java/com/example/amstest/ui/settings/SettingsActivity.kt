package com.example.amstest.ui.settings

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.amstest.data.LauncherTheme
import com.example.amstest.ui.components.WallpaperBackground
import com.example.amstest.ui.theme.AMSTestTheme
import com.example.amstest.viewmodel.LauncherViewModel
import com.example.amstest.viewmodel.LauncherViewModelFactory

class SettingsActivity : ComponentActivity() {
    
    private lateinit var viewModel: LauncherViewModel
    
    private val wallpaperPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            // Save wallpaper to internal storage and update ViewModel
            val wallpaperPath = saveWallpaperToInternalStorage(it)
            wallpaperPath?.let { path ->
                viewModel.updateWallpaper(path)
            }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AMSTestTheme {
                viewModel = viewModel(factory = LauncherViewModelFactory(this@SettingsActivity))
                SettingsScreen(
                    viewModel = viewModel,
                    onWallpaperPick = {
                        wallpaperPickerLauncher.launch("image/*")
                    },
                    onSetAsDefaultLauncher = {
                        setAsDefaultLauncher()
                    },
                    onBack = {
                        finish()
                    }
                )
            }
        }
    }
    
    private fun saveWallpaperToInternalStorage(uri: Uri): String? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            
            val filename = "wallpaper_${System.currentTimeMillis()}.jpg"
            val file = java.io.File(filesDir, filename)
            val outputStream = java.io.FileOutputStream(file)
            
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, outputStream)
            outputStream.close()
            
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    
    private fun setAsDefaultLauncher() {
        val intent = Intent(Settings.ACTION_HOME_SETTINGS)
        startActivity(intent)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: LauncherViewModel,
    onWallpaperPick: () -> Unit,
    onSetAsDefaultLauncher: () -> Unit,
    onBack: () -> Unit
) {
    val settings by viewModel.launcherSettings.collectAsState()
    var showWallpaperPicker by remember { mutableStateOf(false) }
    
    WallpaperBackground(
        wallpaperPath = settings.wallpaperPath
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top App Bar
            TopAppBar(
                title = {
                    Text(
                        text = "Launcher Settings",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Black.copy(alpha = 0.3f)
                )
            )
            
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Default Launcher Section
                item {
                    SettingsSection(title = "Launcher") {
                        SettingsItem(
                            icon = Icons.Default.Home,
                            title = "Set as Default Launcher",
                            subtitle = "Make this your default home screen",
                            onClick = onSetAsDefaultLauncher
                        )
                    }
                }
                
                // Appearance Section
                item {
                    SettingsSection(title = "Appearance") {
                        SettingsItem(
                            icon = Icons.Default.Wallpaper,
                            title = "Change Wallpaper",
                            subtitle = "Customize your home screen background",
                            onClick = {
                                showWallpaperPicker = true
                            }
                        )
                        
                        SettingsSliderItem(
                            icon = Icons.Default.PhotoSizeSelectLarge,
                            title = "Icon Size",
                            subtitle = "Adjust app icon size",
                            value = settings.iconSize,
                            onValueChange = viewModel::updateIconSize,
                            valueRange = 0.5f..2.0f
                        )
                        
                        SettingsSwitchItem(
                            icon = Icons.Default.Label,
                            title = "Show App Labels",
                            subtitle = "Display app names below icons",
                            checked = settings.showAppLabels,
                            onCheckedChange = viewModel::updateShowAppLabels
                        )
                    }
                }
                
                // Grid Layout Section
                item {
                    SettingsSection(title = "Grid Layout") {
                        SettingsSliderItem(
                            icon = Icons.Default.GridView,
                            title = "Grid Columns",
                            subtitle = "Number of app columns",
                            value = settings.gridColumns.toFloat(),
                            onValueChange = { value ->
                                viewModel.updateGridSize(value.toInt(), settings.gridRows)
                            },
                            valueRange = 3f..6f,
                            steps = 3
                        )
                        
                        SettingsSliderItem(
                            icon = Icons.Default.ViewAgenda,
                            title = "Grid Rows",
                            subtitle = "Number of app rows",
                            value = settings.gridRows.toFloat(),
                            onValueChange = { value ->
                                viewModel.updateGridSize(settings.gridColumns, value.toInt())
                            },
                            valueRange = 4f..8f,
                            steps = 4
                        )
                    }
                }
                
                // Behavior Section
                item {
                    SettingsSection(title = "Behavior") {
                        SettingsSwitchItem(
                            icon = Icons.Default.Vibration,
                            title = "Haptic Feedback",
                            subtitle = "Vibrate when touching icons",
                            checked = settings.enableHapticFeedback,
                            onCheckedChange = viewModel::updateHapticFeedback
                        )
                    }
                }
            }
        }
    }
    
    // Wallpaper Picker Dialog
    if (showWallpaperPicker) {
        WallpaperPickerDialog(
            onWallpaperSelected = { wallpaperPath ->
                viewModel.updateWallpaper(wallpaperPath)
                showWallpaperPicker = false
            },
            onCustomWallpaperPick = {
                onWallpaperPick()
                showWallpaperPicker = false
            },
            onDismiss = {
                showWallpaperPicker = false
            }
        )
    }
}

@Composable
fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.Black.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            content()
        }
    }
}

@Composable
fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }
            
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
fun SettingsSwitchItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }
            
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color.Blue,
                    uncheckedThumbColor = Color.Gray,
                    uncheckedTrackColor = Color.DarkGray
                )
            )
        }
    }
}

@Composable
fun SettingsSliderItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
                
                Text(
                    text = if (steps > 0) value.toInt().toString() else String.format("%.1f", value),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = valueRange,
                steps = steps,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.Blue,
                    inactiveTrackColor = Color.Gray
                )
            )
        }
    }
}

@Composable
fun WallpaperPickerDialog(
    onWallpaperSelected: (String?) -> Unit,
    onCustomWallpaperPick: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Choose Wallpaper",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.height(300.dp)
            ) {
                // Default wallpaper
                item {
                    WallpaperOption(
                        title = "Default",
                        isDefault = true,
                        onClick = { onWallpaperSelected(null) }
                    )
                }
                
                // Built-in gradients
                item {
                    WallpaperOption(
                        title = "Ocean",
                        wallpaperId = "gradient_1",
                        onClick = { onWallpaperSelected("gradient_1") }
                    )
                }
                
                item {
                    WallpaperOption(
                        title = "Sunset",
                        wallpaperId = "gradient_2",
                        onClick = { onWallpaperSelected("gradient_2") }
                    )
                }
                
                item {
                    WallpaperOption(
                        title = "Sky",
                        wallpaperId = "gradient_3",
                        onClick = { onWallpaperSelected("gradient_3") }
                    )
                }
                
                item {
                    WallpaperOption(
                        title = "Nature",
                        wallpaperId = "gradient_4",
                        onClick = { onWallpaperSelected("gradient_4") }
                    )
                }
                
                // Custom wallpaper option
                item {
                    Card(
                        onClick = onCustomWallpaperPick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.7f),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White.copy(alpha = 0.1f)
                        )
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Custom",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Custom",
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = Color.Black.copy(alpha = 0.9f)
    )
}

@Composable
fun WallpaperOption(
    title: String,
    wallpaperId: String? = null,
    isDefault: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background preview
            when {
                isDefault -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF1A1A2E),
                                        Color(0xFF16213E),
                                        Color(0xFF0F3460)
                                    )
                                )
                            )
                    )
                }
                wallpaperId == "gradient_1" -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF667eea),
                                        Color(0xFF764ba2)
                                    )
                                )
                            )
                    )
                }
                wallpaperId == "gradient_2" -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFFf093fb),
                                        Color(0xFFf5576c)
                                    )
                                )
                            )
                    )
                }
                wallpaperId == "gradient_3" -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF4facfe),
                                        Color(0xFF00f2fe)
                                    )
                                )
                            )
                    )
                }
                wallpaperId == "gradient_4" -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF43e97b),
                                        Color(0xFF38f9d7)
                                    )
                                )
                            )
                    )
                }
            }
            
            // Overlay and title
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.3f))
                    .padding(8.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
} 