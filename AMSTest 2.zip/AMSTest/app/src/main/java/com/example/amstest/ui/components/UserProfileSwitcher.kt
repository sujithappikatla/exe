package com.example.amstest.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.amstest.data.UserProfile

@Composable
fun UserProfileSwitcher(
    currentUser: UserProfile?,
    userProfiles: List<UserProfile>,
    onSwitchUser: (Int) -> Unit,
    onCreateUser: (String) -> Unit,
    onCreateGuest: () -> Unit,
    onRemoveUser: (Int) -> Unit,
    canCreateUsers: Boolean = true,
    canSwitchUsers: Boolean = true,
    canRemoveUsers: Boolean = true,
    modifier: Modifier = Modifier
) {
    var showUserMenu by remember { mutableStateOf(false) }
    var showCreateUserDialog by remember { mutableStateOf(false) }
    
    // Current user display
    Row(
        modifier = modifier
            .clickable { showUserMenu = true }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // User avatar
        Box(
            modifier = Modifier
                .size(32.dp)
                .background(
                    if (currentUser?.isGuest == true) Color(0xFF4CAF50)
                    else if (currentUser?.isSystemUser == true) Color(0xFF2196F3)
                    else Color(0xFF9C27B0),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (currentUser?.isGuest == true) Icons.Default.Person
                else if (currentUser?.isSystemUser == true) Icons.Default.AdminPanelSettings
                else Icons.Default.AccountCircle,
                contentDescription = "User Avatar",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(8.dp))
        
        // User name
        Text(
            text = currentUser?.name ?: "Current User",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        
        Spacer(modifier = Modifier.width(4.dp))
        
        // Dropdown arrow
        Icon(
            imageVector = Icons.Default.ArrowDropDown,
            contentDescription = "User Menu",
            tint = Color.White.copy(alpha = 0.7f),
            modifier = Modifier.size(16.dp)
        )
    }
    
    // User menu dropdown
    if (showUserMenu) {
        UserMenuDialog(
            userProfiles = userProfiles,
            currentUser = currentUser,
            onDismiss = { showUserMenu = false },
            onSwitchUser = { userId ->
                onSwitchUser(userId)
                showUserMenu = false
            },
            onCreateUser = { 
                showCreateUserDialog = true
                showUserMenu = false
            },
            onCreateGuest = {
                onCreateGuest()
                showUserMenu = false
            },
            onRemoveUser = onRemoveUser,
            canCreateUsers = canCreateUsers,
            canSwitchUsers = canSwitchUsers,
            canRemoveUsers = canRemoveUsers
        )
    }
    
    // Create user dialog
    if (showCreateUserDialog) {
        CreateUserDialog(
            onDismiss = { showCreateUserDialog = false },
            onCreateUser = { name ->
                onCreateUser(name)
                showCreateUserDialog = false
            }
        )
    }
}

@Composable
private fun UserMenuDialog(
    userProfiles: List<UserProfile>,
    currentUser: UserProfile?,
    onDismiss: () -> Unit,
    onSwitchUser: (Int) -> Unit,
    onCreateUser: () -> Unit,
    onCreateGuest: () -> Unit,
    onRemoveUser: (Int) -> Unit,
    canCreateUsers: Boolean,
    canSwitchUsers: Boolean,
    canRemoveUsers: Boolean
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "User Profiles",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // List of user profiles
                userProfiles.forEach { profile ->
                    UserProfileItem(
                        profile = profile,
                        isCurrentUser = profile.id == currentUser?.id,
                        onSwitchUser = { if (canSwitchUsers) onSwitchUser(profile.id) },
                        onRemoveUser = { 
                            if (canRemoveUsers && !profile.isSystemUser) {
                                onRemoveUser(profile.id)
                            }
                        },
                        canSwitch = canSwitchUsers,
                        canRemove = canRemoveUsers && !profile.isSystemUser
                    )
                    
                    if (profile != userProfiles.last()) {
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
                
                if (canCreateUsers) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Create user options
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OutlinedButton(
                            onClick = onCreateUser,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add User")
                        }
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        OutlinedButton(
                            onClick = onCreateGuest,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Guest")
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Close button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close")
                }
            }
        }
    }
}

@Composable
private fun UserProfileItem(
    profile: UserProfile,
    isCurrentUser: Boolean,
    onSwitchUser: () -> Unit,
    onRemoveUser: () -> Unit,
    canSwitch: Boolean,
    canRemove: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = canSwitch && !isCurrentUser) { onSwitchUser() }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // User avatar
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    if (profile.isGuest) Color(0xFF4CAF50)
                    else if (profile.isSystemUser) Color(0xFF2196F3)
                    else Color(0xFF9C27B0),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (profile.isGuest) Icons.Default.Person
                else if (profile.isSystemUser) Icons.Default.AdminPanelSettings
                else Icons.Default.AccountCircle,
                contentDescription = "User Avatar",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(12.dp))
        
        // User info
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = profile.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (isCurrentUser) FontWeight.Bold else FontWeight.Normal
            )
            
            Row {
                if (isCurrentUser) {
                    Text(
                        text = "Current",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                if (profile.isSystemUser) {
                    if (isCurrentUser) Text(" • ", style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "System",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                
                if (profile.isGuest) {
                    if (isCurrentUser || profile.isSystemUser) Text(" • ", style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "Guest",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF4CAF50)
                    )
                }
            }
        }
        
        // Remove button
        if (canRemove && !isCurrentUser) {
            IconButton(onClick = onRemoveUser) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Remove User",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun CreateUserDialog(
    onDismiss: () -> Unit,
    onCreateUser: (String) -> Unit
) {
    var userName by remember { mutableStateOf("") }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Create New User",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = userName,
                    onValueChange = { userName = it },
                    label = { Text("User Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Button(
                        onClick = { 
                            if (userName.isNotBlank()) {
                                onCreateUser(userName.trim())
                            }
                        },
                        enabled = userName.isNotBlank()
                    ) {
                        Text("Create")
                    }
                }
            }
        }
    }
} 