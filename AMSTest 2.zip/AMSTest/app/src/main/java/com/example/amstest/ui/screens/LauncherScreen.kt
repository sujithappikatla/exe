package com.example.amstest.ui.screens

import android.content.Intent
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.amstest.data.AppInfo
import com.example.amstest.ui.components.*
import com.example.amstest.ui.components.UserProfileSwitcher
import com.example.amstest.ui.settings.SettingsActivity
import com.example.amstest.viewmodel.LauncherViewModel
import com.example.amstest.viewmodel.LauncherViewModelFactory
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherScreen(
    viewModel: LauncherViewModel = viewModel(
        factory = LauncherViewModelFactory(LocalContext.current)
    )
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val apps by viewModel.filteredApps.collectAsState()
    val homeScreenShortcuts by viewModel.homeScreenShortcuts.collectAsState()
    val favoriteApps by viewModel.favoriteApps.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val isAppDrawerOpen by viewModel.isAppDrawerOpen.collectAsState()
    val isEditMode by viewModel.isEditMode.collectAsState()
    val settings by viewModel.launcherSettings.collectAsState()
    
    // User profile state
    val userProfiles by viewModel.userProfiles.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    
    // Filter favorite apps from all apps
    val favoriteAppsList = remember(apps, favoriteApps) {
        apps.filter { it.packageName in favoriteApps }
    }
    
    WallpaperBackground(
        wallpaperPath = settings.wallpaperPath
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Main Home Screen
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Bar - with user profile switcher and controls
                TopAppBar(
                    title = {
                        // User Profile Switcher in the title area - always show for debugging
                        UserProfileSwitcher(
                            currentUser = currentUser,
                            userProfiles = userProfiles,
                            canCreateUsers = viewModel.canCreateUsers(),
                            canSwitchUsers = viewModel.canSwitchUsers(),
                            canRemoveUsers = viewModel.canRemoveUsers(),
                            onSwitchUser = { userId -> viewModel.switchToUser(userId) },
                            onCreateUser = { name -> viewModel.createUserProfile(name) },
                            onCreateGuest = { viewModel.createGuestProfile() },
                            onRemoveUser = { userId -> viewModel.removeUserProfile(userId) },
                            modifier = Modifier.fillMaxWidth(0.6f)
                        )
                    },
                    actions = {
                        // Edit Mode Toggle
                        IconButton(
                            onClick = { viewModel.toggleEditMode() }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = if (isEditMode) "Exit Edit" else "Edit Home",
                                tint = if (isEditMode) Color.Yellow else Color.White
                            )
                        }
                        
                        // Settings
                        IconButton(
                            onClick = {
                                val intent = Intent(context, SettingsActivity::class.java)
                                context.startActivity(intent)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    ),
                    modifier = Modifier.statusBarsPadding() // Only status bar padding for top bar
                )
                
                // Home Screen Content - Full screen with swipe detection
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    HomeScreen(
                        shortcuts = homeScreenShortcuts,
                        favoriteApps = favoriteAppsList,
                        columns = settings.homeScreenColumns,
                        rows = settings.homeScreenRows,
                        iconSize = settings.iconSize,
                        showLabels = settings.showHomeScreenLabels,
                        isEditMode = isEditMode,
                        onAppClick = { packageName ->
                            viewModel.launchApp(packageName)
                        },
                        onAppLongClick = { app ->
                            if (!isEditMode) {
                                // Show context menu for favorites
                                if (app.isFavorite) {
                                    viewModel.removeFromFavorites(app.packageName)
                                } else {
                                    viewModel.addToFavorites(app.packageName)
                                }
                            }
                        },
                        onAddShortcut = {
                            // Open app drawer to select apps
                            viewModel.openAppDrawer()
                        },
                        onSwipeUp = {
                            if (!isAppDrawerOpen) {
                                viewModel.openAppDrawer()
                            }
                        }
                    )
                    
                    // Swipe up indicator - positioned at bottom with navigation bar padding
                    if (!isAppDrawerOpen && !isEditMode) {
                        SwipeUpIndicator(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .navigationBarsPadding()
                        )
                    }
                }
            }
            
            // App Drawer Overlay - Full screen with improved swipe handling
            if (isAppDrawerOpen) {
                AppDrawer(
                    isOpen = isAppDrawerOpen,
                    apps = apps,
                    searchQuery = searchQuery,
                    isSearchActive = isSearchActive,
                    columns = settings.gridColumns,
                    iconSize = settings.iconSize,
                    showLabels = settings.showAppLabels,
                    isEditMode = isEditMode,
                    onSearchQueryChange = viewModel::updateSearchQuery,
                    onSearchActiveChange = viewModel::setSearchActive,
                    onAppClick = { app ->
                        if (isEditMode) {
                            // In edit mode, add to favorites instead of launching
                            viewModel.addToFavorites(app.packageName)
                            viewModel.closeAppDrawer()
                            viewModel.setEditMode(false)
                        } else {
                            // Normal mode, launch the app
                            viewModel.launchApp(app.packageName)
                        }
                    },
                    onAppLongClick = { app ->
                        // Toggle favorite status
                        if (app.isFavorite) {
                            viewModel.removeFromFavorites(app.packageName)
                        } else {
                            viewModel.addToFavorites(app.packageName)
                        }
                    },
                    onClose = {
                        viewModel.closeAppDrawer()
                        if (isEditMode) {
                            viewModel.setEditMode(false)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun LauncherHomeScreen() {
    LauncherScreen()
} 