package com.example.amstest.ui.components

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.example.amstest.data.AppInfo

@Composable
fun AppIcon(
    appInfo: AppInfo,
    iconSize: Float = 1.0f,
    showLabel: Boolean = true,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val iconSizeDp = (56 * iconSize).dp
    val textSizeSp = (12 * iconSize).sp
    
    // Safely create bitmap outside of composable calls
    val iconBitmap = remember(appInfo.icon, iconSizeDp) {
        try {
            appInfo.icon.toBitmap(
                width = (iconSizeDp.value * context.resources.displayMetrics.density).toInt(),
                height = (iconSizeDp.value * context.resources.displayMetrics.density).toInt()
            )
        } catch (e: Exception) {
            null
        }
    }
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .padding(8.dp)
            .clickable { onClick() }
    ) {
        // App Icon
        Box(
            modifier = Modifier
                .size(iconSizeDp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Color.White.copy(alpha = 0.1f),
                    RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (iconBitmap != null) {
                Image(
                    bitmap = iconBitmap.asImageBitmap(),
                    contentDescription = appInfo.appName,
                    modifier = Modifier
                        .size((iconSizeDp.value * 0.8).dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            } else {
                // Fallback icon
                Box(
                    modifier = Modifier
                        .size((iconSizeDp.value * 0.8).dp)
                        .background(
                            MaterialTheme.colorScheme.primary,
                            RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = appInfo.appName.take(1).uppercase(),
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = (textSizeSp.value * 1.5).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        
        // App Label
        if (showLabel) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = appInfo.appName,
                color = Color.White,
                fontSize = textSizeSp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(iconSizeDp + 16.dp)
            )
        }
    }
}

@Composable
fun AppIconGrid(
    apps: List<AppInfo>,
    columns: Int = 4,
    iconSize: Float = 1.0f,
    showLabels: Boolean = true,
    onAppClick: (AppInfo) -> Unit,
    onAppLongClick: ((AppInfo) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier
    ) {
        items(apps.size) { index ->
            val app = apps[index]
            AppIcon(
                appInfo = app,
                iconSize = iconSize,
                showLabel = showLabels,
                onClick = { onAppClick(app) },
                onLongClick = onAppLongClick?.let { { it(app) } }
            )
        }
    }
} 