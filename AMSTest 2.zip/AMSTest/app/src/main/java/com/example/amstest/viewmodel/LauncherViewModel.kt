package com.example.amstest.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.amstest.data.AppInfo
import com.example.amstest.data.HomeScreenShortcut
import com.example.amstest.data.LauncherSettings
import com.example.amstest.data.UserProfile
import com.example.amstest.repository.AppRepository
import com.example.amstest.repository.UserProfileManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class LauncherViewModel(
    private val repository: AppRepository,
    private val userProfileManager: UserProfileManager
) : ViewModel() {
    
    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()
    
    private val _homeScreenShortcuts = MutableStateFlow<List<HomeScreenShortcut>>(emptyList())
    val homeScreenShortcuts: StateFlow<List<HomeScreenShortcut>> = _homeScreenShortcuts.asStateFlow()
    
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()
    
    private val _isAppDrawerOpen = MutableStateFlow(false)
    val isAppDrawerOpen: StateFlow<Boolean> = _isAppDrawerOpen.asStateFlow()
    
    private val _isEditMode = MutableStateFlow(false)
    val isEditMode: StateFlow<Boolean> = _isEditMode.asStateFlow()
    
    // User profile related state
    val userProfiles: StateFlow<List<UserProfile>> = userProfileManager.userProfiles
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    
    val currentUser: StateFlow<UserProfile?> = userProfileManager.currentUser
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )
    
    val launcherSettings: StateFlow<LauncherSettings> = repository.launcherSettings
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = LauncherSettings()
        )
    
    val favoriteApps: StateFlow<Set<String>> = repository.favoriteApps
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptySet()
        )
    
    val filteredApps: StateFlow<List<AppInfo>> = combine(
        _apps,
        _searchQuery,
        favoriteApps
    ) { apps, query, favorites ->
        val appsWithFavorites = apps.map { app ->
            app.copy(isFavorite = favorites.contains(app.packageName))
        }
        
        if (query.isBlank()) {
            appsWithFavorites
        } else {
            appsWithFavorites.filter { app ->
                app.appName.contains(query, ignoreCase = true) ||
                app.packageName.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )
    
    init {
        loadApps()
        loadHomeScreenShortcuts()
    }
    
    fun loadApps() {
        viewModelScope.launch {
            try {
                val installedApps = repository.getInstalledApps()
                _apps.value = installedApps
            } catch (e: Exception) {
                // Handle error
                e.printStackTrace()
            }
        }
    }
    
    private fun loadHomeScreenShortcuts() {
        viewModelScope.launch {
            try {
                val shortcuts = repository.getHomeScreenShortcuts()
                _homeScreenShortcuts.value = shortcuts
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    fun launchApp(packageName: String) {
        repository.launchApp(packageName)
        closeAppDrawer()
    }
    
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }
    
    fun setSearchActive(active: Boolean) {
        _isSearchActive.value = active
        if (!active) {
            _searchQuery.value = ""
        }
    }
    
    fun openAppDrawer() {
        _isAppDrawerOpen.value = true
        _isSearchActive.value = false
        _searchQuery.value = ""
    }
    
    fun closeAppDrawer() {
        _isAppDrawerOpen.value = false
        _isSearchActive.value = false
        _searchQuery.value = ""
    }
    
    fun toggleEditMode() {
        _isEditMode.value = !_isEditMode.value
    }
    
    fun setEditMode(enabled: Boolean) {
        _isEditMode.value = enabled
    }
    
    fun addToFavorites(packageName: String) {
        viewModelScope.launch {
            repository.addToFavorites(packageName)
        }
    }
    
    fun removeFromFavorites(packageName: String) {
        viewModelScope.launch {
            repository.removeFromFavorites(packageName)
        }
    }
    
    fun addToHomeScreen(appInfo: AppInfo, row: Int, column: Int) {
        viewModelScope.launch {
            // Implementation for adding to home screen
            // This would involve creating a HomeScreenShortcut and saving it
        }
    }
    
    fun removeFromHomeScreen(shortcutId: String) {
        viewModelScope.launch {
            repository.removeFromHomeScreen(shortcutId)
            loadHomeScreenShortcuts()
        }
    }
    
    fun updateWallpaper(path: String?) {
        viewModelScope.launch {
            repository.updateWallpaper(path)
        }
    }
    
    fun updateIconSize(size: Float) {
        viewModelScope.launch {
            repository.updateIconSize(size)
        }
    }
    
    fun updateGridSize(columns: Int, rows: Int) {
        viewModelScope.launch {
            repository.updateGridSize(columns, rows)
        }
    }
    
    fun updateHomeScreenGridSize(columns: Int, rows: Int) {
        viewModelScope.launch {
            repository.updateHomeScreenGridSize(columns, rows)
        }
    }
    
    fun updateShowAppLabels(show: Boolean) {
        viewModelScope.launch {
            repository.updateShowAppLabels(show)
        }
    }
    
    fun updateShowHomeScreenLabels(show: Boolean) {
        viewModelScope.launch {
            repository.updateShowHomeScreenLabels(show)
        }
    }
    
    fun updateHapticFeedback(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateHapticFeedback(enabled)
        }
    }
    
    // User Profile Management Functions
    fun createUserProfile(name: String) {
        viewModelScope.launch {
            val success = userProfileManager.createUserProfile(name, skipSetupWizard = true)
            if (success) {
                // Optionally show success message
            } else {
                // Handle error - could emit an error state
            }
        }
    }
    
    fun createGuestProfile() {
        viewModelScope.launch {
            val success = userProfileManager.createGuestProfile()
            if (success) {
                // Optionally show success message
            } else {
                // Handle error
            }
        }
    }
    
    fun switchToUser(userId: Int) {
        viewModelScope.launch {
            val success = userProfileManager.switchToUser(userId)
            if (success) {
                // User switch initiated successfully
                // The system will handle the actual switch
            } else {
                // Handle error
            }
        }
    }
    
    fun removeUserProfile(userId: Int) {
        viewModelScope.launch {
            val success = userProfileManager.removeUserProfile(userId)
            if (success) {
                // User removed successfully
            } else {
                // Handle error
            }
        }
    }
    
    fun refreshUserProfiles() {
        userProfileManager.refreshUserProfiles()
    }
    
    fun canCreateUsers(): Boolean = userProfileManager.canCreateUsers()
    fun canSwitchUsers(): Boolean = userProfileManager.canSwitchUsers()
    fun canRemoveUsers(): Boolean = userProfileManager.canRemoveUsers()
    fun isMultiUserSupported(): Boolean = userProfileManager.isMultiUserSupported()
    fun getMaxUsers(): Int = userProfileManager.getMaxUsers()
}

class LauncherViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LauncherViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return LauncherViewModel(
                AppRepository(context),
                UserProfileManager(context)
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
} 