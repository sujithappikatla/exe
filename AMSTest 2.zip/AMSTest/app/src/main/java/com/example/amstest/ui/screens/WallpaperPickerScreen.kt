package com.example.amstest.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.amstest.data.WallpaperInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallpaperPickerScreen(
    onWallpaperSelected: (String?) -> Unit,
    onCustomWallpaperPick: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    
    // Built-in wallpapers (gradients and patterns)
    val builtInWallpapers = remember {
        listOf(
            WallpaperInfo("gradient_1", "Ocean Gradient", "", true),
            WallpaperInfo("gradient_2", "Sunset Gradient", "", true),
            WallpaperInfo("gradient_3", "Forest Gradient", "", true),
            WallpaperInfo("gradient_4", "Purple Gradient", "", true),
            WallpaperInfo("solid_dark", "Dark Theme", "", true),
            WallpaperInfo("solid_light", "Light Theme", "", true)
        )
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A1A2E),
                        Color(0xFF16213E)
                    )
                )
            )
    ) {
        // Top App Bar
        TopAppBar(
            title = {
                Text(
                    text = "Choose Wallpaper",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            },
            actions = {
                IconButton(onClick = onCustomWallpaperPick) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Custom",
                        tint = Color.White
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Transparent
            )
        )
        
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Default option (no wallpaper)
            item {
                WallpaperPreviewCard(
                    title = "Default",
                    isDefault = true,
                    onClick = { onWallpaperSelected(null) }
                )
            }
            
            // Built-in wallpapers
            items(builtInWallpapers) { wallpaper ->
                WallpaperPreviewCard(
                    title = wallpaper.name,
                    wallpaperInfo = wallpaper,
                    onClick = { onWallpaperSelected(wallpaper.id) }
                )
            }
        }
    }
}

@Composable
fun WallpaperPreviewCard(
    title: String,
    wallpaperInfo: WallpaperInfo? = null,
    isDefault: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Background
            if (isDefault) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF1A1A2E),
                                    Color(0xFF16213E),
                                    Color(0xFF0F3460)
                                )
                            )
                        )
                )
            } else {
                wallpaperInfo?.let { info ->
                    when (info.id) {
                        "gradient_1" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color(0xFF667eea),
                                                Color(0xFF764ba2)
                                            )
                                        )
                                    )
                            )
                        }
                        "gradient_2" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color(0xFFf093fb),
                                                Color(0xFFf5576c)
                                            )
                                        )
                                    )
                            )
                        }
                        "gradient_3" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color(0xFF4facfe),
                                                Color(0xFF00f2fe)
                                            )
                                        )
                                    )
                            )
                        }
                        "gradient_4" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color(0xFF43e97b),
                                                Color(0xFF38f9d7)
                                            )
                                        )
                                    )
                            )
                        }
                        "solid_dark" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0xFF121212))
                            )
                        }
                        "solid_light" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0xFFF5F5F5))
                            )
                        }
                        else -> {
                            if (info.path.isNotEmpty()) {
                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data(info.path)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = info.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }
            
            // Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.3f))
            )
            
            // Title
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
} 