from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse
from ModelManager import ModelManager
import base64
import json
from datetime import datetime
import uuid

app = FastAPI()


@app.get("/")
async def get():
    return FileResponse("public/voice_chat_client.html", media_type="text/html")



@app.websocket("/service")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
   

    try:
        # while True:
        message = await websocket.receive_text()
        # print("--------------------------------",message)
        message = json.loads(message)
        if message.get("type") == "START_SESSION":
            input_type = message["data"]["input_type"]
            output_type = message["data"]["output_type"]
        
        session_id = message["session_id"]
        manager = ModelManager(websocket, session_id)

        await websocket.send_text(json.dumps({
            "message_id": message["message_id"],
            "session_id": message["session_id"],
            "timestamp": datetime.now().isoformat(),
            "type": "SESSION_STARTED",
            "data": {}
        }))

        async def input_generator():
            while True:
                try:
                    msg = await websocket.receive_text()
                    msg = json.loads(msg)
                    print("--------------------------------",msg["type"])
                    if msg.get("type") == "AUDIO_STREAM_CHUNK":
                        yield base64.b64decode(msg.get("data").get("audio_content"))
                    elif msg.get("type") == "AUDIO_STREAM_END":
                        break
                    elif msg.get("type") == "TEXT_INPUT":
                        yield msg.get("data").get("text")
                        break
                except Exception as e:
                    print("--------------------------------",e)
                    break

        await manager.handle_stream(input_generator(), input_type, output_type)
        print("--------------------------------",input_type, output_type)


    except WebSocketDisconnect:
        print("--------------------------------", "WebSocketDisconnect")
    finally:
        await manager.stop()
    
    await websocket.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)