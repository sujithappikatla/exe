from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse
from ModelManager import ModelManager
import base64
import json
from datetime import datetime
import uuid

app = FastAPI()


@app.get("/")
async def get():
    return FileResponse("public/voice_chat_client.html", media_type="text/html")

@app.get("/pizza")
async def get():
    return FileResponse("public/pizza_ordering_system.html", media_type="text/html")



@app.websocket("/service")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
   
    try:
        manager = ModelManager(websocket)
        await manager.start_session()
    except WebSocketDisconnect:
        print("[ERROR] WebSocketDisconnect")
    finally:
        if manager:
            await manager.stop()
        print("[INFO] Session ended")
    

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)