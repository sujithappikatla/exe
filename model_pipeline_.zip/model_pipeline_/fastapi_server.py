from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from ModelManager import ModelManager
from FileProcessor import FileProcessor
import base64
import json
from datetime import datetime
import uuid
import os
import mimetypes
import pandas as pd
from pathlib import Path

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Create uploads directory if it doesn't exist
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Create public/images directory for menu item images
IMAGES_DIR = "public/images"
os.makedirs(IMAGES_DIR, exist_ok=True)

# Initialize FileProcessor
file_processor = FileProcessor()

# JSON storage file path
JSON_STORAGE_FILE = os.path.join(UPLOAD_DIR, "restaurant_menu.json")

# Supported file types
SUPPORTED_EXTENSIONS = {
    '.pdf': 'application/pdf',
    '.csv': 'text/csv',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.xls': 'application/vnd.ms-excel',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
}

def validate_file_type(filename: str, content_type: str) -> bool:
    """Validate if the file type is supported"""
    if not filename:
        return False
    
    file_extension = Path(filename).suffix.lower()
    return file_extension in SUPPORTED_EXTENSIONS

def convert_excel_to_csv(excel_file_path: str) -> str:
    """Convert Excel file to CSV and return the CSV file path"""
    try:
        # Read Excel file
        df = pd.read_excel(excel_file_path)
        
        # Create CSV filename
        csv_filename = Path(excel_file_path).stem + '.csv'
        csv_file_path = os.path.join(UPLOAD_DIR, csv_filename)
        
        # Save as CSV
        df.to_csv(csv_file_path, index=False)
        
        # Remove the original Excel file
        os.remove(excel_file_path)
        
        return csv_filename
    except Exception as e:
        # If conversion fails, remove the Excel file and raise error
        if os.path.exists(excel_file_path):
            os.remove(excel_file_path)
        raise Exception(f"Failed to convert Excel to CSV: {str(e)}")

@app.get("/")
async def get():
    return FileResponse("public/voice_chat_client.html", media_type="text/html")

@app.get("/images/{path:path}")
async def get_image(path: str):
    return FileResponse(f"public/images/{path}", media_type="image/png")

@app.get("/cart")
async def get_cart():
    return FileResponse("public/cart.html", media_type="text/html")


@app.get("/pizza")
async def get():
    return FileResponse("public/pizza_ordering_system.html", media_type="text/html")

@app.get("/restaurant_menu")
async def get_restaurant_menu():
    return FileResponse("public/restaurant_menu.html", media_type="text/html")



@app.get("/upload-test")
async def get_upload_test():
    return FileResponse("public/file_upload_test.html", media_type="text/html")

@app.get("/menu-template")
async def get_menu_template():
    return FileResponse("public/menu_template_test.html", media_type="text/html")

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        # Validate file type
        if not validate_file_type(file.filename, file.content_type):
            supported_types = ", ".join(SUPPORTED_EXTENSIONS.keys())
            raise HTTPException(
                status_code=400, 
                detail=f"Unsupported file type. Supported types: {supported_types}"
            )
        
        # Read file content
        content = await file.read()
        
        # Save the file initially
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            buffer.write(content)
        
        # Check if it's an Excel file and convert to CSV
        file_extension = Path(file.filename).suffix.lower()
        final_filename = file.filename
        converted = False
        final_file_path = file_path
        
        if file_extension in ['.xlsx', '.xls']:
            try:
                final_filename = convert_excel_to_csv(file_path)
                final_file_path = os.path.join(UPLOAD_DIR, final_filename)
                converted = True
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Error converting Excel to CSV: {str(e)}")
        
        # Extract content from file using Gemini LLM
        content_extraction_result = await file_processor.process_file(final_file_path, file.filename)
        
        # Save extracted JSON to local storage if extraction was successful
        if content_extraction_result.get("success") and content_extraction_result.get("extracted_json"):
            try:
                with open(JSON_STORAGE_FILE, 'w', encoding='utf-8') as json_file:
                    json.dump(content_extraction_result["extracted_json"], json_file, indent=2)
                print(f"[INFO] Restaurant menu JSON saved to {JSON_STORAGE_FILE}")
            except Exception as json_save_error:
                print(f"[ERROR] Failed to save JSON to local storage: {json_save_error}")
        
        response_data = {
            "message": "File uploaded successfully",
            "original_filename": file.filename,
            "saved_as": final_filename,
            "size": len(content),
            "content_type": file.content_type,
            "converted_to_csv": converted,
            "content_extraction": content_extraction_result,
            "json_saved": content_extraction_result.get("success") and content_extraction_result.get("extracted_json") is not None
        }
        
        # Add conversion info if file was converted
        if converted:
            response_data["conversion_info"] = "Excel file was automatically converted to CSV format"
        
        return response_data
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading file: {str(e)}")

@app.post("/upload-image")
async def upload_image(image: UploadFile = File(...)):
    """
    Upload PNG images to public/images folder for menu items
    """
    try:
        # Validate file type - only PNG allowed
        if not image.filename or not image.filename.lower().endswith('.png'):
            raise HTTPException(
                status_code=400, 
                detail="Only PNG files are allowed for image uploads"
            )
        
        # Check content type
        if image.content_type != 'image/png':
            raise HTTPException(
                status_code=400, 
                detail="Invalid content type. Only PNG images are supported."
            )
        
        # Read image content
        content = await image.read()
        
        # Save the image to public/images directory with original filename
        image_path = os.path.join(IMAGES_DIR, image.filename)
        
        # Check if file already exists and handle it
        if os.path.exists(image_path):
            print(f"[WARNING] Image {image.filename} already exists, overwriting...")
        
        with open(image_path, "wb") as buffer:
            buffer.write(content)
        
        print(f"[INFO] Image saved to {image_path}")
        
        return {
            "message": "Image uploaded successfully",
            "filename": image.filename,
            "saved_as": image.filename,
            "size": len(content),
            "content_type": image.content_type,
            "image_url": f"/images/{image.filename}",
            "file_path": image_path
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading image: {str(e)}")

@app.get("/items_template")
async def get_items_template():
    """
    Get the stored restaurant menu JSON data
    Returns 404 if no file exists in local storage
    """
    try:
        if not os.path.exists(JSON_STORAGE_FILE):
            raise HTTPException(status_code=404, detail="No restaurant menu template found. Please upload a menu file first.")
        
        with open(JSON_STORAGE_FILE, 'r', encoding='utf-8') as json_file:
            menu_data = json.load(json_file)
        
        return menu_data
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading menu template: {str(e)}")

@app.delete("/items_template")
async def delete_items_template():
    """
    Remove the stored restaurant menu JSON file from local storage
    """
    try:
        if not os.path.exists(JSON_STORAGE_FILE):
            raise HTTPException(status_code=404, detail="No restaurant menu template found to delete.")
        
        os.remove(JSON_STORAGE_FILE)
        
        return {
            "message": "Restaurant menu template deleted successfully",
            "file_path": JSON_STORAGE_FILE
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting menu template: {str(e)}")

@app.websocket("/service")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
   
    try:
        manager = ModelManager(websocket)
        await manager.start_session()
    except WebSocketDisconnect:
        print("[ERROR] WebSocketDisconnect")
    finally:
        if manager:
            await manager.stop()
        print("[INFO] Session ended")
    

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)