# Streaming Protocol Specification

## Overview

This document defines the JSON-based protocol for real-time streaming communication with websocket between client and server for a multi-modal AI pipeline that supports:
- Speech-to-Text (STT) processing
- Large Language Model (LLM) text generation
- Text-to-Speech (TTS) audio generation

## Protocol Version

Current Version: 1.0.0

## Message Structure

All messages follow this base structure:

```json
{
  "message_id": "string",      // Unique message identifier
  "session_id": "string",      // Session identifier for tracking conversations
  "timestamp": "ISO 8601",     // Message timestamp
  "type": "string",            // Message type (see Message Types section)
  "data": {}                   // Type-specific payload
}
```

## Message Types

### Client → Server Messages

#### 1. Session Control Messages

##### START_SESSION
Initiates a new session with the server.

```json
{
  "message_id": "msg_123",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:00:00Z",
  "type": "START_SESSION",
  "data": {
        "output_type": "audio"
    }
  }
```

##### END_SESSION
Terminates the current session.

```json
{
  "message_id": "msg_124",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:30:00Z",
  "type": "END_SESSION",
  "data": {
    "reason": "user_initiated"
  }
}
```

#### 2. Input Stream Messages

##### AUDIO_STREAM_START
Signals the beginning of an audio stream from client.

```json
{
  "message_id": "msg_200",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:00Z",
  "type": "AUDIO_STREAM_START",
  "data": {

  }
}
```

##### AUDIO_CHUNK
Contains a chunk of audio data.

```json
{
  "message_id": "msg_201",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:01Z",
  "type": "AUDIO_STREAM_CHUNK",
  "data": {
    "audio_content": "base64_encoded_audio_data", (in format=pyaudio.paInt16, channels=1, rate=16000)
  }
}
```

##### AUDIO_STREAM_END
Signals the end of an audio stream.

```json
{
  "message_id": "msg_250",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:10Z",
  "type": "AUDIO_STREAM_END",
  "data": {

  }
}
```

##### TEXT_INPUT
Sends text input directly to the server.

```json
{
  "message_id": "msg_300",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:02:00Z",
  "type": "TEXT_INPUT",
  "data": {
    "text": "What is the weather today?",
    "function_call_response":[
        {
            "fn_name":"<function_name>",
            "fn_response":"<response_of_function>"
        }
    ]
  }
}
```

### Server → Client Messages

#### 1. Session Acknowledgments

##### SESSION_STARTED
Confirms session initialization.

```json
{
  "message_id": "msg_500",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:00:01Z",
  "type": "SESSION_STARTED",
  "data": {

  }
}
```

#### 2. STT (Speech-to-Text) Messages

##### STT_TRANSCRIPT_START
Indicates STT processing has begun.

```json
{
  "message_id": "msg_600",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:02Z",
  "type": "STT_TRANSCRIPT_START",
  "data": {
  }
}
```

##### STT_TRANSCRIPT_CHUNK
Contains transcribed text chunks.

```json
{
  "message_id": "msg_601",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:03Z",
  "type": "STT_TRANSCRIPT_CHUNK",
  "data": {
    "text": "What is the",
    "is_final": false,
  }
}
```

##### STT_TRANSCRIPT_END
Signals completion of STT processing.

```json
{
  "message_id": "msg_650",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:11Z",
  "type": "STT_TRANSCRIPT_END",
  "data": {
    "final_transcript": "What is the weather today?",
  }
}
```

#### 3. LLM Response Messages

##### LLM_RESPONSE_START
Indicates LLM processing has begun.

```json
{
  "message_id": "msg_700",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:12Z",
  "type": "LLM_RESPONSE_START",
  "data": {

  }
}
```

##### LLM_TEXT_CHUNK
Contains generated text chunks.

```json
{
  "message_id": "msg_701",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:13Z",
  "type": "LLM_TEXT_CHUNK",
  "data": {
    "text": "I'd be happy to help you",
    "function_calls":[
        {
            "function_name": "get_weather",
            "arguments": {
                "location": "current",
                "units": "celsius"
            },
            "call_id": "call_abc123"
        }
    ],
    "image": "base64_image",
  }
}
```

##### LLM_RESPONSE_END
Signals completion of LLM processing.

```json
{
  "message_id": "msg_750",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:20Z",
  "type": "LLM_RESPONSE_END",
  "data": {

  }
}
```

#### 4. TTS (Text-to-Speech) Messages

##### TTS_AUDIO_START
Indicates TTS processing has begun.

```json
{
  "message_id": "msg_800",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:13Z",
  "type": "TTS_AUDIO_START",
  "data": {

  }
}
```

##### TTS_AUDIO_CHUNK
Contains generated audio chunks.

```json
{
  "message_id": "msg_801",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:14Z",
  "type": "TTS_AUDIO_CHUNK",
  "data": {
    "audio_content": "base64_encoded_audio_data", (wav format)
  }
}
```

##### TTS_AUDIO_END
Signals completion of TTS processing.

```json
{
  "message_id": "msg_850",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:25Z",
  "type": "TTS_AUDIO_END",
  "data": {
  }
}
```

#### 5. Error Messages

##### ERROR
Reports errors during processing.

```json
{
  "message_id": "msg_900",
  "session_id": "session_abc",
  "timestamp": "2024-01-01T12:01:15Z",
  "type": "ERROR",
  "data": {
    "error_code": "STT_PROCESSING_FAILED",
    "error_message": "Audio format not supported",
    "severity": "error",
    "recoverable": true
  }
}
```

## Operation States

### Operation Lifecycle

1. **STARTED**: Operation has begun (e.g., STT_TRANSCRIPT_START, LLM_RESPONSE_START)
2. **IN_PROGRESS**: Operation is actively processing (indicated by CHUNK messages)
3. **COMPLETED**: Operation finished successfully (e.g., STT_TRANSCRIPT_END, LLM_RESPONSE_END)
4. **FAILED**: Operation terminated due to error

## Synchronization Rules

1. **Operation Dependencies**: 
   - STT processing begins when audio chunks are received
   - LLM processing begins after STT completion or direct text input
   - TTS processing can start as soon as LLM begins generating text
2. **Parallel Operations**: TTS audio chunks and LLM text chunks can be sent in parallel
3. **Session Integrity**: All messages within a session must have the same session_id

## Error Handling

### Error Codes

- `INVALID_SESSION`: Session ID not found or expired
- `INVALID_FORMAT`: Message format validation failed
- `STT_PROCESSING_FAILED`: Speech-to-text processing error
- `LLM_PROCESSING_FAILED`: Language model processing error
- `TTS_PROCESSING_FAILED`: Text-to-speech processing error
- `RATE_LIMIT_EXCEEDED`: Too many requests
- `RESOURCE_EXHAUSTED`: Server resources unavailable
- `TIMEOUT`: Operation timed out

### Recovery Strategies

1. **Automatic Retry**: For transient errors (network, temporary resource issues)
2. **Operation Restart**: For processing errors within an operation
3. **Session Restart**: For unrecoverable session errors

## Best Practices

1. **Message Size**: Keep individual audio chunks under 1MB when base64 encoded
2. **Heartbeat**: Send heartbeat messages every 30 seconds during idle periods
3. **Buffering**: Clients should buffer audio chunks for smooth playback
4. **Compression**: Consider gzip compression for large text responses
5. **Timeout**: Set reasonable timeouts (30s for LLM, 5s for STT/TTS)

## Example Conversation Flow

```
1. Client → Server: START_SESSION
2. Server → Client: SESSION_STARTED
3. Client → Server: AUDIO_STREAM_START
4. Client → Server: AUDIO_CHUNK (multiple)
5. Server → Client: STT_TRANSCRIPT_START
6. Server → Client: STT_TRANSCRIPT_CHUNK (multiple)
7. Client → Server: AUDIO_STREAM_END
8. Server → Client: STT_TRANSCRIPT_END
9. Server → Client: LLM_RESPONSE_START
10. Server → Client: LLM_TEXT_CHUNK (in parallel with TTS)
11. Server → Client: TTS_AUDIO_START
12. Server → Client: TTS_AUDIO_CHUNK (multiple, interleaved with LLM_TEXT_CHUNK)
13. Server → Client: LLM_RESPONSE_END
14. Server → Client: TTS_AUDIO_END
15. Client → Server: END_SESSION
```

## Version History

- 1.0.0 (2024-01-01): Initial protocol specification 