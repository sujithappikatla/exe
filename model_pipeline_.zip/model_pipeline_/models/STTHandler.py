from models.ModelBase import ModelBase, SendToClientCallable
from asyncio import Queue
from google.cloud.speech_v2 import SpeechAsyncClient
from google.cloud.speech_v2.types import cloud_speech
from google.api_core.client_options import ClientOptions
import asyncio




class STTHandler():

    def __init__(self):
        self.client = SpeechAsyncClient(
            client_options=ClientOptions(
                api_endpoint="us-central1-speech.googleapis.com",
            )
        )
        self.project_id = "cloud-learning-443407"

        self.recognition_config = cloud_speech.RecognitionConfig(
            explicit_decoding_config=cloud_speech.ExplicitDecodingConfig(
                encoding=cloud_speech.ExplicitDecodingConfig.AudioEncoding.LINEAR16,
                sample_rate_hertz=16000,
                audio_channel_count=1,
            ),
            language_codes=["en-US"],
            model="chirp_2",
            features=cloud_speech.RecognitionFeatures(
                enable_automatic_punctuation=True,
                enable_word_time_offsets=False,
                profanity_filter=False,
            ),
        )
        self.streaming_config = cloud_speech.StreamingRecognitionConfig(
            config=self.recognition_config,
            streaming_features=cloud_speech.StreamingRecognitionFeatures(
                interim_results=True,
            )
        )
    
    async def process(
            self, 
            input_stream:Queue, 
            send_to_client:SendToClientCallable
    ) -> str:
        try:
            await send_to_client("STT:START", {
                "text": "Starting STT"
            })

            async def audio_generator():
                yield cloud_speech.StreamingRecognizeRequest(
                    recognizer=f"projects/{self.project_id}/locations/us-central1/recognizers/_",
                    streaming_config=self.streaming_config,
                )
                while True:
                    try:    
                        chunk = input_stream.get_nowait()
                        if chunk is None:
                            break
                        yield cloud_speech.StreamingRecognizeRequest(audio=chunk)
                    except asyncio.QueueEmpty:
                        await asyncio.sleep(0.01)
                        continue
                    except Exception as e:
                        print(f"[ERROR] STTHandler: {e}")
                        break

            self.streaming_responses = await self.client.streaming_recognize(
                requests=audio_generator()
            )

            final_transcript = ""
            async for response in self.streaming_responses:
                for result in response.results:
                    if result.is_final:
                        final_transcript += result.alternatives[0].transcript
                    response_data = {
                        "text": result.alternatives[0].transcript,
                        "is_final": result.is_final,
                    }
                    await send_to_client("STT:PROGRESS", response_data)


            await send_to_client("STT:DONE", {
                "text": final_transcript,
            })

            return final_transcript
        except Exception as e:
            print(f"[ERROR][STTHandler][process] {e}")
            return ""


    async def stop(self):
        try:
            if self.streaming_responses:
                self.streaming_responses.cancel()
        except Exception as e:
            print(f"[ERROR][STTHandler][stop] {e}")
