from models.ModelBase import ModelBase, SendToClientCallable
from typing import AsyncGenerator, Union
from google.cloud import texttospeech
import asyncio
import wave

class TTSHandler():
    def __init__(self):
        self.language = "en-US"
        self.voice = "en-US-Chirp3-HD-Leda"

        self.client = texttospeech.TextToSpeechAsyncClient()
        self.streaming_config = texttospeech.StreamingSynthesizeConfig(
            voice=texttospeech.VoiceSelectionParams(
                name=f"{self.voice}",
                language_code=self.language,
            ),
            streaming_audio_config=texttospeech.StreamingAudioConfig(
                audio_encoding=texttospeech.AudioEncoding.PCM,
                sample_rate_hertz=16000
            )
        )

        self.config_request = texttospeech.StreamingSynthesizeRequest(
            streaming_config=self.streaming_config
        )

    async def process(self, input_stream: AsyncGenerator[Union[str, bytes], None], send_to_client: SendToClientCallable):
        
        await send_to_client("TTS:START", {
            "text": "Starting TTS"
        })

        async def _request_async_generator():
            yield self.config_request
            async for text in input_stream:
                if text is None:
                    break
                yield texttospeech.StreamingSynthesizeRequest(
                    input=texttospeech.StreamingSynthesisInput(text=text)
                )
        # audio_buffer = b""
        # while True:
        try:    
            self.streaming_responses = await self.client.streaming_synthesize(_request_async_generator())

            # print("--------- TTS streaming_synthesize call returned, response iterator obtained.")
            
            async for response in self.streaming_responses:
                if not response.audio_content:
                    continue
                # print(f"--------- TTS Response received, audio_content length: {len(response.audio_content)}")
                await send_to_client("TTS:CHUNK", {
                    "audio_content": response.audio_content
                })
                # audio_buffer += response.audio_content
        except Exception as e:
            if e.message.find("Stream aborted due to long duration elapsed without input sent") != -1:
                print("--------- Stream aborted due to long duration elapsed without input sent")
                # continue
            else:
                print(f"--------- Error in TTS streaming_synthesize: {e}")
                # break
        # print("--------- TTS audio_buffer length: ", len(audio_buffer))
        
        # with wave.open("tts_response.wav", "wb") as f:
        #     f.setnchannels(1)
        #     f.setsampwidth(2)
        #     f.setframerate(16000)
        #     f.writeframes(audio_buffer)

        await send_to_client("TTS:DONE", {
            "text": "TTS Done"
        })

    async def stop(self):
        try:
            # if self.client:
            #     await self.client.close()
            if self.streaming_responses:
                await self.streaming_responses.cancel()
        except Exception as e:
            print(f"--------- Error in TTS stop: {e}")