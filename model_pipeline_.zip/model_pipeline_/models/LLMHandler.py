from models.ModelBase import ModelBase, SendToClientCallable
from typing import AsyncGenerator, Union
from google import genai
from google.genai.types import GenerateContentConfig, HttpOptions
import asyncio

SYSTEM_INSTRUCTION = """
You are Voice Assistant - EVA.
Always answer user query with few words and keep the response short and concise.
Your response is used to generate audio using TTS Model for the user, so dont use any emojis or special characters.
keep your response under 200-250 words at max.
"""


class LLMHandler():
    def __init__(self):
        self.client = genai.Client(
            vertexai=True,
            project="cloud-learning-443407",
            location="us-central1",
            http_options=HttpOptions(api_version="v1"))
        self.model_id = "gemini-2.0-flash-lite"  # Or your chosen model

    async def process(
            self, 
            input_text: str, 
            send_to_client: SendToClientCallable
        ) -> AsyncGenerator[str, None]:
        await send_to_client("LLM:START", {
            "text": "Starting LLM"
        })

        user_prompt = input_text
        # async for chunk in input_stream:
        #     user_prompt += chunk

        # print("user_prompt", user_prompt)

        # For now, just yield the user prompt back as a simple test
        # You should replace this with actual LLM processing
        # yield user_prompt

        # Start the streaming content generation
        self.streaming_responses = await self.client.aio.models.generate_content_stream(
            model=self.model_id,
            contents=user_prompt,
            config=GenerateContentConfig(
                response_modalities=["TEXT"],
                system_instruction=SYSTEM_INSTRUCTION
            ),
        )
        async for chunk in self.streaming_responses:
            print(chunk.text, end="", flush=True)
            await send_to_client("LLM:CHUNK", {
                "text": chunk.text
            })
            yield chunk.text

        await send_to_client("LLM:DONE", {
            "text": "LLM Done"
        })

    async def stop(self):
        try:
            # if self.client:
            #     await self.client.close()
            if self.streaming_responses:
                await self.streaming_responses.cancel()
        except Exception as e:
            print(f"--------- Error in LLM stop: {e}")