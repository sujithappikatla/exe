import wave
import asyncio
from typing import AsyncGenerator, Union

from ModelManager import ModelManager
import pyaudio


async def read_wav_file(file_path:str) -> AsyncGenerator[bytes, None]:
    # with wave.open(file_path, "rb") as wav_file:
    #     while True:
    #         data = wav_file.readframes(chunk_size)
    #         if not data:
    #             break
    #         yield data

    with open(file_path, "rb") as f:
        content = f.read()

        # In practice, stream should be a generator yielding chunks of audio data
        chunk_length = len(content) // 200
        stream = [
            content[start : start + chunk_length]
            for start in range(0, len(content), chunk_length)
        ]

        for chunk in stream:
            print("reading audio chunk")
            yield chunk

async def record_audio(chunk_size:int) -> AsyncGenerator[bytes, None]:
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=chunk_size)
    while True:
        data = stream.read(chunk_size)
        yield data






if __name__ == "__main__":

    async def send_status(status_msg: Union[str, bytes]):
        print(status_msg)


    async def main():
        model_manager = ModelManager()
        async def audio_generator():
            counter = 0
            # async for chunk in read_wav_file("harvard.wav"):
            #     yield chunk
            async for chunk in record_audio(1024):
                counter += 1
                if counter > 100:
                    break
                yield chunk
        await model_manager.handle_stream(audio_generator(), "audio", "audio")
    asyncio.run(main())



