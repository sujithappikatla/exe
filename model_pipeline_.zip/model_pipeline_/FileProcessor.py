from google import genai
from google.genai.types import HttpOptions, Part
import os
import base64
import mimetypes
from pathlib import Path
import json
from pydantic import BaseModel, Field
from typing import List, Optional

class MenuItem(BaseModel):
    name: str
    price: float
    base_toppings: List[str]
    image_url: str = Field(default="")

class IceCreamItem(BaseModel):
    name: str
    price: float
    image_url: str

class DrinkItem(BaseModel):
    name: str
    price: float
    image_url: str

class Topping(BaseModel):
    name: str
    price: float

class FoodCategory(BaseModel):
    items: List[MenuItem]
    toppings: List[Topping]

class SimpleFoodCategory(BaseModel):
    items: List[IceCreamItem]

class DrinkCategory(BaseModel):
    items: List[DrinkItem]

class RestaurantMenu(BaseModel):
    pizzas: FoodCategory
    burgers: FoodCategory
    ice_cream: SimpleFoodCategory
    drinks: DrinkCategory

class FileProcessor:
    def __init__(self):
        self.client = genai.Client(
            vertexai=True,
            project="cloud-learning-443407",
            location="us-central1",
            http_options=HttpOptions(api_version="v1")
        )
        self.model_id = "gemini-2.0-flash"
        
    def get_file_mime_type(self, file_path: str) -> str:
        """Get the MIME type of a file"""
        mime_type, _ = mimetypes.guess_type(file_path)
        return mime_type or 'application/octet-stream'
    
    def read_file_as_base64(self, file_path: str) -> str:
        """Read file and encode as base64"""
        with open(file_path, 'rb') as file:
            return base64.b64encode(file.read()).decode('utf-8')
    
    def read_csv_content(self, file_path: str) -> str:
        """Read CSV file content as text"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return file.read()
        except UnicodeDecodeError:
            # Try with different encoding if UTF-8 fails
            with open(file_path, 'r', encoding='latin-1') as file:
                return file.read()
    
    def generate_image_url(self, item_name: str) -> str:
        """Generate image URL from item name"""
        # Convert to lowercase and replace spaces with dashes
        image_name = item_name.lower().replace(" ", "-")
        return f"/images/{image_name}.png"
    
    def update_empty_image_urls(self, menu_data: dict) -> dict:
        """Update empty image URLs with generated ones based on item names"""
        try:
            # Update pizzas
            if "pizzas" in menu_data and "items" in menu_data["pizzas"]:
                for item in menu_data["pizzas"]["items"]:
                    if not item.get("image_url") or item["image_url"] == "":
                        item["image_url"] = self.generate_image_url(item["name"])
            
            # Update burgers
            if "burgers" in menu_data and "items" in menu_data["burgers"]:
                for item in menu_data["burgers"]["items"]:
                    if not item.get("image_url") or item["image_url"] == "":
                        item["image_url"] = self.generate_image_url(item["name"])
            
            # Update ice cream
            if "ice_cream" in menu_data and "items" in menu_data["ice_cream"]:
                for item in menu_data["ice_cream"]["items"]:
                    if not item.get("image_url") or item["image_url"] == "":
                        item["image_url"] = self.generate_image_url(item["name"])
            
            # Update drinks
            if "drinks" in menu_data and "items" in menu_data["drinks"]:
                for item in menu_data["drinks"]["items"]:
                    if not item.get("image_url") or item["image_url"] == "":
                        item["image_url"] = self.generate_image_url(item["name"])
            
            return menu_data
        except Exception as e:
            print(f"[ERROR] Failed to update image URLs: {e}")
            return menu_data
    
    async def extract_content_from_file(self, file_path: str, original_filename: str) -> dict:
        """
        Extract content from file using Gemini LLM
        Returns dict with extracted text and metadata
        """
        try:
            file_extension = Path(file_path).suffix.lower()
            mime_type = self.get_file_mime_type(file_path)
            
            # Prepare content based on file type
            prompt_text = f"""Extract restaurant food items information from this {file_extension.upper()} file '{original_filename}'.

CRITICAL INSTRUCTIONS:
1. Extract ALL pizzas, burgers, ice cream, and drinks items WITHOUT FAIL
2. For each item, extract: name, price, base_toppings (if applicable), and image_url(if present)
3. For pizzas and burgers, also extract available toppings with prices
4. If no items found for a category, return empty arrays for that category
5. For image_url, use actual URLs if present, otherwise leave it blank
6. Be thorough and don't miss any items
7. Return ONLY the JSON structure - no additional text
8. For price, if not present, for items set it to 5, for toppings set it to 1
9. Use non-decimal values for prices

The file contains restaurant menu information. Extract it systematically."""
            
            if file_extension == '.csv':
                # For CSV files, send as text
                csv_content = self.read_csv_content(file_path)
                content_parts = [
                    Part(text=f"{prompt_text}\n\nCSV Content:\n{csv_content}")
                ]
            else:
                # For PDF and images, send as base64
                file_data = self.read_file_as_base64(file_path)
                content_parts = [
                    Part(text=prompt_text),
                    Part(
                        inline_data={
                            "mime_type": mime_type,
                            "data": file_data
                        }
                    )
                ]
            
            # Generate content using Gemini with structured output
            response = await self.client.aio.models.generate_content(
                model=self.model_id,
                contents=content_parts,
                config={
                    "response_mime_type": "application/json",
                    "response_schema": RestaurantMenu,
                    "system_instruction": """You are a restaurant menu data extraction specialist.
                    
                    Your task is to extract food items from restaurant menus and return them in a structured JSON format.
                    
                    EXTRACTION RULES:
                    1. Look for 4 categories: pizzas, burgers, ice_cream, drinks
                    2. For each item, extract: name, price, base_toppings (pizzas/burgers only), image_url (if present)
                    3. For pizzas and burgers, also extract available toppings with their prices
                    4. If no items found for a category, return empty arrays
                    5. For image_url, use actual URLs if present, otherwise leave it blank
                    6. Be thorough - extract ALL items, don't miss anything
                    7. Return ONLY valid JSON - no additional text or explanation
                    8. For price, if not present, for items set it to 5, for toppings set it to 1
                    9. Use non-decimal values for prices
                    
                    IMPORTANT: Extract every single food item you can find. Missing items is not acceptable."""
                }
            )
            
            # Extract JSON from response
            extracted_json = None
            extracted_text = ""
            
            if response.candidates and len(response.candidates) > 0:
                candidate = response.candidates[0]
                if candidate.content and candidate.content.parts:
                    for part in candidate.content.parts:
                        if hasattr(part, 'text') and part.text:
                            extracted_text += part.text
                            
                            # Try to parse as JSON
                            try:
                                extracted_json = json.loads(part.text)
                                # Update empty image URLs with generated ones
                                if extracted_json:
                                    extracted_json = self.update_empty_image_urls(extracted_json)
                            except json.JSONDecodeError:
                                # If not valid JSON, keep as text
                                extracted_json = None
            
            return {
                "success": True,
                "extracted_text": extracted_text,
                "extracted_json": extracted_json,
                "file_type": file_extension,
                "mime_type": mime_type,
                "processing_method": "csv_text" if file_extension == '.csv' else "base64_multimodal"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "extracted_text": "",
                "extracted_json": None,
                "file_type": file_extension if 'file_extension' in locals() else "unknown",
                "mime_type": mime_type if 'mime_type' in locals() else "unknown"
            }
    
    async def process_file(self, file_path: str, original_filename: str) -> dict:
        """
        Main method to process a file and extract its content
        """
        if not os.path.exists(file_path):
            return {
                "success": False,
                "error": "File not found",
                "extracted_text": "",
                "extracted_json": None
            }
        
        # Check if file is supported
        file_extension = Path(file_path).suffix.lower()
        supported_extensions = ['.pdf', '.csv', '.jpg', '.jpeg', '.png']
        
        if file_extension not in supported_extensions:
            return {
                "success": False,
                "error": f"File type {file_extension} is not supported for content extraction",
                "extracted_text": "",
                "extracted_json": None
            }
        
        # Extract content
        result = await self.extract_content_from_file(file_path, original_filename)
        
        return result 