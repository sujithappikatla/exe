package com.example.gpt_v



import android.util.Log
import kotlinx.coroutines.*
import okhttp3.*
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class DeepgramService {
    private var webSocket: WebSocket? = null
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private val TAG = "DeepgramService"

    private var currentTranscript = StringBuilder()
    private var isFinalized = false
    private var finalTranscriptCallback: ((String) -> Unit)? = null
    private var closureJob: Job? = null

    fun sendAudioData(audioData: ByteArray, onInterimTranscript: (String) -> Unit) {
        if (webSocket == null) {
            initializeWebSocket(onInterimTranscript)
        }
        webSocket?.send(audioData.toByteString())
    }

    private fun initializeWebSocket(onInterimTranscript: (String) -> Unit) {
        val request = Request.Builder()
            .url("wss://api.deepgram.com/v1/listen?model=nova-2&encoding=linear16&sample_rate=16000&language=en-US&punctuate=true&interim_results=true")
            .addHeader("Authorization", "Token 9103bae5d34c6fc24d557c4fea245a0f8ae21bf2")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                val json = JSONObject(text)
                if (json.has("channel")) {
                    val transcript = json.getJSONObject("channel")
                        .getJSONArray("alternatives")
                        .getJSONObject(0)
                        .getString("transcript")
                    val isFinal = json.getBoolean("is_final")

                    if (isFinal) {
                        currentTranscript.append(transcript).append(" ")
                        if (isFinalized) {
                            finalTranscriptCallback?.invoke(currentTranscript.toString().trim())
                            closeConnection()
                        }
                    }
                    onInterimTranscript(currentTranscript.toString().trim())
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket failure: ${t.message}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closed: $code / $reason")
            }
        })
    }

    fun stopStreamingAndGetTranscript(onTranscriptionComplete: (String) -> Unit) {
        isFinalized = true
        finalTranscriptCallback = onTranscriptionComplete

        closureJob = CoroutineScope(Dispatchers.IO).launch {
            delay(2000) // Wait for 2 seconds to receive any pending transcripts
            if (currentTranscript.isNotEmpty()) {
                onTranscriptionComplete(currentTranscript.toString().trim())
            }
            closeConnection()
        }
    }

    fun closeConnection() {
        closureJob?.cancel()
        webSocket?.close(1000, "Streaming stopped")
        webSocket = null
        currentTranscript.clear()
        isFinalized = false
        finalTranscriptCallback = null
    }
}