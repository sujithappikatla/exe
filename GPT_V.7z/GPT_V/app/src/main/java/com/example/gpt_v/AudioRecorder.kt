package com.example.gpt_v



import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.*

class AudioRecorder() {
    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private val coroutineScope = CoroutineScope(Dispatchers.Default + Job())
    private val TAG = "AudioRecorder"

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    @SuppressLint("MissingPermission")
    fun startRecording(onAudioDataAvailable: (ByteArray) -> Unit) {
        Log.d(TAG, "Starting audio recording")
        if (isRecording) {
            Log.d(TAG, "Already recording, ignoring start request")
            return
        }

        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        Log.d(TAG, "Minimum buffer size: $minBufferSize")

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                minBufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord failed to initialize")
                return
            }

            audioRecord?.startRecording()
            isRecording = true

            coroutineScope.launch {
                val buffer = ByteArray(minBufferSize)
                while (isRecording) {
                    val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (bytesRead > 0) {
                        onAudioDataAvailable(buffer.copyOf(bytesRead))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting audio recording: ${e.message}")
            e.printStackTrace()
        }
    }

    fun stopRecording() {
        Log.d(TAG, "Stopping audio recording")
        isRecording = false
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }

    fun release() {
        stopRecording()
        coroutineScope.cancel()
    }
}