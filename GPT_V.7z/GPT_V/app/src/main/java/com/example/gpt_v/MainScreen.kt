package com.example.gpt_v

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    // Updated gradient colors
    val gradientColors = listOf(
        Color(0xFF1E1E1E),  // Dark charcoal
        Color(0xFF2C3E50)   // Dark blue-gray
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(gradientColors)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            TopButtons(
                isRecording = uiState.isRecording,
                onRecordToggle = { viewModel.toggleRecording() },
                onClearConversation = { viewModel.clearConversation() }
            )

            MessageList(
                messages = uiState.messages,
                currentMessage = uiState.currentMessage,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )

            if (uiState.error != null) {
                ErrorMessage(error = uiState.error!!)
            }
        }
    }
}


@Composable
fun TopButtons(
    isRecording: Boolean,
    onRecordToggle: () -> Unit,
    onClearConversation: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Button(
            onClick = onRecordToggle,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isRecording) Color.Red else MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.animateContentSize()
        ) {
            Icon(
                Icons.Default.Mic,
                contentDescription = if (isRecording) "Stop Recording" else "Start Recording"
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isRecording) "Stop" else "Record")
        }

        Button(
            onClick = onClearConversation,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary
            )
        ) {
            Icon(Icons.Default.Delete, contentDescription = "Clear Conversation")
            Spacer(modifier = Modifier.width(4.dp))
            Text("Clear")
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MessageList(
    messages: List<Message>,
    currentMessage: Message?,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier,
        reverseLayout = true
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
        }

        currentMessage?.let { message ->
            item {
                AnimatedMessageBubble(message, true)
            }
        }

        itemsIndexed(messages.asReversed()) { index, message ->
            AnimatedMessageBubble(message, index == 0 && currentMessage == null)
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun AnimatedMessageBubble(message: Message, isNew: Boolean) {
    AnimatedVisibility(
        visible = true,
        enter = fadeIn() + expandVertically(),
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        MessageBubble(message, isNew)
    }
}

@Composable
fun MessageBubble(message: Message, isNew: Boolean) {
    val backgroundColor = when {
        message.sender == "You" -> MaterialTheme.colorScheme.primaryContainer
        isNew -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.secondaryContainer
    }

    val shape = RoundedCornerShape(12.dp)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(backgroundColor),
        shape = shape,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = message.sender,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = message.content,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun ErrorMessage(error: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Text(
            text = error,
            color = MaterialTheme.colorScheme.onErrorContainer,
            modifier = Modifier.padding(16.dp)
        )
    }
}