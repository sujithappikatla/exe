package com.example.gpt_v

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class GptService {
    private val client = OkHttpClient()
    private val apiKey = "sk-proj-OGI5p0RfWmk8Ji8T4nr5T3BlbkFJbyub698XJM5brXvOxuic"
    private val apiUrl = "https://api.openai.com/v1/chat/completions"
    private val TAG = "GptService"

    private val conversationHistory = mutableListOf<Message>()

    fun getResponse(prompt: String): Flow<String> = flow {
        conversationHistory.add(Message("user", prompt))

        val requestBody = JSONObject().apply {
            put("model", "gpt-3.5-turbo")
            put("messages", JSONArray().apply {
                conversationHistory.forEach { message ->
                    put(JSONObject().apply {
                        put("role", message.role)
                        put("content", message.content)
                    })
                }
            })
            put("stream", true)
        }.toString()

        val request = Request.Builder()
            .url(apiUrl)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        Log.d(TAG, "Sending request to GPT API")
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "No error body"
                Log.e(TAG, "API request failed: ${response.code}, Error: $errorBody")
                throw IOException("Unexpected code ${response.code}, Error: $errorBody")
            }

            val reader = response.body?.charStream()
            val assistantResponse = StringBuilder()

            reader?.useLines { lines ->
                lines.forEach { line ->
                    if (line.startsWith("data: ") && line != "data: [DONE]") {
                        try {
                            val jsonData = JSONObject(line.substring(6))
                            val content = jsonData.getJSONArray("choices")
                                .getJSONObject(0)
                                .getJSONObject("delta")
                                .optString("content")
                            if (content.isNotEmpty()) {
                                assistantResponse.append(content)
                                emit(content)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing JSON: ${e.message}, Line: $line")
                        }
                    }
                }
            }

            // Add the assistant's response to the conversation history
            conversationHistory.add(Message("assistant", assistantResponse.toString()))
        }
    }.flowOn(Dispatchers.IO)

    fun clearConversationHistory() {
        conversationHistory.clear()
    }

    data class Message(val role: String, val content: String)
}