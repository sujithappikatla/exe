package com.example.gpt_v

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState

    private val audioRecorder = AudioRecorder()
    private val deepgramService = DeepgramService()
    private val gptService = GptService()

    private var currentTranscription = StringBuilder()
    private var lastInterimTranscript = ""

    private val TAG = "MainViewModel"

    fun toggleRecording() {
        if (_uiState.value.isRecording) {
            stopRecording()
        } else {
            startRecording()
        }
    }

    private fun startRecording() {
        viewModelScope.launch {
            try {
                Log.d(TAG, "Starting recording")
                _uiState.update { it.copy(isRecording = true, error = null, currentMessage = null) }
                currentTranscription.clear()
                lastInterimTranscript = ""

                audioRecorder.startRecording { audioData ->
                    deepgramService.sendAudioData(audioData) { interimTranscript ->
                        Log.d(TAG, "Received interim transcript: $interimTranscript")
                        if (interimTranscript != lastInterimTranscript) {
                            lastInterimTranscript = interimTranscript
                            _uiState.update {
                                it.copy(
                                    currentMessage = Message("You", interimTranscript)
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting recording: ${e.message}", e)
                _uiState.update {
                    it.copy(
                        isRecording = false,
                        error = "Error starting recording: ${e.message}\n\nPlease check your API key and internet connection."
                    )
                }
            }
        }
    }

    private fun stopRecording() {
        viewModelScope.launch {
            Log.d(TAG, "Stopping recording")
            _uiState.update { it.copy(isRecording = false) }
            audioRecorder.stopRecording()
            deepgramService.stopStreamingAndGetTranscript { finalTranscript ->
                Log.d(TAG, "Received final transcript: $finalTranscript")
                _uiState.update {
                    it.copy(
                        messages = it.messages + Message("You", finalTranscript),
                        currentMessage = null
                    )
                }
                sendToGpt(finalTranscript)
            }
        }
    }
    private fun sendToGpt(transcript: String) {
        viewModelScope.launch {
            try {
                Log.d(TAG, "Sending transcript to GPT: $transcript")
                var gptResponse = StringBuilder()
                gptService.getResponse(transcript)
                    .catch { e ->
                        Log.e(TAG, "Error in GPT flow: ${e.message}", e)
                        _uiState.update {
                            it.copy(error = "Error getting GPT response: ${e.message ?: "Unknown error"}")
                        }
                    }
                    .collect { partialResponse ->
                        Log.d(TAG, "Received partial GPT response: $partialResponse")
                        gptResponse.append(partialResponse)
                        _uiState.update { currentState ->
                            val updatedMessages = currentState.messages.toMutableList()
                            if (updatedMessages.lastOrNull()?.sender == "GPT") {
                                updatedMessages[updatedMessages.lastIndex] = Message("GPT", gptResponse.toString())
                            } else {
                                updatedMessages.add(Message("GPT", gptResponse.toString()))
                            }
                            currentState.copy(messages = updatedMessages)
                        }
                    }
            } catch (e: CancellationException) {
                Log.d(TAG, "GPT request was cancelled")
            } catch (e: Exception) {
                Log.e(TAG, "Error getting GPT response", e)
                _uiState.update {
                    it.copy(error = "Error getting GPT response: ${e.message ?: "Unknown error"}")
                }
            }
        }
    }

    fun clearConversation() {
        gptService.clearConversationHistory()
        _uiState.update {
            it.copy(messages = emptyList(), currentMessage = null, error = null)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioRecorder.release()
        deepgramService.closeConnection()
    }
}

data class UiState(
    val messages: List<Message> = emptyList(),
    val currentMessage: Message? = null,
    val isRecording: Boolean = false,
    val error: String? = null
)

data class Message(val sender: String, val content: String)