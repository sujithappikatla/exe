from models.ModelBase import ModelBase, SendToClientCallable
from google import genai
from google.genai.types import GenerateContentConfig, HttpOptions, FunctionDeclaration, Schema, Tool, ToolConfig, FunctionCall, Part, FunctionResponse
import asyncio
from storage.StorageManager import StorageManager
from asyncio import Queue
import json 

SYSTEM_INSTRUCTION = """
You are Voice Assistant - Eva.
Always answer user query with few words and keep the response short and concise.
Your response is used to generate audio using TTS Model for the user, so dont use any emojis or special characters.
keep your response under 200-250 words at max. 
Also keep in mind you are answering to a hotel guest, your grammer should be liking answer to guest directly. 
"""





class LLMHandler():
    def __init__(self):
        self.client = genai.Client(
            vertexai=True,
            project="cloud-learning-443407",
            location="us-central1",
            http_options=HttpOptions(api_version="v1")
        )
        self.model_id = "gemini-2.5-flash-lite"  # Or your chosen model
        self.storage_manager = None
        self.history = []
        self.conversation_history_json = []

        self.MENU_ITEMS = json.load(open("uploads/restaurant_menu.json"))
        with open("uploads/hotel_info.txt", "r") as f:
            self.HOTEL_INFO = f.read()
        # self.system_instruction = f"""
        # {SYSTEM_INSTRUCTION}
        # Here is the list of menu items, when calling functions, item names has to match exactly with the names below:
        # When calling functions, make sure to use same item names as in the list below.
        # {json.dumps(self.MENU_ITEMS)}
        # """
        self.system_instruction = f"""
        {SYSTEM_INSTRUCTION}

        ------------------------------------------------------------
Your primary function is to answer user queries while intelligently using the `showScreen` tool. The sequence of your actions is critical.

**Workflow:**

1.  **Analyze the Query:** First, Map user's request to one of the `Available Screens` listed below.
2.  **Execute the Correct Path:**
    2.1. Your first action is to make a tool call to `showScreen` with the relevant `screen_name`.
    2.2. After the tool call completes and returns its result, you will then formulate and provide your final text-based answer to the user.
    2.3. Make sure to never talk about the tool or screen in response to guest query. Like never say "I have brought up the pool screen for you." or "I have brought up the main screen for you."

**Available Screens:**

*   `spa`: For questions about spa services or bookings.
*   `pool`: For information on pool facilities and hours.
*   `food`: For menus, restaurant hours, dining reservations, in-room dining, or any conversation related to food.
*   `nearby`: For local attractions, points of interest, or directions.
*   `main`: When the user asks to go to the home or main screen.
*   `other`: For any other question that is not related to the screens.

---
**Examples of Correct Behavior**

*   **User asks:** "What time does the pool close tonight?"
*   **Correct AI Response (after `showScreen('pool')` completes):** "The pool closes at 10:00 PM. I've also brought up the pool information screen for you."

*   **User asks:** "Are there any good places to eat around here?"
*   **Correct AI Response (after `showScreen('nearby')` completes):** "Yes, there are several great options nearby. I have pulled up a list of local restaurants for you to browse."

*   **User asks:** "Who was the first person on the moon?"
*   **Correct AI Response (after `showScreen('other')` completes):** "The first person to walk on the moon was Neil Armstrong."
------------------------------------------------------------------
        
VERY IMPORTANT: MAKE SURE TO USE TOOL FIRST AND THEN ANSWER THE QUESTION

        Here is the information about the hotel:
        {self.HOTEL_INFO}

VERY IMPORTANT: DONT MAKE UP INFORMATION, ALWAYS REFER TO THE HOTEL INFO IF YOU DONT KNOW THE ANSWER. IF STILL YOU DONT KNOW THE ANSWER, SAY YOU DON'T KNOW IN POLITE MANNER.
VERY IMPORTANT: IF YOU CANNOT FULLFILL THE USER REQUEST, SAY YOU CANNOT FULLFILL THE REQUEST IN POLITE MANNER, DONT SAY ANY TECHNICAL DETAILS.

------------------------------------------------------------------
You can also use the `placeOrder` tool to place an order for a hotel room with item details.
for room number, always use 102 as the room number.
for item name, extract item name from user query.
for remarks, add other things like quantity, time, destination, etc.
If user asks for changing order, increase quantity, please tell user that its not possible and new order has to placed
IF USER ASKS FOR QUANTITY GREATER THAN 10, PLEASE TELL USER THAT ALLOWED QUANTITY IS 10 ONLY AND DONT MAKE TOOL CALL.

VERY IMPORTANT: WHEN THERE IS ANY BOOKING RELATED QUESTION, DONT USE `showScreen` tool, use `placeOrder` tool instead.

VERY IMPORTANT: WHEN USER ASKS TO TURN OFF LIGHTS, USE `turnOffLights` tool instead of `showScreen` tool.
VERY IMPORTANT: WHEN USER ASKS TO TURN ON LIGHTS, USE `turnOnLights` tool instead of `showScreen` tool.
VERY IMPORTANT: WHEN USER ASKS TO TURN OFF TV, USE `turnOffTV` tool instead of `showScreen` tool.
VERY IMPORTANT: WHEN USER ASKS TO TURN ON TV, USE `turnOnTV` tool instead of `showScreen` tool.
VERY IMPORTANT: WHEN USER ASKS TO TURN OFF ALL OR TURN OFF LIGHTS AND ANYTHING ELSE, USE `turnOffAll` tool instead of `showScreen` tool.
VERY IMPORTANT: WHEN USER ASKS TO TURN ON ALL OR TURN ON LIGHTS AND ANYTHING ELSE, USE `turnOnAll` tool instead of `showScreen` tool.
------------------------------------------------------------------

       """

        # weather_function = FunctionDeclaration(
        #     name="get_current_weather",
        #     description="Get current weather in a given location",
        #     parameters=Schema(
        #         type="object",
        #         properties={
        #             "location": Schema(type="string", description="City name"),
        #             "unit": Schema(type="string", enum=["celsius", "fahrenheit"])
        #         },
        #         required=["location"]
        #     )
        # )
        # self.tools = [Tool(function_declarations=[weather_function])]
        self.tools = [
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="showScreen",
                    description="Display a specific hotel screen based on user request. Use this to show relevant screens for spa, pool, food, nearby attractions, main screen, or turn off.",
                    parameters=Schema(
                        type="object",
                        properties={
                            "screen_name": Schema(
                                type="string", 
                                description="Name of the screen to display. Available options: 'main' (default/home screen), 'spa' (spa services), 'pool' (pool area), 'food' (dining/restaurant), 'nearby' (nearby attractions), 'turnoff' (turn off/goodbye screen)"
                            ),
                        },
                        required=["screen_name"]
                    )
                )
            ]),
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="turnOffLights",
                    description="Turn off the lights in the room.",
                    parameters=Schema(
                        type="object",
                        properties={
                        },
                        required=[]
                    )
                )
            ]),
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="turnOnLights",
                    description="Turn on the lights in the room.",
                    parameters=Schema(
                        type="object",
                        properties={
                        },
                        required=[]
                    )
                )
            ]),
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="turnOffTV",
                    description="Turn off the TV in the room.",
                    parameters=Schema(
                        type="object",
                        properties={
                        },
                        required=[]
                    )
                )
            ]),
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="turnOnTV",
                    description="Turn on the TV in the room.",
                    parameters=Schema(
                        type="object",
                        properties={
                        },
                        required=[]
                    )
                )
            ]),
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="turnOffAll",
                    description="Turn off everything in the room.",
                    parameters=Schema(
                        type="object",
                        properties={
                        },
                        required=[]
                    )
                )
            ]),
            Tool(function_declarations=[
                FunctionDeclaration(
                    name="turnOnAll",
                    description="Turn on everything in the room.",
                    parameters=Schema(
                        type="object",
                        properties={
                        },
                        required=[]
                    )
                )
            ]),
            Tool(
                function_declarations=[
                    FunctionDeclaration(
                        name="placeOrder",
                        description="Place an order for a hotel room with item details",
                        parameters=Schema(
                            type="object",
                            properties={
                                "room_number": Schema(
                                    type="string",
                                    description="Room number for the order"
                                ),
                                "item_name": Schema(
                                    type="string", 
                                    description="Name of the item being ordered"
                                ),
                                "remarks": Schema(
                                    type="string",
                                    description="Additional remarks or notes for the order (optional)"
                                ),
                            },
                            required=["room_number", "item_name"]
                        )
                    )
                ]
            )
        ]
       

    def set_storage_manager(self, storage_manager: StorageManager):
        self.storage_manager = storage_manager
        self.conversation_history_json = self.storage_manager.get_conversation_history()
        for message in self.conversation_history_json:
            self.history.append(genai.types.Content(
                role=message["role"],
                parts=[genai.types.Part(text=message["content"])]
            ))

    async def process(
            self, 
            input_text: str, 
            send_to_client: SendToClientCallable,
            llm_output_queue: Queue
        ):

        
        try:
            self.streaming_cancel_event = asyncio.Event()
            await send_to_client("LLM:START", {
                "text": "Starting LLM"
            })
            print(f"Input Text: {input_text}")
            input_text_json = json.loads(input_text) 
            if input_text_json.get("text") != "":
                input_text = input_text_json.get("text")
            if input_text_json.get("fn_response") is not None:
                function_call_response = input_text_json.get("fn_response")
                function_response_parts = []
                for function_call in function_call_response:

                    function_response_parts.append(genai.types.Part(
                        function_response=FunctionResponse(
                            name=function_call.get("fn_name"),
                            response={"result":function_call.get("fn_response")}
                        )
                    ))
                    
                    self.conversation_history_json.append({
                        "role": "function_response",
                        "name": function_call.get("fn_name"),
                        "content": function_call.get("fn_response")
                    })
                print(f"Function Response Parts: {function_response_parts}")
                if len(function_response_parts) > 0:
                    self.history.append(genai.types.Content(
                        role="function",
                        parts=function_response_parts
                    ))
            else:
                self.conversation_history_json.append({
                    "role": "user",
                    "content": input_text
                })
                

                self.history.append(genai.types.Content(
                    role="user",
                    parts=[genai.types.Part(text=input_text)]
                ))
            print(f"History: {self.history}")
            self.storage_manager.set_conversation_history(self.conversation_history_json)

            self.streaming_responses = await self.client.aio.models.generate_content_stream(
                model=self.model_id,
                contents=self.history,
                config=GenerateContentConfig(
                    response_modalities=["TEXT"],
                    system_instruction=self.system_instruction,
                    tools=self.tools,
                ),
                
            )

            full_llm_response = ""
            function_call_response = []
            async for chunk in self.streaming_responses:
                if chunk.candidates:
                    for candidate in chunk.candidates:
                        if candidate.content and candidate.content.parts:
                            print(f"Candidate: {candidate.content.parts}")
                            for part in candidate.content.parts:

                                if isinstance(part, Part):
                                    if part.text:
                                        if self.streaming_cancel_event.is_set():
                                            break
                                        await send_to_client("LLM:CHUNK", {
                                            "text": chunk.text
                                        })
                                        full_llm_response += chunk.text
                                        llm_output_queue.put_nowait(chunk.text)
                                    elif part.function_call:
                                        print(f"Function Call: {part.function_call}")
                                        # await send_to_client("LLM:FUNCTION_CALL", {
                                        #     "function_name": part.function_call.name,
                                        #     "arguments": part.function_call.args,
                                        #     "call_id":part.function_call.id
                                        # })
                                        function_call_response.append({
                                            "function_name": part.function_call.name,
                                            "arguments": part.function_call.args,
                                            "call_id":part.function_call.id
                                        })
    
                # if chunk.text:
                #     print(chunk.text)
                #     # print(chunk.text, end="", flush=True)
                #     if self.streaming_cancel_event.is_set():
                #         break
                #     await send_to_client("LLM:CHUNK", {
                #         "text": chunk.text
                #     })
                #     full_llm_response += chunk.text
                #     llm_output_queue.put_nowait(chunk.text)
            
            if len(function_call_response) > 0:
                await send_to_client("LLM:FUNCTION_CALL", {
                    "function_calls": function_call_response
                })
            llm_output_queue.put_nowait(None)

            if not self.streaming_cancel_event.is_set():
                if full_llm_response!= "":
                    self.conversation_history_json.append({
                        "role": "model",
                        "content": full_llm_response
                    })
                    self.history.append(genai.types.Content(
                        role="model",
                        parts=[genai.types.Part(text=full_llm_response)]
                    ))
                function_call_parts = []
                for function_call in function_call_response:
                    self.conversation_history_json.append({
                        "role": "function",
                        "name": function_call.get("function_name"),
                        "content": json.dumps(function_call.get("arguments"))
                    })
                    function_call_parts.append(genai.types.Part(function_call=FunctionCall(
                            name=function_call.get("function_name"),
                            args=function_call.get("arguments"),
                            id=function_call.get("call_id")
                        ))
                    )
                print(f"Function Call Parts: {function_call_parts}")
                if len(function_call_parts) > 0:
                    self.history.append(genai.types.Content(
                        role="function",
                        parts=function_call_parts
                    ))
                self.storage_manager.set_conversation_history(self.conversation_history_json)

                await send_to_client("LLM:DONE", {
                    "text": "LLM Done"
                })
        except Exception as e:
            print(f"[ERROR][LLMHandler][process] {e}")



    async def stop(self):
        try:
            self.streaming_cancel_event.set()
        except Exception as e:
            print(f"[ERROR][LLMHandler][stop] {e}")