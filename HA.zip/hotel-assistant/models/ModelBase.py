import asyncio
from abc import ABC, abstractmethod
from typing import AsyncGenerator, Callable, Union, Awaitable

SendToClientCallable = Callable[[str, dict], Awaitable[None]]

class ModelBase(ABC):
    @abstractmethod
    async def process(
        self, 
        input_stream:AsyncGenerator,
        send_to_client:SendToClientCallable,
    ) -> AsyncGenerator:
        pass