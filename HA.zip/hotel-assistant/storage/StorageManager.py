from storage.JSONStorage import JSONStorage

class StorageManager:

    def init_session(self, session_id: str):
        self.storage = JSONStorage(session_id)

    def get_conversation_history(self):
        return self.storage.get_conversation_history()

    def set_conversation_history(self, history: list):
        self.storage.set_conversation_history(history)