﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagicInk
{
    public partial class CustomPanel : Panel
    {
        public CustomPanel()
        {
            // Assuming 'myPanel' is your Panel control
            this.AutoScroll = true; // Enable auto-scrolling
            this.AutoScrollMinSize = new Size(6000, 10000); // Set the vertical scroll length to 1000 pixels

            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.ResizeRedraw, true); // Redraw the control when resized
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true); // Enable double buffering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true); // Ignore the window message WM_ERASEBKGND to reduce flicker
            this.SetStyle(ControlStyles.UserPaint, true); // Control paints itself
        }

        protected override void WndProc(ref Message m)
        {
            // Hide scroll bars by intercepting the relevant Windows message
            WindowInterop.ShowScrollBar(this.Handle, WindowInterop.SB_BOTH, 0);
            base.WndProc(ref m);
        }

        
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            // Do nothing to ignore mouse wheel scrolling
        }
        
        
    }
}
