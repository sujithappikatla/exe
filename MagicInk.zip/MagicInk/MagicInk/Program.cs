using System.Collections;

namespace MagicInk
{
    internal static class Program
    {

        static ArrayList FormsList;
        static ChromeOverlayManager cm;
        public static SynchronizationContext UiContext;


        [STAThread]
        static void Main()
        {
            
            ApplicationConfiguration.Initialize();
            UiContext = SynchronizationContext.Current;
            cm = new ChromeOverlayManager();

            ProcessOverlayCreator creator = new ProcessOverlayCreator();



            //creator.OverlayFor("chrome");
            creator.OverlayFor("POWERPNT");
            FormsList = creator.CreateOverlays();

            if (FormsList.Count > 0)
            {
                
                Application.Run((Form)FormsList[0]);
            }
        }

    }
}