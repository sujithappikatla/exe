using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using static MagicInk.WindowInterop;

namespace MagicInk
{
    public partial class DrawingCanvas : Form
    {

        private System.Windows.Forms.Timer positionTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer scrollTimer = new System.Windows.Forms.Timer();
        private int targetScrollY = 0;
        private int scrollStep = 40; // Pixels to scroll per timer tick


        IntPtr targetWindowHandle;

        private List<List<Point>> drawingPaths = new List<List<Point>>();
        private List<Point> currentPath;

        private Bitmap drawingBitmap;

        private Point previousPoint = Point.Empty;


        private bool isDrawing = false; // Indicates whether the mouse is currently down

        private CustomPanel drawingPanel;

        int width = 0;
        int height = 0;
        public DrawingCanvas(IntPtr twh)
        {

            InitializeComponent();
            targetWindowHandle = twh;

            InitializeWindowStyles();
            InitializePositionAndSizeTimer();
            InitializeDrawingPanel();

            // In your form's Load event or after initializing the panel
            drawingBitmap = new Bitmap(6000, 10000); // Adjust size as necessary
            using (Graphics g = Graphics.FromImage(drawingBitmap))
            {
                g.Clear(Color.HotPink); // Start with a blank canvas
            }

            //MessageBox.Show($"{drawingPanel.Width} {drawingPanel.Height}");

            scrollTimer.Interval = 5; // Milliseconds between ticks - adjust for smoother or faster animation
            scrollTimer.Tick += ScrollTimer_Tick;
            scrollTimer.Start();

        }

        private void ScrollTimer_Tick(object sender, EventArgs e)
        {
            // Calculate the current scroll position and the distance to the target
            int currentScrollY = drawingPanel.VerticalScroll.Value;
            int distanceToTarget = targetScrollY - currentScrollY;

            scrollStep = Math.Abs(distanceToTarget) / 2;

            //if (Math.Abs(distanceToTarget) <= scrollStep)
            if(scrollStep == 0)
            {
                // Close enough to target, jump to final position and stop the timer
                drawingPanel.VerticalScroll.Value = targetScrollY;
               // scrollTimer.Stop();
            }
            else
            {
                // Move towards the target
                drawingPanel.VerticalScroll.Value += Math.Sign(distanceToTarget) * scrollStep;

            }

            // Force the panel to update its scroll position
            drawingPanel.PerformLayout();
        }



        private void InitializeWindowStyles()
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void InitializePositionAndSizeTimer()
        {
            positionTimer.Interval = 10; // Update interval in milliseconds
            positionTimer.Tick += (sender, e) => UpdatePositionAndSize(targetWindowHandle);
            positionTimer.Start();
        }

        private void UpdatePositionAndSize(IntPtr targetHWND)
        {
            if (targetHWND != IntPtr.Zero)
            {
                /*
                IntPtr foregroundWindow = WindowInterop.GetForegroundWindow();
                if (foregroundWindow == this.Handle || foregroundWindow == targetHWND)
                {
                    this.Show();
                }
                else
                {
                    this.Hide();
                }
                */

                WindowInterop.RECT rect;
                if (WindowInterop.GetWindowRect(targetHWND, out rect))
                {
                    this.Invoke(new Action(() =>
                    {
                        if(width!=0)
                        {
                            int topOffset = ((rect.Bottom - rect.Top) - height);
                            
                            this.SetBounds(rect.Left, rect.Top+topOffset, width-50, height - 50);
                           // MessageBox.Show($"{rect.Left} {rect.Top} {rect.Right - rect.Left - 50} {width}");
                        }
                        else
                        {
                            this.SetBounds(rect.Left, rect.Top + 150, rect.Right - rect.Left-50, rect.Bottom - rect.Top - 150);
                        }
                        
                    }));
                }
            }
        }

        private void InitializeDrawingPanel()
        {
            drawingPanel = new CustomPanel();
            drawingPanel.Dock = DockStyle.Fill;
            drawingPanel.AutoScroll = true;
            drawingPanel.BackColor = Color.Transparent;
           // drawingPanel.MouseDown += new MouseEventHandler(PanelMouseDown);
           // drawingPanel.MouseMove += new MouseEventHandler(PanelMouseMove);
           // drawingPanel.MouseUp += new MouseEventHandler(PanelMouseUp);

            drawingPanel.MouseDown += panel1_MouseDown;
            drawingPanel.MouseMove += panel1_MouseMove;
            drawingPanel.MouseUp += panel1_MouseUp;
            drawingPanel.Paint += panel1_Paint;
            drawingPanel.Resize += panel1_Resize;
            drawingPanel.Scroll += panel1_Scroll;
            this.Controls.Add(drawingPanel);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isDrawing = true;
            // Adjust the point for the current scroll position
            previousPoint = new Point(e.X - drawingPanel.AutoScrollPosition.X, e.Y - drawingPanel.AutoScrollPosition.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                using (Graphics g = Graphics.FromImage(drawingBitmap))
                {
                    Point currentPoint = new Point(e.X - drawingPanel.AutoScrollPosition.X, e.Y - drawingPanel.AutoScrollPosition.Y);
                    if (previousPoint != Point.Empty)
                    {
                        g.DrawLine(Pens.Beige, previousPoint, currentPoint);
                    }
                    previousPoint = currentPoint;
                }
                drawingPanel.Invalidate(); // Invalidate to trigger a repaint
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDrawing = false;
            previousPoint = Point.Empty; // Reset previous point
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Draw the bitmap at adjusted position based on the current scroll position
            e.Graphics.DrawImage(drawingBitmap, drawingPanel.AutoScrollPosition.X, drawingPanel.AutoScrollPosition.Y);
        }

        private void panel1_Resize(object sender, EventArgs e)
        {
            drawingPanel.Invalidate(); // Redraw when the panel is resized
        }

        private void panel1_Scroll(object sender, EventArgs e)
        {
            drawingPanel.Refresh(); // Redraw when the panel is resized
        }

        private void DrawingCanvas_Load(object sender, EventArgs e)
        {

        }

        public void ToggleFocusable(bool makeFocusable)
        {
            int exStyle = WindowInterop.GetWindowLong(this.Handle, WindowInterop.GWL_EXSTYLE);
            if (makeFocusable)
            {
                // Remove WS_EX_NOACTIVATE to make the window focusable
                exStyle &= ~(WindowInterop.WS_EX_NOACTIVATE | WindowInterop.WS_EX_TRANSPARENT);
            }
            else
            {
                // Add WS_EX_NOACTIVATE to make the window not focusable
                exStyle |= (WindowInterop.WS_EX_NOACTIVATE | WindowInterop.WS_EX_TRANSPARENT);
            }
            WindowInterop.SetWindowLong(this.Handle, WindowInterop.GWL_EXSTYLE, exStyle);

            // Update the window to apply changes

            this.Show();
        }

        public void SetOverlaySize(int w, int h)
        {
            width = (int)(w*1.5); 
            height = (int)(h*1.5);
            //MessageBox.Show($"width {width} height {height}");
        }

        internal void SetScrollInfo(float scrollX, float scrollY)
        {
            float scrollFactor = 1.5f;

            // drawingPanel.AutoScrollPosition = new Point(Math.Abs((int)(scrollX* scrollFactor)), Math.Abs((int)(scrollY* scrollFactor)));

            targetScrollY = (int)(scrollY * scrollFactor);

            //drawingPanel.VerticalScroll.Value = targetScrollY;

        }
    }
}
