﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagicInk
{
    class ChromeOverlayManager : IProcessOverlay
    {
        Dictionary<string, DrawingCanvas> forms = new Dictionary<string, DrawingCanvas>();
        Queue<string> messages = new Queue<string>();
        private System.Windows.Forms.Timer pt = new System.Windows.Forms.Timer();


        public ChromeOverlayManager() 
        {   
            InitializeChromeServer();

            pt.Interval = 100; // Update interval in milliseconds
            pt.Tick += (sender, e) => check();
            pt.Start();

        }

        void check()
        {
            while(messages.Count > 0)
            {
                var msg = messages.Dequeue();
                var json = JsonSerializer.Deserialize<Dictionary<string, object>>(msg);

                var overlayId = json["windowId"].ToString() + json["tabID"].ToString();

                if(forms.ContainsKey(overlayId) == false)
                {
                    CreateOverlay(overlayId);
                }

                foreach (var item in forms)
                {
                    if(item.Key == overlayId)
                    {
                        item.Value.Show(); 
                    }
                    else
                    {
                        item.Value.Hide();
                    }
                }
                if (json.ContainsKey("width"))
                {
                   // MessageBox.Show($"Settingw {json["width"]} sda" );
                   forms[overlayId].SetOverlaySize(int.Parse(json["width"].ToString()), int.Parse(json["height"].ToString()));
                }
                if(json.ContainsKey("scrollX"))
                {
                    float scrollX = float.Parse(json["scrollX"].ToString());
                    float scrollY = float.Parse(json["scrollY"].ToString());

                    forms[overlayId].SetScrollInfo(scrollX, scrollY);
                }



            }
        }

        private async void InitializeChromeServer()
        {
            
            ChromeServer server = new ChromeServer("http://localhost:8088/");
            server.MessageReceived += Server_MessageReceived;
            await server.StartAsync();
        }

        private void Server_MessageReceived(object sender, string e)
        {
            
            Console.WriteLine($"Message Received: {e}");
            
            messages.Enqueue(e);
            
        }


        public void CreateOverlay(string overlayID)
        {
            if (forms.ContainsKey(overlayID))
                return;
            
            Process[] processList = Process.GetProcesses();

            foreach (Process process in processList)
            {
                Console.WriteLine($"Process: {process.ProcessName} PID: {process.Id}");

                if (process.ProcessName == "chrome")
                {

                    _ = WindowInterop.EnumWindows(new WindowInterop.EnumWindowsProc((hWnd, lParam) =>
                    {


                        uint pid;
                        WindowInterop.GetWindowThreadProcessId(hWnd, out pid);
                        if (pid == process.Id)
                        {
                            // This window belongs to the process we're interested in
                            Console.WriteLine($"Window Handle: {hWnd}");

                            if (WindowInterop.IsWindowVisible(hWnd))
                            {

                                forms[overlayID] = new DrawingCanvas(hWnd);
                                forms[overlayID].Show();    

                            }
                        }



                        return true; // Continue enumerating windows
                    }), IntPtr.Zero);
                }
            }

        }



    }
}
