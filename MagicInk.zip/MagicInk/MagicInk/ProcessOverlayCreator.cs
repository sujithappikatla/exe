﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagicInk
{
    class ProcessOverlayCreator
    {
        ArrayList appNames = new ArrayList();
        public ProcessOverlayCreator() { }

        public void OverlayFor(string appName )
        {
            appNames.Add(appName);
        }

        public ArrayList CreateOverlays()
        {
            ArrayList forms = new ArrayList();
            Process[] processList = Process.GetProcesses();

            foreach (Process process in processList)
            {
                Console.WriteLine($"Process: {process.ProcessName} PID: {process.Id}");

                //if (process.ProcessName == "chrome")
                if(appNames.Contains(process.ProcessName) == true)
                {

                    _ = WindowInterop.EnumWindows(new WindowInterop.EnumWindowsProc((hWnd, lParam) =>
                    {


                        uint pid;
                        WindowInterop.GetWindowThreadProcessId(hWnd, out pid);
                        if (pid == process.Id)
                        {
                            // This window belongs to the process we're interested in
                            Console.WriteLine($"Window Handle: {hWnd}");

                            if (WindowInterop.IsWindowVisible(hWnd))
                            {
                             
                                forms.Add(new DrawingCanvas(hWnd));
                                int len = forms.Count;
                                ((Form)forms[len-1]).Show();

                            }
                        }



                        return true; // Continue enumerating windows
                    }), IntPtr.Zero);
                }
            }
            return forms;

        }
    }
}
