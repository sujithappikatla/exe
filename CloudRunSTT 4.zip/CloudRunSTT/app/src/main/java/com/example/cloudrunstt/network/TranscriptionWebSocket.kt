package com.example.cloudrunstt.network

import android.content.Context
import android.util.Log
import com.example.cloudrunstt.auth.CloudRunAuthenticator
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.TimeUnit

/**
 * Handles WebSocket connection to Cloud Run instance for real-time audio transcription
 */
class TranscriptionWebSocket(
    private val context: Context,
    private val serverUrl: String
) {
    companion object {
        private const val TAG = "TranscriptionWebSocket"
        private const val NORMAL_CLOSURE_STATUS = 1000
    }

    private var webSocket: WebSocket? = null
    private val authenticator by lazy {
        // Extract the host from the WebSocket URL for the target audience
        val audience = serverUrl.replace("wss://", "https://")
        Log.d(TAG, "Target audience: $audience")
        CloudRunAuthenticator(context, audience)
    }
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var isConnected = false

    /**
     * Connects to the WebSocket server with authentication
     * @return Flow of transcription results
     */
    suspend fun connect(): Flow<String> = callbackFlow {
        try {
            // Get authentication token
            val token = authenticator.getAccessToken()
            Log.d(TAG, "Got ID token: ${token}...")
            if (token == null) {
                throw IllegalStateException("Failed to obtain authentication token")
            }

            val request = Request.Builder()
                .url(serverUrl)
                .addHeader("Authorization", "Bearer $token")
                .build()

            Log.d(TAG, "Connecting to WebSocket URL: $serverUrl")

            val listener = object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    super.onOpen(webSocket, response)
                    Log.d(TAG, "WebSocket opened successfully with response: ${response.message}")
                    isConnected = true
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    Log.d(TAG, "Received transcription: $text")
                    trySend(text)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    val errorMessage = """
                        WebSocket failure:
                        Error: ${t.message}
                        Response code: ${response?.code}
                        Response message: ${response?.message}
                        Response body: ${response?.body?.string()}
                    """.trimIndent()
                    Log.e(TAG, errorMessage, t)
                    isConnected = false
                    close(t)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "WebSocket closed with code: $code, reason: $reason")
                    isConnected = false
                    close()
                }
            }

            webSocket = client.newWebSocket(request, listener)
            Log.d(TAG, "WebSocket connection initiated")

        } catch (e: Exception) {
            Log.e(TAG, "WebSocket connection error: ${e.message}", e)
            e.printStackTrace()
            throw e
        }

        // Clean up when the flow collection is cancelled
        awaitClose {
            disconnect()
        }
    }

    /**
     * Sends audio data to the WebSocket server
     * @param audioData ByteArray of audio chunk
     */
    fun sendAudioData(audioData: ByteArray) {
        if (!isConnected) {
            Log.w(TAG, "Cannot send audio data: WebSocket not connected")
            return
        }
        try {
            webSocket?.send(ByteString.of(*audioData))
        } catch (e: Exception) {
            Log.e(TAG, "Error sending audio data: ${e.message}", e)
        }
    }

    fun disconnect() {
        webSocket?.close(NORMAL_CLOSURE_STATUS, "Closing connection")
        webSocket = null
        isConnected = false
        Log.d(TAG, "WebSocket disconnected")
    }
} 