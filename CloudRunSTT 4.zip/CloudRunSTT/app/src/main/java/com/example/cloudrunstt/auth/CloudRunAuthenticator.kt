package com.example.cloudrunstt.auth

import android.content.Context
import android.util.Log
import com.google.auth.oauth2.GoogleCredentials
import com.google.auth.oauth2.IdTokenCredentials
import com.google.auth.oauth2.IdTokenProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import com.google.auth.oauth2.ServiceAccountCredentials

/**
 * Handles authentication for Cloud Run using Google Cloud credentials
 */
class CloudRunAuthenticator(
    private val context: Context,
    private val targetAudience: String
) {
    companion object {
        private const val TAG = "CloudRunAuthenticator"
        private const val CREDENTIALS_FILE_NAME = "sa.json"
    }

    /**
     * Gets a fresh ID token for Cloud Run authentication
     * @return ID token string or null if authentication fails
     */
    suspend fun getAccessToken(): String? = withContext(Dispatchers.IO) {
        try {
            // Load credentials from the app's assets
            context.assets.open(CREDENTIALS_FILE_NAME).use { inputStream ->
                // Load as ServiceAccountCredentials
                val serviceAccount = ServiceAccountCredentials.fromStream(inputStream)
                
                // Create IdTokenCredentials with target audience
                val idTokenCredentials = IdTokenCredentials.newBuilder()
                    .setIdTokenProvider(serviceAccount)
                    .setTargetAudience(targetAudience)
                    .build()
                
                // Refresh to get a new token
                idTokenCredentials.refresh()
                
                // Get the ID token
                idTokenCredentials.idToken?.tokenValue.toString()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting ID token: ${e.message}", e)
            e.printStackTrace()
            null
        }
    }
}