package com.example.cloudrunstt.audio

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.nio.ByteBuffer

/**
 * Handles audio recording functionality and provides audio data as a Flow of ByteArray chunks
 */
class AudioRecorder {
    companion object {
        private const val TAG = "AudioRecorder"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val BUFFER_SIZE_FACTOR = 2
    }

    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private val bufferSize = AudioRecord.getMinBufferSize(
        SAMPLE_RATE,
        CHANNEL_CONFIG,
        AUDIO_FORMAT
    ) * BUFFER_SIZE_FACTOR

    /**
     * Starts recording audio and emits chunks of audio data as ByteArray
     * @return Flow of ByteArray containing audio chunks
     */
    fun startRecording(): Flow<ByteArray> = flow {
        try {
            initializeAudioRecord()
            
            val buffer = ByteBuffer.allocateDirect(bufferSize)
            val audioData = ByteArray(bufferSize)
            
            audioRecord?.startRecording()
            isRecording = true
            Log.d(TAG, "Started recording audio")

            while (isRecording) {
                val bytesRead = audioRecord?.read(buffer, bufferSize) ?: 0
                if (bytesRead > 0) {
                    buffer.get(audioData)
                    emit(audioData.copyOf())
                    buffer.clear()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error recording audio: ${e.message}", e)
            throw e
        }
    }.flowOn(Dispatchers.IO)

    @SuppressLint("MissingPermission")
    private fun initializeAudioRecord() {
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            bufferSize
        )
    }

    fun stopRecording() {
        isRecording = false
        audioRecord?.apply {
            stop()
            release()
        }
        audioRecord = null
        Log.d(TAG, "Stopped recording audio")
    }
} 