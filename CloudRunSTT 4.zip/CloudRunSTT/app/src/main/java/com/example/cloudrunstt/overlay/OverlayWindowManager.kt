package com.example.cloudrunstt.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.lifecycle.lifecycleScope

/**
 * Manages the overlay window that displays transcription text
 */
class OverlayWindowManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    companion object {
        private const val TAG = "OverlayWindowManager"
        private const val MAX_LINES = 3
    }

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: ComposeView? = null
    private var transcriptionLines = mutableStateListOf<String>()

    private val savedStateRegistryOwner = object : SavedStateRegistryOwner {
        private val savedStateRegistryController = SavedStateRegistryController.create(this)
        override val lifecycle = lifecycleOwner.lifecycle
        override val savedStateRegistry: SavedStateRegistry
            get() = savedStateRegistryController.savedStateRegistry
        init {
            savedStateRegistryController.performRestore(null)
        }
    }

    private val layoutParams = WindowManager.LayoutParams().apply {
        type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        format = PixelFormat.TRANSLUCENT
        width = WindowManager.LayoutParams.MATCH_PARENT
        height = WindowManager.LayoutParams.WRAP_CONTENT
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        y = 100 // Distance from bottom
    }

    fun show(content: @Composable () -> Unit) {
        try {
            if (overlayView == null) {
                overlayView = ComposeView(context).apply {
                    setViewTreeLifecycleOwner(lifecycleOwner)
                    setViewTreeSavedStateRegistryOwner(savedStateRegistryOwner)
                    
                    setViewCompositionStrategy(
                        ViewCompositionStrategy.DisposeOnDetachedFromWindow
                    )
                    
                    setContent {
                        SubtitleOverlay(transcriptionLines)
                    }
                }
                windowManager.addView(overlayView, layoutParams)
                Log.d(TAG, "Overlay window shown")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing overlay window: ${e.message}", e)
        }
    }

    @Composable
    private fun SubtitleOverlay(lines: List<String>) {
        val lazyListState = rememberLazyListState()
        val configuration = LocalConfiguration.current
        val screenWidth = configuration.screenWidthDp.dp
        
        LaunchedEffect(lines.size) {
            if (lines.isNotEmpty()) {
                lazyListState.animateScrollToItem(lines.size - 1)
            }
        }

        Box(
            modifier = Modifier
                .width(screenWidth * 0.8f)
                .background(Color.Black.copy(alpha = 0.7f))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 24.dp, max = 120.dp), // Explicit height constraints
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                lines.takeLast(MAX_LINES).forEach { line ->
                    AnimatedVisibility(
                        visible = true,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Text(
                            text = line,
                            color = Color.White,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }

    fun updateTranscriptionFlow(flow: Flow<String>) {
        lifecycleOwner.lifecycleScope.launch {
            flow.collectLatest { text ->
                transcriptionLines.add(text)
                if (transcriptionLines.size > MAX_LINES * 2) {
                    transcriptionLines.removeFirst()
                }
                overlayView?.invalidate()
                Log.d(TAG, "Updated transcription text: $text")
            }
        }
    }

    fun hide() {
        try {
            overlayView?.let {
                windowManager.removeView(it)
                overlayView = null
                transcriptionLines.clear()
                Log.d(TAG, "Overlay window hidden")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error hiding overlay window: ${e.message}", e)
        }
    }
} 