package com.example.launchtest

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import android.util.Log

@Composable
fun OverlayButton(onClick: () -> Unit) {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (isPressed) 0.9f else 1f)
    
    // Reset isPressed after animation
    LaunchedEffect(isPressed) {
        if (isPressed) {
            delay(100)
            isPressed = false
        }
    }

    Box(
        modifier = Modifier
            .wrapContentSize()
            .padding(16.dp)
    ) {
        // Main button
        Button(
            onClick = { 
                Log.d("OverlayButton", "Main button clicked")
                isPressed = true
                onClick()
            },
            modifier = Modifier
                .size(80.dp)
                .align(Alignment.BottomEnd)
                .scale(scale),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
        ) {
            Text("+", color = Color.White)
        }
    }
}
