package com.example.launchtest

import android.os.Bundle
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInteropFilter
import android.view.View
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.core.view.WindowCompat
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp

class AppActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Make the activity appear as a dialog that takes up the full screen
        window.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        
        window.apply {
            attributes.width = WindowManager.LayoutParams.MATCH_PARENT
            attributes.height = WindowManager.LayoutParams.MATCH_PARENT
            attributes.flags = attributes.flags or 
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            
            setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
            
            statusBarColor = android.graphics.Color.TRANSPARENT
            navigationBarColor = android.graphics.Color.TRANSPARENT
        }
        
        setContent {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x80000000))
            ) {
                DrawingCanvas()
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun DrawingCanvas() {
    var showPopup by remember { mutableStateOf(false) }
    val paths = remember { mutableStateListOf<Path>() }
    var currentPath by remember { mutableStateOf(Path()) }
    val drawColor = Color.White
    val backgroundColor = Color(0x80000000) // Semi-transparent black background

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .navigationBarsPadding()
                .pointerInteropFilter { event ->
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            currentPath = Path().apply {
                                moveTo(event.x, event.y)
                            }
                            true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            currentPath.lineTo(event.x, event.y)
                            paths.add(currentPath)
                            currentPath = Path().apply {
                                moveTo(event.x, event.y)
                            }
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            paths.add(currentPath)
                            currentPath = Path()
                            showPopup = true  // Show popup when drawing ends
                            true
                        }
                        else -> false
                    }
                }
        ) {
            // Calculate the full size of the screen
            val canvasWidth = size.width
            val canvasHeight = size.height
            
            // Draw the semi-transparent background for the entire canvas
            drawRect(
                color = backgroundColor,
                size = androidx.compose.ui.geometry.Size(canvasWidth, canvasHeight)
            )

            // Draw all completed paths
            paths.forEach { path ->
                drawPath(
                    path = path,
                    color = drawColor,
                    style = Stroke(width = 10f)
                )
            }

            // Draw the current path
            drawPath(
                path = currentPath,
                color = drawColor,
                style = Stroke(width = 10f)
            )
        }

        // Add the sliding popup
        if (showPopup) {
            SlidingPopup(
                onDismiss = { showPopup = false }
            )
        }
    }
}

@Composable
fun SlidingPopup(onDismiss: () -> Unit) {
    val offsetY = remember { Animatable(1000f) }

    LaunchedEffect(Unit) {
        offsetY.animateTo(
            targetValue = 0f,
            animationSpec = tween(
                durationMillis = 300,
                easing = FastOutSlowInEasing
            )
        )
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.CenterEnd
    ) {
        Surface(
            modifier = Modifier
                .width(400.dp)
                .fillMaxHeight(0.9f)
                .offset(y = offsetY.value.dp),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text("Your Popup Content Here")
            }
        }
    }
}
