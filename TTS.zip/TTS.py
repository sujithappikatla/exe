# import google.cloud.texttospeech as texttospeech
from google.cloud import texttospeech
import numpy as np
import asyncio

class TTS:
    def __init__(self, voice: str, language: str, text_generator: asyncio.Queue=None):
        self.client = texttospeech.TextToSpeechAsyncClient()
        self.streaming_config = texttospeech.StreamingSynthesizeConfig(
            voice=texttospeech.VoiceSelectionParams(
                name=f"{language}-Chirp3-HD-{voice}",
                language_code=language,
            ),
            streaming_audio_config=texttospeech.StreamingAudioConfig(
                audio_encoding=texttospeech.AudioEncoding.PCM,
                sample_rate_hertz=16000
            )
        )

        self.config_request = texttospeech.StreamingSynthesizeRequest(
            streaming_config=self.streaming_config
        )

        self.text_generator = text_generator
        self.input_text = ""

    async def _request_async_generator(self):
            yield self.config_request
            async for text in self.text_generator:
                # print(f"--------- TTS _request_async_generator got text: {text}")
                self.input_text += text
                yield texttospeech.StreamingSynthesizeRequest(
                    input=texttospeech.StreamingSynthesisInput(text=text)
                )


    async def init(self):
        streaming_responses = await self.client.streaming_synthesize(self._request_async_generator())
        # print("--------- TTS streaming_synthesize call returned, response iterator obtained.")

        async def response_generator():
            try:
                # print("---------  TTS response_generator (audio consumer) started")
                async for response in streaming_responses:
                    if not response.audio_content:
                        # print("--------- TTS received response with no audio_content, skipping.")
                        continue
                    # print(f"--------- TTS Response received, audio_content length: {len(response.audio_content)}")
                    # yield np.frombuffer(response.audio_content, dtype=np.int16)
                    yield response.audio_content
            except Exception as e:
                print(f"---------Error in TTS response_generator: {e}")
                yield None # Signal error
            finally:
                print("--------- TTS response_generator finished.")


        return response_generator()



# def request_generator():
#     data = ["Hello, how are you?", "I'm fine, thank you.", "What is your name?", "I'm a robot."]
#     for i in data:
#         yield i

# tts = TTS(request_generator()).init()
# for chunk in tts:
#     print(len(chunk))



# async def main():
#     queue = asyncio.Queue()

#     tts_handler = TTS(queue) # Create instance once
#     tts_audio_generator = await tts_handler.init() # Initialize and get generator

#     async def producer():
#         for i in range(3):
#             await asyncio.sleep(1)
#             text_to_speak = f"This is sentence number {i+1}."
#             print(f"Producer putting: {text_to_speak}")
#             await queue.put(text_to_speak)
#         await asyncio.sleep(1)
#         print("Producer putting None to signal end.")
#         await queue.put(None) # Signal end of text

#     async def consumer():
#         print("Consumer started.")
#         async for chunk in tts_audio_generator:
#             if chunk is not None:
#                 print(f"Consumer received audio chunk of size: {len(chunk)}")
#             else:
#                 print("Consumer received None chunk, stopping.")
#                 break
#         print("Consumer finished.")

#     # Run producer and consumer concurrently
#     await asyncio.gather(producer(), consumer())


# if __name__ == "__main__":
#     asyncio.run(main())
