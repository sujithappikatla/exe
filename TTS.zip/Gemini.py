from google import genai
from google.genai import types
import asyncio
import time
from openai import AsyncOpenAI


class Gemini:
    def __init__(self, gemini_language:str):

        self.gemini_language = gemini_language
        self.model = "gemini-2.0-flash-lite"
        self.max_output_tokens = 256
        self.temperature = 0.2
        self.system_instruction = f"You are very energetic and enthusiastic Assistant. Be concise and clear. Strictly make sure to answer in {self.gemini_language} Language, no matter what user input text language is"

        self.client = AsyncOpenAI(
            api_key="AIzaSyBOdIk2jRNC3lCK2to_HYxHq7vK54cpPjw",
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/"
        )

    async def generate_content(self, contents):
        start_time = time.time()

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self.system_instruction},
                {
                    "role": "user",
                    "content": contents
                }
            ],
            stream=True
        )

        first_chunk_time = None
        async for chunk in response:
            if first_chunk_time is None:
                first_chunk_time = time.time()
            yield chunk.choices[0].delta.content
        end_time = time.time()
        print(f"Time taken to generate content: {end_time - start_time} seconds")
        print(f"Time taken to generate first chunk: {first_chunk_time - start_time} seconds")






# class Gemini:
#     def __init__(self, gemini_language:str):

#         self.gemini_language = gemini_language
#         self.model = "gemini-2.0-flash-lite"
#         self.max_output_tokens = 256
#         self.temperature = 0.2
#         self.system_instruction = f"Be concise and clear. Strictly make sure to answer in {self.gemini_language} Language, no matter what user input text language is"

#         self.client = genai.Client(
#             vertexai=True,
#             project='cloud-learning-443407',
#             location='us-central1',
#             http_options=types.HttpOptions(api_version='v1')
#         )


#     async def generate_content(self, contents):
#         start_time = time.time()
#         response_stream = await self.client.aio.models.generate_content_stream(
#             model=self.model,
#             contents=contents,
#             config=types.GenerateContentConfig(
#                 max_output_tokens=self.max_output_tokens,
#                 temperature=self.temperature,
#                 system_instruction=self.system_instruction
#             )
#         )
#         first_chunk_time = None
#         async for chunk in response_stream:
#             if first_chunk_time is None:
#                 first_chunk_time = time.time()
#             yield chunk.text
#         end_time = time.time()
#         print(f"Time taken to generate content: {end_time - start_time} seconds")
#         print(f"Time taken to generate first chunk: {first_chunk_time - start_time} seconds")



# async def main():
#     gemini = Gemini("Telugu")
    
#     # Example 1: Simple prompt with streaming response
#     print("Example 1: Quantum computing explanation")
#     async for chunk in gemini.generate_content("Explain quantum computing in simple terms."):
#         print(chunk)
#     print("\n")
    

# if __name__ == "__main__":
#     asyncio.run(main())
