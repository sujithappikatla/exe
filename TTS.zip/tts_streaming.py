"""Synthesizes speech from a stream of input text."""
from google.cloud import texttospeech
import numpy as np
import sounddevice as sd
import soundfile as sf
import time
client = texttospeech.TextToSpeechClient()

# See https://cloud.google.com/text-to-speech/docs/voices for all voices.
streaming_config = texttospeech.StreamingSynthesizeConfig(
    voice=texttospeech.VoiceSelectionParams(
        name="en-US-Chirp3-HD-Charon",
        language_code="en-US",
    )
)

# Set the config for your stream. The first request must contain your config, and then each subsequent request must contain text.
config_request = texttospeech.StreamingSynthesizeRequest(
    streaming_config=streaming_config
)

prompt = """
Google Cloud Text-to-Speech (TTS) is a powerful API that converts text into natural-sounding audio. Here's a breakdown:

**Key Features:**

* **High-Fidelity Speech:** Leverages advanced AI to generate speech that closely resembles human voices.
* **Wide Voice Selection:** Offers a vast library of over 380 voices across 50+ languages and variants, catering to diverse needs.
* **Customization Options:**
    * **Custom Voice:** Create unique voices tailored to your brand or specific requirements using your own audio recordings.
    * **SSML Support:** Utilize Speech Synthesis Markup Language (SSML) to control pronunciation, pacing, and other speech nuances.
* **Integration Flexibility:** Easily integrate with various applications and devices via REST or gRPC APIs.
* **Use Cases:**
    * **Voice Assistants:** Powering conversational AI in smart devices, chatbots, and voice-activated applications.
    * **Accessibility:** Enabling screen readers and text-to-speech features for users with disabilities.
    * **E-learning:** Creating engaging and accessible educational content.
    * **Audiobooks and Podcasts:** Producing high-quality audio for audiobooks, podcasts, and other audio content.
    * **Interactive Experiences:** Enhancing user experiences in games, virtual reality, and other interactive applications.

**In essence, Google Cloud Text-to-Speech empowers developers and businesses to:**

* **Enhance user experiences:** Create more engaging and inclusive interactions through natural-sounding speech.
* **Increase accessibility:** Make information more accessible to a wider audience, including those with visual impairments.
* **Improve efficiency:** Automate tasks like reading aloud documents, generating voiceovers, and creating interactive voice responses.
* **Innovate with new applications:** Explore novel use cases by leveraging the power of AI-powered speech synthesis.

If you're looking to add a voice dimension to your applications or projects, Google Cloud Text-to-Speech is a valuable tool to consider.
"""


text_iterator = [
    "Hello there. ",
    "How are you ",
    "today? It's ",
    "such nice weather outside.",
]

# Request generator. Consider using Gemini or another LLM with output streaming as a generator.
def request_generator():
    yield config_request
    for text in prompt.split(" "):
        yield texttospeech.StreamingSynthesizeRequest(
            input=texttospeech.StreamingSynthesisInput(text=text)
        )

streaming_responses = client.streaming_synthesize(request_generator())

# Assuming a sample rate of 24000 Hz as used in the original code.
# If your voice model uses a different sample rate, adjust this value.
# For example, some Google Cloud TTS voices might output at 24000 Hz or 48000 Hz.
# You might need to inspect the first response or know the voice's characteristics
# to set this dynamically if it's not fixed.
sample_rate = 24000  # Hz

# Setup the output stream
# Using 1 channel (mono) as is typical for TTS.
# dtype='int16' because the audio_content is typically 16-bit PCM.
try:
    stream = sd.OutputStream(samplerate=sample_rate, channels=1, dtype='int16')
    stream.start()
    print(f"Audio stream started at {sample_rate} Hz.")
    count = 0
    for response in streaming_responses:
        count += 1
        if response.audio_content:
            chunk = np.frombuffer(response.audio_content, dtype=np.int16)
            stream.write(chunk)
            print(f"Played audio chunk, size in bytes: {len(response.audio_content)}")
    print(f"Total chunks processed: {count}")
except Exception as e:
    print(f"An error occurred: {e}")
finally:
    if 'stream' in locals() and stream:
        stream.stop()
        stream.close()
        print("Audio stream stopped and closed.")

# The original code for saving to 'output.wav' is removed as we are streaming.
# If you need to save the file as well, you would have to collect the chunks
# in a list again and then write them, similar to your original code.
# For example:
# all_chunks_for_saving = []
# ... in the loop: all_chunks_for_saving.append(chunk) ...
# audio_buffer_for_saving = np.concatenate(all_chunks_for_saving)
# sf.write('output.wav', audio_buffer_for_saving, sample_rate)