import os
from flask import Flask, render_template, redirect, request
from flask_socketio import SocketIO, emit, join_room, leave_room
from TTS import TTS
import asyncio
from Gemini import Gemini
app = Flask(__name__, static_folder='frontend', static_url_path='/static')
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

@app.route('/')
def index():
    return redirect('/static/index.html')

@app.route('/index.html')
def index_html():
    return redirect('/static/index.html')

@socketio.on('connect')
def handle_connect():
    print(f"Client connected: {request.sid}")
    join_room(request.sid)

@socketio.on('disconnect')
def handle_disconnect():
    print(f"Client disconnected: {request.sid}")
    leave_room(request.sid)

@socketio.on('message')
def handle_message(data):
    client_id = request.sid
    print(f"Client {client_id} sent: {data}")
    
    async def process_tts():
        # async def text_generator():
        #     yield data
        
        text = data["text"]
        voice = data["voice"]
        gemini_language = data["gemini-language"]
        language = data["language"]
        gemini = Gemini(gemini_language)   

        generator = gemini.generate_content(text)

        try:
            tts = TTS(voice,language, generator)
            responses = await tts.init()
            
            async for chunk in responses:
                # print(f"Sending audio chunk to client {client_id}")
                if chunk is not None:
                    # Send audio chunks only to the requesting client
                    socketio.emit('audio_chunk', {'data': chunk, 'text': tts.input_text}, room=client_id)
        except Exception as e:
            print(f"Error in TTS processing: {e}")
    
    # Run the async function in a background task
    socketio.start_background_task(asyncio.run, process_tts())

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=8000, allow_unsafe_werkzeug=True)

