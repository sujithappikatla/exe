const socket = io();
let audioContext;
let audioQueue = [];
let isPlaying = false;

// UI elements
const connectionStatus = document.getElementById('connection-status');
const audioStatus = document.getElementById('audio-status');

// Update UI status displays
function updateConnectionStatus(status) {
    connectionStatus.textContent = status;
    connectionStatus.className = status === 'Connected' ? 'text-green-500' : 'text-red-500';
}

function updateAudioStatus(status) {
    audioStatus.textContent = status;
    
    // Reset classes
    audioStatus.className = '';
    
    // Add appropriate color class
    if (status === 'Playing') {
        audioStatus.className = 'text-green-500 animate-pulse';
    } else if (status === 'Buffering') {
        audioStatus.className = 'text-yellow-500';
    } else {
        audioStatus.className = 'text-gray-400';
    }
}

// Initialize audio context on user interaction to comply with browser autoplay policies
function initAudio() {
    if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        console.log('Audio context initialized');
    }
}

// Convert hex string to ArrayBuffer
function hexToArrayBuffer(hexString) {
    const bytes = new Uint8Array(hexString.length / 2);
    for (let i = 0; i < hexString.length; i += 2) {
        bytes[i / 2] = parseInt(hexString.substring(i, i + 2), 16);
    }
    return bytes.buffer;
}

// Play audio from buffer - PCM format
async function playAudioBuffer(arrayBuffer) {
    try {
        updateAudioStatus('Processing');
        
        // Create an AudioBuffer from the PCM data
        // Assuming 16-bit PCM, mono, 24000Hz sample rate (adjust if needed)
        const pcmData = new Int16Array(arrayBuffer);
        
        // Convert Int16Array to Float32Array for AudioBuffer
        const float32Data = new Float32Array(pcmData.length);
        for (let i = 0; i < pcmData.length; i++) {
            // Convert from Int16 (-32768 to 32767) to Float32 (-1.0 to 1.0)
            float32Data[i] = pcmData[i] / 32768.0;
        }
        
        // Create AudioBuffer
        const sampleRate = 16000; // Adjust to match your TTS output sample rate
        const audioBuffer = audioContext.createBuffer(1, float32Data.length, sampleRate);
        audioBuffer.getChannelData(0).set(float32Data);
        
        // Play the buffer
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        
        source.onended = () => {
            console.log('Finished playing audio chunk');
            playNextInQueue();
        };
        
        updateAudioStatus('Playing');
        source.start(0);
        console.log('Playing audio chunk');
    } catch (error) {
        console.error('Error playing audio:', error);
        playNextInQueue();
    }
}

// Process next audio in queue
function playNextInQueue() {
    if (audioQueue.length > 0) {
        const nextBuffer = audioQueue.shift();
        playAudioBuffer(nextBuffer);
    } else {
        isPlaying = false;
        updateAudioStatus('Idle');
        console.log('Audio queue empty');
    }
}

// Add audio to queue and start playing if not already
function addToAudioQueue(arrayBuffer) {
    audioQueue.push(arrayBuffer);
    
    if (!isPlaying) {
        isPlaying = true;
        playNextInQueue();
    } else if (audioQueue.length > 1) {
        updateAudioStatus('Buffering (' + audioQueue.length + ')');
    }
}

socket.on('connect', function() {
    console.log('Connected to server');
    updateConnectionStatus('Connected');
});

socket.on('disconnect', function() {
    console.log('Disconnected from server');
    updateConnectionStatus('Disconnected');
    updateAudioStatus('Idle');
});

socket.on('audio_chunk', function(data) {
    console.log('Received audio chunk');
    if (data && data.data) {
        // const arrayBuffer = hexToArrayBuffer(data.data);
        const arrayBuffer = data.data;
        const text = data.text;
        document.getElementById('text-input-text').textContent = text;
        addToAudioQueue(arrayBuffer);
    }
});

document.getElementById('send-btn').addEventListener('click', function() {
    initAudio(); // Initialize audio context on user interaction
    
    const text = document.getElementById('text-input').value;
    if (!text.trim()) return; // Don't send empty text
    
    console.log('Sending text:', text);
    
    const request_json = {
        "text": text,
        "voice": document.getElementById('voice-status').value,
        "gemini-language": document.getElementById('gemini-language-status').value,
        "language": document.getElementById('language-status').value
    }

    socket.emit('message', request_json);

     
    // Clear input after sending
    // document.getElementById('text-input').value = '';
});

// Initialize UI on load
updateConnectionStatus('Connecting...');