### Running Modules (files inside directories)
```
python3 -m parser.PymupdfParser 
```