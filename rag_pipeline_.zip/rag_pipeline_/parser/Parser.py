from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class Document:
    """
    Document class for storing document data.
    """
    content: str
    id: int
    fileName: str
    fileType: str


class Parser(ABC):
    """
    Abstract class for parsing files.
    """

    def __init__(self):
        self.files = []

    @abstractmethod
    def consider_file(self, file_path: str) -> bool:
        pass

    @abstractmethod
    def consider_directory(self, directory_path: str) -> bool:
        pass
    
    @abstractmethod
    def parse(self) -> list[Document]:
        pass
    