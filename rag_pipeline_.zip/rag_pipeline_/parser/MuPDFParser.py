from .Parser import Parser, Document
import os
import pymupdf4llm
import shutil
from datetime import datetime
import fitz

class MuPDFParser(Parser):
    def __init__(self):
        super().__init__()
        self.files = []
        self.supported_file_types = [".pdf", ".txt"]
        self.file_id_counter = 0
        self.parser_assets_dir = "parser_assets/"+str(datetime.now().strftime("%Y_%m_%d_%H_%M_%S"))
        os.makedirs(self.parser_assets_dir, exist_ok=True)

    def consider_file(self, file_path: str) -> bool:
        file_extension = os.path.splitext(file_path)[1]
        if file_extension not in self.supported_file_types:
            return False
        self.files.append(file_path)
        return True
    
    def consider_directory(self, directory_path: str) -> bool:
        for file in os.listdir(directory_path):
            file_path = os.path.join(directory_path, file)
            if os.path.isdir(file_path):
                self.consider_directory(file_path)
            elif self.files.count(file_path) == 0 and not self.consider_file(file_path) :
                print(f"Skipping file: {file_path}, not supported file type")
        return True
    

    def _copy_file_to_parser_assets(self, file_path: str) -> str:
        file_name = os.path.basename(file_path)
        parser_file_path = os.path.join(self.parser_assets_dir, file_name)
        shutil.copy(file_path, parser_file_path)
        return parser_file_path

    def _parse_pdf(self, file_path: str) -> list[Document]:
        documents = []
        file_name = os.path.basename(file_path)
        file_name_without_extension = os.path.splitext(file_name)[0]
        file_extension = os.path.splitext(file_path)[1]
        md_text = pymupdf4llm.to_markdown(file_path)
        new_doc = Document(
            content=md_text,
            id=self.file_id_counter,
            fileName=file_name,
            fileType=file_extension
        )
        documents.append(new_doc)
        self.file_id_counter += 1

        doc = fitz.open(file_path)
        images = []
        for page in doc:
            images.extend(page.get_images())
        
        for idx, image in enumerate(images):
            image_path = doc.extract_image(image[0])
            image_bytes = image_path["image"]
            image_name = f"{file_name_without_extension}_{idx}.png"
            image_path = os.path.join(self.parser_assets_dir, image_name)
            with open(image_path, "wb") as f:
                f.write(image_bytes)
            
            image_doc = Document(
                content=image_path,
                id=self.file_id_counter,
                fileName=image_name,
                fileType="image/png"
            )
            documents.append(image_doc)
            self.file_id_counter += 1

        return documents

    def _parse_txt(self, file_path: str) -> list[Document]:
        documents = []
        file_name = os.path.basename(file_path)
        file_extension = os.path.splitext(file_path)[1]
        with open(file_path, "r") as file:
            content = file.read()
        new_doc = Document(
            content=content,
            id=self.file_id_counter,
            fileName=file_name,
            fileType=file_extension
        )
        documents.append(new_doc)
        self.file_id_counter += 1
        return documents

    def parse(self) -> list[Document]:
        documents = []
        for f in self.files:
            file_path = self._copy_file_to_parser_assets(f)
            file_extension = os.path.splitext(file_path)[1]
            if file_extension == ".pdf":
                documents.extend(self._parse_pdf(file_path))
            elif file_extension == ".txt":
                documents.extend(self._parse_txt(file_path))
            else:
                raise ValueError(f"Unsupported file type: {file_extension}")

        return documents
    
if __name__ == "__main__":
    parser = MuPDFParser()
    parser.consider_directory("assets")

    documents = parser.parse()
    for d in documents:
        print(d)
        print("-"*100)