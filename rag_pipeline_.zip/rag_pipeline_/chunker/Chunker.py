from abc import ABC, abstractmethod
from dataclasses import dataclass
from parser.Parser import Document

@dataclass
class Chunk:
    """
    Chunk class for storing chunk data.
    """
    content: str
    id: int
    fileName: str
    fileType: str
    doc_id: int
    full_doc_content: str


class Chunker(ABC):
    """
    Abstract class for chunking documents.
    """
    @abstractmethod
    def __init__(self, documents: list[Document], chunk_size: int, chunk_overlap: int):
        pass

    @abstractmethod
    def get_chunks(self) -> list[Chunk]:
        pass
    