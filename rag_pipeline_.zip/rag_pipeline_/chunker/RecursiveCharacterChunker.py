from langchain_text_splitters import RecursiveCharacterTextSplitter
from parser.MuPDFParser import MuPDFParser
from .Chunker import Chunker, Chunk
from parser.Parser import Document

class RecursiveCharacterChunker(Chunker):
    """
    Chunker that splits documents into chunks of a given size.
    """
    def __init__(self, documents: list[Document], chunk_size: int, chunk_overlap: int):
        self.documents = documents
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def get_chunks(self) -> list[Chunk]:
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=self.chunk_size, chunk_overlap=self.chunk_overlap)
        chunk_idx = 0

        final_chunks = []
        for doc in self.documents:
            new_chunks = [Chunk(
                content=chunk, 
                id=chunk_idx+idx, 
                fileName=doc.fileName, 
                fileType=doc.fileType, 
                doc_id=doc.id,
                full_doc_content=doc.content
                ) 
                for idx, chunk in enumerate(text_splitter.split_text(doc.content))
            ]
            final_chunks.extend(new_chunks)
            chunk_idx += len(new_chunks)
        
        return final_chunks


if __name__ == "__main__":
    parser = MuPDFParser()
    parser.consider_directory("assets")

    documents = parser.parse()
    chunker = RecursiveCharacterChunker(documents, 100, 20)
    chunks = chunker.get_chunks()
    for idx, chunk in enumerate(chunks):
        print(f"Chunk {idx}: {chunk}")
        print("-"*100)