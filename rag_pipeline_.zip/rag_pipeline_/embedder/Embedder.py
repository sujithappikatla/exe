from abc import ABC, abstractmethod
from chunker.Chunker import Chunk

class Embedder(ABC):
    @abstractmethod
    def create_collection(self, collection_name: str):
        pass

    @abstractmethod
    def insert_chunks(self, chunks: list[Chunk]) -> bool:
        pass

    @abstractmethod
    def get_similar_chunks(self, query: str, k: int) -> list[Chunk]:
        pass
